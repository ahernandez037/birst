import {Store} from "@ngrx/store";
import {Injectable} from "@angular/core";
import {AppState} from "../models/app-state";
import {ElectronService} from "./electron.service";
import {IpcMessage} from "../../backend/ipc-handlers";
import {ConsoleMessage} from "../models/console-message";
import * as fromAppState from "../store/app-state.actions";

@Injectable({
	providedIn: "root"
})
export class AppStateService {
	constructor(
		private _electronService: ElectronService,
		private _store: Store<{ appState: AppState }>
	) {
		this._electronService.on(IpcMessage.UpdateAppVersion, (payload) => {
			this._store.dispatch(fromAppState.updateAppVersion({appVersion: payload[0]}));
		});

		this._electronService.on(IpcMessage.UpdateIsAppReady, (payload) => {
			this._store.dispatch(fromAppState.updateIsAppReady({isAppReady: payload[0]}));
			this._store.dispatch(fromAppState.updateSnowflakeSessionId({snowflakeSessionId: payload[1]}));
		});

		this._electronService.on(IpcMessage.GetScenarioId, (payload) => {
			this._store.dispatch(fromAppState.updateScenarioId({scenarioId: payload[0]}));
		});

		this._electronService.on(IpcMessage.UpdateUser, (payload) => {
			this._store.dispatch(fromAppState.updateUser({user: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.UpdateUserSettings, (payload) => {
			this._store.dispatch(fromAppState.updateUserSettings({userSettings: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.UpdateGeoStates, (payload) => {
			this._store.dispatch(fromAppState.updateGeoStates({geoStates: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.UpdateWorkCompBureauRates, (payload) => {
			this._store.dispatch(fromAppState.updateWorkCompBureauRates({workCompBureauRates: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.UpdateProducts, (payload) => {
			this._store.dispatch(fromAppState.updateProducts({products: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.UpdateReleaseNotes, (payload) => {
			this._store.dispatch(fromAppState.updateReleaseNotes({releaseNotes: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.UpdateAvailableDates, (payload) => {
			this._store.dispatch(fromAppState.updateAvailableDates({availableDates: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.AddConsoleMessage, (payload) => {
			this._store.dispatch(fromAppState.addConsoleMessage({consoleMessages: [new ConsoleMessage(JSON.parse(payload))]}));
		});

		this._electronService.on(IpcMessage.StopConsoleMessageTimer, (payload) => {
			this._store.dispatch(fromAppState.stopConsoleMessageTimer({timerId: payload[0]}));
		});
	}
}
