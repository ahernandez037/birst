import {Store} from "@ngrx/store";
import {Inject} from "@angular/core";
import {Injectable} from "@angular/core";
import {DOCUMENT} from "@angular/common";
import {AppState} from "../models/app-state";
import {updateColorTheme} from "../store/app-state.actions";

@Injectable({
	providedIn: "root"
})
export class ColorThemeService {
	private static readonly DARK_THEME_CLASS = "dark-theme";

	constructor(
		@Inject(DOCUMENT) private _document: Document,
		private _store: Store<{ appState: AppState }>
	) {}

	selectLightTheme(): void {
		this._document.documentElement.classList.remove(ColorThemeService.DARK_THEME_CLASS);
		this._store.dispatch(updateColorTheme({colorTheme: "light"}));
	}

	selectDarkTheme(): void {
		this._document.documentElement.classList.add(ColorThemeService.DARK_THEME_CLASS);
		this._store.dispatch(updateColorTheme({colorTheme: "dark"}));
	}
}
