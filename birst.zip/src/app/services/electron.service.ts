import {Injectable, NgZone} from "@angular/core";

@Injectable({
	providedIn: "root"
})
export class ElectronService {
	// Exposed to the global window object through Electron's preload script.
	private _ipcRenderer = window.require("electron").ipcRenderer;

	constructor(private _ngZone: NgZone) {}

	on(channel: string, listener: (...args: any[]) => void): void {
		this._ipcRenderer.on(channel, (_event, ...args: any[]) => {
			// Must use NgZone due to Electron IPC messages occur outside the
			// Angular zone, meaning that when they are processed, Angular is
			// not immediately aware therefore it will not run change detection,
			// which causes the UI to not update. By calling the listener within
			// the NgZone.run() method, we ensure that Angular immediately
			// detects changes and updates the UI.
			this._ngZone.run(() => {
				listener(args);
			});
		});
	}

	send(channel: string, ...args: any[]): void {
		this._ipcRenderer.send(channel, args);
	}

	sendSync(channel: string, ...args: any[]): any {
		this._ipcRenderer.sendSync(channel, args);
	}

	async invoke(channel: string, ...args: any[]): Promise<any> {
		return await this._ipcRenderer.invoke(channel, args);
	}
}
