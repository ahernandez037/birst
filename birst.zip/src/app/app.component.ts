import {Store} from "@ngrx/store";
import {Observable, Subscription} from "rxjs";
import {Component, OnInit, OnDestroy} from "@angular/core";
import {AppState} from "./models/app-state";
import {IpcMessage} from "src/backend/ipc-handlers";
import {UserSettings} from "src/backend/user-settings";
import * as fromAppState from "./store/app-state.selectors";
import {ElectronService} from "./services/electron.service";
import {AppStateService} from "./services/app-state.service";
import {ColorThemeService} from "./services/color-theme.service";
import {updateMaintenanceSettings, updateSettingsFile, updateTestSuites} from "./store/app-state.actions";

@Component({
	selector: "app-root",
	templateUrl: "./app.component.html",
	styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit, OnDestroy {
	isAppReady$: Observable<boolean>;
	isFirstTimeSetup$: Observable<boolean>;
	userSettings$: Observable<UserSettings>;
	isDeveloper$: Observable<boolean>;
	isConsoleVisible = false;
	private _userSettingsSubscription: Subscription;

	constructor(
		// Inject AppStateService to initialize Electron IPC listeners.
		// @ts-ignore declared but its value is never read.
		private _appStateService: AppStateService,
		private _store: Store<{ appState: AppState }>,
		private _colorTheme: ColorThemeService,
		private _electronService: ElectronService
	) {}

	ngOnInit() {
		this.isAppReady$ = this._store.select(fromAppState.selectIsAppReady);
		this.isFirstTimeSetup$ = this._store.select(fromAppState.selectIsFirstTimeSetup);
		this.userSettings$ = this._store.select(fromAppState.selectUserSettings);
		this.isDeveloper$ = this._store.select(fromAppState.selectIsDeveloper);

		this._userSettingsSubscription = this.userSettings$.subscribe((userSettings) => {
			userSettings.isDarkMode
				? this._colorTheme.selectDarkTheme()
				: this._colorTheme.selectLightTheme();

			userSettings.isConsoleShownOnStartup
				? (this.isConsoleVisible = true)
				: (this.isConsoleVisible = false);
		});

		this.initIpcListeners();
	}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.GetTestSuites, (payload) => {
			this._store.dispatch(updateTestSuites({testSuites: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.GetMaintenanceSettings, (payload) => {
			this._store.dispatch(updateMaintenanceSettings({maintenanceSettings: JSON.parse(payload)}));
		});

		this._electronService.on(IpcMessage.UpdateUserSettingsFile, (payload) => {
			this._store.dispatch(updateSettingsFile({settingsFile: payload[0]}));
		});
	}

	ngOnDestroy(): void {
		this._userSettingsSubscription.unsubscribe();
	}

	hideConsole(): void {
		this.isConsoleVisible = false;
		this._electronService.send(IpcMessage.HideConsole);
	}

	showConsole(): void {
		this.isConsoleVisible = true;
		this._electronService.send(IpcMessage.ShowConsole);
	}
}
