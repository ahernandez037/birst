import {Component, Input, WritableSignal} from "@angular/core";
import {ImportantMessage} from "src/backend/monitor";

@Component({
	selector: "app-important-messages",
	templateUrl: "./important-messages.component.html",
	styleUrls: ["./important-messages.component.scss"]
})
export class ImportantMessagesComponent {
	@Input() importantLogMessages: WritableSignal<ImportantMessage[]>;
	importantLogMessagesColumns = ["timestamp", "type", "userId", "scenarioId", "payload"];
}
