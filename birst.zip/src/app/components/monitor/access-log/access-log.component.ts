import {Component, Input, WritableSignal} from "@angular/core";
import {AccessLog} from "src/backend/monitor";

@Component({
	selector: "app-access-log",
	templateUrl: "./access-log.component.html",
	styleUrls: ["./access-log.component.scss"]
})
export class AccessLogComponent {
	@Input() accessLog: WritableSignal<AccessLog[]>;
	accessLogColumns = ["rowNumber", "userId", "lastAccessed", "appVersion"];
}
