import {Store} from "@ngrx/store";
import {ThemeOption} from "ngx-echarts";
import type {ECharts, EChartsOption} from "echarts";
import {Observable, Subscription, Subject} from "rxjs";
import {Component, OnInit, OnDestroy, OnChanges, Input, SimpleChanges} from "@angular/core";
import {AppState} from "src/app/models/app-state";
import {Runtime, ScenarioRun, SumOfScenarioRunsByDate} from "src/backend/monitor";
import {
	selectMonitorAverageRuntimes,
	selectMonitorScenarioRuns
} from "src/app/store/app-state.selectors";

const averageRuntimesColors = ["#5470C6", "#91CC75", "#EE6666"];

@Component({
	selector: "app-statistics",
	templateUrl: "./statistics.component.html",
	styleUrls: ["./statistics.component.scss"]
})
export class StatisticsComponent implements OnInit, OnDestroy, OnChanges {
	@Input() isFetchingData: boolean;
	@Input() areDevelopersIncluded = false;
	@Input() eChartTheme: string | ThemeOption;
	@Input() developers: string[];
	chart: string = "Daily Scenario Runs";
	charts: string[] = ["Daily Scenario Runs", "Rate Change Scenarios"];
	isFetchingData$ = new Subject<boolean>();
	dailyScenarioRunsChartInstance: ECharts;

	dailyScenarioRunsOptions: EChartsOption = {
		title: {
			left: "center",
			top: 10,
			text: "Daily Scenario Runs (Rolling 30 Working Days)",
			textStyle: {
				fontSize: 14
			}
		},
		legend: {},
		tooltip: {
			trigger: "axis",
			axisPointer: {
				type: "shadow"
			}
		},
		grid: {
			bottom: 30
		},
		xAxis: {
			type: "category",
			data: []
		},
		yAxis: {
			type: "value"
		},
		series: [
			{
				data: [],
				type: "line"
			}
		]
	};

	averageRuntimesChartInstance: ECharts;

	averageRuntimesOptions: EChartsOption = {
		color: averageRuntimesColors,
		title: {
			left: "center",
			top: 10,
			text: "Rate Change Scenarios",
			textStyle: {
				fontSize: 14
			}
		},
		tooltip: {
			trigger: "axis",
			axisPointer: {
				type: "shadow"
			}
		},
		legend: {
			bottom: 5,
			selected: {
				"Average runtime (minutes)": true,
				"Average record count": true,
				"Total number of runs": true
			}
		},
		grid: {
			right: "20%",
			bottom: 55
		},
		xAxis: [
			{
				type: "category",
				axisTick: {
					alignWithLabel: true
				},
				data: []
			}
		],
		yAxis: [
			{
				type: "value",
				name: "Runtime",
				position: "right",
				alignTicks: true,
				axisLine: {
					show: true,
					lineStyle: {
						color: averageRuntimesColors[0]
					}
				},
				axisLabel: {
					formatter: "{value} min"
				}
			},
			{
				type: "value",
				name: "Runs",
				position: "right",
				alignTicks: true,
				offset: 80,
				axisLine: {
					show: true,
					lineStyle: {
						color: averageRuntimesColors[1]
					}
				},
				axisLabel: {
					formatter: "{value}"
				}
			},
			{
				type: "value",
				name: "Records",
				position: "left",
				alignTicks: true,
				axisLine: {
					show: true,
					lineStyle: {
						color: averageRuntimesColors[2]
					}
				},
				axisLabel: {
					formatter: "{value}"
				}
			}
		],
		series: [
			{
				name: "Average runtime (minutes)",
				type: "bar",
				data: []
			},
			{
				name: "Total number of runs",
				type: "bar",
				yAxisIndex: 1,
				data: []
			},
			{
				name: "Average record count",
				type: "line",
				yAxisIndex: 2,
				data: []
			}
		]
	};

	scenarioRuns$: Observable<ScenarioRun[]>;
	scenarioRunsSubscription: Subscription;
	scenarioRuns: ScenarioRun[] = [];
	sumOfScenarioRunsByDate: SumOfScenarioRunsByDate[] = [];
	minDailyScenarioRuns = 0;
	maxDailyScenarioRuns = 0;
	avgDailyScenarioRuns = 0;
	averageRuntimes$: Observable<Runtime[]>;
	averageRuntimesSubscription: Subscription;

	constructor(private _store: Store<{ appState: AppState }>) {
		this.scenarioRuns$ = this._store.select(selectMonitorScenarioRuns);
		this.averageRuntimes$ = this._store.select(selectMonitorAverageRuntimes);
	}

	ngOnInit(): void {}

	ngOnChanges(changes: SimpleChanges): void {
		this.updateSumOfScenarioRunsByDate();
		this.isFetchingData$.next(changes["isFetchingData"]?.currentValue || false);
	}

	ngOnDestroy(): void {
		this.scenarioRunsSubscription.unsubscribe();
		this.averageRuntimesSubscription.unsubscribe();
		this.isFetchingData$.unsubscribe();
	}

	onChartInitDailyScenarioRuns(event: ECharts) {
		this.dailyScenarioRunsChartInstance = event;

		this.scenarioRunsSubscription = this.scenarioRuns$.subscribe((value) => {
			this.scenarioRuns = value;
			this.updateSumOfScenarioRunsByDate();
		});
	}

	onChartInitAverageRuntimes(event: ECharts) {
		this.averageRuntimesChartInstance = event;

		this.averageRuntimesSubscription = this.averageRuntimes$.subscribe((value) => {
			this.averageRuntimesOptions.xAxis = [
				{
					type: "category",
					axisTick: {
						alignWithLabel: true
					},
					data: value.map((el) => el.product)
				}
			];

			this.averageRuntimesOptions.series = [
				{
					name: "Average runtime (minutes)",
					type: "bar",
					data: value.map((el) => (el.averageRuntimeInSeconds / 60).toFixed(2))
				},
				{
					name: "Total number of runs",
					type: "bar",
					yAxisIndex: 1,
					data: value.map((el) => el.numberOfRuns)
				},
				{
					name: "Average record count",
					type: "line",
					yAxisIndex: 2,
					data: value.map((el) => el.averageRecordCount)
				}
			];

			this.averageRuntimesChartInstance.setOption(this.averageRuntimesOptions);
		});
	}

	updateSumOfScenarioRunsByDate(): void {
		// Create set of unique dates
		const dates = new Set<string>();

		for (const scenarioRun of this.scenarioRuns) {
			dates.add(scenarioRun.date);
		}

		// Loop through scenario runs and sum by date
		const sumOfScenarioRunsByDate: SumOfScenarioRunsByDate[] = [];

		for (const date of dates) {
			const scenarioRunsByDate: SumOfScenarioRunsByDate = {
				date: date,
				numberOfRuns: 0
			};

			for (const scenarioRun of this.scenarioRuns) {
				// Skip developers depending on UI toggle
				if (
					!this.areDevelopersIncluded &&
					this.developers.includes(scenarioRun.userId.toUpperCase())
				) {
					continue;
				}

				if (scenarioRun.date === date) {
					scenarioRunsByDate.numberOfRuns += scenarioRun.numberOfRuns;
				}
			}

			sumOfScenarioRunsByDate.push(scenarioRunsByDate);
		}

		this.sumOfScenarioRunsByDate = sumOfScenarioRunsByDate;

		if (this.dailyScenarioRunsChartInstance) {
			this.dailyScenarioRunsOptions.xAxis = {
				type: "category",
				data: this.sumOfScenarioRunsByDate.map((el) => el.date)
			};

			this.dailyScenarioRunsOptions.series = [
				{
					type: "line",
					data: this.sumOfScenarioRunsByDate.map((el) => el.numberOfRuns)
				}
			];

			this.dailyScenarioRunsChartInstance.setOption(this.dailyScenarioRunsOptions);
		}

		this.minDailyScenarioRuns = Math.min(
			0,
			...this.sumOfScenarioRunsByDate.map((el) => el.numberOfRuns)
		);

		this.maxDailyScenarioRuns = Math.max(
			0,
			...this.sumOfScenarioRunsByDate.map((el) => el.numberOfRuns)
		);

		this.avgDailyScenarioRuns =
			this.sumOfScenarioRunsByDate.map((el) => el.numberOfRuns).reduce((a, b) => a + b, 0) /
				this.sumOfScenarioRunsByDate.length || 0;
	}
}
