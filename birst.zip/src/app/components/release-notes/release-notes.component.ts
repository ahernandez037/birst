import {DateTime} from "luxon";
import {Store} from "@ngrx/store";
import {Observable, of, Subscription} from "rxjs";
import {Component, OnInit, OnDestroy} from "@angular/core";
import {Release} from "../../models/release";
import {AppState} from "../../models/app-state";
import {selectReleaseNotes} from "../../store/app-state.selectors";
import {ReleaseNote, ReleaseNoteType} from "src/backend/release-notes";

@Component({
	selector: "app-release-notes",
	templateUrl: "./release-notes.component.html",
	styleUrls: ["./release-notes.component.scss"]
})
export class ReleaseNotesComponent implements OnInit, OnDestroy {
	releases: Release[];
	releases$: Observable<Release[]>;
	releaseNotes$: Observable<ReleaseNote[]>;
	private _releaseNotesSubscription: Subscription;
	constructor(private _store: Store<{ appState: AppState }>) {}

	ngOnInit(): void {
		this.releases = [];
		this.releases$ = of(this.releases);
		this.releaseNotes$ = this._store.select(selectReleaseNotes);

		this._releaseNotesSubscription = this.releaseNotes$.subscribe((releaseNotes) => {
			const versions = new Set<string>();

			for (const releaseNote of releaseNotes) {
				versions.add(releaseNote.fullVersion);
			}

			Array.from(versions)
				.sort(this._compareSemanticVersions)
				.reverse()
				.forEach((version) => {
					const releaseDate = DateTime.fromFormat(this._getReleaseDate(releaseNotes, version), "yyyy-MM-dd").toFormat("DDD");
					const announcements = this._getNotesByType(releaseNotes, version, "ANNOUNCEMENT");
					const newFeatures = this._getNotesByType(releaseNotes, version, "NEW-FEATURE");
					const enhancements = this._getNotesByType(releaseNotes, version, "ENHANCEMENT");
					const bugFixes = this._getNotesByType(releaseNotes, version, "BUG-FIX");

					this.releases.push({
						dateAndVersion: `${releaseDate} (v${version})`,
						announcements: announcements.map((release) => release.description),
						newFeatures: newFeatures.map((release) => release.description),
						enhancements: enhancements.map((release) => release.description),
						bugFixes: bugFixes.map((release) => release.description)
					});
				});
		});
	}

	ngOnDestroy(): void {
		this._releaseNotesSubscription.unsubscribe();
	}

	private _compareSemanticVersions(versionA: string, versionB: string): number {
		// Split strings into array containing individual version parts.
		const aVersionParts = versionA.split(".");
		const bVersionParts = versionB.split(".");
		// Contingency in case there's a 4th or 5th version.
		const numberOfParts = Math.min(aVersionParts.length, bVersionParts.length);

		// Look through each version part, i.e., major, minor, patch, and compare.
		for (let i = 0; i < numberOfParts; i++) {
			const aVersionPart = Number(aVersionParts[i]) || 0;
			const bVersionPart = Number(bVersionParts[i]) || 0;

			if (aVersionPart !== bVersionPart) {
				return aVersionPart > bVersionPart ? 1 : -1;
			}
		}

		// Output if the all checked version parts are equal.
		return bVersionParts.length - aVersionParts.length;
	}

	private _getReleaseDate(releaseNotes: ReleaseNote[], version: string): string {
		const releaseDate = releaseNotes.find((releaseNote) => releaseNote.fullVersion === version)?.releaseDate;

		if (releaseDate) {
			return String(releaseDate);
		} else {
			return "1970-01-01";
		}
	}

	private _getNotesByType(
		releaseNotes: ReleaseNote[],
		version: string,
		releaseNoteType: ReleaseNoteType
	): ReleaseNote[] {
		return releaseNotes.filter(
			(releaseNote) =>
				releaseNote.fullVersion === version && releaseNote.category === releaseNoteType
		);
	}
}
