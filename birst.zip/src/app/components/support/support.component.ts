import {Store} from "@ngrx/store";
import {Observable, Subscription} from "rxjs";
import {MatSnackBar} from "@angular/material/snack-bar";
import {Component, OnInit, OnDestroy} from "@angular/core";
import {AppState} from "src/app/models/app-state";
import {ScenarioForm} from "src/backend/scenario";
import {IpcMessage} from "src/backend/ipc-handlers";
import {MaintenanceSettings} from "src/backend/app-settings";
import {ElectronService} from "src/app/services/electron.service";
import * as fromAppStateSelector from "src/app/store/app-state.selectors";

@Component({
	selector: "app-support",
	templateUrl: "./support.component.html",
	styleUrls: ["./support.component.scss"]
})
export class SupportComponent implements OnInit, OnDestroy {
	maintenanceSettings$: Observable<MaintenanceSettings>;
	isFirstTimeSetup$: Observable<boolean>;
	appVersion$: Observable<string>;
	snowflakeSessionId$: Observable<string>;
	isDeveloper$: Observable<boolean>;
	scenarioForm$: Observable<ScenarioForm>;
	scenarioForm: ScenarioForm;
	private _scenarioFormSubscription: Subscription;

	constructor(
		private _store: Store<{ appState: AppState }>,
		private _electronService: ElectronService,
		private _matSnackBar: MatSnackBar
	) {}

	ngOnInit(): void {
		this.maintenanceSettings$ = this._store.select(fromAppStateSelector.selectMaintenanceSettings);
		this.isFirstTimeSetup$ = this._store.select(fromAppStateSelector.selectIsFirstTimeSetup);
		this.appVersion$ = this._store.select(fromAppStateSelector.selectAppVersion);
		this.snowflakeSessionId$ = this._store.select(fromAppStateSelector.selectSnowflakeSessionId);
		this.isDeveloper$ = this._store.select(fromAppStateSelector.selectIsDeveloper);
		this.scenarioForm$ = this._store.select(fromAppStateSelector.selectScenarioForm);
		this.scenarioForm = {} as ScenarioForm;

		this._scenarioFormSubscription = this.scenarioForm$.subscribe((value) => {
			this.scenarioForm = value;
		});
	}

	ngOnDestroy(): void {
		this._scenarioFormSubscription.unsubscribe();
	}

	openUsersGuide(): void {
		this._matSnackBar.open("Opening user's guide...", undefined, {
			duration: 5000,
			horizontalPosition: "center",
			verticalPosition: "bottom"
		});

		this._electronService.send(
			IpcMessage.OpenUrl,
			"//hm2ntfs01/xacm632$/Tools_Team/birst/docs/users-guide/site/index.html"
		);
	}

	openTechnicalDocumentation(): void {
		this._matSnackBar.open("Opening technical documentation...", undefined, {
			duration: 5000,
			horizontalPosition: "center",
			verticalPosition: "bottom"
		});

		this._electronService.send(
			IpcMessage.OpenUrl,
			"https://pages.git.farmersinsurance.com/a-hernandez/birst/"
		);
	}

	reportProblem(): void {
		this._matSnackBar.open("Creating new email...", undefined, {
			duration: 5000,
			horizontalPosition: "center",
			verticalPosition: "bottom"
		});

		this._electronService.send(
			IpcMessage.CreateEmailReportProblem,
			JSON.stringify(this.scenarioForm)
		);
	}

	submitFeedback(): void {
		this._matSnackBar.open("Creating new email...", undefined, {
			duration: 5000,
			horizontalPosition: "center",
			verticalPosition: "bottom"
		});

		this._electronService.send(IpcMessage.CreateEmailSubmitFeedback);
	}
}
