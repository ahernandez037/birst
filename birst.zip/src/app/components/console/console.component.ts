import {Store} from "@ngrx/store";
import {Observable} from "rxjs";
import {Component, OnInit, OnDestroy} from "@angular/core";
import {AppState} from "src/app/models/app-state";
import {ConsoleMessage} from "src/app/models/console-message";
import {
	selectConsoleMessages,
	selectIsUsingDevelopmentDatabaseSchemas
} from "src/app/store/app-state.selectors";

@Component({
	selector: "app-console",
	templateUrl: "./console.component.html",
	styleUrls: ["./console.component.scss"]
})
export class ConsoleComponent implements OnInit, OnDestroy {
	consoleMessages$: Observable<ConsoleMessage[]>;
	isUsingDevelopmentDatabaseSchemas$: Observable<boolean>;

	constructor(private _store: Store<{ appState: AppState }>) {}

	ngOnInit(): void {
		this.consoleMessages$ = this._store.select(selectConsoleMessages);
		this.isUsingDevelopmentDatabaseSchemas$ = this._store.select(
			selectIsUsingDevelopmentDatabaseSchemas
		);
	}

	ngOnDestroy(): void {}
}
