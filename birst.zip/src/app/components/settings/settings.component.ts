import {Store} from "@ngrx/store";
import {Observable, Subscription} from "rxjs";
import {Component, OnInit, OnDestroy} from "@angular/core";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {AppState} from "../../models/app-state";
import {UserSettings} from "src/backend/user-settings";
import * as fromAppState from "../../store/app-state.selectors";
import {SettingsFormGroup} from "src/app/models/settings-form-group";
import {ColorThemeService} from "../../services/color-theme.service";
import {BrowseDirectoryButton} from "src/app/models/browse-directory-button";
import {updateIsUsingDevelopmentDatabaseSchemas} from "src/app/store/app-state.actions";

@Component({
	selector: "app-settings",
	templateUrl: "./settings.component.html",
	styleUrls: ["./settings.component.scss"]
})
export class SettingsComponent implements OnInit, OnDestroy {
	userSettings$: Observable<UserSettings>;
	isDeveloper$: Observable<boolean>;
	settingsForm: FormGroup<SettingsFormGroup>;
	browseDirectoryButtons: BrowseDirectoryButton[];
	private _userSettingsSubscription: Subscription;
	private _isUsingDevelopmentDatabaseSchemasSubscription: Subscription;

	constructor(
		private _store: Store<{ appState: AppState }>,
		private _formBuilder: FormBuilder,
		public colorTheme: ColorThemeService
	) {}

	ngOnInit() {
		this.userSettings$ = this._store.select(fromAppState.selectUserSettings);
		this.isDeveloper$ = this._store.select(fromAppState.selectIsDeveloper);

		this.settingsForm = this._formBuilder.nonNullable.group({
			userSettingsVersion: [0],
			isResetRequired: [false],
			emailAddress: ["", [Validators.required, Validators.email]],
			defaultScenarioDirectory: ["", Validators.required],
			appSettingsDirectory: ["", Validators.required],
			excelTemplatesDirectory: ["", Validators.required],
			emailFunctionsDirectory: ["", Validators.required],
			nextStepsFunctionsDirectory: ["", Validators.required],
			sqlFunctionsDirectory: ["", Validators.required],
			ratesFileIgnoredFieldsDirectory: ["", Validators.required],
			ratesFileOrderByDirectory: ["", Validators.required],
			ratesFileRateFieldsDirectory: ["", Validators.required],
			testSuitesDirectory: ["", Validators.required],
			snowparkDirectory: ["", Validators.required],
			isDarkMode: [false, Validators.required],
			isConsoleShownOnStartup: [true, Validators.required],
			isDynamicJsPrinted: [false, Validators.required],
			isMonitorNotificationOn: [true, Validators.required],
			isUsingDevelopmentDatabaseSchemas: [true, Validators.required]
		});

		this.browseDirectoryButtons = [
			{
				formControlName: "defaultScenarioDirectory",
				isLoading: false
			},
			{
				formControlName: "appSettingsDirectory",
				isLoading: false
			},
			{
				formControlName: "excelTemplatesDirectory",
				isLoading: false
			},
			{
				formControlName: "emailFunctionsDirectory",
				isLoading: false
			},
			{
				formControlName: "nextStepsFunctionsDirectory",
				isLoading: false
			},
			{
				formControlName: "sqlFunctionsDirectory",
				isLoading: false
			},
			{
				formControlName: "ratesFileIgnoredFieldsDirectory",
				isLoading: false
			},
			{
				formControlName: "ratesFileOrderByDirectory",
				isLoading: false
			},
			{
				formControlName: "ratesFileRateFieldsDirectory",
				isLoading: false
			},
			{
				formControlName: "testSuitesDirectory",
				isLoading: false
			},
			{
				formControlName: "snowparkDirectory",
				isLoading: false
			}
		];

		this._isUsingDevelopmentDatabaseSchemasSubscription =
			this.settingsForm.controls.isUsingDevelopmentDatabaseSchemas.valueChanges.subscribe(
				(value) => {
					this._store.dispatch(updateIsUsingDevelopmentDatabaseSchemas({isUsingDevelopmentDatabaseSchemas: value}));
				}
			);

		this._userSettingsSubscription = this.userSettings$.subscribe((userSettings) => {
			this.settingsForm.setValue({
				userSettingsVersion: userSettings.userSettingsVersion,
				isResetRequired: userSettings.isResetRequired,
				emailAddress: userSettings.emailAddress,
				defaultScenarioDirectory: userSettings.defaultScenarioDirectory,
				appSettingsDirectory: userSettings.appSettingsDirectory,
				excelTemplatesDirectory: userSettings.excelTemplatesDirectory,
				emailFunctionsDirectory: userSettings.emailFunctionsDirectory,
				nextStepsFunctionsDirectory: userSettings.nextStepsFunctionsDirectory,
				sqlFunctionsDirectory: userSettings.sqlFunctionsDirectory,
				ratesFileIgnoredFieldsDirectory: userSettings.ratesFileIgnoredFieldsDirectory,
				ratesFileOrderByDirectory: userSettings.ratesFileOrderByDirectory,
				ratesFileRateFieldsDirectory: userSettings.ratesFileRateFieldsDirectory,
				testSuitesDirectory: userSettings.testSuitesDirectory,
				snowparkDirectory: userSettings.snowparkDirectory,
				isDarkMode: userSettings.isDarkMode,
				isConsoleShownOnStartup: userSettings.isConsoleShownOnStartup,
				isDynamicJsPrinted: userSettings.isDynamicJsPrinted,
				isMonitorNotificationOn: userSettings.isMonitorNotificationOn,
				isUsingDevelopmentDatabaseSchemas: userSettings.isUsingDevelopmentDatabaseSchemas
			});

			this.settingsForm.updateValueAndValidity();
		});
	}

	ngOnDestroy(): void {
		this._userSettingsSubscription.unsubscribe();
		this._isUsingDevelopmentDatabaseSchemasSubscription.unsubscribe();
	}
}
