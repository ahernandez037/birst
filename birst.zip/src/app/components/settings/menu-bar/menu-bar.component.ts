import {Store} from "@ngrx/store";
import {Observable, Subscription} from "rxjs";
import {MatSnackBar} from "@angular/material/snack-bar";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {AppState} from "src/app/models/app-state";
import {IpcMessage} from "src/backend/ipc-handlers";
import {MaintenanceSettings} from "src/backend/app-settings";
import {ElectronService} from "src/app/services/electron.service";
import {SettingsFormGroup} from "src/app/models/settings-form-group";
import {selectMaintenanceSettings, selectSettingsFile} from "src/app/store/app-state.selectors";
import {updateSettingsFile} from "src/app/store/app-state.actions";

@Component({
	selector: "app-settings-menu-bar",
	templateUrl: "./menu-bar.component.html",
	styleUrls: ["./menu-bar.component.scss"]
})
export class MenuBarComponent implements OnInit, OnDestroy {
	@Input() isDeveloper$: Observable<boolean>;
	maintenanceSettings$: Observable<MaintenanceSettings>;
	settingsFile$: Observable<"prod" | "dev">;
	settingsFileSubscription: Subscription;
	formGroup: FormGroup<SettingsFormGroup>;
	private _settingsFile: "prod" | "dev";

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
		private _snackBar: MatSnackBar,
		private _store: Store<{ appState: AppState }>
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;

		this.initIpcListeners();

		this.maintenanceSettings$ = this._store.select(selectMaintenanceSettings);
		this.settingsFile$ = this._store.select(selectSettingsFile);

		this.settingsFileSubscription = this.settingsFile$.subscribe((value)=> {
			if (value === "prod") {
				this._settingsFile = "prod";
			} else {
				this._settingsFile = "dev";
			}
		});
	}

	ngOnDestroy(): void {
		this.settingsFileSubscription.unsubscribe();
	}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.SaveUserSettingsSuccess, () => {
			this._snackBar.open("Settings saved successfully.", undefined, {
				duration: 2500,
				horizontalPosition: "center",
				verticalPosition: "bottom"
			});
		});
	}

	saveSettings(): void {
		this._electronService.send(
			IpcMessage.SaveUserSettings,
			JSON.stringify(this.formGroup.value),
			this._settingsFile
		);

		if (this.formGroup.controls.isConsoleShownOnStartup.value) {
			this._electronService.send(IpcMessage.ShowConsole);
		} else {
			this._electronService.send(IpcMessage.HideConsole);
		}
	}

	loadSettings(environment: "prod" | "dev"): void {
		this._store.dispatch(updateSettingsFile({settingsFile: environment}));
		this._electronService.send(IpcMessage.LoadUserSettings,	environment);
	}
}
