import {ComponentFixture, TestBed} from "@angular/core/testing";
import {SnowparkComponent} from "./snowpark.component";

describe("SnowparkComponent", () => {
	let component: SnowparkComponent;
	let fixture: ComponentFixture<SnowparkComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SnowparkComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(SnowparkComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
