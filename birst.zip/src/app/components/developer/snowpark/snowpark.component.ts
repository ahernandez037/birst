import {Component, OnInit, OnDestroy} from "@angular/core";
import {IpcMessage} from "src/backend/ipc-handlers";
import {ElectronService} from "src/app/services/electron.service";

@Component({
	selector: "app-snowpark",
	templateUrl: "./snowpark.component.html",
	styleUrls: ["./snowpark.component.scss"]
})
export class SnowparkComponent implements OnInit, OnDestroy {
	isBrowsingForFile: boolean;
	isDeployRunning: boolean;
	snowparkConfigFile: string;

	constructor(private _electronService: ElectronService) {}

	ngOnInit(): void {
		this.isBrowsingForFile = false;
		this.isDeployRunning = false;
		this.snowparkConfigFile = "";
		this.initIpcListeners();
	}

	ngOnDestroy(): void {}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.DoneDeployingSnowparkProcedure, () => {
			this.isDeployRunning = false;
		});
	}

	async browseConfigFile(): Promise<void> {
		this.isBrowsingForFile = true;
		this.snowparkConfigFile = await this._electronService.invoke(IpcMessage.GetSnowparkConfigFile);
		this.isBrowsingForFile = false;
	}

	deploySnowparkProcedure(): void {
		this.isDeployRunning = true;
		this._electronService.send(IpcMessage.DeploySnowparkProcedure, this.snowparkConfigFile);
	}
}
