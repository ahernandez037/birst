import {ComponentFixture, TestBed} from "@angular/core/testing";
import {AutomatedTestsComponent} from "./automated-tests.component";

describe("AutomatedTestsComponent", () => {
	let component: AutomatedTestsComponent;
	let fixture: ComponentFixture<AutomatedTestsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [AutomatedTestsComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(AutomatedTestsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
