import {ComponentFixture, TestBed} from "@angular/core/testing";
import {ScenarioDirectoryComponent} from "./scenario-directory.component";

describe("ScenarioDirectoryComponent", () => {
	let component: ScenarioDirectoryComponent;
	let fixture: ComponentFixture<ScenarioDirectoryComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [ScenarioDirectoryComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(ScenarioDirectoryComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
