import {Component, OnInit, Input, OnDestroy} from "@angular/core";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Observable} from "rxjs";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {ElectronService} from "src/app/services/electron.service";
import {IpcMessage} from "src/backend/ipc-handlers";
import {RateRevision} from "src/backend/rate-revision";
import {UserSettings} from "src/backend/user-settings";

@Component({
	selector: "app-scenario-directory",
	templateUrl: "./scenario-directory.component.html",
	styleUrls: ["./scenario-directory.component.scss"]
})
export class ScenarioDirectoryComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() userSettings$: Observable<UserSettings>;
	formGroup: FormGroup<ScenarioFormGroup>;
	isBrowseScenarioDirectoryLoading: boolean;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		this.isBrowseScenarioDirectoryLoading = false;
	}

	ngOnDestroy(): void {}

	async getScenarioDirectory(): Promise<void> {
		this.isBrowseScenarioDirectoryLoading = true;
		const directory = await this._electronService.invoke(IpcMessage.GetDirectory);

		if (directory) {
			this.formGroup.controls.scenarioDirectory.setValue(directory);
			this.formGroup.controls.scenarioDirectory.updateValueAndValidity();
		}

		this.isBrowseScenarioDirectoryLoading = false;
	}

	openScenarioDirectory(): void {
		this._electronService.send(
			IpcMessage.OpenUrl,
			this.formGroup.controls.scenarioDirectory.value ?? ""
		);
	}
}
