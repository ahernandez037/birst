import {ComponentFixture, TestBed} from "@angular/core/testing";
import {DataDumpTableComponent} from "./data-dump-table.component";

describe("DataDumpTableComponent", () => {
	let component: DataDumpTableComponent;
	let fixture: ComponentFixture<DataDumpTableComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [DataDumpTableComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(DataDumpTableComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
