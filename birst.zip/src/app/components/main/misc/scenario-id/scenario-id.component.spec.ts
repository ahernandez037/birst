import {ComponentFixture, TestBed} from "@angular/core/testing";
import {ScenarioIdComponent} from "./scenario-id.component";

describe("ScenarioIdComponent", () => {
	let component: ScenarioIdComponent;
	let fixture: ComponentFixture<ScenarioIdComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [ScenarioIdComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(ScenarioIdComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
