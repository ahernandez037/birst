import {ComponentFixture, TestBed} from "@angular/core/testing";
import {AllVersionsToggleComponent} from "./all-versions-toggle.component";

describe("AllVersionsToggleComponent", () => {
	let component: AllVersionsToggleComponent;
	let fixture: ComponentFixture<AllVersionsToggleComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [AllVersionsToggleComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(AllVersionsToggleComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
