import {Component, OnInit, Input, OnDestroy} from "@angular/core";
import {FormGroup, FormGroupDirective, Validators} from "@angular/forms";
import {Subscription} from "rxjs";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {toggleSaveDataDump} from "../../shared/data-dump";

@Component({
	selector: "app-fdrc-timestamp",
	templateUrl: "./fdrc-timestamp.component.html",
	styleUrls: ["./fdrc-timestamp.component.scss"]
})
export class FdrcTimestampComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;
	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		const fdrcTimestamp = this.formGroup.controls.fdrcTimestamp;

		this._subscription = this.formGroup.controls.dataSource.valueChanges.subscribe((value) => {
			if (value === "MRT" || value === "QAT") {
				fdrcTimestamp.setValidators([Validators.required]);
			} else {
				fdrcTimestamp.clearValidators();
				fdrcTimestamp.setValue("");
			}

			toggleSaveDataDump(this.formGroup);
		});
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}
}
