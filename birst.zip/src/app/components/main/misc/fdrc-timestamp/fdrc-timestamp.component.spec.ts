import {ComponentFixture, TestBed} from "@angular/core/testing";
import {FdrcTimestampComponent} from "./fdrc-timestamp.component";

describe("FdrcTimestampComponent", () => {
	let component: FdrcTimestampComponent;
	let fixture: ComponentFixture<FdrcTimestampComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [FdrcTimestampComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(FdrcTimestampComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
