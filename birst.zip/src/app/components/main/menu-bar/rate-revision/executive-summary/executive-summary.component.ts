import {Component, OnInit, OnDestroy, Inject} from "@angular/core";
import {MAT_DIALOG_DATA, MatDialog} from "@angular/material/dialog";
import {ExecutiveSummaryDialogData} from "src/app/models/executive-summary-dialog-data";
import {InScopeTablesComponent} from "./in-scope-tables/in-scope-tables.component";

@Component({
	selector: "app-executive-summary",
	templateUrl: "./executive-summary.component.html",
	styleUrls: ["./executive-summary.component.scss"]
})
export class ExecutiveSummaryComponent implements OnInit, OnDestroy {
	summaryDisplayedColumns: string[] = [
		"state",
		"lineOfBusiness",
		"newDate",
		"renewalDate",
		"availableDate"
	];

	detailDisplayedColumns: string[] = [
		"product",
		"version",
		"policyCount",
		"exposureCount",
		"modifiedPremiumCurrent",
		"modifiedPremiumProposed",
		"impactAmount",
		"impactPercent",
		"toleranceLo",
		"toleranceHi",
		"inScopeTables",
		"queryMethod",
		"inforceDate",
		"scenarioId"
	];

	constructor(
		@Inject(MAT_DIALOG_DATA) public data: ExecutiveSummaryDialogData,
		public dialog: MatDialog
	) {}

	ngOnInit(): void {}
	ngOnDestroy(): void {}

	async showInScopeTables(inScopeTables: string): Promise<void> {
		this.dialog.open(InScopeTablesComponent, {
			data: {
				tables: !inScopeTables ? [] : inScopeTables.split(",")
			}
		});
	}
}
