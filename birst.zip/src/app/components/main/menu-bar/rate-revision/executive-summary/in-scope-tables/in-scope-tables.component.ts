import {Component, OnInit, OnDestroy, Inject} from "@angular/core";
import {MAT_DIALOG_DATA} from "@angular/material/dialog";
import {InScopeTablesDialogData} from "src/app/models/in-scope-tables-dialog-data";

@Component({
	selector: "app-in-scope-tables",
	templateUrl: "./in-scope-tables.component.html",
	styleUrls: ["./in-scope-tables.component.scss"]
})
export class InScopeTablesComponent implements OnInit, OnDestroy {
	constructor(@Inject(MAT_DIALOG_DATA) public data: InScopeTablesDialogData) {}
	ngOnInit(): void {}
	ngOnDestroy(): void {}
}
