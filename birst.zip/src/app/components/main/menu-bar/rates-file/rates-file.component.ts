import {Observable} from "rxjs";
import {Store} from "@ngrx/store";
import {MatSnackBar} from "@angular/material/snack-bar";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, OnDestroy, Input, Output, EventEmitter} from "@angular/core";
import {AppState} from "src/app/models/app-state";
import {IpcMessage} from "src/backend/ipc-handlers";
import {RateRevision} from "src/backend/rate-revision";
import {MaintenanceSettings} from "src/backend/app-settings";
import * as fromAppState from "src/app/store/app-state.selectors";
import {ElectronService} from "src/app/services/electron.service";
import {updateAdvancedInputs} from "../../shared/database-objects";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

@Component({
	selector: "app-rates-file",
	templateUrl: "./rates-file.component.html",
	styleUrls: ["./rates-file.component.scss"]
})
export class RatesFileComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Output() isFormDisabledChange = new EventEmitter<boolean>();
	maintenanceSettings$: Observable<MaintenanceSettings>;
	formGroup: FormGroup<ScenarioFormGroup>;
	isRatesFileBeingCreated: boolean;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
		private _store: Store<{ appState: AppState }>,
		private _matSnackBar: MatSnackBar
	) {}

	ngOnInit(): void {
		this.maintenanceSettings$ = this._store.select(fromAppState.selectMaintenanceSettings);
		this.formGroup = this._formGroupDirective.control;
		this.isRatesFileBeingCreated = false;
		this.initIpcListeners();
	}

	ngOnDestroy(): void {}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.CreateRatesFileSuccess, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isRatesFileBeingCreated = false;

			this._matSnackBar.open("Rates file created successfully.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom"
			});
		});

		this._electronService.on(IpcMessage.CreateRatesFileCanceled, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isRatesFileBeingCreated = false;
		});

		this._electronService.on(IpcMessage.CreateRatesFileError, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isRatesFileBeingCreated = false;
		});

		this._electronService.on(IpcMessage.RatesFileDoesNotExist, () => {
			this._matSnackBar.open("Rates file does not exist.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom"
			});
		});
	}

	async createRatesFile(): Promise<void> {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isRatesFileBeingCreated = true;

		const databaseObjects = await this._electronService.invoke(
			IpcMessage.GetDatabaseObjects,
			JSON.stringify(this.formGroup.value)
		);

		updateAdvancedInputs(this.formGroup, JSON.parse(databaseObjects));

		this._electronService.send(
			IpcMessage.CreateRatesFile,
			JSON.stringify(this.formGroup.value)
		);
	}

	openRatesFile(): void {
		this._matSnackBar.open("Opening the rates file...", undefined, {
			duration: 10000,
			horizontalPosition: "center",
			verticalPosition: "bottom"
		});

		this._electronService.send(IpcMessage.OpenRatesFile, JSON.stringify(this.formGroup.value));
	}
}
