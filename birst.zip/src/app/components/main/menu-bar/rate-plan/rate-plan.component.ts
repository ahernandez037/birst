import {Observable} from "rxjs";
import {Store} from "@ngrx/store";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, OnDestroy, Input, Output, EventEmitter} from "@angular/core";
import {AppState} from "src/app/models/app-state";
import {IpcMessage} from "src/backend/ipc-handlers";
import {RateRevision} from "src/backend/rate-revision";
import {MaintenanceSettings} from "src/backend/app-settings";
import * as fromAppState from "src/app/store/app-state.selectors";
import {ElectronService} from "src/app/services/electron.service";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

@Component({
	selector: "app-rate-plan",
	templateUrl: "./rate-plan.component.html",
	styleUrls: ["./rate-plan.component.scss"]
})
export class RatePlanComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Output() isFormDisabledChange = new EventEmitter<boolean>();
	maintenanceSettings$: Observable<MaintenanceSettings>;
	formGroup: FormGroup<ScenarioFormGroup>;
	isLoading: boolean;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
		private _store: Store<{ appState: AppState }>
	) {}

	ngOnInit(): void {
		this.maintenanceSettings$ = this._store.select(fromAppState.selectMaintenanceSettings);
		this.formGroup = this._formGroupDirective.control;
		this.initIpcListeners();
	}

	ngOnDestroy(): void {}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.GetRatePlanCurrent, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isLoading = false;
		});

		this._electronService.on(IpcMessage.GetRatePlanUsed, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isLoading = false;
		});
	}

	getRatePlanCurrent(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isLoading = true;

		this._electronService.send(
			IpcMessage.GetRatePlanCurrent,
			JSON.stringify(this.formGroup.value)
		);
	}

	getRatePlanUsed(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isLoading = true;

		this._electronService.send(
			IpcMessage.GetRatePlanUsed,
			JSON.stringify(this.formGroup.value)
		);
	}
}
