import {Component, OnInit, OnDestroy} from "@angular/core";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {MatDialog} from "@angular/material/dialog";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs";
import {AppState} from "src/app/models/app-state";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {ElectronService} from "src/app/services/electron.service";
import {IpcMessage} from "src/backend/ipc-handlers";
import {NextSteps} from "src/backend/next-steps";
import {NextStepsDialogComponent} from "./next-steps-dialog/next-steps-dialog.component";
import {MaintenanceSettings} from "src/backend/app-settings";
import {selectMaintenanceSettings} from "src/app/store/app-state.selectors";

@Component({
	selector: "app-next-steps",
	templateUrl: "./next-steps.component.html",
	styleUrls: ["./next-steps.component.scss"]
})
export class NextStepsComponent implements OnInit, OnDestroy {
	maintenanceSettings$: Observable<MaintenanceSettings>;
	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
		private _dialog: MatDialog,
		private _store: Store<{ appState: AppState }>
	) {}

	ngOnInit(): void {
		this.maintenanceSettings$ = this._store.select(selectMaintenanceSettings);
		this.formGroup = this._formGroupDirective.control;
		this.initIpcListeners();
	}

	ngOnDestroy(): void {}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.ShowNextSteps, () => {
			this.showNextSteps();
		});
	}

	async showNextSteps(): Promise<void> {
		const nextSteps: NextSteps = JSON.parse(
			await this._electronService.invoke(
				IpcMessage.GetNextSteps,
				JSON.stringify(this.formGroup.value),
				this.formGroup.valid
			)
		);

		this._dialog.open(NextStepsDialogComponent, {
			width: nextSteps.modalWidth ? `${nextSteps.modalWidth}px` : undefined,
			height: nextSteps.modalHeight ? `${nextSteps.modalHeight}px` : undefined,
			data: {
				isAppStartAnnouncements: false,
				body: nextSteps.htmlContent,
				buttons: nextSteps.buttons
			}
		});
	}
}
