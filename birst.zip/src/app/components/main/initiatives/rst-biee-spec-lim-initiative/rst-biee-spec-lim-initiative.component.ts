import {Observable, Subscription} from "rxjs";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, Input, OnDestroy} from "@angular/core";
import {MatSlideToggleChange} from "@angular/material/slide-toggle";
import {IpcMessage} from "src/backend/ipc-handlers";
import {RateRevision} from "src/backend/rate-revision";
import {ElectronService} from "src/app/services/electron.service";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

@Component({
	selector: "app-rst-biee-spec-lim-initiative",
	templateUrl: "./rst-biee-spec-lim-initiative.component.html",
	styleUrls: ["./rst-biee-spec-lim-initiative.component.scss"]
})
export class RstBieeSpecLimInitiativeComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	formGroup: FormGroup<ScenarioFormGroup>;
	private _runModeSubscription: Subscription;
	private _productSubscription: Subscription;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;

		this._runModeSubscription = this.formGroup.controls.runMode.valueChanges.subscribe(
			(value) => {
				if (value !== "RATE-CHANGE") {
					this.formGroup.controls.isRstBieeSpecifiedLimitInitiative.setValue(false);
				}
			}
		);

		this._productSubscription = this.formGroup.controls.product.valueChanges.subscribe(
			(value) => {
				if (value !== "RST") {
					this.formGroup.controls.isRstBieeSpecifiedLimitInitiative.setValue(false);
				}
			}
		);
	}

	ngOnDestroy(): void {
		this._runModeSubscription.unsubscribe();
		this._productSubscription.unsubscribe();
	}

	// Logging this element separately since couldn't do it within the appLog
	// directive.
	logToggleChange(event: MatSlideToggleChange) {
		this._electronService.send(
			IpcMessage.Log,
			"INPUT-TOGGLE",
			"IS-RST-BIEE-SPECIFIED-LIMIT-INITIATIVE" + ": " + event.checked
		);
	}
}
