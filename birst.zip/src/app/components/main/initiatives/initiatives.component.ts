import {Observable} from "rxjs";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, Input, OnDestroy} from "@angular/core";
import {Product} from "src/backend/products";
import {GeoState} from "src/backend/geo-states";
import {RateRevision} from "src/backend/rate-revision";
import {UserSettings} from "src/backend/user-settings";
import {AvailableDate} from "src/backend/available-dates";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

@Component({
	selector: "app-initiatives",
	templateUrl: "./initiatives.component.html",
	styleUrls: ["./initiatives.component.scss"]
})
export class InitiativesComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() geoStates$: Observable<GeoState[]>;
	@Input() products$: Observable<Product[]>;
	@Input() availableDates$: Observable<AvailableDate[]>;
	@Input() scenarioId$: Observable<string>;
	@Input() userSettings$: Observable<UserSettings>;
	formGroup: FormGroup<ScenarioFormGroup>;
	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}
}
