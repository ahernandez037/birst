import {ComponentFixture, TestBed} from "@angular/core/testing";
import {RstGlSalesInitiativeComponent} from "./rst-gl-sales-initiative.component";

describe("RstGlSalesInitiativeComponent", () => {
	let component: RstGlSalesInitiativeComponent;
	let fixture: ComponentFixture<RstGlSalesInitiativeComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({declarations: [RstGlSalesInitiativeComponent]});
		fixture = TestBed.createComponent(RstGlSalesInitiativeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
