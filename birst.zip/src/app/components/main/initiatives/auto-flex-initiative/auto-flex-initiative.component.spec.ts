import {ComponentFixture, TestBed} from "@angular/core/testing";
import {AutoFlexInitiativeComponent} from "./auto-flex-initiative.component";

describe("AutoFlexInitiativeComponent", () => {
	let component: AutoFlexInitiativeComponent;
	let fixture: ComponentFixture<AutoFlexInitiativeComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [AutoFlexInitiativeComponent]
		});
		fixture = TestBed.createComponent(AutoFlexInitiativeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
