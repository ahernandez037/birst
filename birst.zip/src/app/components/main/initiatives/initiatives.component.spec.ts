import {ComponentFixture, TestBed} from "@angular/core/testing";
import {InitiativesComponent} from "./initiatives.component";

describe("InitiativesComponent", () => {
	let component: InitiativesComponent;
	let fixture: ComponentFixture<InitiativesComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [InitiativesComponent]
		});
		fixture = TestBed.createComponent(InitiativesComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
