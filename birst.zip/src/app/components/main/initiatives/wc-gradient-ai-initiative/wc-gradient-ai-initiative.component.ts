import {Observable, Subscription} from "rxjs";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, Input, OnDestroy} from "@angular/core";
import {MatSlideToggleChange} from "@angular/material/slide-toggle";
import {IpcMessage} from "src/backend/ipc-handlers";
import {RateRevision} from "src/backend/rate-revision";
import {ElectronService} from "src/app/services/electron.service";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

@Component({
	selector: "app-wc-gradient-ai-initiative",
	templateUrl: "./wc-gradient-ai-initiative.component.html",
	styleUrls: ["./wc-gradient-ai-initiative.component.scss"]
})
export class WcGradientAiInitiativeComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	formGroup: FormGroup<ScenarioFormGroup>;
	private _runModeSubscription: Subscription;
	private _lineOfBusinessSubscription: Subscription;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;

		this._runModeSubscription = this.formGroup.controls.runMode.valueChanges.subscribe(
			(value) => {
				if (value !== "RATE-CHANGE") {
					this.formGroup.controls.isWorkCompGradientAiInitiative.setValue(false);
				}
			}
		);

		this._lineOfBusinessSubscription =
			this.formGroup.controls.lineOfBusiness.valueChanges.subscribe((value) => {
				if (value !== "WC") {
					this.formGroup.controls.isWorkCompGradientAiInitiative.setValue(false);
				}
			});
	}

	ngOnDestroy(): void {
		this._runModeSubscription.unsubscribe();
		this._lineOfBusinessSubscription.unsubscribe();
	}

	// Logging this element separately since couldn't do it within the appLog
	// directive.
	logToggleChange(event: MatSlideToggleChange) {
		this._electronService.send(
			IpcMessage.Log,
			"INPUT-TOGGLE",
			"IS-WC-GRADIENT-AI-INITIATIVE" + ": " + event.checked
		);

		// Also automatically set "all versions" to true when this initiative is
		// enabled.
		if (event.checked) {
			this.formGroup.controls.useAllVersionsData.setValue(true);
		} else {
			this.formGroup.controls.useAllVersionsData.setValue(false);
		}
	}
}
