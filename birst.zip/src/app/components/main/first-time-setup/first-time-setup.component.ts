import {Store} from "@ngrx/store";
import {Component, OnInit, OnDestroy} from "@angular/core";
import {FormGroup, FormBuilder, Validators} from "@angular/forms";
import {AppState} from "src/app/models/app-state";
import {IpcMessage} from "src/backend/ipc-handlers";
import {updateIsAppReady} from "src/app/store/app-state.actions";
import {ElectronService} from "src/app/services/electron.service";

@Component({
	selector: "app-first-time-setup",
	templateUrl: "./first-time-setup.component.html",
	styleUrls: ["./first-time-setup.component.scss"]
})
export class FirstTimeSetupComponent implements OnInit, OnDestroy {
	firstTimeSetupForm: FormGroup;

	constructor(
		private _formBuilder: FormBuilder,
		private _store: Store<{ appState: AppState }>,
		private _electronService: ElectronService
	) {}

	ngOnInit(): void {
		this.firstTimeSetupForm = this._formBuilder.group({
			emailAddress: ["", [Validators.required, Validators.email]]
		});
	}

	ngOnDestroy(): void {}

	submitFirstTimeSetupForm() {
		this._store.dispatch(updateIsAppReady({isAppReady: false}));

		this._electronService.send(
			IpcMessage.FirstTimeSetup,
			JSON.stringify(this.firstTimeSetupForm.value)
		);
	}
}
