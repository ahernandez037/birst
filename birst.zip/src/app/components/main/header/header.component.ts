import {Observable} from "rxjs";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {RateRevision} from "src/backend/rate-revision";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

@Component({
	selector: "app-main-header",
	templateUrl: "./header.component.html",
	styleUrls: ["./header.component.scss"]
})
export class HeaderComponent implements OnInit, OnDestroy {
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() overallRateImpact$: Observable<number | null>;
	formGroup: FormGroup<ScenarioFormGroup>;
	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}
}
