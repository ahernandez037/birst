import {FormGroup} from "@angular/forms";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

export const isProductAndVersionSelected = (formGroup: FormGroup<ScenarioFormGroup>): boolean => {
	const lineOfBusiness = formGroup.controls.lineOfBusiness;
	const product = formGroup.controls.product;
	const version = formGroup.controls.version;

	switch (lineOfBusiness.value) {
	case "CMP":
		if (product.value !== "N/A" && product.valid) {
			return true;
		}

		break;
	case "AUTO":
		if (
			product.value !== "N/A" &&
				product.valid &&
				version.value !== "N/A" &&
				version.valid
		) {
			return true;
		}

		break;
	case "WC":
		if (version.value !== "N/A" && version.valid) {
			return true;
		}

		break;
	case "UMB":
		return true;
	}

	return false;
};
