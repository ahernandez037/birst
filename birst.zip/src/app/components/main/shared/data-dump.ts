import {FormGroup} from "@angular/forms";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

export const toggleSaveDataDump = (formGroup: FormGroup<ScenarioFormGroup>) => {
	if (isLargeDataDump(formGroup)) {
		formGroup.controls.saveDataDumpToHardDrive.setValue(false);
	}
	else {
		formGroup.controls.saveDataDumpToHardDrive.setValue(true);
	}
};

export const isLargeDataDump = (formGroup: FormGroup<ScenarioFormGroup>): boolean => {
	if (formGroup.controls.runMode.value === "ON-LEVEL") {
		return true;
	}

	if (
		formGroup.controls.runMode.value === "VALIDATION" &&
		formGroup.controls.dataSource.value === "PROD" &&
		formGroup.controls.geoState.value === "ALL"
	) {
		return true;
	}

	if (formGroup.controls.geoState.value === "CA") {
		return true;
	}

	if (
		formGroup.controls.lineOfBusiness.value === "CMP" &&
		formGroup.controls.geoState.value === "TX"
	) {
		return true;
	}

	if (formGroup.controls.useCountrywideData.value) {
		return true;
	}

	if (formGroup.controls.isAutoFlexRollout.value) {
		return true;
	}

	return false;
};
