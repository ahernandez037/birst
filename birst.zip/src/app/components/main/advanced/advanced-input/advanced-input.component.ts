import {Observable} from "rxjs";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {RateRevision} from "src/backend/rate-revision";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {isProductAndVersionSelected} from "../../shared/product-and-version";

@Component({
	selector: "app-advanced-input",
	templateUrl: "./advanced-input.component.html",
	styleUrls: ["./advanced-input.component.scss"]
})
export class AdvancedInputComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() label: string;
	@Input() fcName: string;
	@Input() logId: string;
	formGroup: FormGroup<ScenarioFormGroup>;
	isProductAndVersionSelected: (formGroup: FormGroup<ScenarioFormGroup>) => boolean;
	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		this.isProductAndVersionSelected = isProductAndVersionSelected;
	}

	ngOnDestroy(): void {}
}
