import {Observable} from "rxjs";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {RateRevision} from "src/backend/rate-revision";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

@Component({
	selector: "app-advanced",
	templateUrl: "./advanced.component.html",
	styleUrls: ["./advanced.component.scss"]
})
export class AdvancedComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	formGroup: FormGroup<ScenarioFormGroup>;
	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}
}
