import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {DateTime} from "luxon";
import {Observable, Subscription} from "rxjs";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {AvailableDate} from "src/backend/available-dates";
import {RateRevision} from "src/backend/rate-revision";
import {isProductAndVersionSelected} from "../../shared/product-and-version";

@Component({
	selector: "app-new-date",
	templateUrl: "./new-date.component.html",
	styleUrls: ["./new-date.component.scss"]
})
export class NewDateComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() availableDates$: Observable<AvailableDate[]>;
	formGroup: FormGroup<ScenarioFormGroup>;
	private _newDateSubscription: Subscription;
	private _availableDatesSubscription: Subscription;
	private _availableDates: AvailableDate[] = [];
	isProductAndVersionSelected: (formGroup: FormGroup<ScenarioFormGroup>) => boolean;
	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		this.isProductAndVersionSelected = isProductAndVersionSelected;

		this._availableDatesSubscription = this.availableDates$.subscribe(
			(value) => (this._availableDates = value)
		);

		const availableDate = this.formGroup.controls.availableDate;

		this._newDateSubscription = this.formGroup.controls.newDate.valueChanges.subscribe(
			(value) => {
				if (value) {
					const newDateToUse = DateTime.fromJSDate(new Date(value)).toFormat("yyyy-MM-dd");
					availableDate.setValue(this.getAvailableDateFromNewDate(newDateToUse));
				} else {
					availableDate.setValue("");
				}

				availableDate.updateValueAndValidity();
			}
		);
	}

	ngOnDestroy(): void {
		this._newDateSubscription.unsubscribe();
		this._availableDatesSubscription.unsubscribe();
	}

	getAvailableDateFromNewDate(newDate: string): string {
		// Convert input date to the first of the month, otherwise non-first
		// of the month input dates will have no matching available date. Since
		// newDate is formatted as yyyy-MM-dd, e.g., 2022-05-21, using substring
		// to grab the first 8 characters and append "01" as the day.
		const newDateAsFirstOfMonth = newDate.substring(0, 8) + "01";
		const availableDate = this._availableDates.find((availableDate) => availableDate.newDate === newDateAsFirstOfMonth)?.availableDate;

		if (availableDate) {
			return DateTime.fromFormat(availableDate, "yyyy-MM-dd").toUTC().toISO() ?? "";
		} else {
			return "";
		}
	}
}
