import {Observable, Subscription} from "rxjs";
import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {FormGroup, FormGroupDirective, Validators} from "@angular/forms";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {RateRevision} from "src/backend/rate-revision";
import {getDefaultInforceDate} from "../../shared/inforce-date";

@Component({
	selector: "app-query-method",
	templateUrl: "./query-method.component.html",
	styleUrls: ["./query-method.component.scss"]
})
export class QueryMethodComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		const inforceDate = this.formGroup.controls.inforceDate;
		const startDate = this.formGroup.controls.startDate;
		const endDate = this.formGroup.controls.endDate;

		this._subscription = this.formGroup.controls.queryMethod.valueChanges.subscribe((value) => {
			if (value === "IN-FORCE") {
				inforceDate.setValue(getDefaultInforceDate());
				inforceDate.setValidators(Validators.required);
				startDate.clearValidators();
				startDate.setValue("");
				endDate.clearValidators();
				endDate.setValue("");
			} else {
				startDate.setValidators(Validators.required);
				endDate.setValidators(Validators.required);
				inforceDate.clearValidators();
				inforceDate.setValue("");
			}

			inforceDate.updateValueAndValidity();
			startDate.updateValueAndValidity();
			endDate.updateValueAndValidity();
		});
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}
}
