import {ComponentFixture, TestBed} from "@angular/core/testing";
import {OnLevelRatePlanComponent} from "./on-level-rate-plan.component";

describe("OnLevelRatePlanComponent", () => {
	let component: OnLevelRatePlanComponent;
	let fixture: ComponentFixture<OnLevelRatePlanComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [OnLevelRatePlanComponent]
		});
		fixture = TestBed.createComponent(OnLevelRatePlanComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
