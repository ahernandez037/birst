import {Subscription} from "rxjs";
import {FormGroup, FormGroupDirective, Validators} from "@angular/forms";
import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";

@Component({
	selector: "app-on-level-rate-plan",
	templateUrl: "./on-level-rate-plan.component.html",
	styleUrls: ["./on-level-rate-plan.component.scss"]
})
export class OnLevelRatePlanComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	formGroup: FormGroup<ScenarioFormGroup>;
	private _runModeSubscription: Subscription;
	private _onLevelRatePlanSubscription: Subscription;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		const onLevelRatePlan = this.formGroup.controls.onLevelRatePlan;
		const onLevelRatePlanDate = this.formGroup.controls.onLevelRatePlanDate;

		this._runModeSubscription = this.formGroup.controls.runMode.valueChanges.subscribe((value) => {
			if (value === "ON-LEVEL") {
				onLevelRatePlan.setValue("LATEST");
				onLevelRatePlan.setValidators(Validators.required);
			} else {
				onLevelRatePlan.clearValidators();
				onLevelRatePlan.setValue("");
				onLevelRatePlanDate.clearValidators();
				onLevelRatePlanDate.setValue("");
			}

			onLevelRatePlan.updateValueAndValidity();
			onLevelRatePlanDate.updateValueAndValidity();
		});

		this._onLevelRatePlanSubscription = this.formGroup.controls.onLevelRatePlan.valueChanges.subscribe((value) => {
			if (value === "OTHER") {
				onLevelRatePlanDate.setValidators(Validators.required);
			} else {
				onLevelRatePlanDate.clearValidators();
				onLevelRatePlanDate.setValue("");
			}

			onLevelRatePlanDate.updateValueAndValidity();
		});
	}

	ngOnDestroy(): void {
		this._runModeSubscription.unsubscribe();
		this._onLevelRatePlanSubscription.unsubscribe();
	}
}
