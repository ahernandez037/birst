import {ComponentFixture, TestBed} from "@angular/core/testing";
import {RenewalDateComponent} from "./renewal-date.component";

describe("RenewalDateComponent", () => {
	let component: RenewalDateComponent;
	let fixture: ComponentFixture<RenewalDateComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [RenewalDateComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(RenewalDateComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
