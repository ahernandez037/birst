import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {FormGroup, FormGroupDirective} from "@angular/forms";
import {DateTime} from "luxon";
import {Observable, Subscription} from "rxjs";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {RateRevision} from "src/backend/rate-revision";
import {isProductAndVersionSelected} from "../../shared/product-and-version";

@Component({
	selector: "app-renewal-date",
	templateUrl: "./renewal-date.component.html",
	styleUrls: ["./renewal-date.component.scss"]
})
export class RenewalDateComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;
	isProductAndVersionSelected: (formGroup: FormGroup<ScenarioFormGroup>) => boolean;
	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		this.isProductAndVersionSelected = isProductAndVersionSelected;

		const lineOfBusiness = this.formGroup.controls.lineOfBusiness;
		const newDate = this.formGroup.controls.newDate;
		const renewalDate = this.formGroup.controls.renewalDate;

		this._subscription = this.formGroup.controls.renewalDate.valueChanges.subscribe((value) => {
			if (value) {
				const renewalDateToUse = DateTime.fromJSDate(new Date(value)).toFormat("yyyy-MM-dd");

				if (lineOfBusiness.value === "WC") {
					newDate.setValue(renewalDate.value);
				} else {
					const updatedNewDate =
						DateTime.fromFormat(renewalDateToUse, "yyyy-MM-dd")
							.minus({months: 2})
							.toUTC()
							.toISO() ?? "";

					newDate.setValue(updatedNewDate);
				}
			} else {
				newDate.setValue("");
			}

			newDate.updateValueAndValidity();
		});
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}
}
