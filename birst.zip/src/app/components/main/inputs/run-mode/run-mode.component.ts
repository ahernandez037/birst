import {Store} from "@ngrx/store";
import {Observable, Subscription} from "rxjs";
import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {FormGroup, FormGroupDirective, Validators} from "@angular/forms";
import {AppState} from "src/app/models/app-state";
import {RateRevision} from "src/backend/rate-revision";
import {toggleSaveDataDump} from "../../shared/data-dump";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {updateOverallRateImpact} from "src/app/store/app-state.actions";

@Component({
	selector: "app-run-mode",
	templateUrl: "./run-mode.component.html",
	styleUrls: ["./run-mode.component.scss"]
})
export class RunModeComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _store: Store<{ appState: AppState }>
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;

		const geoState = this.formGroup.controls.geoState;
		const newDate = this.formGroup.controls.newDate;
		const renewalDate = this.formGroup.controls.renewalDate;
		const availableDate = this.formGroup.controls.availableDate;
		const isAutoFlexRollout = this.formGroup.controls.isAutoFlexRollout;

		this._subscription = this.formGroup.controls.runMode.valueChanges.subscribe((value) => {
			this.formGroup.controls.geoState.setValue("");

			if (value === "RATE-CHANGE") {
				this.formGroup.controls.queryMethod.setValue("IN-FORCE");
				newDate.setValidators(Validators.required);
				renewalDate.setValidators(Validators.required);
				availableDate.setValidators(Validators.required);
			} else {
				newDate.clearValidators();
				renewalDate.clearValidators();
				availableDate.clearValidators();
				isAutoFlexRollout.clearValidators();
				newDate.setValue("");
				renewalDate.setValue("");
				availableDate.setValue("");
				// The Auto Flex initiative option is only available for Rate
				// Change mode.
				isAutoFlexRollout.setValue(false);
			}

			geoState.updateValueAndValidity();
			newDate.updateValueAndValidity();
			renewalDate.updateValueAndValidity();
			availableDate.updateValueAndValidity();
			isAutoFlexRollout.updateValueAndValidity();
			this._store.dispatch(updateOverallRateImpact({overallRateImpact: null}));
			toggleSaveDataDump(this.formGroup);
		});
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}
}
