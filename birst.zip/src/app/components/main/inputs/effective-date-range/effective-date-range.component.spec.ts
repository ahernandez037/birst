import {ComponentFixture, TestBed} from "@angular/core/testing";
import {EffectiveDateRangeComponent} from "./effective-date-range.component";

describe("EffectiveDateRangeComponent", () => {
	let component: EffectiveDateRangeComponent;
	let fixture: ComponentFixture<EffectiveDateRangeComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [EffectiveDateRangeComponent]
		}).compileComponents();

		fixture = TestBed.createComponent(EffectiveDateRangeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
