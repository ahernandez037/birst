import {DateTime} from "luxon";
import {Store} from "@ngrx/store";
import {Observable, Subscription} from "rxjs";
import {MatSelectChange} from "@angular/material/select";
import {Component, OnInit, OnDestroy, Input} from "@angular/core";
import {FormControl, FormGroup, FormGroupDirective, Validators} from "@angular/forms";
import {AppState} from "src/app/models/app-state";
import {RateRevision} from "src/backend/rate-revision";
import {WorkCompBureauRate} from "src/backend/wc-bureau-rates";
import {ScenarioFormGroup} from "src/app/models/scenario-form-group";
import {isProductAndVersionSelected} from "../../shared/product-and-version";
import {selectScenarioForm, selectWorkCompBureauRates} from "src/app/store/app-state.selectors";

@Component({
	selector: "app-wc-bureau-rates",
	templateUrl: "./wc-bureau-rates.component.html",
	styleUrls: ["./wc-bureau-rates.component.scss"]
})
export class WcBureauRatesComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	formGroup: FormGroup<ScenarioFormGroup>;
	workCompAdoptBureauRates: FormControl<boolean>;
	workCompBureauEffectiveDate: FormControl<string>;
	workCompBureauReleaseDate: FormControl<string>;
	workCompBureauStatusFlag: FormControl<string>;
	workCompBureauRates: WorkCompBureauRate[] = [];
	allOptions: (WorkCompBureauRate & { displayText: string })[];
	filteredOptions: (WorkCompBureauRate & { displayText: string })[];
	private _workCompBureauRatesSubscription: Subscription;
	private _geoStateSubscription: Subscription;
	private _workCompAdoptBureauRatesSubscription: Subscription;
	private _scenarioFormSubscription: Subscription;
	isProductAndVersionSelected: (formGroup: FormGroup<ScenarioFormGroup>) => boolean;

	// Needed to create a standalone form control due to unique case for the
	// "Bureau Rates Effective Date" dropdown select field. The unique case
	// being that the field is not tied directly to a single form control, as
	// there are three separate form controls that comprise this single
	// selection: 1) effective date, 2) release date, 3) status flag. We have
	// this standalone form control for the sole purpose of displaying the
	// "required" error message in the UI if the user were to miss making a
	// selection.
	bureauDateControl: FormControl<string | null>;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _store: Store<{ appState: AppState }>
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		this.workCompAdoptBureauRates = this.formGroup.controls.workCompAdoptBureauRates;
		this.workCompBureauEffectiveDate = this.formGroup.controls.workCompBureauEffectiveDate;
		this.workCompBureauReleaseDate = this.formGroup.controls.workCompBureauReleaseDate;
		this.workCompBureauStatusFlag = this.formGroup.controls.workCompBureauStatusFlag;
		this.isProductAndVersionSelected = isProductAndVersionSelected;
		this.bureauDateControl = new FormControl("", Validators.required);

		this._workCompBureauRatesSubscription = this._store
			.select(selectWorkCompBureauRates)
			.subscribe((value) => {
				this.workCompBureauRates = value;
				this.allOptions = [];

				for (const v of value) {
					this.allOptions.push({
						geoState: v.geoState,
						effectiveDate: v.effectiveDate,
						releaseDate: v.releaseDate,
						statusFlag: v.statusFlag,
						displayText: `${DateTime.fromFormat(v.effectiveDate, "yyyy-MM-dd").toFormat(
							"MM/dd/yyyy"
						)} (Released: ${DateTime.fromFormat(v.releaseDate, "yyyy-MM-dd").toFormat(
							"MM/dd/yyyy"
						)}) ${v.statusFlag === "A" ? "Approved" : "Proposed"}`
					});
				}
			});

		this._geoStateSubscription = this.formGroup.controls.geoState.valueChanges.subscribe(
			(value) => {
				this.filteredOptions = this.allOptions.filter(
					(option) => option.geoState === value
				);
			}
		);

		this._workCompAdoptBureauRatesSubscription =
			this.formGroup.controls.workCompAdoptBureauRates.valueChanges.subscribe((value) => {
				this.bureauDateControl.setValue("");
				this.workCompBureauEffectiveDate.setValue("");
				this.workCompBureauReleaseDate.setValue("");
				this.workCompBureauStatusFlag.setValue("");

				if (!value) {
					this.bureauDateControl.clearValidators();
					this.workCompBureauEffectiveDate.clearValidators();
					this.workCompBureauReleaseDate.clearValidators();
					this.workCompBureauStatusFlag.clearValidators();
				} else {
					this.bureauDateControl.setValidators(Validators.required);
					this.workCompBureauEffectiveDate.setValidators(Validators.required);
					this.workCompBureauReleaseDate.setValidators(Validators.required);
					this.workCompBureauStatusFlag.setValidators(Validators.required);
				}

				this.bureauDateControl.updateValueAndValidity();
				this.workCompBureauEffectiveDate.updateValueAndValidity();
				this.workCompBureauReleaseDate.updateValueAndValidity();
				this.workCompBureauStatusFlag.updateValueAndValidity();
			});

		// Need to subscribe to scenario form for when a scenario file is loaded
		// the UI must be manually updated since the scenario form data does not
		// have an actual field for the bureau date, as it is composed of three
		// individual fields. Therefore, this manual update is necessary.
		this._scenarioFormSubscription = this._store
			.select(selectScenarioForm)
			.subscribe((value) => {
				if (value.lineOfBusiness === "WC") {
					// Creating unique key by concatenating the different fields
					// and using a pipe, i.e., |, as a delimiter.
					this.bureauDateControl.setValue(
						value.geoState +
							"|" +
							value.workCompBureauEffectiveDate +
							"|" +
							value.workCompBureauReleaseDate +
							"|" +
							value.workCompBureauStatusFlag
					);
				}
			});
	}

	ngOnDestroy(): void {
		this._workCompBureauRatesSubscription.unsubscribe();
		this._geoStateSubscription.unsubscribe();
		this._workCompAdoptBureauRatesSubscription.unsubscribe();
		this._scenarioFormSubscription.unsubscribe();
	}

	setValues(event: MatSelectChange): void {
		// Creating unique key by concatenating the different fields and using
		// a pipe, i.e., |, as a delimiter.
		let key = "";

		const rate = this.workCompBureauRates.find((rate) => {
			key =
				rate.geoState +
				"|" +
				rate.effectiveDate +
				"|" +
				rate.releaseDate +
				"|" +
				rate.statusFlag;

			return key === event.value;
		});

		if (rate) {
			this.bureauDateControl.setValue(key);
			this.workCompBureauEffectiveDate.setValue(rate.effectiveDate);
			this.workCompBureauReleaseDate.setValue(rate.releaseDate);
			this.workCompBureauStatusFlag.setValue(rate.statusFlag);
		} else {
			this.bureauDateControl.setValue("");
			this.workCompBureauEffectiveDate.setValue("");
			this.workCompBureauReleaseDate.setValue("");
			this.workCompBureauStatusFlag.setValue("");
		}
	}
}
