import {createAction, props} from "@ngrx/store";
import {RateRevision} from "src/backend/rate-revision";
import {AppState} from "../models/app-state";
import {MaintenanceSettings} from "src/backend/app-settings";

export const updateMaintenanceSettings = createAction(
	"[AppState] Update Maintenance Settings",
	props<{ maintenanceSettings: MaintenanceSettings }>()
);

export const updateAppVersion = createAction(
	"[AppState] Update App Version",
	props<{ appVersion: string }>()
);

export const updateIsAppReady = createAction(
	"[AppState] Update Is App Ready",
	props<{ isAppReady: boolean }>()
);

export const updateSnowflakeSessionId = createAction(
	"[AppState] Update Snowflake Session ID",
	props<{ snowflakeSessionId: string }>()
);

export const updateScenarioId = createAction(
	"[AppState] Update Scenario ID",
	props<{ scenarioId: string }>()
);

export const updateUser = createAction(
	"[AppState] Update User",
	props<Pick<AppState, "user">>()
);

export const updateUserSettings = createAction(
	"[AppState] Update User Settings",
	props<Pick<AppState, "userSettings">>()
);

export const updateGeoStates = createAction(
	"[AppState] Update Geo States",
	props<Pick<AppState, "geoStates">>()
);

export const updateWorkCompBureauRates = createAction(
	"[AppState] Update Work Comp Bureau Rates",
	props<Pick<AppState, "workCompBureauRates">>()
);

export const updateProducts = createAction(
	"[AppState] Update Products",
	props<Pick<AppState, "products">>()
);

export const updateReleaseNotes = createAction(
	"[AppState] Update Release Notes",
	props<Pick<AppState, "releaseNotes">>()
);

export const updateAvailableDates = createAction(
	"[AppState] Update Available Dates",
	props<Pick<AppState, "availableDates">>()
);

export const addConsoleMessage = createAction(
	"[AppState] Add Console Message",
	props<Pick<AppState, "consoleMessages">>()
);

export const stopConsoleMessageTimer = createAction(
	"[AppState] Stop Console Message Timer",
	props<{ timerId: string }>()
);

export const updateScenarioForm = createAction(
	"[AppState] Update Scenario Form",
	props<Pick<AppState, "scenarioForm">>()
);

export const updateIsScenarioFormValid = createAction(
	"[AppState] Update Is Scenario Form Valid",
	props<{ isScenarioFormValid: boolean }>()
);

export const updateOverallRateImpact = createAction(
	"[AppState] Update Overall Rate Impact",
	props<{ overallRateImpact: number | null }>()
);

export const updateRateRevision = createAction(
	"[AppState] Update Rate Revision",
	props<{ rateRevision: RateRevision }>()
);

export const updateTestSuites = createAction(
	"[AppState] Update Test Suites",
	props<Pick<AppState, "testSuites">>()
);

export const updateIsTestSuiteRunning = createAction(
	"[AppState] Update Is Test Suite Running",
	props<{ isTestSuiteRunning: boolean }>()
);

export const updateColorTheme = createAction(
	"[AppState] Update Color Theme",
	props<{ colorTheme: string }>()
);

export const updateMonitorScenarioRuns = createAction(
	"[AppState] Update Monitor Scenario Runs",
	props<Pick<AppState, "monitorScenarioRuns">>()
);

export const updateMonitorAverageRuntimes = createAction(
	"[AppState] Update Monitor Average Runtimes",
	props<Pick<AppState, "monitorAverageRuntimes">>()
);

export const updateIsUsingDevelopmentDatabaseSchemas = createAction(
	"[AppState] Update Is Using Development Database Schemas",
	props<{ isUsingDevelopmentDatabaseSchemas: boolean }>()
);

export const updateSettingsFile = createAction(
	"[AppState] Update Settings File",
	props<{ settingsFile: "prod" | "dev" }>()
);
