import {createSelector} from "@ngrx/store";
import {AppState} from "../models/app-state";

const selectAppState = (state: { appState: AppState }) => state.appState;

export const selectMaintenanceSettings = createSelector(
	selectAppState,
	(state: AppState) => state.maintenanceSettings
);

export const selectAppVersion = createSelector(
	selectAppState,
	(state: AppState) => state.appVersion
);

export const selectIsAppReady = createSelector(
	selectAppState,
	(state: AppState) => state.isAppReady
);

export const selectSnowflakeSessionId = createSelector(
	selectAppState,
	(state: AppState) => state.snowflakeSessionId
);

export const selectUser = createSelector(
	selectAppState, (state: AppState) => state.user
);

export const selectUserSettings = createSelector(
	selectAppState,
	(state: AppState) => state.userSettings
);

export const selectGeoStates = createSelector(
	selectAppState, (state: AppState) => state.geoStates
);

export const selectWorkCompBureauRates = createSelector(
	selectAppState,
	(state: AppState) => state.workCompBureauRates
);

export const selectProducts = createSelector(
	selectAppState, (state: AppState) => state.products
);

export const selectScenarioId = createSelector(
	selectAppState,
	(state: AppState) => state.scenarioId
);

export const selectReleaseNotes = createSelector(
	selectAppState,
	(state: AppState) => state.releaseNotes
);

export const selectAvailableDates = createSelector(
	selectAppState,
	(state: AppState) => state.availableDates
);

export const selectIsFirstTimeSetup = createSelector(
	selectAppState,
	(state: AppState) => state.user.isFirstTimeSetup
);

export const selectIsDeveloper = createSelector(
	selectAppState,
	(state: AppState) => state.user.isDeveloper
);

export const selectIsFitMember = createSelector(
	selectAppState,
	(state: AppState) => state.user.isFitMember
);

export const selectConsoleMessages = createSelector(
	selectAppState,
	(state: AppState) => state.consoleMessages
);

export const selectScenarioForm = createSelector(
	selectAppState,
	(state: AppState) => state.scenarioForm
);

export const selectIsScenarioFormValid = createSelector(
	selectAppState,
	(state: AppState) => state.isScenarioFormValid
);

export const selectOverallRateImpact = createSelector(
	selectAppState,
	(state: AppState) => state.overallRateImpact
);

export const selectRateRevision = createSelector(
	selectAppState,
	(state: AppState) => state.rateRevision
);

export const selectIsTestSuiteRunning = createSelector(
	selectAppState,
	(state: AppState) => state.isTestSuiteRunning
);

export const selectTestSuites = createSelector(
	selectAppState,
	(state: AppState) => state.testSuites
);

export const selectColorTheme = createSelector(
	selectAppState,
	(state: AppState) => state.colorTheme
);

export const selectMonitorScenarioRuns = createSelector(
	selectAppState,
	(state: AppState) => state.monitorScenarioRuns
);

export const selectMonitorAverageRuntimes = createSelector(
	selectAppState,
	(state: AppState) => state.monitorAverageRuntimes
);

export const selectIsUsingDevelopmentDatabaseSchemas = createSelector(
	selectAppState,
	(state: AppState) => state.isUsingDevelopmentDatabaseSchemas
);

export const selectSettingsFile = createSelector(
	selectAppState,
	(state: AppState) => state.settingsFile
);
