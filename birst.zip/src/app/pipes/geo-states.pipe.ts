import {Pipe, PipeTransform} from "@angular/core";
import {GeoState} from "src/backend/geo-states";

@Pipe({
	name: "geoStates"
})
export class GeoStatesPipe implements PipeTransform {
	transform(value: GeoState[] | null, runMode: string | null | undefined): GeoState[] {
		if (!value || value?.length === 0) {
			return [];
		}

		if (runMode !== "RATE-CHANGE") {
			return [
				{
					name: "All States",
					abbreviation: "ALL",
					number: 0
				},
				...value
			];
		} else {
			return value;
		}
	}
}
