import {Pipe, PipeTransform} from "@angular/core";
import {Product} from "src/backend/products";
import {getUniqueValues} from "./shared/get-unique-values";

@Pipe({
	name: "product"
})
export class ProductPipe implements PipeTransform {
	transform(
		value: Product[] | null,
		geoState: string | null | undefined,
		lineOfBusiness: string | null | undefined
	): Pick<Product, "productCode" | "productDescription">[] {
		if (!value || value?.length === 0) {
			return [];
		}

		return getUniqueValues(
			value
				.filter(
					(product) =>
						product.isAvailable &&
						(product.stateCode === geoState || geoState === "ALL") &&
						product.lineOfBusinessCode === lineOfBusiness &&
						product.productCode !== "N/A"
				)
				.map(({productCode, productDescription}) => ({
					productCode,
					productDescription
				}))
		);
	}
}
