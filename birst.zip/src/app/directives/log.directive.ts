import {Subscription} from "rxjs";
import {MatSelect} from "@angular/material/select";
import {MatTabGroup} from "@angular/material/tabs";
import {
	Input,
	OnInit,
	Injector,
	Directive,
	OnDestroy,
	ElementRef,
	HostListener
} from "@angular/core";
import {LogSubType} from "src/backend/logger";
import {IpcMessage} from "src/backend/ipc-handlers";
import {ElectronService} from "../services/electron.service";

@Directive({
	selector: "[appLog]"
})
export class LogDirective implements OnInit, OnDestroy {
	@Input() logId: string;
	@Input() logSubType: LogSubType;
	private _subscription: Subscription;
	private _matSelect: MatSelect;
	private _matTabGroup: MatTabGroup;

	constructor(
		private _elementRef: ElementRef,
		private _injector: Injector,
		private _electronService: ElectronService
	) {}

	ngOnInit(): void {
		if (this.logSubType === "INPUT-SELECT") {
			this._matSelect = this._injector.get(MatSelect);

			this._subscription = this._matSelect.selectionChange.subscribe((state) => {
				this._electronService.send(
					IpcMessage.Log,
					"INPUT-SELECT",
					this.logId + ": " + state.value
				);
			});
		}

		if (this.logSubType === "TAB-CLICK") {
			this._matTabGroup = this._injector.get(MatTabGroup);

			this._subscription = this._matTabGroup.selectedTabChange.subscribe((state) => {
				this._electronService.send(
					IpcMessage.Log,
					"TAB-CLICK",
					this.logId + ": " + state.tab.textLabel
				);
			});
		}
	}

	ngOnDestroy(): void {
		// Sometimes subscription will be undefined, therefore using ?.
		this._subscription?.unsubscribe();
	}

	@HostListener("click") onClick(): void {
		if (this.logSubType === "BUTTON-CLICK") {
			this._electronService.send(IpcMessage.Log, "BUTTON-CLICK", this.logId);
		}

		if (this.logSubType === "RADIO-CLICK") {
			this._electronService.send(IpcMessage.Log, "RADIO-CLICK", this.logId);
		}
	}

	@HostListener("change") onChange(): void {
		if (this.logSubType === "INPUT-TEXT") {
			this._electronService.send(
				IpcMessage.Log,
				"INPUT-TEXT",
				this.logId + ": " + this._elementRef.nativeElement.value
			);
		}
	}

	@HostListener("dateChange") onDateChange(): void {
		if (this.logSubType === "INPUT-DATE") {
			this._electronService.send(
				IpcMessage.Log,
				"INPUT-DATE",
				this.logId + ": " + this._elementRef.nativeElement.value
			);
		}
	}
}
