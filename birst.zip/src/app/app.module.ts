import {NgModule} from "@angular/core";
import {StoreModule} from "@ngrx/store";
import {AppComponent} from "./app.component";
import {NgxEchartsModule} from "ngx-echarts";
import {ClipboardModule} from "@angular/cdk/clipboard";
import {BrowserModule} from "@angular/platform-browser";
import {ReactiveFormsModule, FormsModule} from "@angular/forms";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";

import {MatTabsModule} from "@angular/material/tabs";
import {MatIconModule} from "@angular/material/icon";
import {MatMenuModule} from "@angular/material/menu";
import {MatInputModule} from "@angular/material/input";
import {MatTableModule} from "@angular/material/table";
import {MatRadioModule} from "@angular/material/radio";
import {MatSelectModule} from "@angular/material/select";
import {MatButtonModule} from "@angular/material/button";
import {MatDialogModule} from "@angular/material/dialog";
import {MatSliderModule} from "@angular/material/slider";
import {MatNativeDateModule} from "@angular/material/core";
import {MatDividerModule} from "@angular/material/divider";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatSnackBarModule} from "@angular/material/snack-bar";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatSlideToggleModule} from "@angular/material/slide-toggle";
import {MatButtonToggleModule} from "@angular/material/button-toggle";
import {MatProgressSpinnerModule} from "@angular/material/progress-spinner";
import {MatFormFieldModule, MAT_FORM_FIELD_DEFAULT_OPTIONS} from "@angular/material/form-field";

import {ProductPipe} from "./pipes/product.pipe";
import {VersionPipe} from "./pipes/version.pipe";
import {GeoStatesPipe} from "./pipes/geo-states.pipe";
import {LogDirective} from "./directives/log.directive";
import {appStateReducer} from "./store/app-state.reducer";
import {LineOfBusinessPipe} from "./pipes/line-of-business.pipe";

import {MainComponent} from "./components/main/main.component";
import {MiscComponent} from "./components/main/misc/misc.component";
import {ConsoleComponent} from "./components/console/console.component";
import {SupportComponent} from "./components/support/support.component";
import {MonitorComponent} from "./components/monitor/monitor.component";
import {InputsComponent} from "./components/main/inputs/inputs.component";
import {DragAndDropDirective} from "./directives/drag-and-drop.directive";
import {SettingsComponent} from "./components/settings/settings.component";
import {DeveloperComponent} from "./components/developer/developer.component";
import {AdvancedComponent} from "./components/main/advanced/advanced.component";
import {GeneralComponent} from "./components/settings/general/general.component";
import {DevMiscComponent} from "./components/developer/dev-misc/dev-misc.component";
import {ProductComponent} from "./components/main/inputs/product/product.component";
import {VersionComponent} from "./components/main/inputs/version/version.component";
import {SnowparkComponent} from "./components/developer/snowpark/snowpark.component";
import {RunModeComponent} from "./components/main/inputs/run-mode/run-mode.component";
import {NewDateComponent} from "./components/main/inputs/new-date/new-date.component";
import {AccessLogComponent} from "./components/monitor/access-log/access-log.component";
import {ReleaseNotesComponent} from "./components/release-notes/release-notes.component";
import {GeoStateComponent} from "./components/main/inputs/geo-state/geo-state.component";
import {ScenarioComponent} from "./components/main/menu-bar/scenario/scenario.component";
import {StatisticsComponent} from "./components/monitor/statistics/statistics.component";
import {InitiativesComponent} from "./components/main/initiatives/initiatives.component";
import {RatePlanComponent} from "./components/main/menu-bar/rate-plan/rate-plan.component";
import {ScenarioIdComponent} from "./components/main/misc/scenario-id/scenario-id.component";
import {DataSourceComponent} from "./components/main/misc/data-source/data-source.component";
import {NextStepsComponent} from "./components/main/menu-bar/next-steps/next-steps.component";
import {RatesFileComponent} from "./components/main/menu-bar/rates-file/rates-file.component";
import {HeaderComponent as MainHeaderComponent} from "./components/main/header/header.component";
import {QueryMethodComponent} from "./components/main/inputs/query-method/query-method.component";
import {InforceDateComponent} from "./components/main/inputs/inforce-date/inforce-date.component";
import {RenewalDateComponent} from "./components/main/inputs/renewal-date/renewal-date.component";
import {HealthChecksComponent} from "./components/developer/health-checks/health-checks.component";
import {FdrcTimestampComponent} from "./components/main/misc/fdrc-timestamp/fdrc-timestamp.component";
import {FirstTimeSetupComponent} from "./components/main/first-time-setup/first-time-setup.component";
import {MenuBarComponent as MainMenuBarComponent} from "./components/main/menu-bar/menu-bar.component";
import {RateRevisionComponent} from "./components/main/menu-bar/rate-revision/rate-revision.component";
import {AvailableDateComponent} from "./components/main/inputs/available-date/available-date.component";
import {DataDumpTableComponent} from "./components/main/misc/data-dump-table/data-dump-table.component";
import {HeaderComponent as SettingsHeaderComponent} from "./components/settings/header/header.component";
import {AutomatedTestsComponent} from "./components/developer/automated-tests/automated-tests.component";
import {AdvancedInputComponent} from "./components/main/advanced/advanced-input/advanced-input.component";
import {WcBureauRatesComponent} from "./components/main/inputs/wc-bureau-rates/wc-bureau-rates.component";
import {DataDumpToggleComponent} from "./components/main/misc/data-dump-toggle/data-dump-toggle.component";
import {LineOfBusinessComponent} from "./components/main/inputs/line-of-business/line-of-business.component";
import {MenuBarComponent as SettingsMenuBarComponent} from "./components/settings/menu-bar/menu-bar.component";
import {ImportantMessagesComponent} from "./components/monitor/important-messages/important-messages.component";
import {DeveloperSettingsComponent} from "./components/settings/developer-settings/developer-settings.component";
import {ScenarioDirectoryComponent} from "./components/main/misc/scenario-directory/scenario-directory.component";
import {CountrywideToggleComponent} from "./components/main/misc/countrywide-toggle/countrywide-toggle.component";
import {AllVersionsToggleComponent} from "./components/main/misc/all-versions-toggle/all-versions-toggle.component";
import {EffectiveDateRangeComponent} from "./components/main/inputs/effective-date-range/effective-date-range.component";
import {NextStepsDialogComponent} from "./components/main/menu-bar/next-steps/next-steps-dialog/next-steps-dialog.component";
import {AutoFlexInitiativeComponent} from "./components/main/initiatives/auto-flex-initiative/auto-flex-initiative.component";
import {ExecutiveSummaryComponent} from "./components/main/menu-bar/rate-revision/executive-summary/executive-summary.component";
import {TestSuiteResultsComponent} from "./components/developer/automated-tests/test-suite-results/test-suite-results.component";
import {RstGlSalesInitiativeComponent} from "./components/main/initiatives/rst-gl-sales-initiative/rst-gl-sales-initiative.component";
import {InScopeTablesComponent} from "./components/main/menu-bar/rate-revision/executive-summary/in-scope-tables/in-scope-tables.component";
import {WcGradientAiInitiativeComponent} from "./components/main/initiatives/wc-gradient-ai-initiative/wc-gradient-ai-initiative.component";
import {OnLevelRatePlanComponent} from "./components/main/inputs/on-level-rate-plan/on-level-rate-plan.component";
import {RstBieeSpecLimInitiativeComponent} from "./components/main/initiatives/rst-biee-spec-lim-initiative/rst-biee-spec-lim-initiative.component";

@NgModule({
	declarations: [
		ProductPipe,
		VersionPipe,
		LogDirective,
		AppComponent,
		MainComponent,
		GeoStatesPipe,
		MiscComponent,
		InputsComponent,
		ConsoleComponent,
		SupportComponent,
		RunModeComponent,
		ProductComponent,
		VersionComponent,
		NewDateComponent,
		GeneralComponent,
		DevMiscComponent,
		MonitorComponent,
		RatePlanComponent,
		ScenarioComponent,
		SettingsComponent,
		AdvancedComponent,
		GeoStateComponent,
		SnowparkComponent,
		AccessLogComponent,
		DeveloperComponent,
		RatesFileComponent,
		NextStepsComponent,
		LineOfBusinessPipe,
		StatisticsComponent,
		MainHeaderComponent,
		DataSourceComponent,
		ScenarioIdComponent,
		InitiativesComponent,
		QueryMethodComponent,
		InforceDateComponent,
		RenewalDateComponent,
		MainMenuBarComponent,
		DragAndDropDirective,
		HealthChecksComponent,
		ReleaseNotesComponent,
		RateRevisionComponent,
		WcBureauRatesComponent,
		InScopeTablesComponent,
		AvailableDateComponent,
		FdrcTimestampComponent,
		DataDumpTableComponent,
		AdvancedInputComponent,
		AutomatedTestsComponent,
		LineOfBusinessComponent,
		FirstTimeSetupComponent,
		DataDumpToggleComponent,
		SettingsHeaderComponent,
		SettingsMenuBarComponent,
		NextStepsDialogComponent,
		TestSuiteResultsComponent,
		ExecutiveSummaryComponent,
		CountrywideToggleComponent,
		AllVersionsToggleComponent,
		DeveloperSettingsComponent,
		ScenarioDirectoryComponent,
		ImportantMessagesComponent,
		EffectiveDateRangeComponent,
		AutoFlexInitiativeComponent,
		RstGlSalesInitiativeComponent,
		WcGradientAiInitiativeComponent,
		OnLevelRatePlanComponent,
		RstBieeSpecLimInitiativeComponent
	],
	imports: [
		FormsModule,
		MatTabsModule,
		BrowserModule,
		MatIconModule,
		MatMenuModule,
		MatRadioModule,
		MatInputModule,
		MatTableModule,
		ClipboardModule,
		MatSelectModule,
		MatButtonModule,
		MatDialogModule,
		MatSliderModule,
		MatTooltipModule,
		MatDividerModule,
		MatSnackBarModule,
		MatFormFieldModule,
		MatNativeDateModule,
		ReactiveFormsModule,
		MatDatepickerModule,
		MatSlideToggleModule,
		MatButtonToggleModule,
		BrowserAnimationsModule,
		MatProgressSpinnerModule,
		StoreModule.forRoot({appState: appStateReducer}),
		NgxEchartsModule.forRoot({
			echarts: () => import("echarts")
		})
	],
	providers: [{provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: {appearance: "fill"}}],
	bootstrap: [AppComponent]
})
export class AppModule {}
