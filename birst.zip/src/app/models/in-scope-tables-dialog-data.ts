export interface InScopeTablesDialogData {
	tables: string[];
}
