import {connection, execute} from "../database";

export let snowflakeSessionId = "TBD";

export const setSnowflakeSessionId = async (): Promise<void> => {
	if (!connection) {
		return;
	}

	const [, rs] = await execute({sqlText: "SELECT CURRENT_SESSION() AS session_id;"});

	if (rs) {
		snowflakeSessionId = String((rs[0] as Record<string, unknown>)["SESSION_ID"]);
	}
};
