import {join} from "path";
import {app} from "electron";
import {readFile} from "fs-extra";
import {parse} from "comment-json";
import {user} from "../user";
import {log} from "../logger";
import {mainWindow} from "../main";
import {IpcMessage} from "../ipc-handlers";
import {userSettings} from "../user-settings";
import {executeDynamicJsFunction, loadDynamicJsFunction} from "../dynamic-js";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";
import {
	ExecutionState,
	SnowflakeSettings,
	MaintenanceSettings,
	AutoUpdaterSettings,
	AnnouncementsForConsole
} from "./types";

export let autoUpdaterSettings: AutoUpdaterSettings = {
	feedUrl: "",
	checkForUpdatesInterval: null
};

// Default to all false settings. These values will only be overridden if the
// user is not a developer.
export let maintenanceSettings: MaintenanceSettings = {
	reloadInterval: null,
	// Scenario.
	disableScenario: false,
	disableScenarioNew: false,
	disableScenarioLoad: false,
	disableScenarioClone: false,
	disableScenarioDirectory: false,
	disableScenarioRun: false,
	// Rates file.
	disableRatesFile: false,
	disableRatesFileCreate: false,
	disableRatesFileOpen: false,
	// Rate plan.
	disableRatePlan: false,
	disableRatePlanCurrent: false,
	disableRatePlanUsed: false,
	// Rate revision.
	disableRateRevision: false,
	disableRateRevisionExecutiveSummary: false,
	disableRateRevisionInitiateRateRevision: false,
	disableRateRevisionCancelRateRevision: false,
	disableRateRevisionOpenFitDirectory: false,
	disableRateRevisionSaveRatesAndGenerateOutput: false,
	disableRateRevisionSendRequestToDeleteRates: false,
	disableRateRevisionSaveRates: false,
	disableRateRevisionDeleteRates: false,
	disableRateRevisionCreateClsFiles: false,
	disableRateRevisionCreateRatabaseFiles: false,
	// Next steps.
	disableNextSteps: false,
	// Settings.
	disableSaveSettings: false,
	// Support.
	disableUsersGuide: false,
	disableTechnicalDocumentation: false,
	disableReportProblem: false,
	disableSubmitFeedback: false
};

export let snowflakeSettings: SnowflakeSettings = {
	account: "TBD",
	authenticator: "TBD",
	roleForFit: "TBD",
	roleForDeveloper: "TBD",
	roleForOthers: "TBD",
	warehouseForFit: "TBD",
	warehouseForDeveloper: "TBD",
	warehouseForOthers: "TBD",
	role: "TBD",
	warehouse: "TBD",
	database: "TBD",
	schema: "TBD",
	dataDumpDatabaseSchema: "TBD"
};

export let forcedAppQuitMessages: Record<ExecutionState, string>;
export let announcementsForDialog: string;
export let announcementsForConsole: AnnouncementsForConsole;

export const loadAutoUpdaterSettings = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading auto updater settings...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingAutoUpdaterSettings
	});

	try {
		const parsedJson: unknown = parse((await readFile(join(userSettings.appSettingsDirectory, "auto-updater.jsonc"))).toString());
		autoUpdaterSettings = parsedJson as AutoUpdaterSettings;
		stopConsoleMessageTimer(ConsoleMessageId.LoadingAutoUpdaterSettings);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingAutoUpdaterSettings);
		throw err;
	}
};

export const loadMaintenanceSettings = async (): Promise<void> => {
	// Maintenance mode does not apply to developers.
	if (user.isDeveloper) {
		return;
	}

	const load = async (isAppStartLoad: boolean): Promise<void> => {
		try {
			const parsedJson: unknown = parse((await readFile(join(userSettings.appSettingsDirectory, "maintenance.jsonc"))).toString());
			maintenanceSettings = parsedJson as MaintenanceSettings;

			mainWindow.webContents.send(
				IpcMessage.GetMaintenanceSettings,
				JSON.stringify(maintenanceSettings)
			);
		} catch (err) {
			if (isAppStartLoad) {
				throw err;
			}

			// If not app start load, i.e., being called from interval below,
			// silently catching and logging errors since errors will occur if
			// computer is left on for an extended period of time and it's
			// disconnected from the VPN.
			log({
				type: "INFO",
				subType: "BACKEND",
				payload: String(err),
				bypassDatabase: true
			});
		}
	};

	// First time load (on app start up).
	try {
		addConsoleMessage({
			text: "Loading maintenance settings...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingMaintenanceSettings
		});

		await load(true);
		stopConsoleMessageTimer(ConsoleMessageId.LoadingMaintenanceSettings);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingMaintenanceSettings);
		throw err;
	}

	// Reload maintenance settings at the specified interval, or every 15
	// minutes if not defined.
	setInterval(() => {
		load(false);
	}, maintenanceSettings.reloadInterval || 900_000);
};

export const loadSnowflakeSettings = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading Snowflake settings...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingSnowflakeSettings
	});

	try {
		const parsedJson: unknown = parse((await readFile(join(userSettings.appSettingsDirectory, "snowflake.jsonc"))).toString());
		snowflakeSettings = parsedJson as SnowflakeSettings;
		snowflakeSettings.role = getSnowflakeRole();
		snowflakeSettings.warehouse = getSnowflakeWarehouse();
		snowflakeSettings.dataDumpDatabaseSchema = snowflakeSettings.dataDumpDatabaseSchema.toLowerCase();
		stopConsoleMessageTimer(ConsoleMessageId.LoadingSnowflakeSettings);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingSnowflakeSettings);
		throw err;
	}
};

const getSnowflakeRole = (): string => {
	let userRole = snowflakeSettings.roleForOthers;

	if (user.isFitMember) {
		userRole = snowflakeSettings.roleForFit;
	} else if (user.isDeveloper) {
		userRole = snowflakeSettings.roleForDeveloper;
	}

	return userRole;
};

const getSnowflakeWarehouse = (): string => {
	let warehouse = snowflakeSettings.warehouseForOthers;

	if (user.isFitMember) {
		warehouse = snowflakeSettings.warehouseForFit;
	} else if (user.isDeveloper) {
		warehouse = snowflakeSettings.warehouseForDeveloper;
	}

	return warehouse;
};

export const loadAnnouncementsForDialog = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading dialog announcements...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingDialogAnnouncements
	});

	try {
		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.appSettingsDirectory, "announcements-dialog.js")))[0];

		announcementsForDialog = JSON.stringify(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas
				}
			})
		);

		stopConsoleMessageTimer(ConsoleMessageId.LoadingDialogAnnouncements);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingDialogAnnouncements);
		throw err;
	}
};

export const loadAnnouncementsForConsole = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading console announcements...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingConsoleAnnouncements
	});

	try {
		const parsedJson: unknown = parse((await readFile(join(userSettings.appSettingsDirectory, "announcements-console.jsonc"))).toString());
		announcementsForConsole = parsedJson as AnnouncementsForConsole;
		stopConsoleMessageTimer(ConsoleMessageId.LoadingConsoleAnnouncements);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingConsoleAnnouncements);
		throw err;
	}
};

export const loadForcedAppQuitMessages = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading miscellaneous messages...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingForcedAppQuitMessages
	});

	try {
		const parsedJson: unknown = parse((await readFile(join(userSettings.appSettingsDirectory, "forced-app-quit-messages.jsonc"))).toString());
		forcedAppQuitMessages = parsedJson as Record<ExecutionState, string>;
		stopConsoleMessageTimer(ConsoleMessageId.LoadingForcedAppQuitMessages);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingForcedAppQuitMessages);
		throw err;
	}
};
