export interface CombinedSerffReport {
	state: string;
	productType: string;
	polFarmersCompanyId: string;
	polFarmersCompanyName: string;
	numPolicies: number;
	modPremCurrent: number;
	modPremProposed: number;
	impact: number;
	dollarChange: number;
	maxPolicyChange: number;
	minPolicyChange: number;
}
