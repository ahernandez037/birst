import {ipcMain} from "electron";
import {logAsync} from "../logger";
import {mainWindow} from "../main";
import {isFileOpen} from "../utilities";
import {IpcMessage} from "../ipc-handlers";
import {createCombinedSerffReport, getCombinedSerffReportFilepath} from "./create";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer
} from "../console-message";

export const serffIpcHandler = (): void => {
	ipcMain.on(IpcMessage.CreateCombinedSerffReport, async () => {
		try {
			if (await isFileOpen(getCombinedSerffReportFilepath())) {
				addConsoleMessage({text: `${Emoji.Error} Please close the existing file before proceeding.`});
				mainWindow.webContents.send(IpcMessage.DoneCreatingCombinedSerffReport);
				return;
			}

			addConsoleMessage({
				text: "Creating combined SERFF report...",
				hasTimer: true,
				timerId: ConsoleMessageId.CreatingCombinedSerffReport
			});
			await createCombinedSerffReport();
			addConsoleMessage({text: "Finished creating the combined SERFF report."});
		} catch (err) {
			addConsoleMessage({text: `${Emoji.Error} ${String(err)}`});
			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err)
			});
		} finally {
			stopConsoleMessageTimer(ConsoleMessageId.CreatingCombinedSerffReport);
			mainWindow.webContents.send(IpcMessage.DoneCreatingCombinedSerffReport);
		}
	});
};
