import {join} from "path";
import * as xlsx from "xlsx";
import {app} from "electron";
import {copy} from "fs-extra";
import {execute} from "../database";
import {CombinedSerffReport} from "./types";
import {userSettings} from "../user-settings";
import {scenarioFile} from "../scenario-file";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";

export const getCombinedSerffReportFilepath = (): string =>
	join(scenarioFile.scenarioForm.scenarioDirectory, "SERFF_Combined_Report.xlsm");

export const createCombinedSerffReport = async (): Promise<void> => {
	await createReport();
	const products = await getProducts();
	const records: CombinedSerffReport[][] = [];
	for (const product of products) {
		records.push(await getReport(product));
	}
	await createExcel(records);
};

const createReport = async (): Promise<void> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CreateCombinedSerffReport)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile
			}
		})
	);

	await execute({sqlText});
};

const getProducts = async (): Promise<string[]> => {
	const products: string[] = [];
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetCombinedSerffReportProducts)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas
			}
		})
	);

	const [, rs] = await execute({sqlText});

	if (rs) {
		for (const result of rs as Record<string, unknown>[]) {
			products.push(String(result["PRODUCT"]));
		}
	}

	return products;
};

const getReport = async (product: string): Promise<CombinedSerffReport[]> => {
	const records: CombinedSerffReport[] = [];
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetCombinedSerffReport)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				product
			}
		})
	);

	const [, rs] = await execute({sqlText});

	if (rs) {
		for (const result of rs as Record<string, unknown>[]) {
			records.push({
				state: String(result["STATE"]),
				productType: String(result["PRODUCT_TYPE"]),
				polFarmersCompanyId: String(result["POL_FARMERS_COMPANY_ID"]),
				polFarmersCompanyName: String(result["POL_FARMERS_COMPANY_NAME"]),
				numPolicies: Number(result["NUM_POLICIES"]),
				modPremCurrent: Number(result["MOD_PREM_CURRENT"]),
				modPremProposed: Number(result["MOD_PREM_PROPOSED"]),
				impact: Number(result["IMPACT"]),
				dollarChange: Number(result["DOLLAR_CHANGE"]),
				maxPolicyChange: Number(result["MAX_POLICY_CHANGE"]),
				minPolicyChange: Number(result["MIN_POLICY_CHANGE"])
			});
		}
	}

	return records;
};

const createExcel = async (reports: CombinedSerffReport[][]): Promise<void> => {
	await copy(
		join(userSettings.excelTemplatesDirectory, "serff-combined-report-template.xlsm"),
		getCombinedSerffReportFilepath()
	);

	const wb = xlsx.readFile(getCombinedSerffReportFilepath(), {
		bookVBA: true,
		cellFormula: true
	});
	const ws = wb.Sheets["for_serff"];

	// Data insertion starts at row three.
	let row = 3;
	for (const report of reports) {
		xlsx.utils.sheet_add_json(ws, report, {
			header: [
				"state",
				"productType",
				"polFarmersCompanyId",
				"polFarmersCompanyName",
				"numPolicies",
				"modPremCurrent",
				"modPremProposed",
				"impact",
				"dollarChange",
				"maxPolicyChange",
				"minPolicyChange"
			],
			skipHeader: true,
			origin: `A${row}`
		});
		// Go down another six rows to insert next set of data.
		row += 6;
	}

	xlsx.writeFile(wb, getCombinedSerffReportFilepath(), {
		compression: true,
		bookType: "xlsm"
	});
};
