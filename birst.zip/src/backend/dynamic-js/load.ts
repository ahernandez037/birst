import {parse} from "path";
import {readFile} from "fs-extra";
import {log} from "../logger";
import {DANGEROUS_KEYWORDS, DynamicJsFunction} from "./types";

export const loadDynamicJsFunction = async (filepath: string): Promise<[DynamicJsFunction]> => {
	log({
		type: "INFO",
		subType: "BACKEND",
		payload: `Loading dynamic JS function: ${filepath}`,
		bypassDatabase: true
	});

	const functionBody = await readFile(filepath, "utf8");
	const functionName = parse(filepath).name;
	const dangerousKeyword = getDangerousKeyword(functionBody);

	if (dangerousKeyword) {
		throw new Error(`Potentially dangerous keyword "${dangerousKeyword}" found in dynamic JavaScript function "${functionName}".`);
	}

	return [
		{
			name: functionName,
			body: functionBody
		}
	];
};

const getDangerousKeyword = (functionBody: string): string => {
	let output = "";

	for (const keyword of DANGEROUS_KEYWORDS) {
		if (functionBody.toUpperCase().includes(keyword.toUpperCase() + "(")) {
			output = keyword;
		}
	}

	return output;
};
