import * as sf from "snowflake-sdk";
import {logAsync} from "../logger";
import {SnowflakeSettings} from "../app-settings";
import {
	addConsoleMessage,
	ConsoleMessageId,
	Emoji,
	stopConsoleMessageTimer
} from "../console-message";

export let connection: sf.Connection | null = null;

export const connect = (args: {
	userEmailAddress: string;
	snowflakeSettings: SnowflakeSettings;
}): Promise<void> => {
	addConsoleMessage({
		text: "Connecting to database...",
		hasTimer: true,
		timerId: ConsoleMessageId.ConnectingToDatabase
	});

	return new Promise((resolve, reject) => {
		sf.createConnection({
			username: args.userEmailAddress,
			account: args.snowflakeSettings.account,
			authenticator: args.snowflakeSettings.authenticator,
			role: args.snowflakeSettings.role,
			warehouse: args.snowflakeSettings.warehouse,
			database: args.snowflakeSettings.database,
			schema: args.snowflakeSettings.schema,
			clientSessionKeepAlive: true
		})
			.connectAsync((err, conn) => {
				if (err) {
					reject(err);
					return;
				}

				connection = conn;
				resolve();
			})
			.catch(async (err) => {
				addConsoleMessage({text: `${Emoji.Error} ${String(err)}`});
				addConsoleMessage({text: `${Emoji.Warning} Confirm you are connected to the VPN and restart the application.`});
				await logAsync({type: "ERROR", subType: "BACKEND", payload: String(err)});
			})
			.finally(() => {
				stopConsoleMessageTimer(ConsoleMessageId.ConnectingToDatabase);
			});
	});
};
