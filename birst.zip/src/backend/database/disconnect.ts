import {log} from "../logger";
import {connection} from "./connect";

export const disconnect = (): Promise<void> => {
	log({
		type: "INFO",
		subType: "BACKEND",
		payload: "Disconnecting from database.",
		bypassDatabase: true
	});

	return new Promise((resolve, reject) => {
		if (!connection) {
			resolve();
			return;
		}

		connection.destroy((err) => {
			if (err) {
				reject(err);
				return;
			}

			resolve();
		});
	});
};
