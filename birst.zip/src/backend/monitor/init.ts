import {join} from "path";
import {app, MessageBoxOptions, dialog} from "electron";
import {logAsync} from "../logger";
import {mainWindow} from "../main";
import {execute} from "../database";
import {IpcMessage} from "../ipc-handlers";
import {userSettings} from "../user-settings";
import {AccessLog, ImportantMessage, Runtime, ScenarioRun} from "./types";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";

let refreshInterval: NodeJS.Timer;
let isInitialLoad = true;
let previousNumberOfErrorMessages = 0;

export const initMonitor = (): void => {
	getMonitorData();

	// Default to 30 minutes (converted to milliseconds).
	refreshInterval = setInterval(async () => {
		getMonitorData();
	}, 30 * 60 * 1000);
};

export const updateRefreshInterval = (refreshIntervalMinutes: number): void => {
	clearInterval(refreshInterval);

	// Convert minutes to milliseconds.
	refreshInterval = setInterval(async () => {
		getMonitorData();
	}, refreshIntervalMinutes * 60 * 1000);
};

export const getMonitorData = async (): Promise<void> => {
	const [importantMessages, accessLog, scenarioRuns, runtimes] = await Promise.all([
		loadImportantMessages(),
		loadAccessLogs(),
		loadScenarioRuns(),
		loadRuntimes()
	]);

	if (userSettings.isMonitorNotificationOn) {
		checkForNewErrorMessages(
			importantMessages.filter((importantMessage) => importantMessage.type === "ERROR")
				.length
		);
	}

	mainWindow.webContents.send(
		IpcMessage.GetMonitorData,
		JSON.stringify(importantMessages),
		JSON.stringify(accessLog),
		JSON.stringify(scenarioRuns),
		JSON.stringify(runtimes)
	);
};

const checkForNewErrorMessages = (newNumberOfErrorMessages: number): void => {
	if (isInitialLoad) {
		isInitialLoad = false;
		previousNumberOfErrorMessages = newNumberOfErrorMessages;
		return;
	}

	if (newNumberOfErrorMessages > previousNumberOfErrorMessages) {
		alertThereAreNewErrorMessages();
	}

	previousNumberOfErrorMessages = newNumberOfErrorMessages;
};

const alertThereAreNewErrorMessages = async (): Promise<void> => {
	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		noLink: true,
		title: " BIRST Monitor Notification",
		message: "There are new error messages."
	};

	await dialog.showMessageBox(mainWindow, dialogOptions);
};

const loadImportantMessages = async (): Promise<ImportantMessage[]> => {
	const importantLogMessages: ImportantMessage[] = [];

	try {
		const rs = await queryDatabase(SqlFunctionFile.GetMonitorImportantMessages);

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				importantLogMessages.push({
					timestamp: new Date(String(result["CREATED_AT_UTC"])),
					type: String(result["TYPE"]),
					userId: String(result["USER_ID"]),
					scenarioId: String(result["SCENARIO_ID"]),
					payload: String(result["PAYLOAD"])
				});
			}
		}
	} catch (err) {
		await logAsync({
			type: "ERROR",
			subType: "BACKEND",
			payload: String(err)
		});
	}

	return importantLogMessages;
};

const loadAccessLogs = async (): Promise<AccessLog[]> => {
	const accessLogs: AccessLog[] = [];

	try {
		const rs = await queryDatabase(SqlFunctionFile.GetMonitorAccessLogs);

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				accessLogs.push({
					rowNumber: Number(result["ROW_NUM"]),
					userId: String(result["USER_ID"]),
					lastAccessed: new Date(String(result["LAST_ACCESSED"])),
					appVersion: String(result["APP_VERSION"])
				});
			}
		}
	} catch (err) {
		await logAsync({
			type: "ERROR",
			subType: "BACKEND",
			payload: String(err)
		});
	}

	return accessLogs;
};

const loadScenarioRuns = async (): Promise<ScenarioRun[]> => {
	const scenarioRuns: ScenarioRun[] = [];

	try {
		const rs = await queryDatabase(SqlFunctionFile.GetMonitorScenarioRuns);

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				scenarioRuns.push({
					date: new Date(String(result["DATE"])).toISOString().substring(0, 10),
					userId: String(result["USER_ID"]),
					numberOfRuns: Number(result["NUMBER_OF_RUNS"])
				});
			}
		}
	} catch (err) {
		await logAsync({
			type: "ERROR",
			subType: "BACKEND",
			payload: String(err)
		});
	}

	return scenarioRuns;
};

const loadRuntimes = async (): Promise<Runtime[]> => {
	const runtimes: Runtime[] = [];

	try {
		const rs = await queryDatabase(SqlFunctionFile.GetMonitorRuntimes);

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				runtimes.push({
					product: String(result["PRODUCT"]),
					numberOfRuns: Number(result["NUMBER_OF_RUNS"]),
					averageRuntimeInSeconds: Number(result["AVERAGE_RUNTIME_IN_SECONDS"]),
					averageRecordCount: Number(result["AVERAGE_RECORD_COUNT"])
				});
			}
		}
	} catch (err) {
		await logAsync({
			type: "ERROR",
			subType: "BACKEND",
			payload: String(err)
		});
	}

	return runtimes;
};

const queryDatabase = async (sqlFunctionFile: SqlFunctionFile): Promise<unknown[] | undefined> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, sqlFunctionFile)))[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas
			}
		})
	);
	const [, rs] = await execute({sqlText});

	return rs;
};
