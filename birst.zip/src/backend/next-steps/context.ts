import {join} from "path";
import {app} from "electron";
import {user} from "../user";
import {ScenarioForm} from "../scenario";
import {userSettings} from "../user-settings";
import {rateRevision} from "../rate-revision";
import {scenarioFile} from "../scenario-file";
import {executeDynamicJsFunction, loadDynamicJsFunction} from "../dynamic-js";

export const getFunctionByContext = async (
	scenarioForm: ScenarioForm,
	isScenarioFormValid: boolean
): Promise<string> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.nextStepsFunctionsDirectory, "get-function-by-context.js")))[0];

	return String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				isUserFitMember: user.isFitMember,
				isUserDeveloper: user.isDeveloper,
				scenarioForm: scenarioForm,
				isScenarioFormValid: isScenarioFormValid,
				scenarioFile: scenarioFile,
				rateRevision: rateRevision
			}
		})
	);
};
