import {ipcMain} from "electron";
import {logAsync} from "../logger";
import {IpcMessage} from "../ipc-handlers";
import {getFunctionByContext} from "./context";
import {getNextStepsFunctionValues} from "./values";
import {addConsoleMessage} from "../console-message";

export const nextStepsIpcHandler = (): void => {
	ipcMain.handle(IpcMessage.GetNextSteps, async (_event, payload) => {
		try {
			const scenarioForm = JSON.parse(payload[0]);
			const isScenarioFormValid = payload[1];
			const nextStepsFilename = await getFunctionByContext(scenarioForm, isScenarioFormValid);
			const nextSteps = await getNextStepsFunctionValues(nextStepsFilename, scenarioForm);
			return JSON.stringify(nextSteps);
		} catch (err) {
			addConsoleMessage({text: String(err)});

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err)
			});

			return null;
		}
	});
};
