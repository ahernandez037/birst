const htmlContent = `
	<p>Howdy! This is the default message! 😊</p>
`;

return { htmlContent, modalWidth: null, modalHeight: null, buttons: [] };
