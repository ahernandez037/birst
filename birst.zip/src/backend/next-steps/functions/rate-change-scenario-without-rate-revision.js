const htmlContent = `
	<p>
	It looks like you successfully ran a rate change scenario. If you achieved the desired rate impact and are ready to initiate the rate revision process, the recommended next steps are:
	</p>
	<ul>
	<li>
		Click on <b>Rate Revision</b> and then <b>Initiate Rate Revision</b>.
	</li>
	</ul>
	<p>
	For more information, please refer to the user's guide, which is found under
	the <b>Support</b> tab.
	</p>
`;

return { htmlContent, modalWidth: null, modalHeight: null, buttons: [] };
