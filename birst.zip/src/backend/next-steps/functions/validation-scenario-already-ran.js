const htmlContent = `
	<p>
	It looks like you entered all needed information and you have already ran the
	scenario. Based on this, the recommended next steps are:
	</p>
	<ul>
	<li>
		You may proceed with reviewing the output, i.e., the <b>Report</b> file
		and/or the <b>Data Dump</b>.
	</li>
	<li>
		Or, you can run the scenario again by clicking on <b>Scenario</b> and then
		<b>Run</b>.
	</li>
	</ul>
	<p>
	For more information, please refer to the user's guide, which is found under
	the <b>Support</b> tab.
	</p>
`;

return { htmlContent, modalWidth: null, modalHeight: null, buttons: [] };
