export interface NextSteps {
	htmlContent: string;
	modalWidth: number;
	modalHeight: number;
	buttons: [{ text: string; type: "WEBSITE" | "DIRECTORY"; url: string }];
}
