import {dialog, ipcMain, MessageBoxOptions, Notification, shell} from "electron";
import {logAsync} from "../logger";
import {IpcMessage} from "../ipc-handlers";
import {ExecutionState} from "../app-settings";
import {mainWindow, updateExecutionState} from "../main";
import {addConsoleMessage, Emoji} from "../console-message";
import {prefillScenarioFile, saveScenarioFile} from "../scenario-file";
import {createRatesFile, resetRatesFile, applicableRateTables} from "./create";
import {doesRatesFileExist, isRatesFileOpen, getRatesFileAbsoluteFilepath} from "./file";

export const ratesFileIpcHandler = (): void => {
	ipcMain.on(IpcMessage.CreateRatesFile, async (_event, payload) => {
		resetRatesFile();

		try {
			prefillScenarioFile(JSON.parse(payload));

			if (await isRatesFileOpen()) {
				throw new Error(`${Emoji.Error} The rates file is currently open. Please close the file before proceeding.`);
			}

			if (!(await doesUserWantToOverwrite())) {
				mainWindow.webContents.send(IpcMessage.CreateRatesFileCanceled);
				addConsoleMessage({text: "Action has been canceled."});
				return;
			}

			updateExecutionState(ExecutionState.CreatingRatesFile);
			await saveScenarioFile();
			await createRatesFile();
			mainWindow.webContents.send(IpcMessage.CreateRatesFileSuccess);
			addConsoleMessage({text: `Number of tables: ${applicableRateTables.length}`});

			new Notification({
				title: `${Emoji.Bell} The rates file has been created`,
				body: `Number of tables: ${applicableRateTables.length}`
			}).show();
		} catch (err) {
			if (String(err).includes("The rates file is currently open. Please close the file before proceeding.")) {
				addConsoleMessage({text: `${Emoji.Warning} The rates file is currently open. Please close the file before proceeding.`});

				await logAsync({
					type: "WARNING",
					subType: "BACKEND",
					payload: `The rates file is currently open: ${getRatesFileAbsoluteFilepath()}`
				});
			} else {
				addConsoleMessage({text: `${Emoji.Error} ${String(err)}`});
				await logAsync({type: "ERROR", subType: "BACKEND", payload: String(err)});
			}

			mainWindow.webContents.send(IpcMessage.CreateRatesFileError);
		} finally {
			updateExecutionState(ExecutionState.AtRest);
		}
	});

	ipcMain.on(IpcMessage.OpenRatesFile, (_event, payload) => {
		prefillScenarioFile(JSON.parse(payload));

		if (doesRatesFileExist()) {
			shell.openExternal(getRatesFileAbsoluteFilepath()).catch(async (err) => {
				const errString = String(err);
				addConsoleMessage({text: `${Emoji.Error} ${errString}`});
				await logAsync({type: "ERROR", subType: "BACKEND", payload: errString});
			});
		} else {
			mainWindow.webContents.send(IpcMessage.RatesFileDoesNotExist);
		}
	});
};

const doesUserWantToOverwrite = async (): Promise<boolean> => {
	if (!doesRatesFileExist()) {
		return true;
	}

	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["Yes", "No"],
		defaultId: 1,
		cancelId: 1,
		noLink: true,
		title: " Confirmation Required",
		message: "The rates file already exists. Are you sure you want to overwrite it?"
	};

	return (await dialog.showMessageBox(mainWindow, dialogOptions)).response === 0 ? true : false;
};
