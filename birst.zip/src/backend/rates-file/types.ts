/**
 * Used when reading the "table_list" worksheet from the rates file.
 */
export interface TableListRow {
	"In Scope": string;
	"Programmed in RE": string;
	"RB Effective Date": Date;
	"Full Table Name": string;
	"CLS Table Number": string;
	"Ratabase System Name": string;
	Comments: string;
}

/**
 * Used to create an array of all rate tables for the given scenario. Data
 * sourced from prd_bizdb_coml.birst_tool.rate_table_list.
 */
export interface RateTable {
	fullTableName: string;
	/**
	 * This table name should be no more than 31 characters long, to comply with
	 * Excel's worksheet name character limit.
	 */
	ratesFileTableName: string;
	programmedInRatingEngine: string;
	isOpenForProposedRates: boolean;
	clsTableNumber: string;
	ratabaseSystemName: string;
	commentsForRatesFile: string;
}

/**
 * Used to create an array of only the applicable rate tables, i.e., excludes
 * any empty tables.
 */
export type ApplicableRateTable = {
	previousRevisionRenewalDate: Date;
} & RateTable;

/**
 * Used to create an array of objects that's used to determine which fields are
 * rate/factor fields that are open to modification for proposed rates.
 */
export interface RateFields {
	global: [
		{
			fieldName: string;
			isPercentChange: boolean;
		},
	];
	unique: [
		{
			tableName: string;
			fieldName: string;
			isPercentChange: boolean;
		},
	];
}

/**
 * Used to create an array of the "ORDER BY" clauses which are passed to the
 * SQL function that queries the rate tables.
 */
export interface RateTableOrderBy {
	tableName: string;
	orderBy: string;
}

/**
 * Used to keep track of the components that go into creating the Excel formula
 * for the "Target Count" & "Changed Target Count" columns of the "table_list"
 * worksheet. Each "_PROPOSED" column from a rate table requires its own
 * component.
 */
export interface TargetCount {
	tableName: string;
	components: string[];
}

/**
 * Used to create array of these objects that will contain the processed/cleaned
 * data to upload to the database.
 */
export interface RateTableForUpload {
	tableName: string;
	records: Record<string, unknown>[];
}

export interface InScopeRateTable {
	fullTableName: string;
	ratesFileTableName: string;
}

export interface ClsTableRecord {
	company: string;
	clsValue: string;
	clsTable: string;
	clsOrder: string;
}

/**
 * List of Work Comp tables that need special handling, such as because the
 * rates for these tables may be overridden by rates from the rating bureau
 * (when the user selects to adopt the bureau rates). Or tables that are used to
 * override certain mappings, e.g., class codes.
 */
export const SPECIAL_WC_TABLES = [
	"WC_BUREAU_LC",
	"WC_CAT",
	"WC_TERRORISM",
	"WC_HAZARD_CODE",
	"WC_MINIMUM_PREMIUM_NONBUREAU",
	"WC_MINIMUM_PREMIUM_OVERRIDE",
	"WC_CLASS_CODE_MAPPING",
	"WC_DEVIATION",
	"WC_PAYROLL_USLH"
];

/**
 * Files with list of rate table fields to ignore, i.e., do not include them in
 * the rates file tables.
 */
export const RATES_FILE_IGNORED_FIELDS_FILENAME = {
	"AUTO-AUTO": "auto.jsonc",
	"AUTO-GAR": "garage.jsonc",
	"CMP-ASR": "cmp-asr.jsonc",
	"CMP-CON": "cmp-con.jsonc",
	"CMP-HAB": "cmp-hab.jsonc",
	"CMP-MFG": "cmp-mfg.jsonc",
	"CMP-REA": "cmp-rea.jsonc",
	"CMP-ROS": "cmp-ros.jsonc",
	"CMP-RST": "cmp-rst.jsonc",
	"CMP-WHL": "cmp-whl.jsonc",
	UMB: "umbrella.jsonc",
	WC: "work-comp.jsonc"
} as const;

/**
 * Files that contain the rate table fields for the rates/factors that are open
 * to change, i.e., for proposed rates.
 */
export const RATES_FILE_RATE_FIELDS_FILENAME = {
	"AUTO-AUTO": "auto.jsonc",
	"AUTO-GAR": "garage.jsonc",
	"CMP-ASR": "cmp-asr.jsonc",
	"CMP-CON": "cmp-con.jsonc",
	"CMP-HAB": "cmp-hab.jsonc",
	"CMP-MFG": "cmp-mfg.jsonc",
	"CMP-REA": "cmp-rea.jsonc",
	"CMP-ROS": "cmp-ros.jsonc",
	"CMP-RST": "cmp-rst.jsonc",
	"CMP-WHL": "cmp-whl.jsonc",
	UMB: "umbrella.jsonc",
	WC: "work-comp.jsonc"
} as const;

/**
 * Object used to look up the rate table 'ORDER BY' settings file for each
 * product. These are the files that the 'RatesFile' module uses to pass the
 * "ORDER BY" clause to the SQL functions used to query rate tables.
 */
export const RATES_FILE_ORDER_BY_FILENAME = {
	"AUTO-AUTO": "auto.jsonc",
	"AUTO-GAR": "garage.jsonc",
	"CMP-ASR": "cmp-asr.jsonc",
	"CMP-CON": "cmp-con.jsonc",
	"CMP-HAB": "cmp-hab.jsonc",
	"CMP-MFG": "cmp-mfg.jsonc",
	"CMP-REA": "cmp-rea.jsonc",
	"CMP-ROS": "cmp-ros.jsonc",
	"CMP-RST": "cmp-rst.jsonc",
	"CMP-WHL": "cmp-whl.jsonc",
	UMB: "umbrella.jsonc",
	WC: "work-comp.jsonc"
} as const;

/* Not all legacy rate tables have new business effective dates and/or written
dates and therefore need special handling. */
export const TABLES_WITHOUT_NB_EFF_DATE = [
	"ART_BTU_V5_1",
	"ART_BUS_ESTBL_YR",
	"ART_CREDIT_V5_1",
	"ART_EXPERIENCE_V5_1",
	"ART_DRIVER_RATING_V5_1",
	"ART_MED_BASE_V5",
	"ART_MED_ILF_V5",
	"ART_MILEAGE",
	"ART_PIP_BASE_V5",
	"ART_PIP_LIM_V5",
	"ART_PIP_STACK",
	"ART_POP_ACTIVATOR",
	"ART_POP_FACTOR",
	"ART_REINST_SURCHARGE",
	"ART_SIC_V5_1",
	"ART_ZIP_TERR_EXP",
	"ART_ACCT_COMP",
	"ART_ANTITHEFT",
	"ART_BASERATE",
	"ART_BASERATEV1",
	"ART_BASERATEV1_MI_BIPD_TTT",
	"ART_BASERATEV1_MI_COLL",
	"ART_BC",
	"ART_BC_V5",
	"ART_BCFACTORS",
	"ART_BTFACTORS",
	"ART_BTI",
	"ART_BTIV5",
	"ART_BTU",
	"ART_BTU_V5",
	"ART_BUS_ENTITY",
	"ART_BUS_EXTENSION",
	"ART_BUS_PERS_USE",
	"ART_CA_WAIV_COLL_DED",
	"ART_CILF",
	"ART_CORP_DISC",
	"ART_CREDIT",
	"ART_DED_COST_TYPE",
	"ART_DOC",
	"ART_DRIVER_PU_RATIO",
	"ART_DRIVER_RATING",
	"ART_DRIVER_RATING_V4",
	"ART_EARLY_SHOP",
	"ART_EXPERIENCE",
	"ART_EXPERIENCE_V5",
	"ART_EXPMOD_LEGACY_91743",
	"ART_FELLOW_EC",
	"ART_FLEET_LEG",
	"ART_FLEET_V4",
	"ART_FULL_PAY_DISC",
	"ART_GLASS_DED",
	"ART_GLS_DED_LEGACY",
	"ART_GOOD_PAY_DISC",
	"ART_HIRED_CAR",
	"ART_LEASE_LOAN",
	"ART_LIAB_VEHAGE",
	"ART_MED_BASE_PPT",
	"ART_MED_BASE_TTT",
	"ART_MI_COLL_BROAD_ADDL_CHG",
	"ART_MI_COLL_TYPE_92474",
	"ART_MI_INTER_INTRA_92473",
	"ART_MINPREM",
	"ART_MISC_RATES",
	"ART_MODELYEAR",
	"ART_NO_PRIOR_INS",
	"ART_NON_OWN",
	"ART_PACKAGE",
	"ART_PACKAGE_V4",
	"ART_PACKAGE_V5",
	"ART_PART_NONOWN",
	"ART_PASSIVE_RESTRAINT",
	"ART_PHYSD_VEHAGE",
	"ART_PIP_ADDL_A",
	"ART_PIP_ATTENDANTCARE",
	"ART_PIP_BASE_LEGACY_PPT",
	"ART_PIP_BASE_LEGACY_TTT",
	"ART_PIP_BASE_LEGACY_TTT_TX",
	"ART_PIP_BASE_V4",
	"ART_PIP_BASE_V4_TX",
	"ART_PIP_COORD",
	"ART_PIP_DED",
	"ART_PIP_DED_FL",
	"ART_PIP_EXCLUSION",
	"ART_PIP_LIM",
	"ART_PIP_WORK_LOSS",
	"ART_PL_DISC",
	"ART_PPI_BASE",
	"ART_PPI_DED",
	"ART_PPT_COLL_DED",
	"ART_PPT_COMP_DED",
	"ART_PRICERANGE",
	"ART_PRIMARY",
	"ART_RADIUS",
	"ART_RATE_CAP",
	"ART_RLM",
	"ART_SCH_ELIG",
	"ART_SCH_RNG",
	"ART_SECONDARY",
	"ART_SIC",
	"ART_SILF",
	"ART_SPEC_EQUIP",
	"ART_SYMBOL",
	"ART_SYMBOL_BIPD",
	"ART_SYMBOL_PHYSD",
	"ART_TERR",
	"ART_TERR_V5",
	"ART_TIER_CHG",
	"ART_TIER_CITATIONS",
	"ART_TIER_FACTOR",
	"ART_TIER_FLEET",
	"ART_TIER_PFRS",
	"ART_TIER_YEARS",
	"ART_TIER_YOUTH",
	"ART_TOW",
	"ART_TTT_COLL_DED",
	"ART_TTT_COMP_DED",
	"ART_TX_PPT_CLASS_DIFF",
	"ART_TX_PPT_DED_DIFF",
	"ART_TX_PPT_MED_PIP_BASERATE",
	"ART_TX_PPT_MED_PIP_ILF",
	"ART_TX_PPT_VALUE_SYM_DIFF",
	"ART_TX_PREM_DISC_W_BUS_GARAGE",
	"ART_TX_PREM_DISC_WO_SCHOOL_BUS",
	"ART_TXPRICEGROUP",
	"ART_UIM_LEG_BASE_CSL",
	"ART_UIM_LEG_BASE_SPLIT",
	"ART_UIM_LEG_BASE_STNDALN",
	"ART_UIM_LEG_ILF_CSL_STNDALN",
	"ART_UIM_LEG_ILF_SPLIT_STNDALN",
	"ART_UM_ADD_ON",
	"ART_UM_BASE",
	"ART_UM_BASE_CT",
	"ART_UM_BTU",
	"ART_UM_DED",
	"ART_UM_DOC_BASE",
	"ART_UM_HNA_759",
	"ART_UM_ILF",
	"ART_UM_ILF_CT",
	"ART_UM_ILF_SPLIT",
	"ART_UM_ILF_V5",
	"ART_UM_LEG_BASE",
	"ART_UM_LEG_BASE_VA",
	"ART_UM_LEG_ILF_CSL",
	"ART_UM_LEG_ILF_SPLIT",
	"ART_UM_STACK_FCT",
	"ART_UM_SYMBOL",
	"ART_UMPD_ILF",
	"ART_UMPD_LEG_BASE",
	"ART_VEH_TECH_DISC",
	"ART_YEARS_IN_BUS",
	"ART_ZIP_TERR",
	"ASR_PROP_DED",
	"ASR_SPRINKLERED",
	"CON_PROP_DED",
	"CON_SPRINKLERED",
	"GAR_RLM",
	"MFG_PROP_DED",
	"MFG_SPRINKLERED",
	"WHL_PROP_DED",
	"WHL_SPRINKLERED"
];

export const TABLES_WITHOUT_WRITTEN_DATE = [
	"ART_BTU_V5_1",
	"ART_BUS_ESTBL_YR",
	"ART_CREDIT_V5_1",
	"ART_DRIVER_RATING_V5_1",
	"ART_MED_BASE_V5",
	"ART_MED_ILF_V5",
	"ART_MILEAGE",
	"ART_PIP_BASE_V5",
	"ART_PIP_LIM_V5",
	"ART_PIP_STACK",
	"ART_POP_ACTIVATOR",
	"ART_POP_FACTOR",
	"ART_REINST_SURCHARGE",
	"ART_SIC_V5_1",
	"ART_ZIP_TERR_EXP",
	"ART_EXPERIENCE_V5_1",
	"ART_ACCT_COMP",
	"ART_ANTITHEFT",
	"ART_BASERATE",
	"ART_BASERATEV1",
	"ART_BASERATEV1_MI_BIPD_TTT",
	"ART_BASERATEV1_MI_COLL",
	"ART_BC",
	"ART_BC_V5",
	"ART_BCFACTORS",
	"ART_BDND_POLL_CNTR_TOOLS",
	"ART_BTFACTORS",
	"ART_BTI",
	"ART_BTIV5",
	"ART_BTU",
	"ART_BTU_V5",
	"ART_BUS_ENTITY",
	"ART_BUS_EXTENSION",
	"ART_BUS_PERS_USE",
	"ART_CA_WAIV_COLL_DED",
	"ART_CILF",
	"ART_CORP_DISC",
	"ART_CREDIT",
	"ART_DED_COST_TYPE",
	"ART_DOC",
	"ART_DRIVER_PU_RATIO",
	"ART_DRIVER_RATING",
	"ART_DRIVER_RATING_V4",
	"ART_EARLY_SHOP",
	"ART_EXPERIENCE",
	"ART_EXPERIENCE_V5",
	"ART_EXPMOD_LEGACY_91743",
	"ART_FELLOW_EC",
	"ART_FLEET_LEG",
	"ART_FLEET_V4",
	"ART_FULL_PAY_DISC",
	"ART_GLASS_DED",
	"ART_GLS_DED_LEGACY",
	"ART_GOOD_PAY_DISC",
	"ART_HIRED_CAR",
	"ART_LEASE_LOAN",
	"ART_LIAB_VEHAGE",
	"ART_MED_BASE_PPT",
	"ART_MED_BASE_TTT",
	"ART_MI_COLL_BROAD_ADDL_CHG",
	"ART_MI_COLL_TYPE_92474",
	"ART_MI_INTER_INTRA_92473",
	"ART_MINPREM",
	"ART_MISC_RATES",
	"ART_MODELYEAR",
	"ART_NO_PRIOR_INS",
	"ART_NON_OWN",
	"ART_PACKAGE",
	"ART_PACKAGE_V4",
	"ART_PACKAGE_V5",
	"ART_PART_NONOWN",
	"ART_PASSIVE_RESTRAINT",
	"ART_PHYSD_VEHAGE",
	"ART_PIP_ADDL_A",
	"ART_PIP_ATTENDANTCARE",
	"ART_PIP_BASE_LEGACY_PPT",
	"ART_PIP_BASE_LEGACY_TTT",
	"ART_PIP_BASE_LEGACY_TTT_TX",
	"ART_PIP_BASE_V4",
	"ART_PIP_BASE_V4_TX",
	"ART_PIP_COORD",
	"ART_PIP_DED",
	"ART_PIP_DED_FL",
	"ART_PIP_EXCLUSION",
	"ART_PIP_LIM",
	"ART_PIP_WORK_LOSS",
	"ART_PL_DISC",
	"ART_PPI_BASE",
	"ART_PPI_DED",
	"ART_PPT_COLL_DED",
	"ART_PPT_COMP_DED",
	"ART_PRICERANGE",
	"ART_PRIMARY",
	"ART_RADIUS",
	"ART_RATE_CAP",
	"ART_RLM",
	"ART_SCH_ELIG",
	"ART_SCH_RNG",
	"ART_SECONDARY",
	"ART_SIC",
	"ART_SILF",
	"ART_SPEC_EQUIP",
	"ART_SYMBOL",
	"ART_SYMBOL_BIPD",
	"ART_SYMBOL_PHYSD",
	"ART_TERR",
	"ART_TERR_V5",
	"ART_TIER_CHG",
	"ART_TIER_CITATIONS",
	"ART_TIER_FACTOR",
	"ART_TIER_FLEET",
	"ART_TIER_PFRS",
	"ART_TIER_YEARS",
	"ART_TIER_YOUTH",
	"ART_TOW",
	"ART_TTT_COLL_DED",
	"ART_TTT_COMP_DED",
	"ART_TX_PPT_CLASS_DIFF",
	"ART_TX_PPT_DED_DIFF",
	"ART_TX_PPT_MED_PIP_BASERATE",
	"ART_TX_PPT_MED_PIP_ILF",
	"ART_TX_PPT_VALUE_SYM_DIFF",
	"ART_TX_PREM_DISC_W_BUS_GARAGE",
	"ART_TX_PREM_DISC_WO_SCHOOL_BUS",
	"ART_TXPRICEGROUP",
	"ART_UIM_LEG_BASE_CSL",
	"ART_UIM_LEG_BASE_SPLIT",
	"ART_UIM_LEG_BASE_STNDALN",
	"ART_UIM_LEG_ILF_CSL_STNDALN",
	"ART_UIM_LEG_ILF_SPLIT_STNDALN",
	"ART_UM_ADD_ON",
	"ART_UM_BASE",
	"ART_UM_BASE_CT",
	"ART_UM_BTU",
	"ART_UM_DED",
	"ART_UM_DOC_BASE",
	"ART_UM_HNA_759",
	"ART_UM_ILF",
	"ART_UM_ILF_CT",
	"ART_UM_ILF_SPLIT",
	"ART_UM_ILF_V5",
	"ART_UM_LEG_BASE",
	"ART_UM_LEG_BASE_VA",
	"ART_UM_LEG_ILF_CSL",
	"ART_UM_LEG_ILF_SPLIT",
	"ART_UM_STACK_FCT",
	"ART_UM_SYMBOL",
	"ART_UMPD_ILF",
	"ART_UMPD_LEG_BASE",
	"ART_VEH_TECH_DISC",
	"ART_YEARS_IN_BUS",
	"ART_ZIP_TERR",
	"ASR_PROP_DED",
	"ASR_SPRINKLERED",
	"CON_PROP_DED",
	"CON_SPRINKLERED",
	"GAR_RLM",
	"MFG_PROP_DED",
	"MFG_SPRINKLERED",
	"WHL_PROP_DED",
	"WHL_SPRINKLERED"
];
