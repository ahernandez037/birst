import {join} from "path";
import {existsSync} from "fs-extra";
import {isFileOpen} from "../utilities";
import {scenarioFile} from "../scenario-file";

export const isRatesFileOpen = async (): Promise<boolean> =>
	await isFileOpen(getRatesFileAbsoluteFilepath());

export const doesRatesFileExist = (): boolean => {
	return !!scenarioFile.files.ratesFile && existsSync(getRatesFileAbsoluteFilepath());
};

export const getRatesFileAbsoluteFilepath = (): string => {
	return join(scenarioFile.scenarioForm.scenarioDirectory, scenarioFile.files.ratesFile);
};
