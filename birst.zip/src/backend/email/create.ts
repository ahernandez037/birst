import {join} from "path";
import {app} from "electron";
import {randomUUID} from "crypto";
import {spawn} from "child_process";
import {outputFile, remove} from "fs-extra";
import {user} from "../user";
import {logAsync} from "../logger";
import {executionState} from "../main";
import {getUncPath} from "../utilities";
import {ScenarioForm} from "../scenario";
import {loadEmailRecipients} from "./load";
import {scenarioFile} from "../scenario-file";
import {rateRevision} from "../rate-revision";
import {getFormattedDates} from "../utilities";
import {EmailTrigger, EmailRecipient, MAP_TRIGGER_TO_FILE} from "./types";
import {executeDynamicJsFunction, loadDynamicJsFunction} from "../dynamic-js";
import {userSettings, USER_LOG_FILE, USER_TEMP_DIRECTORY} from "../user-settings";

export const createEmail = async (args: {
	emailTrigger: EmailTrigger;
	scenarioForm: ScenarioForm;
}): Promise<void> => {
	const [subject, body] = await getMessage({
		emailTrigger: args.emailTrigger,
		scenarioForm: args.scenarioForm
	});

	let [toRecipients, ccRecipients, bccRecipients] = getDistributionList({
		emailTrigger: args.emailTrigger,
		scenarioForm: args.scenarioForm,
		recipients: await loadEmailRecipients()
	});

	// Exit early if there are no recipients, i.e., don't create email.
	// An example of when this would occur is if a certain trigger has been
	// decommissioned, e.g, everyone is set to 'N/A' in the email_recipient
	// database table.
	if (!toRecipients && !ccRecipients && !bccRecipients) {
		return;
	}

	// Ensure that both the person who created the scenario, and the person
	// who initiated the rate revision, which could differ, are included in
	// the email.
	if (
		(
			args.emailTrigger === EmailTrigger.RateRevisionCanceled ||
			args.emailTrigger === EmailTrigger.RatesDeleted
		) &&
		!(toRecipients + ccRecipients + bccRecipients).includes(scenarioFile.createdByEmail.toLowerCase())
	) {
		toRecipients += `;${scenarioFile.createdByEmail.toLowerCase()}`;
	}

	if (
		(
			args.emailTrigger === EmailTrigger.RateRevisionCanceled ||
			args.emailTrigger === EmailTrigger.RatesDeleted
		) &&
		!(toRecipients + ccRecipients + bccRecipients).includes(scenarioFile.executiveSummary.rateRevisionInitiatedByEmail.toLowerCase())
	) {
		toRecipients += `;${scenarioFile.executiveSummary.rateRevisionInitiatedByEmail.toLowerCase()}`;
	}

	// If the person who is sending the email, i.e, the current user, is
	// included in the To/CC/BCC, take out their email address as they don't
	// need to email themselves.
	if (toRecipients.includes(userSettings.emailAddress.toLowerCase())) {
		toRecipients = toRecipients.replaceAll(userSettings.emailAddress.toLowerCase(), "");
	}

	if (ccRecipients.includes(userSettings.emailAddress.toLowerCase())) {
		ccRecipients = ccRecipients.replaceAll(userSettings.emailAddress.toLowerCase(), "");
	}

	if (bccRecipients.includes(userSettings.emailAddress.toLowerCase())) {
		bccRecipients = bccRecipients.replaceAll(userSettings.emailAddress.toLowerCase(), "");
	}

	const vbScript = `
		Dim outlook, email
		Set outlook = Wscript.CreateObject("Outlook.Application")
		Set mail = outlook.CreateItem(0)
		With mail
			.To = "${toRecipients}"
			.Cc = "${ccRecipients}"
			.Bcc = "${bccRecipients}"
			.Subject = "${subject}"
			.HTMLBody = "${body.replace(/(\r\n|\n|\r)/gm, "").replace(/"/g, "\"\"")}"
			${args.emailTrigger === EmailTrigger.ProblemReported ? `.Attachments.Add("${USER_LOG_FILE}")` : ""}
			${args.emailTrigger === EmailTrigger.ForcedAppQuit ? `.Attachments.Add("${await getUncPath(join(scenarioFile.scenarioForm.scenarioDirectory, scenarioFile.files.scenarioFile))}")` : ""}
			.Display
		End With
		Set mail = Nothing
		Set outlook = Nothing
	`;

	// Append UUID to filename to prevent collisions in case users are
	// running multiple instances of the application.
	const uuid = randomUUID();
	const vbScriptFilepath = join(USER_TEMP_DIRECTORY, "outbound-email-" + uuid + ".vbs");

	await outputFile(vbScriptFilepath, vbScript, {encoding: "utf8"});
	const cscript = spawn("C:\\Windows\\System32\\cscript.exe", [vbScriptFilepath]);

	cscript.stderr.on("data", (err) => {
		throw new Error(String(err));
	});

	cscript.on("close", async () => {
		await remove(vbScriptFilepath);
	});
};

const getMessage = async (args: {
	emailTrigger: EmailTrigger;
	scenarioForm?: ScenarioForm;
}): Promise<[string, string]> => {
	try {
		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.emailFunctionsDirectory, MAP_TRIGGER_TO_FILE[args.emailTrigger])))[0];
		const email = executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				appVersion: app.getVersion(),
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				isUserFitMember: user.isFitMember,
				isUserDeveloper: user.isDeveloper,
				scenarioForm: args.scenarioForm,
				scenarioFile: scenarioFile,
				rateRevision: rateRevision,
				formattedDates: getFormattedDates(),
				executionState: executionState
			}
		});

		return [
			(email as Record<string, string>)["subject"],
			(email as Record<string, string>)["body"]
		];
	} catch (err) {
		await logAsync({type: "ERROR", subType: "BACKEND", payload: String(err)});
		throw err;
	}
};

const getDistributionList = (args: {
	emailTrigger: EmailTrigger;
	scenarioForm: ScenarioForm;
	recipients: EmailRecipient[];
}): [string, string, string] => {
	const stepA = getFilteredByTrigger(args.emailTrigger, args.recipients);
	const stepB = getFilteredByProperty({
		recipients: stepA,
		scenarioForm: args.scenarioForm,
		property: "geoState"
	});
	const stepC = getFilteredByProperty({
		recipients: stepB,
		scenarioForm: args.scenarioForm,
		property: "lineOfBusiness"
	});
	const stepD = getFilteredByProperty({
		recipients: stepC,
		scenarioForm: args.scenarioForm,
		property: "product"
	});
	const allRecipients = getFilteredByProperty({
		recipients: stepD,
		scenarioForm: args.scenarioForm,
		property: "version"
	});

	return [
		getRecipientsByType("TO", args.emailTrigger, allRecipients),
		getRecipientsByType("CC", args.emailTrigger, allRecipients),
		getRecipientsByType("BCC", args.emailTrigger, allRecipients)
	];
};

const getFilteredByTrigger = (
	trigger: EmailTrigger,
	recipients: EmailRecipient[]
): EmailRecipient[] =>
	recipients.filter((recipient) => ["TO", "CC", "BCC"].includes(String(recipient[trigger as keyof EmailRecipient])));

const getFilteredByProperty = (args: {
	recipients: EmailRecipient[];
	scenarioForm: ScenarioForm;
	property: keyof Pick<EmailRecipient, "geoState" | "lineOfBusiness" | "product" | "version">;
}): EmailRecipient[] => {
	const applicableProperties = ["ALL", "N/A", args.scenarioForm[args.property]];
	return args.recipients.filter((recipient) => applicableProperties.some((prop) => recipient[args.property].includes(prop)));
};

const getRecipientsByType = (
	recipientType: "TO" | "CC" | "BCC",
	trigger: EmailTrigger,
	allRecipients: EmailRecipient[]
): string => {
	return allRecipients
		.filter((recipient) => recipient[trigger as keyof EmailRecipient] === recipientType)
		.map((recipient) => recipient.emailAddress.toLowerCase())
		.join(";");
};
