const subject = "[BIRST] Report a Problem";

const body = `
<br /><br />
<b>*** BIRST Automated Message Below ***</b>
<br /><br />
<span><b>appVersion:</b> ${args.appVersion}</span>
<br />
<span><b>isNodeJsDevEnv:</b> ${args.isNodeJsDevEnv}</span>
<br />
<span><b>isDatabaseDevEnv:</b> ${args.isDatabaseDevEnv}</span>
<br />
<span><b>isUserFitMember:</b> ${args.isUserFitMember}</span>
<br />
<span><b>isUserDeveloper:</b> ${args.isUserDeveloper}</span>
<br />
<span><b>scenarioForm:</b></span>
<br />
<span style="white-space: pre">${JSON.stringify(args.scenarioForm, null, 2)}</span>
<br />
<span><b>scenarioFile:</b></span>
<br />
<span style="white-space: pre">${JSON.stringify(args.scenarioFile, null, 2)}</span>
<br />
<span><b>rateRevision:</b></span>
<br />
<span style="white-space: pre">${JSON.stringify(args.rateRevision, null, 2)}</span>
<br />
<span><b>formattedDates:</b></span>
<br />
<span style="white-space: pre">${JSON.stringify(args.formattedDates, null, 2)}</span>
<br />
 `;

return { subject, body };
