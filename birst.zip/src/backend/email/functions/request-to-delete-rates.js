const state = args.scenarioFile.scenarioForm.geoState;

const lineOfBusiness =
	args.scenarioFile.scenarioForm.product === "GAR"
		? ""
		: ` ${args.scenarioFile.scenarioForm.lineOfBusiness}`;

const product =
	args.scenarioFile.scenarioForm.product === "N/A" ||
	args.scenarioFile.scenarioForm.product === "AUTO"
		? ""
		: ` ${args.scenarioFile.scenarioForm.product}`;

let version = "";

version =
	args.scenarioFile.scenarioForm.product === "AUTO"
		? ` v${args.scenarioFile.scenarioForm.version}`
		: version;

version =
	args.scenarioFile.scenarioForm.lineOfBusiness === "WC"
		? `${args.scenarioFile.scenarioForm.version}`
		: version;

const newBusinessDate = args.formattedDates.newDate;
const renewalDate = args.formattedDates.renewalDate;
const availableDate = args.formattedDates.availableDate;

const impactAmount =
	"$" + Number(args.scenarioFile.executiveSummary.impactAmount).toLocaleString("en-US");

const impactPercent =
	String((Number(args.scenarioFile.executiveSummary.impactPercent) * 100).toFixed(2)) + "%";

const directory = args.scenarioFile.scenarioForm.scenarioDirectory;
const hyperlink = `<a href="${directory}">${directory}</a>`;
const subject = `[BIRST] Request to Delete Rates - ${state}${lineOfBusiness}${product}${version} - Renewal Date: ${renewalDate}`;

const body = `
<b>Please provide a brief reason why the rates need to be deleted:</b>
<br /><br /><br /><br /><br />
<b>*** BIRST Automated Message Below ***</b>
<br /><br />
<p>This is a request to delete the rates for the rate revision listed below.</p>
<b>Next Steps:</b>
<br />
<ul>
	<li>
		<b>Technical Solutions Team:</b>
		<ul>
			<li>Open the scenario file for this product.</li>
			<li>
				Delete the rates from the database by clicking on 'Rate Revision' and then on
				'Delete Rates'
			</li>
		</ul>
	</li>
</ul>
<p>The BIRST files are located here: ${hyperlink}</p>
<b>Rate Revision Details:</b>
<table border="1" cellpadding="4" cellspacing="0">
	<tbody>
		<tr>
			<td bgcolor="#072A6C">Scenario ID</td>
			<td>${args.scenarioFile.scenarioForm.scenarioId}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">State</td>
			<td>${args.scenarioFile.scenarioForm.geoState}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Line of Business</td>
			<td>${args.scenarioFile.scenarioForm.lineOfBusiness}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Product</td>
			<td>${product}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Version</td>
			<td>${args.scenarioFile.scenarioForm.version}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">New Business Date</td>
			<td>${newBusinessDate}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Renewal Date</td>
			<td>${renewalDate}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Available Date</td>
			<td>${availableDate}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Impact Amount</td>
			<td>${impactAmount}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Impact Percent</td>
			<td>${impactPercent}</td>
		</tr>
	</tbody>
</table>
<br />
`;

return { subject, body };
