export interface AvailableDate {
	newDate: string;
	availableDate: string;
}
