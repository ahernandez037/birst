import {app} from "electron";
import {join} from "path";
import {log} from "../logger";
import {mainWindow} from "../main";
import {execute} from "../database";
import {AvailableDate} from "./types";
import {IpcMessage} from "../ipc-handlers";
import {userSettings} from "../user-settings";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const loadAvailableDates = async (): Promise<void> => {
	const availableDates: AvailableDate[] = [];

	addConsoleMessage({
		text: "Loading available dates...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingAvailableDates
	});

	log({
		type: "INFO",
		subType: "BACKEND",
		payload: "Loading available dates.",
		bypassDatabase: true
	});

	try {
		const rs = await queryDatabase();

		if (rs) {
			for (const r of rs as Record<string, unknown>[]) {
				availableDates.push({
					newDate: String(r["NEW_DATE"]),
					availableDate: String(r["AVAILABLE_DATE"])
				});
			}

			mainWindow.webContents.send(
				IpcMessage.UpdateAvailableDates,
				JSON.stringify(availableDates)
			);
		}

		stopConsoleMessageTimer(ConsoleMessageId.LoadingAvailableDates);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingAvailableDates);
		throw err;
	}
};

const queryDatabase = async (): Promise<unknown[] | undefined> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetAvailableDates)))[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas
			}
		})
	);
	const [, rs] = await execute({sqlText});

	return rs;
};
