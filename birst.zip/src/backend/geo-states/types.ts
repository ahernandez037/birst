export interface GeoState {
	name: string;
	abbreviation: string;
	number: number;
}
