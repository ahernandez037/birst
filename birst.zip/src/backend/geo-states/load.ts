import {join} from "path";
import {app} from "electron";
import {GeoState} from "./types";
import {mainWindow} from "../main";
import {execute} from "../database";
import {IpcMessage} from "../ipc-handlers";
import {userSettings} from "../user-settings";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const loadGeoStates = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading states...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingGeoStates
	});

	try {
		const geoStates: GeoState[] = [];
		const rs = await queryDatabase();

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				geoStates.push({
					name: String(result["STATE_NAME"]),
					abbreviation: String(result["STATE_CODE"]),
					number: Number(result["STATE_NUMBER"])
				});
			}

			mainWindow.webContents.send(IpcMessage.UpdateGeoStates, JSON.stringify(geoStates));
		}

		stopConsoleMessageTimer(ConsoleMessageId.LoadingGeoStates);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingGeoStates);
		throw err;
	}
};

const queryDatabase = async (): Promise<unknown[] | undefined> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetGeoStateList)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas
			}
		})
	);

	const [, rs] = await execute({sqlText});
	return rs;
};
