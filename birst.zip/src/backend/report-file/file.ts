import {join} from "path";
import * as fs from "fs-extra";
import {scenarioFile} from "../scenario-file";

export const doesReportFileExist = (): boolean => {
	if (!scenarioFile.scenarioForm.scenarioDirectory || !scenarioFile.files.reportFile) {
		return false;
	}

	return fs.existsSync(getReportFileAbsoluteFilepath());
};

export const getReportFileAbsoluteFilepath = (): string => {
	return join(scenarioFile.scenarioForm.scenarioDirectory, scenarioFile.files.reportFile);
};
