import {join} from "path";
import {app} from "electron";
import {execute} from "../database";
import {userSettings} from "../user-settings";
import {scenarioFile} from "../scenario-file";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const createReports = async (): Promise<void> => {
	addConsoleMessage({
		text: "Creating reports...",
		hasTimer: true,
		timerId: ConsoleMessageId.CreatingReports
	});

	try {
		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CreateReports)))[0];
		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
					scenarioFile
				}
			})
		);

		await execute({sqlText});
		stopConsoleMessageTimer(ConsoleMessageId.CreatingReports);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CreatingReports);
		throw err;
	}
};
