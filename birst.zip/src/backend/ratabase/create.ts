import * as xlsx from "xlsx";
import {DateTime} from "luxon";
import {app, Notification} from "electron";
import {pathExists, ensureDir, copy} from "fs-extra";
import {join} from "path";
import {logAsync} from "../logger";
import {execute} from "../database";
import {isFileOpen} from "../utilities";
import {userSettings} from "../user-settings";
import {scenarioFile} from "../scenario-file";
import {tablesForUpload} from "../rates-file/create";
import {RATABASE_EXCEL_TEMPLATE, RATABASE_FILE_PREFIX} from "./types";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {Emoji, addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const createRatabaseFiles = async (): Promise<void> => {
	// Return early if there are no in-scope tables.
	if (!tablesForUpload.length) {
		return;
	}

	try {
		addConsoleMessage({
			text: "Creating Ratabase files...",
			hasTimer: true,
			timerId: ConsoleMessageId.CreatingRatabaseTables
		});

		// Removing last 7 characters form the scenario directory, i.e., "\\BIRST".
		const ratabaseDirectory = scenarioFile.scenarioForm.scenarioDirectory.substring(0, scenarioFile.scenarioForm.scenarioDirectory.length - 6) + "\\IT\\Ratabase";

		if (!(await pathExists(ratabaseDirectory))) {
			await ensureDir(ratabaseDirectory);
		}

		if (["HAB", "REA", "ROS", "RST"].includes(scenarioFile.scenarioForm.product)) {
			await createForNewRaters(ratabaseDirectory);
		} else {
			await createForLegacyRaters(ratabaseDirectory);
		}

		addConsoleMessage({text: "Finished creating Ratabase files."});
		new Notification({title: `${Emoji.Bell} Finished creating Ratabase files`}).show();
		stopConsoleMessageTimer(ConsoleMessageId.CreatingRatabaseTables);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CreatingRatabaseTables);
		throw err;
	}
};

const createForNewRaters = async (directory: string): Promise<void> => {
	for (const table of tablesForUpload) {
		const filepath = join(directory, table.tableName + ".xlsx");

		if (await isFileOpen(filepath)) {
			const message = `Unable to create Ratabase file for table ${table.tableName} as the file is currently in use.`;
			addConsoleMessage({text: `${Emoji.Warning} ${message}`});

			await logAsync({
				type: "WARNING",
				subType: "BACKEND",
				payload: message
			});
		} else {
			const workbook = xlsx.utils.book_new();
			const worksheet = xlsx.utils.json_to_sheet(removeUnneededColumns(table.records));
			xlsx.utils.book_append_sheet(workbook, worksheet, "Data");
			xlsx.writeFile(workbook, filepath, {compression: true});
		}
	}
};

const removeUnneededColumns = (records: Record<string, unknown>[]): Record<string, unknown>[] => {
	const newRecords: Record<string, unknown>[] = [];

	for (const record of records) {
		newRecords.push(getFilteredRecord(record));
	}

	return newRecords;
};

const getFilteredRecord = (record: Record<string, unknown>): Record<string, unknown> => {
	const unneededProperties = ["UPLOAD_USER", "UPLOAD_DATE"];
	return Object.keys(record).reduce((object: Record<string, unknown>, key) => {
		if (!unneededProperties.includes(key)) {
			object[key] = record[key];
		}

		return object;
	}, {});
};

const createForLegacyRaters = async (directory: string): Promise<void> => {
	const tables = new Set<string>();

	for (const table of tablesForUpload) {
		tables.add(table.tableName);
	}

	// Work Comp has several mandatory Ratabase tables, i.e., the Ratabase
	// files must be created even if there aren't any rate changes.
	if (scenarioFile.scenarioForm.lineOfBusiness === "WC") {
		// For CATASTROPHE.
		tables.add("WC_CAT");
		// For CLASS_RATE_MIN_PREM.
		tables.add("WC_BUREAU_LC");
		// For COMPANY_MULTIPLIER.
		tables.add("WC_COMPANY_MULTIPLIER");
		// For EXPENSE_CONSTANT.
		tables.add("WC_EXPENSE_CONSTANT_NONBUREAU");
		// For TERRORISM.
		tables.add("WC_TERRORISM");
		// For CLASS_DEVIATION.
		tables.add("WC_DEVIATION");
	}

	for (const table of tables) {
		// The 'system name' is the name of the table in the Ratabase system
		// itself, which may (very likely) be different than the table name
		// in Snowflake.
		let systemName = await getSystemName(table);

		if (
			scenarioFile.scenarioForm.geoState === "IL" &&
			systemName.toUpperCase() === "MISC_CHARGE_BY_HAZARD_GRP"
		) {
			systemName = "SMALL_DEDUCTIBLE_DISCOUNT";
		}

		// If there is no system name then move on to the next table as the
		// system name is needed to create the output file.
		if (
			!systemName ||
			systemName.toUpperCase() === "NULL" ||
			systemName.toUpperCase() === "UNDEFINED"
		) {
			continue;
		}

		await createTable(systemName);
		const orderBy = await getOrderBy(table);
		const results = await getTable(orderBy ? `ORDER BY ${orderBy}` : "");

		// Skip empty tables.
		if (!results.length) {
			continue;
		}

		const filename =
			RATABASE_FILE_PREFIX[scenarioFile.scenarioForm.lineOfBusiness as keyof typeof RATABASE_FILE_PREFIX] +
			"-" +
			scenarioFile.scenarioForm.geoState +
			"_" +
			systemName +
			"_N_" +
			DateTime.fromFormat(scenarioFile.scenarioForm.newDate, "yyyy-MM-dd").toFormat("MM_dd_yyyy") +
			"_A_" +
			DateTime.fromFormat(scenarioFile.scenarioForm.availableDate, "yyyy-MM-dd").toFormat("MM_dd_yyyy") +
			"_1.xlsx";

		const filepath = join(directory, filename);

		if (await isFileOpen(filepath)) {
			const message = `Unable to create Ratabase file for table ${table} as the file is currently in use.`;
			addConsoleMessage({text: `${Emoji.Warning} ${message}`});

			await logAsync({
				type: "WARNING",
				subType: "BACKEND",
				payload: message
			});
		} else {
			await copyTemplate({directory, filename, systemName});
			const workbook = xlsx.readFile(filepath, {bookVBA: false});
			const tableDataWorksheet = workbook.Sheets["TableData"];
			const filingInformationWorksheet = workbook.Sheets["FilingInformation"];
			// Most templates start data on cell A4.
			let tableDataCell = "A4";

			if (["EARLY_SHOPPING_DISC", "PKG_DISC_FACTOR"].includes(systemName.toUpperCase())) {
				// These tables start on cell A5 instead of cell A4.
				tableDataCell = "A5";
			}

			// Populate the Data worksheet.
			xlsx.utils.sheet_add_json(tableDataWorksheet, results, {
				skipHeader: true,
				origin: tableDataCell
			});

			// Populate the FilingInformation worksheet.
			xlsx.utils.sheet_add_aoa(
				filingInformationWorksheet,
				[[scenarioFile.scenarioForm.geoState]],
				{origin: "B5"}
			);

			xlsx.utils.sheet_add_aoa(
				filingInformationWorksheet,
				[
					[
						DateTime.fromFormat(
							scenarioFile.scenarioForm.newDate,
							"yyyy-MM-dd"
						).toFormat("MM/dd/yyyy")
					]
				],
				{origin: "B6"}
			);

			xlsx.utils.sheet_add_aoa(
				filingInformationWorksheet,
				[
					[
						DateTime.fromFormat(
							scenarioFile.scenarioForm.renewalDate,
							"yyyy-MM-dd"
						).toFormat("MM/dd/yyyy")
					]
				],
				{origin: "B7"}
			);

			xlsx.utils.sheet_add_aoa(
				filingInformationWorksheet,
				[
					[
						DateTime.fromFormat(
							scenarioFile.scenarioForm.availableDate,
							"yyyy-MM-dd"
						).toFormat("MM/dd/yyyy")
					]
				],
				{origin: "B8"}
			);

			xlsx.writeFile(workbook, filepath, {compression: true});
		}
	}
};

const getSystemName = async (tableName: string): Promise<string> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetRatabaseSystemName)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile: scenarioFile,
				tableName: tableName
			}
		})
	);

	const [, results] = await execute({sqlText});

	if (results && results.length > 0) {
		return String((results[0] as Record<string, unknown>)["RATABASE_TABLE_NAME"]);
	}

	return "";
};

const createTable = async (tableName: string): Promise<void> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CreateRatabaseTable)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile: scenarioFile,
				tableName: tableName
			}
		})
	);

	await execute({sqlText});
};

const getOrderBy = async (tableName: string): Promise<string> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetRatabaseTableOrderBy)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile: scenarioFile,
				tableName: tableName
			}
		})
	);

	const [, rs] = await execute({sqlText});

	if (rs && rs.length > 0) {
		return String((rs[0] as Record<string, unknown>)["ORDER_BY"]);
	}

	return "";
};

const getTable = async (orderBy: string): Promise<Record<string, unknown>[]> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetRatabaseTable)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile: scenarioFile,
				orderBy: orderBy
			}
		})
	);

	const [, results] = await execute({sqlText});

	if (results && results.length > 0) {
		return results as Record<string, unknown>[];
	}

	return [];
};

const copyTemplate = async (args: {
	directory: string;
	filename: string;
	systemName: string;
}): Promise<void> => {
	let templateFilepath = join(
		userSettings.excelTemplatesDirectory,
		"/ratabase",
		scenarioFile.scenarioForm.lineOfBusiness === "AUTO" ? "/auto" : "/wc",
		RATABASE_EXCEL_TEMPLATE[args.systemName as keyof typeof RATABASE_EXCEL_TEMPLATE]
	);

	if (
		scenarioFile.scenarioForm.lineOfBusiness === "WC" &&
		["CA", "TX"].includes(scenarioFile.scenarioForm.geoState) &&
		args.systemName.toUpperCase() === "CLASS_RATE_MIN_PREM"
	) {
		templateFilepath = join(
			userSettings.excelTemplatesDirectory,
			"/ratabase/wc",
			RATABASE_EXCEL_TEMPLATE["CLASS_RATE_MIN_PREM_TX_CA"]
		);
	}

	await copy(templateFilepath, join(args.directory, args.filename));
};
