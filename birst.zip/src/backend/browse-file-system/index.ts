export * from "./ipc";
