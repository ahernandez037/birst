import {default as electronLog} from "electron-log";
import {execute} from "../database";
import {scenarioId} from "../scenario";
import {LogSubType, LogType} from "./types";
import {snowflakeSessionId} from "../app-settings";
import {USER_ID, USER_LOG_FILE} from "../user-settings";

electronLog.transports.file.maxSize = 5_242_880; // 5 MB max log file size
electronLog.transports.file.resolvePath = () => USER_LOG_FILE;
electronLog.catchErrors();

/**
 * Logs to hard drive and database (if not bypassed) in a non-blocking manner.
 * Does not guarantee log will be saved to database for example in case the
 * database has a lock on the log table. This shouldn't be an issue for trivial
 * logging such as logging UI interactions, but for logging of more important
 * messages, it is recommended to use the logAsync function instead.
 */
export const log = (args: {
	type: LogType;
	subType: LogSubType;
	payload: string;
	bypassDatabase?: boolean;
}): void => {
	logToHardDrive({
		type: args.type,
		subType: args.subType,
		payload: args.payload
	});

	if (!args.bypassDatabase) {
		logToDatabase({
			type: args.type,
			subType: args.subType,
			payload: args.payload
		});
	}
};

/**
 * Logs to hard drive and database in a blocking manner, if called with "await".
 * Recommended to use this function over the non-blocking function for critical
 * logging to ensure data is saved to the database which is not guaranteed by
 * the non-blocking function. Not recommended to use this function for trivial
 * logging (such as UI interactions) since it could significantly slow down the
 * UI.
 */
export const logAsync = async (args: {
	type: LogType;
	subType: LogSubType;
	payload: string;
}): Promise<void> => {
	logToHardDrive({
		type: args.type,
		subType: args.subType,
		payload: args.payload
	});

	await logToDatabaseAsync({
		type: args.type,
		subType: args.subType,
		payload: args.payload
	});
};

const logToHardDrive = (args: { type: LogType; subType: LogSubType; payload: string }): void => {
	switch (args.type) {
	case "INFO":
		electronLog.info(`${args.subType} - ${args.payload}`);
		break;
	case "WARNING":
		electronLog.warn(`${args.subType} - ${args.payload}`);
		break;
	case "ERROR":
		electronLog.error(`${args.subType} - ${args.payload}`);
		break;
	}
};

const logToDatabase = (args: { type: LogType; subType: LogSubType; payload: string }): void => {
	execute({
		sqlText: `
			INSERT INTO prd_bizdb_coml.public_sandbox.birst_log_node_js (
				created_at_utc,
				snowflake_session_id,
				scenario_id,
				user_id,
				type,
				sub_type,
				payload
			)
			VALUES (
				'${new Date().toISOString()}',
				'${snowflakeSessionId}',
				'${scenarioId}',
				'${USER_ID}',
				'${args.type}',
				'${args.subType}',
				/* Escape backlashes and single quotes */
				'${args?.payload?.replace(/\\/g, "\\\\")?.replace(/'/g, "''") ?? ""}'
			);
		`
	}).catch((err) => {
		logToHardDrive({type: "ERROR", subType: "BACKEND", payload: String(err)});
	});
};

const logToDatabaseAsync = async (args: {
	type: LogType;
	subType: LogSubType;
	payload: string;
}): Promise<void> => {
	await execute({
		sqlText: `
			INSERT INTO prd_bizdb_coml.public_sandbox.birst_log_node_js (
				created_at_utc,
				snowflake_session_id,
				scenario_id,
				user_id,
				type,
				sub_type,
				payload
			)
			VALUES (
				'${new Date().toISOString()}',
				'${snowflakeSessionId}',
				'${scenarioId}',
				'${USER_ID}',
				'${args.type}',
				'${args.subType}',
				/* Escape backlashes and single quotes */
				'${args?.payload?.replace(/\\/g, "\\\\")?.replace(/'/g, "''") ?? ""}'
			);
		`
	}).catch((err) => {
		logToHardDrive({type: "ERROR", subType: "BACKEND", payload: String(err)});
	});
};
