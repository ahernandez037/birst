export type LogType = "INFO" | "WARNING" | "ERROR";

export type LogSubType =
	| "BACKEND"
	| "JSON"
	| "BUTTON-CLICK"
	| "TAB-CLICK"
	| "INPUT-SELECT"
	| "INPUT-TEXT"
	| "INPUT-DATE"
	| "INPUT-TOGGLE"
	| "RADIO-CLICK";
