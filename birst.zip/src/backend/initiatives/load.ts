import {join} from "path";
import {app} from "electron";
import {WorkCompLCM} from "./types";
import {execute} from "../database";
import {userSettings} from "../user-settings";
import {scenarioFile} from "../scenario-file";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {ConsoleMessageId, addConsoleMessage, stopConsoleMessageTimer} from "../console-message";

export const loadImplementedInitiatives = async (): Promise<string[]> => {
	try {
		const initiatives: string[] = [];

		addConsoleMessage({
			text: "Loading implemented initiatives...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingImplementedInitiatives
		});

		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetImplementedInitiatives)))[0];
		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
					scenarioFile
				}
			})
		);
		const [, rs] = await execute({sqlText});

		if (rs) {
			for (const r of rs as Record<string, unknown>[]) {
				initiatives.push(String(r["NAME"]));
			}
		}

		stopConsoleMessageTimer(ConsoleMessageId.LoadingImplementedInitiatives);
		return initiatives;
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingImplementedInitiatives);
		throw err;
	}
};

export const getWorkCompLCMs = async (): Promise<WorkCompLCM[]> => {
	try {
		const lcms: WorkCompLCM[] = [];

		addConsoleMessage({
			text: "Loading LCMs...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingWorkCompLCMs
		});

		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetWorkCompLCMs)))[0];
		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
					scenarioFile
				}
			})
		);
		const [, rs] = await execute({sqlText});

		if (rs) {
			for (const r of rs as Record<string, unknown>[]) {
				lcms.push({
					geoState: String(r["GEO_STATE"]),
					uwCompany: String(r["UW_COMPANY"]),
					lcm: Number(r["LCM"])
				});
			}
		}

		stopConsoleMessageTimer(ConsoleMessageId.LoadingWorkCompLCMs);
		return lcms;
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingWorkCompLCMs);
		throw err;
	}
};
