import {join} from "path";
import * as xlsx from "xlsx";
import {execute} from "../database";
import {USER_TEMP_DIRECTORY} from "../user-settings";
import {addConsoleMessage} from "../console-message";
import {
	RateTableListMap,
	DuplicateCheckResult,
	HealthCheckProductCode,
	DuplicateCheckRateTable,
	DuplicateCheckOutputFile
} from "./types";

export const checkForDuplicates = async (productCode: HealthCheckProductCode): Promise<void> => {
	const results: DuplicateCheckResult[] = [];
	const rateTables = await getRateTables(productCode);

	for (const rateTable of rateTables) {
		addConsoleMessage({text: `Processing: ${rateTable.ratabaseTableName}`});

		const [, rs] = await execute({
			sqlText: `
			WITH cte AS (
				SELECT 1 AS cnt
				FROM prd_bizdb_coml.rate_tables.${rateTable.ratabaseTableName}
				GROUP BY ${rateTable.compositeKey}
				HAVING COUNT(1) > 1
			)
			SELECT SUM(cnt) AS duplicate_count
			FROM cte;
			`
		});

		if (rs) {
			for (const r of rs as Record<string, unknown>[]) {
				results.push({
					tableName: rateTable.ratabaseTableName,
					duplicateCount: Number(r["DUPLICATE_COUNT"]),
					query:
						`SELECT ${rateTable.compositeKey}\n` +
						`FROM prd_bizdb_coml.rate_tables.${rateTable.ratabaseTableName}\n` +
						`GROUP BY ${rateTable.compositeKey}\n` +
						"HAVING COUNT(1) > 1;"
				});
			}
		}
	}

	const tablesWithDuplicates = results.filter((result) => result.duplicateCount > 0);
	addConsoleMessage({text: `Total tables with duplicates: ${tablesWithDuplicates.length}`});

	if (tablesWithDuplicates.length > 0) {
		const resultsFilepath = await saveResultsToFile(productCode, tablesWithDuplicates);
		addConsoleMessage({text: `Results saved to: ${resultsFilepath}`});
	}
};

const getRateTables = async (
	productCode: HealthCheckProductCode
): Promise<DuplicateCheckRateTable[]> => {
	const [, rs] = await execute({
		sqlText: `
				SELECT
					state_include,
					state_exclude,
					line_of_business,
					product,
					version,
					ratabase_table_name,
					rates_file_table_name,
					programmed_in_rating_engine,
					is_included_in_rates_file,
					is_open_for_proposed_rates,
					composite_key,
					legacy_table_name
				FROM ${RateTableListMap[productCode]};
			`
	});
	const rateTables: DuplicateCheckRateTable[] = [];

	if (rs) {
		for (const r of rs as Record<string, unknown>[]) {
			rateTables.push({
				stateInclude: String(r["STATE_INCLUDE"]),
				stateExclude: String(r["STATE_EXCLUDE"]),
				lineOfBusiness: String(r["LINE_OF_BUSINESS"]),
				product: String(r["PRODUCT"]),
				version: String(r["VERSION"]),
				ratabaseTableName: String(r["RATABASE_TABLE_NAME"]),
				ratesFileTableName: String(r["RATES_FILE_TABLE_NAME"]),
				programmedInRatingEngine: String(r["PROGRAMMED_IN_RATING_ENGINE"]),
				isIncludedInRatesFile: Boolean(r["IS_INCLUDED_IN_RATES_FILE"]),
				isOpenForProposedRates: Boolean(r["IS_OPEN_FOR_PROPOSED_RATES"]),
				compositeKey: String(r["COMPOSITE_KEY"]),
				legacyTableName: String(r["LEGACY_TABLE_NAME"])
			});
		}
	}

	return rateTables;
};

const saveResultsToFile = async (
	productCode: HealthCheckProductCode,
	tablesWithDuplicates: DuplicateCheckResult[]
): Promise<string> => {
	const resultsFilepath = join(USER_TEMP_DIRECTORY, DuplicateCheckOutputFile[productCode]);
	const workbook = xlsx.utils.book_new();
	const worksheet = xlsx.utils.json_to_sheet(tablesWithDuplicates);
	xlsx.utils.book_append_sheet(workbook, worksheet, "tables_with_duplicates");
	await xlsx.writeFile(workbook, resultsFilepath, {compression: true});
	return resultsFilepath;
};
