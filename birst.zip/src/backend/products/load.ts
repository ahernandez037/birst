import {join} from "path";
import {app} from "electron";
import {Product} from "./types";
import {mainWindow} from "../main";
import {execute} from "../database";
import {IpcMessage} from "../ipc-handlers";
import {userSettings} from "../user-settings";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const loadProducts = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading products...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingProducts
	});

	try {
		const products: Product[] = [];
		const rs = await queryDatabase();

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				products.push({
					id: Number(result["ID"]),
					stateCode: String(result["STATE_CODE"]),
					lineOfBusinessCode: String(result["LINE_OF_BUSINESS_CODE"]),
					lineOfBusinessDescription: String(result["LINE_OF_BUSINESS_DESCRIPTION"]),
					productCode: String(result["PRODUCT_CODE"]),
					productDescription: String(result["PRODUCT_DESCRIPTION"]),
					versionCode: String(result["VERSION_CODE"]),
					versionDescription: String(result["VERSION_DESCRIPTION"]),
					// When running in dev mode make all products available.
					// Otherwise, use table driven availability settings.
					isAvailable: app.isPackaged ? !!result["IS_AVAILABLE"] : true
				});
			}

			mainWindow.webContents.send(IpcMessage.UpdateProducts, JSON.stringify(products));
		}

		stopConsoleMessageTimer(ConsoleMessageId.LoadingProducts);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingProducts);
		throw err;
	}
};

const queryDatabase = async (): Promise<unknown[] | undefined> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetProducts)))[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas
			}
		})
	);
	const [, rs] = await execute({sqlText});

	return rs;
};
