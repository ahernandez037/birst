export interface Product {
	id: number;
	stateCode: string;
	lineOfBusinessCode: string;
	lineOfBusinessDescription: string;
	productCode: string;
	productDescription: string;
	versionCode: string;
	versionDescription: string;
	isAvailable: boolean;
}
