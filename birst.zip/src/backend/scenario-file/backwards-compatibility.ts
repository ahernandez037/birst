import {log} from "../logger";
import {scenarioFile} from "./load";

/**
 * Insert code to support backwards compatibility whenever there's changes to
 * the scenario file format/contents. For example, if a new field is introduced.
 */
export const applyBackwardsCompatibilityPatches = (): void => {
	if (scenarioFile?.scenarioForm?.isRstBieeSpecifiedLimitInitiative === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding isRstBieeSpecifiedLimitInitiative property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.isRstBieeSpecifiedLimitInitiative = false;
	}

	if (scenarioFile?.scenarioForm?.onLevelRatePlan === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding onLevelRatePlan property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.onLevelRatePlan = "";
	}

	if (scenarioFile?.scenarioForm?.onLevelRatePlanDate === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding onLevelRatePlanDate property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.onLevelRatePlanDate = "";
	}

	if (scenarioFile?.scenarioForm?.isWorkCompGradientAiInitiative === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding isWorkCompGradientAiInitiative property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.isWorkCompGradientAiInitiative = false;
	}

	if (scenarioFile?.scenarioForm?.isRstGlSalesInitiative === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding isRstGlSalesInitiative property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.isRstGlSalesInitiative = false;
	}

	if (scenarioFile?.scenarioForm?.workCompAdoptBureauRates === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding workCompAdoptBureauRates property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.workCompAdoptBureauRates = false;
	}

	if (scenarioFile?.scenarioForm?.workCompBureauEffectiveDate === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding workCompBureauEffectiveDate property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.workCompBureauEffectiveDate = "";
	}

	if (scenarioFile?.scenarioForm?.workCompBureauReleaseDate === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding workCompBureauReleaseDate property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.workCompBureauReleaseDate = "";
	}

	if (scenarioFile?.scenarioForm?.workCompBureauStatusFlag === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding workCompBureauStatusFlag property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.workCompBureauStatusFlag = "";
	}

	if (scenarioFile?.ratePlan === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding ratePlan property.",
			bypassDatabase: true
		});

		scenarioFile.ratePlan = [];
	}

	if (scenarioFile?.appVersion === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding appVersion property.",
			bypassDatabase: true
		});

		// It wasn't until v1.3.0 that this property was added.
		scenarioFile.appVersion = "1.2.0";
	}

	if (scenarioFile.scenarioForm?.isAutoFlexRollout === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding isAutoFlexRollout property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.isAutoFlexRollout = false;
	}

	if (scenarioFile.files?.fitExhibitsFile === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding fitExhibitsFile property.",
			bypassDatabase: true
		});

		scenarioFile.files.fitExhibitsFile = "";
	}

	if (scenarioFile?.createdByEmail === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding createdByEmail property.",
			bypassDatabase: true
		});

		scenarioFile.createdByEmail = "";
	}

	if (scenarioFile.executiveSummary?.rateRevisionInitiatedByEmail === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding rateRevisionInitiatedByEmail property.",
			bypassDatabase: true
		});

		scenarioFile.executiveSummary.rateRevisionInitiatedByEmail = "";
	}

	if (scenarioFile.scenarioForm?.useCountrywideData === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding useCountrywideData property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.useCountrywideData = false;
	}

	if (scenarioFile.scenarioForm?.useAllVersionsData === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding useAllVersionsData property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.useAllVersionsData = false;
	}

	if (scenarioFile.scenarioForm?.driverDataOverrideTable === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding driverDataOverrideTable property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.driverDataOverrideTable = "N/A";
	}

	if (scenarioFile.scenarioForm?.fdrcTimestamp === undefined) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Adding fdrcTimestamp property.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.fdrcTimestamp = "";
	}

	if (scenarioFile.scenarioForm.inforceDate.length > 10) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Trimming inforceDate string to 10 characters.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.inforceDate = scenarioFile.scenarioForm.inforceDate.substring(0, 10);
	}

	if (scenarioFile.scenarioForm.renewalDate.length > 10) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Trimming renewalDate string to 10 characters.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.renewalDate = scenarioFile.scenarioForm.renewalDate.substring(0, 10);
	}

	if (scenarioFile.scenarioForm.newDate.length > 10) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Trimming newDate string to 10 characters.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.newDate = scenarioFile.scenarioForm.newDate.substring(0, 10);
	}

	if (scenarioFile.scenarioForm.availableDate.length > 10) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Trimming availableDate string to 10 characters.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.availableDate = scenarioFile.scenarioForm.availableDate.substring(0, 10);
	}

	if (scenarioFile.scenarioForm.startDate.length > 10) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Trimming startDate string to 10 characters.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.startDate = scenarioFile.scenarioForm.startDate.substring(0, 10);
	}

	if (scenarioFile.scenarioForm.endDate.length > 10) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Trimming endDate string to 10 characters.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.endDate = scenarioFile.scenarioForm.endDate.substring(0, 10);
	}

	if (scenarioFile.scenarioForm.fdrcTimestamp.length > 10) {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Backwards compatibility patch: Trimming fdrcTimestamp string to 10 characters.",
			bypassDatabase: true
		});

		scenarioFile.scenarioForm.fdrcTimestamp = scenarioFile.scenarioForm.fdrcTimestamp.substring(0, 10);
	}
};
