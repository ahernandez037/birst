import {z} from "zod";
import {RatePlan} from "../rate-plan";
import {ScenarioForm} from "../scenario";
import {RateHistory} from "../rate-history";
import {ExecutiveSummary} from "../executive-summary";

export interface ScenarioFile {
	appVersion: string;
	createdBy: string;
	createdByEmail: string;
	createdAtUtc: string;
	scenarioForm: ScenarioForm;
	files: ScenarioOutputFiles;
	executiveSummary: ExecutiveSummary;
	rateHistory: RateHistory[];
	ratePlan: RatePlan[];
}

export interface ScenarioOutputFiles {
	scenarioFile: string;
	ratesFile: string;
	reportFile: string;
	dataDumpFile: string;
	fitExhibitsFile: string;
}

// Zod schema used to parse & validate input which is sourced from a JSON file.
export const scenarioFileZodSchema: z.ZodType<ScenarioFile> =
	z.object({
		appVersion: z.string(),
		createdBy: z.string(),
		createdByEmail: z.string(),
		createdAtUtc: z.string(),
		scenarioForm: z.object({
			runMode: z.string(),
			queryMethod: z.string(),
			inforceDate: z.string(),
			startDate: z.string(),
			endDate: z.string(),
			onLevelRatePlan: z.string(),
			onLevelRatePlanDate: z.string(),
			geoState: z.string(),
			lineOfBusiness: z.string(),
			product: z.string(),
			version: z.string(),
			workCompAdoptBureauRates: z.boolean(),
			workCompBureauEffectiveDate: z.string(),
			workCompBureauReleaseDate: z.string(),
			workCompBureauStatusFlag: z.string(),
			newDate: z.string(),
			renewalDate: z.string(),
			availableDate: z.string(),
			fdrcTimestamp: z.string(),
			dataSource: z.string(),
			scenarioId: z.string(),
			scenarioDirectory: z.string(),
			dataDumpTable: z.string(),
			saveDataDumpToHardDrive: z.boolean(),
			useCountrywideData: z.boolean(),
			useAllVersionsData: z.boolean(),
			isAutoFlexRollout: z.boolean(),
			isRstGlSalesInitiative: z.boolean(),
			isWorkCompGradientAiInitiative: z.boolean(),
			isRstBieeSpecifiedLimitInitiative: z.boolean(),
			extractPolicyData: z.string(),
			rateTableListCurrent: z.string(),
			rateTableListProposed: z.string(),
			prepareRateTablesCurrent: z.string(),
			prepareRateTablesProposed: z.string(),
			assignRatesCurrent: z.string(),
			assignRatesProposed: z.string(),
			calculatePremiumCurrent: z.string(),
			calculatePremiumProposed: z.string(),
			createDataDump: z.string(),
			createReports: z.string(),
			policyDataOverrideTable: z.string(),
			driverDataOverrideTable: z.string()
		}).strict(),
		files: z.object({
			scenarioFile: z.string(),
			ratesFile: z.string(),
			reportFile: z.string(),
			dataDumpFile: z.string(),
			fitExhibitsFile: z.string()
		}).strict(),
		executiveSummary: z.object({
			isRateRevisionCreated: z.boolean(),
			rateRevisionInitiatedByEmail: z.string(),
			policyCount: z.number().nullable(),
			exposureCount: z.number().nullable(),
			modifiedPremiumCurrent: z.number().nullable(),
			modifiedPremiumProposed: z.number().nullable(),
			impactAmount: z.number().nullable(),
			impactPercent: z.number().nullable(),
			toleranceLo: z.number().nullable(),
			toleranceHi: z.number().nullable(),
			inScopeTables: z.string(),
			inScopeBureauTables: z.string()
		}).strict(),
		rateHistory: z.array(
			z.object({
				state: z.string(),
				channel: z.string(),
				company: z.string(),
				lineOfBusiness: z.string(),
				product: z.string(),
				version: z.string(),
				segment: z.string(),
				coverage: z.string(),
				renewalDate: z.string(),
				rate: z.number(),
				inforcePremium: z.number()
			}).strict()
		),
		ratePlan: z.array(
			z.object({
				version: z.string(),
				ratePlan: z.string(),
				availableAsOf: z.string()
			}).strict()
		)
	}).strict();

export type ScenarioFileSchema = z.infer<typeof scenarioFileZodSchema>;
