import {RunMode, ScenarioForm} from "../scenario";

export const runModePrefix: Record<RunMode, string> = {
	"RATE-CHANGE": "Rate_Change",
	VALIDATION: "Validation",
	"ON-LEVEL": "On_Level"
} as const;

export const getPrefixesFromScenarioForm = (
	scenarioForm: ScenarioForm
): [string, string, string, string, string, string, string] => [
	getLineOfBusinessPrefix(scenarioForm),
	getProductPrefix(scenarioForm),
	getVersionPrefix(scenarioForm),
	getGeoStatePrefix(scenarioForm),
	getRenewalEffectiveDatePrefix(scenarioForm),
	getDataSourcePrefix(scenarioForm),
	getInforceDatePrefix(scenarioForm)
];

const getLineOfBusinessPrefix = (scenarioForm: ScenarioForm): string =>
	scenarioForm.lineOfBusiness === "AUTO" ? "" : scenarioForm.lineOfBusiness + "_";

const getProductPrefix = (scenarioForm: ScenarioForm): string =>
	scenarioForm.product && scenarioForm.product !== "N/A" ? scenarioForm.product + "_" : "";

const getVersionPrefix = (scenarioForm: ScenarioForm): string => {
	if (scenarioForm.version && scenarioForm.version !== "N/A" && scenarioForm.product !== "AUTO") {
		return scenarioForm.version + "_";
	}

	if (scenarioForm.product === "AUTO") {
		return "v" + scenarioForm.version + "_";
	}
	return "";
};

const getGeoStatePrefix = (scenarioForm: ScenarioForm): string => scenarioForm.geoState + "_";

const getRenewalEffectiveDatePrefix = (scenarioForm: ScenarioForm): string =>
	scenarioForm.renewalDate ? scenarioForm.renewalDate.substring(0, 10) + "_" : "";

const getDataSourcePrefix = (scenarioForm: ScenarioForm): string =>
	scenarioForm.dataSource === "PROD" ? "" : scenarioForm.dataSource + "_";

const getInforceDatePrefix = (scenarioForm: ScenarioForm): string =>
	scenarioForm.inforceDate ? scenarioForm.inforceDate.substring(0, 10) + "_" : "";
