import {RunMode} from "../scenario";
import {scenarioFile} from "./load";
import {InScopeRateTable} from "../rates-file";

export const updateScenarioFileExecutiveSummary = (records: Record<string, unknown>[]): void => {
	if (scenarioFile.scenarioForm.runMode === RunMode.RateChange) {
		const policyCount = records[0] ? Number(records[0]["POLICY_COUNT"]) : 0;
		const exposureCount = records[0] ? Number(records[0]["EXPOSURE_COUNT"]) : 0;
		const modifiedPremiumCurrent = records[0] ? Number(records[0]["MOD_PREM_CURRENT"]) : 0;
		const modifiedPremiumProposed = records[0] ? Number(records[0]["MOD_PREM_PROPOSED"]) : 0;
		const impactAmount = records[0] ? Number(records[0]["IMPACT_AMT"]) : 0;
		const impactPercent = records[0] ? Number(records[0]["IMPACT_PCT"]) : 0;
		const toleranceLo = records[0] ? Number(records[0]["TOLERANCE_LO"]) : 0;
		const toleranceHi = records[0] ? Number(records[0]["TOLERANCE_HI"]) : 0;

		scenarioFile.executiveSummary.policyCount = policyCount;
		scenarioFile.executiveSummary.exposureCount = exposureCount;
		scenarioFile.executiveSummary.modifiedPremiumCurrent = modifiedPremiumCurrent;
		scenarioFile.executiveSummary.modifiedPremiumProposed = modifiedPremiumProposed;
		scenarioFile.executiveSummary.impactAmount = impactAmount;
		scenarioFile.executiveSummary.impactPercent = impactPercent;
		scenarioFile.executiveSummary.toleranceLo = toleranceLo;
		scenarioFile.executiveSummary.toleranceHi = toleranceHi;
	}
};

export const updateScenarioFileExecutiveSummaryInScopeTables = (
	inScopeTables: InScopeRateTable[]
): void => {
	scenarioFile.executiveSummary.inScopeTables = inScopeTables
		.map((table) => table.fullTableName)
		.join(",");
};
