import {join} from "path";
import {existsSync, copy, chmod} from "fs-extra";
import {MessageBoxOptions, dialog} from "electron";
import {logAsync} from "../logger";
import {mainWindow} from "../main";
import {saveScenarioFile} from "./save";
import {IpcMessage} from "../ipc-handlers";
import {prefillScenarioFile} from "./prefill";
import {getDirectory} from "../browse-file-system";
import {loadScenarioFile, scenarioFile} from "./load";
import {RunMode, ScenarioForm} from "../scenario/types";
import {Emoji, addConsoleMessage} from "../console-message";
import {createScenarioId, scenarioId, updateScenarioId} from "../scenario/scenario-id";

export const cloneScenarioFile = async (scenarioForm: ScenarioForm): Promise<void> => {
	try {
		// Only allowing cloning for scenarios that were created by v1.3.0 or
		// newer since there are breaking changes due to the new Excel file
		// format being used starting with v1.3.0.
		const majorAppVersion = scenarioFile.appVersion.split(".")[0];
		const minorAppVersion = scenarioFile.appVersion.split(".")[1];

		if (
			Number(majorAppVersion) < 1 ||
			(Number(majorAppVersion) === 1 && Number(minorAppVersion) < 3)
		) {
			addConsoleMessage({text: `${Emoji.StopSign} Sorry, cloning is only available for scenarios created by v1.3.0 or newer of the BIRST application ${Emoji.SadFace}`});
			mainWindow.webContents.send(IpcMessage.CloneScenarioFileCanceled);
			addConsoleMessage({text: "Action has been canceled."});
			return;
		}

		const destinationDirectory = await getDirectory("Select Destination Directory");

		if (!destinationDirectory) {
			mainWindow.webContents.send(IpcMessage.CloneScenarioFileCanceled);
			addConsoleMessage({text: "Action has been canceled."});
			return;
		}

		// Prefilling if these values are empty as this means that the user is
		// trying to clone a scenario file that doesn't yet exist, i.e., they
		// populated the UI but haven't created the rates file or ran the
		// scenario yet.
		if (
			!scenarioFile.scenarioForm.scenarioDirectory ||
			(scenarioFile.scenarioForm.runMode === RunMode.RateChange &&
				!scenarioFile.files.ratesFile)
		) {
			prefillScenarioFile(scenarioForm);
		}

		if (scenarioFile.scenarioForm.runMode === RunMode.RateChange) {
			const sourceRatesFileFilepath = join(
				scenarioFile.scenarioForm.scenarioDirectory,
				scenarioFile.files.ratesFile
			);

			if (await isCopyingRatesFile(sourceRatesFileFilepath)) {
				const destinationRatesFileFilepath = join(
					destinationDirectory,
					scenarioFile.files.ratesFile
				);

				if (await confirmOverwriteRatesFile(destinationRatesFileFilepath)) {
					await copy(sourceRatesFileFilepath, destinationRatesFileFilepath);

					// Set read & write permissions since the rates file being
					// copied could be from a rate revision, in which case the
					// rates file would have read-only permission.
					await chmod(destinationRatesFileFilepath, 0o600);
				} else {
					mainWindow.webContents.send(IpcMessage.CloneScenarioFileCanceled);
					addConsoleMessage({text: "Action has been canceled."});
					return;
				}
			}
		}

		prefillScenarioFile(scenarioForm);
		updateScenarioId(createScenarioId());

		scenarioFile.scenarioForm.scenarioId = scenarioId;
		scenarioFile.scenarioForm.scenarioDirectory = destinationDirectory;
		scenarioFile.scenarioForm.dataDumpTable = "TBD";
		scenarioFile.executiveSummary.isRateRevisionCreated = false;
		scenarioFile.executiveSummary.rateRevisionInitiatedByEmail = "";

		const newScenarioFilepath = join(
			scenarioFile.scenarioForm.scenarioDirectory,
			scenarioFile.files.scenarioFile
		);

		if (await confirmOverwriteScenarioFile(newScenarioFilepath)) {
			await saveScenarioFile();
		} else {
			mainWindow.webContents.send(IpcMessage.CloneScenarioFileCanceled);
			addConsoleMessage({text: "Action has been canceled."});
			return;
		}

		await loadScenarioFile({uncFilepath: newScenarioFilepath});
		mainWindow.webContents.send(IpcMessage.CloneScenarioFileSuccess);
	} catch (err) {
		addConsoleMessage({text: `${Emoji.Error} ${String(err)}`});
		await logAsync({type: "ERROR", subType: "BACKEND", payload: String(err)});
		mainWindow.webContents.send(IpcMessage.CloneScenarioFileError);
	}
};

const confirmOverwriteScenarioFile = async (filepath: string): Promise<boolean> => {
	if (existsSync(filepath)) {
		const dialogOptions: MessageBoxOptions = {
			type: "warning",
			buttons: ["Yes", "No"],
			defaultId: 1,
			cancelId: 1,
			noLink: true,
			title: " Confirmation Required",
			message: "The scenario file already exists in the destination directory.\n\nAre you sure you want to overwrite it?"
		};

		return (await dialog.showMessageBox(mainWindow, dialogOptions)).response === 0 ? true : false;
	}

	return true;
};

const isCopyingRatesFile = async (filepath: string): Promise<boolean> => {
	if (existsSync(filepath)) {
		const dialogOptions: MessageBoxOptions = {
			type: "warning",
			buttons: ["Yes", "No"],
			defaultId: 1,
			cancelId: 1,
			noLink: true,
			title: " Confirmation Required",
			message: "Would you also like to copy the rates file?"
		};

		return (await dialog.showMessageBox(mainWindow, dialogOptions)).response === 0 ? true : false;
	}

	return false;
};

const confirmOverwriteRatesFile = async (filepath: string): Promise<boolean> => {
	if (existsSync(filepath)) {
		const dialogOptions: MessageBoxOptions = {
			type: "warning",
			buttons: ["Yes", "No"],
			defaultId: 1,
			cancelId: 1,
			noLink: true,
			title: " Confirmation Required",
			message: "The rates file already exists in the destination directory.\n\nAre you sure you want to overwrite it?"
		};

		return (await dialog.showMessageBox(mainWindow, dialogOptions)).response === 0 ? true : false;
	}

	return true;
};
