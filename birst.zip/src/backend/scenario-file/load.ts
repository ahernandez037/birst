import {z} from "zod";
import {dirname} from "path";
import {app} from "electron";
import {readJson} from "fs-extra";
import {mainWindow} from "../main";
import {log, logAsync} from "../logger";
import {IpcMessage} from "../ipc-handlers";
import {RunMode, updateScenarioId} from "../scenario";
import {USER_SCENARIO_DIRECTORY} from "../user-settings";
import {ScenarioFile, scenarioFileZodSchema} from "./types";
import {addConsoleMessage, Emoji} from "../console-message";
import {loadRateRevision, rateRevision} from "../rate-revision";
import {applyBackwardsCompatibilityPatches} from "./backwards-compatibility";

export let scenarioFile: ScenarioFile;

export const loadScenarioFile = async (args: {
	uncFilepath: string;
	skipScenarioDirectoryOverride?: boolean;
	skipLoadRateRevision?: boolean;
	isTestRun?: boolean;
}): Promise<void> => {
	try {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: `Loading scenario: ${args.uncFilepath}`,
			bypassDatabase: true
		});

		scenarioFile = await readJson(args.uncFilepath);
		applyBackwardsCompatibilityPatches();
		validateSchema();
		scenarioFile.scenarioForm.scenarioDirectory = getUpdatedScenarioDirectory(dirname(args.uncFilepath));

		if (
			!args.skipLoadRateRevision &&
			scenarioFile.scenarioForm.runMode === RunMode.RateChange
		) {
			await loadRateRevision();
		}

		if (!args.skipScenarioDirectoryOverride) {
			overrideScenarioDirectory();
		}

		mainWindow.webContents.send(
			IpcMessage.LoadScenarioSuccess,
			JSON.stringify(scenarioFile.scenarioForm)
		);

		if (scenarioFile.executiveSummary.impactPercent !== null) {
			mainWindow.webContents.send(
				IpcMessage.UpdateOverallRateImpact,
				(scenarioFile.executiveSummary.impactPercent * 100).toFixed(2)
			);
		}

		if (!args.skipLoadRateRevision) {
			mainWindow.webContents.send(
				IpcMessage.UpdateRateRevision,
				JSON.stringify(rateRevision)
			);
		}

		updateScenarioId(scenarioFile.scenarioForm.scenarioId);
	} catch (err) {
		addConsoleMessage({text: `${Emoji.Error} ${String(err)}`});
		await logAsync({type: "ERROR", subType: "BACKEND", payload: String(err)});
		mainWindow.webContents.send(IpcMessage.LoadScenarioCanceled);
		if (args.isTestRun) { throw err; }
	}
};

const validateSchema = (): void => {
	try {
		scenarioFileZodSchema.parse(scenarioFile);
	} catch (err) {
		throw new Error(`The scenario file does not match the expected schema. ${(err as z.ZodError).errors[0].message}. Property path: ${(err as z.ZodError).errors[0].path}. Please make sure that you have the latest version of the application installed. You can find the version number in the Support tab.`);
	}
};

const getUpdatedScenarioDirectory = (directoryWhereScenarioFileWasOpenedFrom: string): string => {
	// Function used to overwrite the scenario directory to match wherever the
	// scenario file was opened from, in case it's different than the scenario
	// directory from the scenario file. This is to ensure the output files are
	// placed in the same directory as wherever the user may copy the scenario
	// file to. Also, in case the scenario file was opened directly form an
	// email attachment, in which case the filepath would point to a temporary
	// directory, in this case default to use the user's default scenario
	// directory. Also, when the scenario file is for a created rate revision,
	// i.e., it was opened from the shared drive, then no need to modify the
	// path.
	if (
		scenarioFile.scenarioForm.scenarioDirectory.toLowerCase() !== directoryWhereScenarioFileWasOpenedFrom.toLowerCase() &&
		!scenarioFile.executiveSummary.isRateRevisionCreated
	) {
		// Temp directory, meaning that the scenario file was likely opened from
		// an email attachment.
		return directoryWhereScenarioFileWasOpenedFrom.toLowerCase().includes("appdata\\local")
			? USER_SCENARIO_DIRECTORY
			: directoryWhereScenarioFileWasOpenedFrom;
	} else {
		return scenarioFile.scenarioForm.scenarioDirectory;
	}
};

const overrideScenarioDirectory = (): void => {
	// If rate revision has been created. Overwrite the scenario directory with
	// the one that's in the database. This is in case the user opens the
	// scenario file from another location, this way it will still point to the
	// location in the 632 shared drive.
	if (rateRevision.createdBy) {
		if (rateRevision.isCanceled) {
			scenarioFile.scenarioForm.scenarioDirectory = rateRevision.scenarioDirectoryCanceled;
		} else {
			scenarioFile.scenarioForm.scenarioDirectory = rateRevision.scenarioDirectory;
		}
	}
};

export const resetScenarioFile = (): void => {
	scenarioFile = {
		appVersion: app.getVersion(),
		createdBy: "",
		createdByEmail: "",
		createdAtUtc: "",
		scenarioForm: {
			runMode: "",
			queryMethod: "",
			geoState: "",
			lineOfBusiness: "",
			product: "",
			version: "",
			workCompAdoptBureauRates: true,
			workCompBureauEffectiveDate: "",
			workCompBureauReleaseDate: "",
			workCompBureauStatusFlag: "",
			newDate: "",
			renewalDate: "",
			availableDate: "",
			inforceDate: "",
			startDate: "",
			endDate: "",
			onLevelRatePlan: "",
			onLevelRatePlanDate: "",
			fdrcTimestamp: "",
			dataSource: "",
			scenarioId: "",
			scenarioDirectory: "",
			dataDumpTable: "",
			saveDataDumpToHardDrive: true,
			useCountrywideData: false,
			useAllVersionsData: false,
			isAutoFlexRollout: false,
			isRstGlSalesInitiative: false,
			isWorkCompGradientAiInitiative: false,
			isRstBieeSpecifiedLimitInitiative: false,
			extractPolicyData: "",
			rateTableListCurrent: "",
			rateTableListProposed: "",
			prepareRateTablesCurrent: "",
			prepareRateTablesProposed: "",
			assignRatesCurrent: "",
			assignRatesProposed: "",
			calculatePremiumCurrent: "",
			calculatePremiumProposed: "",
			createDataDump: "",
			createReports: "",
			policyDataOverrideTable: "",
			driverDataOverrideTable: ""
		},
		files: {
			scenarioFile: "",
			ratesFile: "",
			reportFile: "",
			dataDumpFile: "",
			fitExhibitsFile: ""
		},
		executiveSummary: {
			isRateRevisionCreated: false,
			rateRevisionInitiatedByEmail: "",
			policyCount: null,
			exposureCount: null,
			modifiedPremiumCurrent: null,
			modifiedPremiumProposed: null,
			impactAmount: null,
			impactPercent: null,
			toleranceLo: null,
			toleranceHi: null,
			inScopeTables: "",
			inScopeBureauTables: ""
		},
		rateHistory: [],
		ratePlan: []
	};
};

// To initialize the scenario file object on program load.
resetScenarioFile();
