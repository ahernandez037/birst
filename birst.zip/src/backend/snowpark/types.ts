export interface SnowparkConfigFile {
	role: string;
	database: string;
	stage: string;
	zipFile: string;
	objectType: string;
	objectName: string;
	params: string[];
	returns: string;
	runtimeVersion: string;
	packages: string[];
	deployScript: string;
	handler: string;
	executeAs: string;
}
