import {app, BrowserWindow, dialog} from "electron";
const unhandled = require("electron-unhandled");

// Needed to prevent issues with the application installer during first time
// installation and during application updates.
if (require("electron-squirrel-startup")) {
	unhandled({showDialog: false});
	app.quit();
} else {
	unhandled({showDialog: true});
}

import {initMonitor} from "./monitor";
import {log, logAsync} from "./logger";
import {getUncPath} from "./utilities";
import {loadUsers, user} from "./user";
import {loadTestSuites} from "./tests";
import {loadProducts} from "./products";
import {loadGeoStates} from "./geo-states";
import {initAutoUpdater} from "./auto-updater";
import {loadReleaseNotes} from "./release-notes";
import {createEmail, EmailTrigger} from "./email";
import {loadAvailableDates} from "./available-dates";
import {loadWorkCompBureauRates} from "./wc-bureau-rates";
import {initIpcHandlers, IpcMessage} from "./ipc-handlers";
import {addConsoleMessage, Emoji} from "./console-message";
import {loadScenarioFile, scenarioFile} from "./scenario-file";
import {connect, connection, disconnect, execute} from "./database";
import {loadAncillaryUtilities, copyAncillaryUtilities} from "./utilities/ancillary";
import {
	userSettings,
	loadUserSettings,
	createUserDirectories,
	USER_ID,
	USER_LOG_FILE,
	USER_SETTINGS_FILE,
	USER_HOME_DIRECTORY
} from "./user-settings";
import {
	ExecutionState,
	snowflakeSettings,
	snowflakeSessionId,
	forcedAppQuitMessages,
	loadSnowflakeSettings,
	setSnowflakeSessionId,
	announcementsForDialog,
	announcementsForConsole,
	loadAutoUpdaterSettings,
	loadMaintenanceSettings,
	loadForcedAppQuitMessages,
	loadAnnouncementsForDialog,
	loadAnnouncementsForConsole
} from "./app-settings";

export const MAIN_WINDOW_WIDTH = 1350;
export const MAIN_WINDOW_HALF_WIDTH = 675;
export const MAIN_WINDOW_HEIGHT = 800;
export let mainWindow: BrowserWindow;
export let numberOfMainWindowColumns = 1;
export let isSmallScreen = false;
export let executionState: ExecutionState = ExecutionState.AtRest;
let isAppQuitting = false;

app.whenReady().then(async () => {
	// Cannot require the screen module until the app is ready.
	const {screen} = require("electron");

	try {
		await createWindow();
		mainWindow.webContents.send(IpcMessage.UpdateAppVersion, app.getVersion());
		initIpcHandlers();
		createUserDirectories();

		if (app.isPackaged) {
			loadUserSettings("prod");
		} else {
			loadUserSettings("dev");
		}

		if (userSettings.isConsoleShownOnStartup) {
			numberOfMainWindowColumns = 2;
		}

		// When running on smaller screen, e.g., on laptop screen @ 1080p
		// resolution and 150% or greater zoom, then default to starting the app
		// window maximized. This makes all the HTML elements line up better,
		// i.e., without weird wrapping.

		// Typical work area sizes for laptop (in pixels):
		// 1280 x 680 @ 1080p 150% zoom
		// 1536 x 824 @ 1080p 125% zoom
		// 1920 x 1040 @ 1080p 100% zoom
		if (screen.getPrimaryDisplay().workAreaSize.width < 1536) {
			isSmallScreen = true;
		}

		if (isSmallScreen && userSettings.isConsoleShownOnStartup) {
			mainWindow.maximize();
		}

		if (!userSettings.isConsoleShownOnStartup) {
			mainWindow.setSize(MAIN_WINDOW_HALF_WIDTH, MAIN_WINDOW_HEIGHT);
			mainWindow.center();
		}

		// Showing window after loadUserSettings() to first apply dark/light
		// theme and show/hide console on startup user settings.
		mainWindow.show();

		// Add event listeners for when the main window is resized.
		mainWindow.on("resized", () => {
			const [width, height] = mainWindow.getSize();

			if (numberOfMainWindowColumns === 2 && width < MAIN_WINDOW_WIDTH) {
				mainWindow.setSize(MAIN_WINDOW_WIDTH, height);
			}

			if (numberOfMainWindowColumns === 1 && width < MAIN_WINDOW_HALF_WIDTH) {
				mainWindow.setSize(MAIN_WINDOW_HALF_WIDTH, height);
			}
		});

		mainWindow.on("unmaximize", () => {
			const [width, height] = mainWindow.getSize();
			if (numberOfMainWindowColumns === 2 && width < MAIN_WINDOW_WIDTH) {
				mainWindow.setSize(MAIN_WINDOW_WIDTH, height);
			}
			if (numberOfMainWindowColumns === 1) {
				mainWindow.setSize(MAIN_WINDOW_HALF_WIDTH, height);
			}
		});

		await Promise.all([
			loadAncillaryUtilities()
				.then(async () => {
					// Only copying from production when not running in the
					// development environment. This is to allow testing of
					// ancillary tool builds. Otherwise, the test builds would
					// be overwritten by the production builds.
					if (app.isPackaged) {
						await copyAncillaryUtilities();
					}
				}),
			loadAutoUpdaterSettings()
				.then(() => {
					initAutoUpdater();
				}),
			loadAnnouncementsForDialog()
				.then(() => {
					if (JSON.parse(announcementsForDialog).htmlContent) {
						mainWindow.webContents.send(
							IpcMessage.ShowAnnouncementsDialog,
							announcementsForDialog
						);
					}
				}),
			loadAnnouncementsForConsole(),
			loadTestSuites(),
			loadForcedAppQuitMessages(),
			loadUsers()
				.then(async () => {
					await Promise.all([
						// Maintenance settings must be loaded after users
						// since need to know if user is a developer.
						loadMaintenanceSettings(),
						connectToDatabase()
					]);
				})
		]);

		mainWindow.on("close", async (event) => {
			handleAppQuit(event);
		});

		mainWindow.webContents.send(IpcMessage.UpdateIsAppReady, true, snowflakeSessionId);

		if (user.isFirstTimeSetup) {
			addConsoleMessage({text: `${Emoji.Warning} First time setup required.`});
		} else {
			addConsoleMessage({text: `Good to go! ${Emoji.ThumbsUp}`});
		}

		if (announcementsForConsole.header) {
			addConsoleMessage({text: announcementsForConsole.header});
		}

		for (const announcement of announcementsForConsole.announcements) {
			addConsoleMessage({text: announcement});
		}

		if (announcementsForConsole.footer) {
			addConsoleMessage({text: announcementsForConsole.footer});
		}

		if (isScenarioBeingLoaded()) {
			await loadScenarioFile({uncFilepath: await getUncPath(process.argv[1])});
		}

		if (user.isDeveloper) {
			initMonitor();
		}

		await logStartUpInformation();
	} catch (err) {
		const errorMessage = String(err);
		addConsoleMessage({text: `${Emoji.Error} ${errorMessage}`});

		if (
			errorMessage
				.toUpperCase()
				.includes("THE USER YOU WERE TRYING TO AUTHENTICATE AS DIFFERS FROM THE USER CURRENTLY LOGGED IN AT THE IDP")
		) {
			addConsoleMessage({text: `${Emoji.Warning} Under the Settings tab, confirm your email address is correct. If it is not, enter your correct email address, click on Save, and restart the application.`});
		} else {
			addConsoleMessage({text: `${Emoji.Warning} Confirm you are connected to the VPN and restart the application.`});
		}

		await logAsync({type: "ERROR", subType: "BACKEND", payload: errorMessage});
	}
});

const createWindow = async (): Promise<void> => {
	mainWindow = new BrowserWindow({
		show: false,
		width: MAIN_WINDOW_WIDTH,
		height: MAIN_WINDOW_HEIGHT,
		center: true,
		webPreferences: {
			nodeIntegration: true,
			contextIsolation: false
		}
	});

	mainWindow.setMenuBarVisibility(false);
	await mainWindow.loadFile("dist/birst/index.html");
};

export const connectToDatabase = async (): Promise<void> => {
	if (!user.isFirstTimeSetup) {
		await loadSnowflakeSettings();

		await connect({
			userEmailAddress: userSettings.emailAddress,
			snowflakeSettings: snowflakeSettings
		});

		await Promise.all([
			setSnowflakeSessionId(),
			loadGeoStates(),
			loadProducts(),
			loadReleaseNotes(),
			loadAvailableDates(),
			loadWorkCompBureauRates()
		]);
	}
};

// Checking for '.birst' in CLI argument because, when the app is first
// installed, Squirrel uses the '--squirrel-firstrun' argument, so we want to
// ignore any argument that does not include the words '.birst' to prevent an
// error message.
const isScenarioBeingLoaded = (): boolean => {
	return !!(
		app.isPackaged &&
		process.argv[1] &&
		process.argv[1].toUpperCase().includes(".BIRST")
	);
};

const handleAppQuit = async (event: Electron.Event): Promise<void> => {
	// If app is quitting, exit early and the app event listener
	// "window-all-closed" will take it from here.
	if (isAppQuitting) {
		return;
	}

	event.preventDefault();

	if (executionState === ExecutionState.AtRest) {
		isAppQuitting = true;
		mainWindow.close();
		return;
	}

	if (
		(
			await dialog.showMessageBox(mainWindow, {
				type: "warning",
				buttons: ["Yes", "No"],
				defaultId: 1,
				cancelId: 1,
				noLink: true,
				title: " Confirmation Required",
				message: forcedAppQuitMessages[executionState]
			})
		).response === 0 ? true : false
	) {
		try {
			let logType = "INFO";
			if (
				executionState === ExecutionState.InitiatingRateRevision ||
				executionState === ExecutionState.CancelingRateRevision ||
				executionState === ExecutionState.SavingRatesAndGeneratingOutput
			) {
				// For the conditions above, tag the log message as an error
				// message since these forced app quits likely require clean up.
				logType = "ERROR";
				createEmail({
					emailTrigger: EmailTrigger.ForcedAppQuit,
					scenarioForm: scenarioFile.scenarioForm
				});
			}

			await execute({
				sqlText: `
					INSERT INTO prd_bizdb_coml.public_sandbox.birst_log_node_js (
						created_at_utc,
						snowflake_session_id,
						scenario_id,
						user_id,
						type,
						sub_type,
						payload
					)
					VALUES (
						'${new Date().toISOString()}',
						'${snowflakeSessionId}',
						'${scenarioFile.scenarioForm.scenarioId}',
						'${USER_ID}',
						'${logType}',
						'BACKEND',
						'Forced app quit: ${executionState}'
					);
				`
			}).catch((err) => {
				log({
					type: "ERROR",
					subType: "BACKEND",
					payload: String(err),
					bypassDatabase: true
				});
			});
		} catch (err) {
			log({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
				bypassDatabase: true
			});
		} finally {
			isAppQuitting = true;
			mainWindow.close();
		}
	}
};

app.on("window-all-closed", () => {
	disconnect()
		.catch((err) => {
			log({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
				bypassDatabase: true
			});
		})
		.finally(() => {
			app.quit();
		});
});

const logStartUpInformation = async (): Promise<void> => {
	await logAsync({
		type: "INFO",
		subType: "JSON",
		payload: JSON.stringify({
			type: "APP-START",
			isDev: !app.isPackaged,
			isFirstTimeSetup: user.isFirstTimeSetup,
			homeDirectory: USER_HOME_DIRECTORY,
			logFile: USER_LOG_FILE,
			settingsFile: USER_SETTINGS_FILE,
			settingsFileVersion: userSettings.userSettingsVersion,
			emailAddress: userSettings.emailAddress,
			snowflakeConnectionId: connection?.getId(),
			snowflakeSessionId: snowflakeSessionId,
			snowflakeRole: snowflakeSettings.role,
			snowflakeWarehouse: snowflakeSettings.warehouse,
			commandLineArguments: process.argv,
			appVersion: app.getVersion()
		})
	});
};

export const updateNumberOfMainWindowColumns = (n: number): void => {
	numberOfMainWindowColumns = n;
};

export const updateExecutionState = (es: ExecutionState): void => {
	executionState = es;
};
