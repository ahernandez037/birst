import {ipcMain} from "electron";
import {IpcMessage} from "../ipc-handlers";
import {overrideDatabaseObjects} from "./override";
import {getProductionDatabaseObjects} from "./production";
import {Emoji, addConsoleMessage} from "../console-message";

export const databaseObjectsIpcHandler = (): void => {
	ipcMain.handle(IpcMessage.GetDatabaseObjects, async (_event, payload) => {
		try {
			const scenarioForm = JSON.parse(payload);
			const productionDatabaseObjects = await getProductionDatabaseObjects(scenarioForm);

			if (productionDatabaseObjects) {
				return JSON.stringify(overrideDatabaseObjects(scenarioForm, productionDatabaseObjects));
			} else {
				return "";
			}
		} catch(err) {
			addConsoleMessage({text: `${Emoji.Error} ${String(err)}`});
			return "";
		}
	});
};
