import {DatabaseObjects} from "./types";
import {ScenarioForm} from "../scenario";
import {userSettings} from "../user-settings";

export const overrideDatabaseObjects = (
	scenarioForm: ScenarioForm,
	productionDatabaseObjects: DatabaseObjects
): DatabaseObjects => {
	let extractPolicyData = scenarioForm.extractPolicyData;
	let rateTableListCurrent = scenarioForm.rateTableListCurrent;
	let rateTableListProposed = scenarioForm.rateTableListProposed;
	let prepareRateTablesCurrent = scenarioForm.prepareRateTablesCurrent;
	let prepareRateTablesProposed = scenarioForm.prepareRateTablesProposed;
	let assignRatesCurrent = scenarioForm.assignRatesCurrent;
	let assignRatesProposed = scenarioForm.assignRatesProposed;
	let calculatePremiumCurrent = scenarioForm.calculatePremiumCurrent;
	let calculatePremiumProposed = scenarioForm.calculatePremiumProposed;
	let createDataDump = scenarioForm.createDataDump;
	let createReports = scenarioForm.createReports;
	let policyDataOverrideTable = scenarioForm.policyDataOverrideTable;
	let driverDataOverrideTable = scenarioForm.driverDataOverrideTable;

	// Replace the birst_tool schema with either the production or development
	// schema depending on the isUsingDevelopmentDatabaseSchemas setting.
	if (userSettings.isUsingDevelopmentDatabaseSchemas) {
		extractPolicyData = extractPolicyData.replace(".birst_tool.", ".birst_tool_dev.");
		rateTableListCurrent = rateTableListCurrent.replace(".birst_tool.", ".birst_tool_dev.");
		rateTableListProposed = rateTableListProposed.replace(".birst_tool.", ".birst_tool_dev.");
		prepareRateTablesCurrent = prepareRateTablesCurrent.replace(".birst_tool.", ".birst_tool_dev.");
		prepareRateTablesProposed = prepareRateTablesProposed.replace(".birst_tool.", ".birst_tool_dev.");
		assignRatesCurrent = assignRatesCurrent.replace(".birst_tool.", ".birst_tool_dev.");
		assignRatesProposed = assignRatesProposed.replace(".birst_tool.", ".birst_tool_dev.");
		calculatePremiumCurrent = calculatePremiumCurrent.replace(".birst_tool.", ".birst_tool_dev.");
		calculatePremiumProposed = calculatePremiumProposed.replace(".birst_tool.", ".birst_tool_dev.");
		createDataDump = createDataDump.replace(".birst_tool.", ".birst_tool_dev.");
		createReports = createReports.replace(".birst_tool.", ".birst_tool_dev.");
		policyDataOverrideTable = policyDataOverrideTable.replace(".birst_tool.", ".birst_tool_dev.");
		driverDataOverrideTable = driverDataOverrideTable.replace(".birst_tool.", ".birst_tool_dev.");
	} else {
		extractPolicyData = extractPolicyData.replace(".birst_tool_dev.", ".birst_tool.");
		rateTableListCurrent = rateTableListCurrent.replace(".birst_tool_dev.", ".birst_tool.");
		rateTableListProposed = rateTableListProposed.replace(".birst_tool_dev.", ".birst_tool.");
		prepareRateTablesCurrent = prepareRateTablesCurrent.replace(".birst_tool_dev.", ".birst_tool.");
		prepareRateTablesProposed = prepareRateTablesProposed.replace(".birst_tool_dev.", ".birst_tool.");
		assignRatesCurrent = assignRatesCurrent.replace(".birst_tool_dev.", ".birst_tool.");
		assignRatesProposed = assignRatesProposed.replace(".birst_tool_dev.", ".birst_tool.");
		calculatePremiumCurrent = calculatePremiumCurrent.replace(".birst_tool_dev.", ".birst_tool.");
		calculatePremiumProposed = calculatePremiumProposed.replace(".birst_tool_dev.", ".birst_tool.");
		createDataDump = createDataDump.replace(".birst_tool_dev.", ".birst_tool.");
		createReports = createReports.replace(".birst_tool_dev.", ".birst_tool.");
		policyDataOverrideTable = policyDataOverrideTable.replace(".birst_tool_dev.", ".birst_tool.");
		driverDataOverrideTable = driverDataOverrideTable.replace(".birst_tool_dev.", ".birst_tool.");
	}

	return {
		extractPolicyData: scenarioForm.extractPolicyData
			? extractPolicyData
			: productionDatabaseObjects.extractPolicyData,
		rateTableListCurrent: scenarioForm.rateTableListCurrent
			? rateTableListCurrent
			: productionDatabaseObjects.rateTableListCurrent,
		rateTableListProposed: scenarioForm.rateTableListProposed
			? rateTableListProposed
			: productionDatabaseObjects.rateTableListProposed,
		prepareRateTablesCurrent: scenarioForm.prepareRateTablesCurrent
			? prepareRateTablesCurrent
			: productionDatabaseObjects.prepareRateTablesCurrent,
		prepareRateTablesProposed: scenarioForm.prepareRateTablesProposed
			? prepareRateTablesProposed
			: productionDatabaseObjects.prepareRateTablesProposed,
		assignRatesCurrent: scenarioForm.assignRatesCurrent
			? assignRatesCurrent
			: productionDatabaseObjects.assignRatesCurrent,
		assignRatesProposed: scenarioForm.assignRatesProposed
			? assignRatesProposed
			: productionDatabaseObjects.assignRatesProposed,
		calculatePremiumCurrent: scenarioForm.calculatePremiumCurrent
			? calculatePremiumCurrent
			: productionDatabaseObjects.calculatePremiumCurrent,
		calculatePremiumProposed: scenarioForm.calculatePremiumProposed
			? calculatePremiumProposed
			: productionDatabaseObjects.calculatePremiumProposed,
		createDataDump: scenarioForm.createDataDump
			? createDataDump
			: productionDatabaseObjects.createDataDump,
		createReports: scenarioForm.createReports
			? createReports
			: productionDatabaseObjects.createReports,
		policyDataOverrideTable: scenarioForm.policyDataOverrideTable
			? policyDataOverrideTable
			: productionDatabaseObjects.policyDataOverrideTable,
		driverDataOverrideTable: scenarioForm.driverDataOverrideTable
			? driverDataOverrideTable
			: productionDatabaseObjects.driverDataOverrideTable
	};
};
