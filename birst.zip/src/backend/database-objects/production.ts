import {join} from "path";
import {app} from "electron";
import {execute} from "../database";
import {DatabaseObjects} from "./types";
import {ScenarioForm} from "../scenario";
import {userSettings} from "../user-settings";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const getProductionDatabaseObjects = async (
	scenarioForm: ScenarioForm
): Promise<DatabaseObjects | undefined> => {
	try {
		addConsoleMessage({
			text: "Loading database objects...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingDatabaseObjects
		});

		const rs = await queryDatabase(scenarioForm);

		if (rs) {
			stopConsoleMessageTimer(ConsoleMessageId.LoadingDatabaseObjects);

			return {
				extractPolicyData: String((rs[0] as Record<string, unknown>)["EXTRACT_POLICY_DATA"]),
				rateTableListCurrent: String((rs[0] as Record<string, unknown>)["RATE_TABLE_LIST_CURRENT"]),
				rateTableListProposed: String((rs[0] as Record<string, unknown>)["RATE_TABLE_LIST_PROPOSED"]),
				prepareRateTablesCurrent: String((rs[0] as Record<string, unknown>)["PREPARE_RATE_TABLES_CURRENT"]),
				prepareRateTablesProposed: String((rs[0] as Record<string, unknown>)["PREPARE_RATE_TABLES_PROPOSED"]),
				assignRatesCurrent: String((rs[0] as Record<string, unknown>)["ASSIGN_RATES_CURRENT"]),
				assignRatesProposed: String((rs[0] as Record<string, unknown>)["ASSIGN_RATES_PROPOSED"]),
				calculatePremiumCurrent: String((rs[0] as Record<string, unknown>)["CALCULATE_PREMIUM_CURRENT"]),
				calculatePremiumProposed: String((rs[0] as Record<string, unknown>)["CALCULATE_PREMIUM_PROPOSED"]),
				createDataDump: String((rs[0] as Record<string, unknown>)["CREATE_DATA_DUMP"]),
				createReports: String((rs[0] as Record<string, unknown>)["CREATE_REPORTS"]),
				policyDataOverrideTable: String((rs[0] as Record<string, unknown>)["POLICY_DATA_OVERRIDE_TABLE"]),
				driverDataOverrideTable: String((rs[0] as Record<string, unknown>)["DRIVER_DATA_OVERRIDE_TABLE"])
			};
		}

		stopConsoleMessageTimer(ConsoleMessageId.LoadingDatabaseObjects);
		return undefined;
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingDatabaseObjects);
		throw err;
	}
};

const queryDatabase = async (scenarioForm: ScenarioForm): Promise<unknown[] | undefined> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetDatabaseObjects)))[0];

	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioForm
			}
		})
	);

	const [, rs] = await execute({sqlText});
	return rs;
};
