import {ipcMain} from "electron";
import {ScenarioForm} from "../scenario";
import {USER_ID} from "../user-settings";
import {IpcMessage} from "../ipc-handlers";
import {snowflakeSettings} from "../app-settings";
import {getPrefixesFromScenarioForm} from "../scenario-file";

export const dataDumpIpcHandler = (): void => {
	ipcMain.handle(IpcMessage.GetDataDumpTableName, (_event, payload) => {
		return JSON.stringify(getDataDumpTableName(JSON.parse(payload)));
	});
};

export const getDataDumpTableName = (scenarioForm: ScenarioForm): string => {
	let [
		lineOfBusiness,
		product,
		version,
		geoState,
		renewalDate,
		dataSource
	] = getPrefixesFromScenarioForm(scenarioForm);

	if (geoState.toUpperCase() === "ALL_") {
		geoState = "CW_";
	}

	renewalDate = renewalDate.replace(/-/g, "");
	const runMode = scenarioForm.runMode.replace(/-/g, "_") + "_";
	const queryMethod = scenarioForm.queryMethod === "IN-FORCE" ? "INFORCE_" : "EFF_DATE_";
	const startDate = scenarioForm.startDate
		? scenarioForm.startDate.substring(0, 10).replace(/-/g, "") + "_"
		: "";
	const endDate = scenarioForm.endDate
		? scenarioForm.endDate.substring(0, 10).replace(/-/g, "") + "_"
		: "";
	const inforceDate =
			scenarioForm.queryMethod === "IN-FORCE"
				? scenarioForm.inforceDate
					? scenarioForm.inforceDate.substring(0, 10).replace(/-/g, "") + "_"
					: ""
				: "";

	return (
		snowflakeSettings.dataDumpDatabaseSchema +
		"." +
		(
			"bdd_" +
			lineOfBusiness +
			product +
			version +
			geoState +
			renewalDate +
			runMode +
			dataSource +
			queryMethod +
			startDate +
			endDate +
			inforceDate +
			USER_ID +
			"_" +
			scenarioForm.scenarioId
		)
			.replace(/-/g, "_")
			.replace(/\./g, "_")
			.toLocaleLowerCase()
	);
};
