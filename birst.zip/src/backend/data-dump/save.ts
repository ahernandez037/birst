import {join} from "path";
import {promisify} from "util";
import {stringify} from "csv/sync";
import {createWriteStream} from "fs-extra";
import {pipeline, Transform} from "stream";
import {log} from "../logger";
import {connection} from "../database";
import {scenarioFile} from "../scenario-file";
import {convertKeysToLowercase} from "../utilities";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const saveDataDump = async (): Promise<void> => {
	const pipelineStream = promisify(pipeline);

	addConsoleMessage({
		text: "Saving data dump to hard drive...",
		hasTimer: true,
		timerId: ConsoleMessageId.SavingDataDumpToHardDrive
	});

	const transformStream = getTransformStream();
	const writeStream = createWriteStream(join(scenarioFile.scenarioForm.scenarioDirectory, scenarioFile.files.dataDumpFile));

	let orderBy = "pol_policy_sk, cov_coverage_id";

	if (scenarioFile.scenarioForm.lineOfBusiness === "UMB") {
		orderBy = "umb_ul_policy_sk, underlying_policy_type";
	}

	if (scenarioFile.scenarioForm.lineOfBusiness === "WC") {
		orderBy = "policy_sk, wc_class_code";
	}

	const sqlText = `
		SELECT *
		FROM ${scenarioFile.scenarioForm.dataDumpTable}
		ORDER BY ${orderBy};
  	`;

	return new Promise((resolve, reject) => {
		connection?.execute({
			sqlText,
			streamResult: true,
			complete: async (err, statement) => {
				if (err) {
					const message = `Unable to start data dump stream: ${err.message}`;
					addConsoleMessage({text: message});

					log({
						type: "INFO",
						subType: "BACKEND",
						payload: message
					});

					stopConsoleMessageTimer(ConsoleMessageId.SavingDataDumpToHardDrive);
					reject(err);
				} else {
					await pipelineStream(statement.streamRows(), transformStream, writeStream);
					writeStream.end();
					stopConsoleMessageTimer(ConsoleMessageId.SavingDataDumpToHardDrive);
					resolve();
				}
			}
		});
	});
};

const getTransformStream = (): Transform => {
	const transformStream = new Transform({objectMode: true});

	let records: Record<string, unknown>[] = [];
	let isFirstRecord = true;

	transformStream._transform = (chunk, _encode, callback) => {
		records = [];
		records.push(convertKeysToLowercase(chunk) as Record<string, unknown>);

		callback(
			null,
			stringify(records, {
				header: isFirstRecord,
				cast: {
					date: (value) => value.toISOString().slice(0, 10)
				}
			})
		);

		isFirstRecord = false;
	};

	return transformStream;
};
