import {join} from "path";
import {app} from "electron";
import {execute} from "../database";
import {scenarioFile} from "../scenario-file";
import {userSettings} from "../user-settings";
import {loadRatesFile, RateTableForUpload, tablesForUpload} from "../rates-file";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const doRatesExist = async (table: RateTableForUpload): Promise<boolean> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CheckIfRatesExist)))[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				tableName: table.tableName,
				scenarioFile: scenarioFile
			}
		})
	);
	const [, results] = await execute({sqlText});
	const recordCount = Number((results as Record<string, unknown>[])[0]["RECORD_COUNT"]);
	if (recordCount > 0) {
		return true;
	}
	return false;
};

export const checkForSavedRates = async (): Promise<void> => {
	try {
		const tablesWithSavedRates: string[] = [];
		const tablesWithoutSavedRates: string[] = [];

		await loadRatesFile();

		addConsoleMessage({
			text: "Checking for saved rates...",
			hasTimer: true,
			timerId: ConsoleMessageId.CheckingForSavedRates
		});

		for (const table of tablesForUpload) {
			if (await doRatesExist(table)) {
				tablesWithSavedRates.push(table.tableName);
			} else {
				tablesWithoutSavedRates.push(table.tableName);
			}
		}

		// Work Comp has a special table that gets saved in the background even
		// when no proposed rates are entered. This is due to the minimum
		// premium calculations that are needed to derive the Farmers minimum
		// premium. Therefore, need to always check if the rates exist for this
		// table.
		if (
			scenarioFile.scenarioForm.lineOfBusiness === "WC" &&
			(await doRatesExist({tableName: "wc_minimum_premium_nonbureau", records: []})) &&
			!tablesForUpload.find(
				(table) => table.tableName.toUpperCase() === "WC_MINIMUM_PREMIUM_NONBUREAU"
			)
		) {
			tablesWithSavedRates.push("wc_minimum_premium_nonbureau");
		}

		if (!tablesWithSavedRates.length) {
			addConsoleMessage({text: "Did not find any in-scope rate tables with saved rates."});
		} else {
			addConsoleMessage({text: `Found the following in-scope rate tables with saved rates: ${tablesWithSavedRates.join(", ")}`});

			if (tablesWithoutSavedRates.length) {
				addConsoleMessage({text: `Found the following in-scope rate tables <b>without</b> saved rates: ${tablesWithoutSavedRates.join(", ")}`});
			}
		}
		stopConsoleMessageTimer(ConsoleMessageId.CheckingForSavedRates);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CheckingForSavedRates);
		throw err;
	}
};
