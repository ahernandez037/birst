import {join} from "path";
import * as xlsx from "xlsx";
import {chmod, copy} from "fs-extra";
import {log} from "../logger";
import {scenarioFile} from "../scenario-file";
import {userSettings} from "../user-settings";
import {waitUntilFileClosed} from "../utilities";
import {lineOfBusinessDirectory} from "../rate-revision";
import {runBirstFileFormatter} from "../utilities/ancillary";
import {getReportFileAbsoluteFilepath} from "../report-file";
import {addScenarioDetailsToExcelWorkbook} from "../scenario/details";
import {ConsoleMessageId, addConsoleMessage, stopConsoleMessageTimer} from "../console-message";
import {
	getInScopeRateTables,
	workbook as ratesFileWorkbook,
	getWorksheetWithoutScratchAreaColumns
} from "../rates-file";

export const createFitExhibits = async (isDevTest?: boolean): Promise<void> => {
	// Return early in case FIT exhibits file is undefined, which could be the
	// case for older scenario files, i.e., when the property didn't yet exist
	// in the schema.
	if (!scenarioFile.files.fitExhibitsFile) {
		return;
	}

	const inScopeRateTables = getInScopeRateTables();

	if (inScopeRateTables.length === 0) {
		if (isDevTest) {
			throw new Error("Unable to create the FIT exhibits because there are no in-scope rate tables.");
		}

		// If running in production environment, just show a message, i.e.,
		// don't throw an error as the initiate rate revision process needs to
		// continue until finalized.
		addConsoleMessage({text: "Did not create any FIT exhibits because there are no in-scope rate tables."});

		log({
			type: "WARNING",
			subType: "BACKEND",
			payload: "Did not create any FIT exhibits because there are no in-scope rate tables."
		});

		return;
	}

	try {
		addConsoleMessage({
			text: "Creating FIT exhibits...",
			hasTimer: true,
			timerId: ConsoleMessageId.CreatingFitExhibits
		});

		await copy(
			join(userSettings.excelTemplatesDirectory, "fit-exhibits-template.xlsm"),
			getFitExhibitsFileAbsoluteFilepath(isDevTest)
		);

		const fitExhibitsWorkbook = xlsx.readFile(getFitExhibitsFileAbsoluteFilepath(isDevTest), {
			bookVBA: true
		});

		addScenarioDetailsToExcelWorkbook(fitExhibitsWorkbook);

		// Delete the dummy worksheet.
		delete fitExhibitsWorkbook.Sheets["dummy"];
		for (let i = 0; i < fitExhibitsWorkbook.SheetNames.length; i++) {
			if (fitExhibitsWorkbook.SheetNames[i] === "dummy") {
				fitExhibitsWorkbook.SheetNames.splice(i, 1);
			}
		}

		if (scenarioFile.scenarioForm.lineOfBusiness === "WC") {
			// For Work Comp we're copying the rates_exhibits worksheet from the
			// report file into the FIT exhibits file.
			const reportFileWorkbook = xlsx.readFile(getReportFileAbsoluteFilepath(), {
				// To convert date from sequential serial number to ISO string.
				cellDates: true
			});
			const ratesExhibit = reportFileWorkbook.Sheets["rates_exhibit"];

			if (ratesExhibit["!autofilter"]) {
				delete ratesExhibit["!autofilter"];
			}

			xlsx.utils.book_append_sheet(fitExhibitsWorkbook, ratesExhibit, "rates_exhibit");
		}

		for (const rateTable of inScopeRateTables) {
			// Skipping this Work Comp table since the RATES_EXHIBIT worksheet
			// from the report file is used in it's place.
			if (rateTable.fullTableName.toUpperCase() === "WC_BUREAU_LC") {
				continue;
			}

			// Get rate table worksheet without "scratch area" columns.
			const worksheet = getWorksheetWithoutScratchAreaColumns(ratesFileWorkbook.Sheets[rateTable.ratesFileTableName]);

			const sourceJson: Record<string, unknown>[] = xlsx.utils.sheet_to_json(worksheet, {
				blankrows: true,
				skipHidden: false,
				defval: ""
			});

			const targetJson: Record<string, unknown>[] = [];

			// Loop through all rows
			for (const record of sourceJson) {
				// Holds the transformed column, e.g., new column name after
				// dropping the "_PROPOSED" wording.
				const column: Record<string, unknown> = {};

				// Loop through all columns.
				for (const [key, value] of Object.entries(record)) {
					if (key.startsWith("__EMPTY")) {
						continue;
					}

					// Exclude unwanted columns.
					if (
						![
							"STATE",
							"RB_EFF_DATE",
							"NB_EFF_DATE",
							"EFF_DATE",
							"WRITTEN_DATE",
							"NEW_DATE",
							"RENEWAL_DATE",
							"AVAILABLE_DATE",
							"ID",
							"PAS_TABLE_NUM"
						].includes(key.toUpperCase()) &&
						!key.toUpperCase().endsWith("_CURRENT") &&
						!key.toUpperCase().endsWith("_PCT_CHG")
					) {
						// Remove "_PROPOSED" wording.
						column[`${key.replace("_PROPOSED", "")}`] = value;
					}
				}

				targetJson.push(column);
			}

			xlsx.utils.book_append_sheet(
				fitExhibitsWorkbook,
				xlsx.utils.json_to_sheet(targetJson),
				rateTable.ratesFileTableName
			);
		}

		log({
			type: "INFO",
			subType: "BACKEND",
			payload: `FIT Exhibits filepath: ${getFitExhibitsFileAbsoluteFilepath(isDevTest)}`,
			bypassDatabase: true
		});

		await xlsx.writeFile(fitExhibitsWorkbook, getFitExhibitsFileAbsoluteFilepath(isDevTest), {
			bookType: "xlsm",
			compression: true
		});

		stopConsoleMessageTimer(ConsoleMessageId.CreatingFitExhibits);
		// Added wait since shared drives can be slow to save/close files.
		await waitUntilFileClosed(getFitExhibitsFileAbsoluteFilepath(isDevTest));

		addConsoleMessage({
			text: "Applying formatting...",
			hasTimer: true,
			timerId: ConsoleMessageId.ApplyingExcelFormatting
		});

		await runBirstFileFormatter("FIT-EXHIBITS", getFitExhibitsFileAbsoluteFilepath(isDevTest));
		stopConsoleMessageTimer(ConsoleMessageId.ApplyingExcelFormatting);
		// Added wait since shared drives can be slow to save/close files.
		await waitUntilFileClosed(getFitExhibitsFileAbsoluteFilepath(isDevTest));
		// Set file mode to read only.
		await chmod(getFitExhibitsFileAbsoluteFilepath(isDevTest), 0o400);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CreatingFitExhibits);
		stopConsoleMessageTimer(ConsoleMessageId.ApplyingExcelFormatting);
		throw err;
	}
};

const getFitExhibitsFileAbsoluteFilepath = (isDevTest?: boolean): string => {
	// If calling as a developer test, e.g., from the Developer / Misc tab in
	// the UI, output to the same directory where the scenario is located.
	if (isDevTest) {
		return join(
			scenarioFile.scenarioForm.scenarioDirectory,
			scenarioFile.files.fitExhibitsFile
		);
	}

	// Otherwise, i.e., running in production environment, output to the FIT
	// directory that's in the shared drive.
	const targetDirectory =
		lineOfBusinessDirectory[
			scenarioFile.scenarioForm.lineOfBusiness as keyof typeof lineOfBusinessDirectory
		] +
		scenarioFile.scenarioForm.geoState +
		"\\" +
		scenarioFile.scenarioForm.renewalDate.substring(0, 10) +
		"_RB\\FIT";

	return join(targetDirectory, scenarioFile.files.fitExhibitsFile);
};
