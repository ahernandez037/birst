import {DateTime} from "luxon";
import {logAsync} from "../logger";
import {scenarioFile} from "../scenario-file";
import {RatesBeingUsed, RunMode} from "./types";
import {addConsoleMessage, Emoji, ConsoleMessageId} from "../console-message";
import {getDataDumpDuplicateCount, getDataDumpRecordCount} from "../data-dump";

export const getRateTypeMessage = (ratesBeingUsed: RatesBeingUsed): string =>
	scenarioFile.scenarioForm.runMode === RunMode.RateChange ? ratesBeingUsed.toLowerCase() : "";

export const getUiMessageIdForPrepareRateTables = (
	ratesBeingUsed: RatesBeingUsed
): ConsoleMessageId =>
	ratesBeingUsed === RatesBeingUsed.Current
		? ConsoleMessageId.PreparingRateTablesCurrent
		: ConsoleMessageId.PreparingRateTablesProposed;

export const getUiMessageIdForGetRateData = (rates: RatesBeingUsed): ConsoleMessageId =>
	rates === RatesBeingUsed.Current
		? ConsoleMessageId.AssigningCurrentRates
		: ConsoleMessageId.AssigningProposedRates;

export const getUiMessageIdForCalculatePremium = (rates: RatesBeingUsed): ConsoleMessageId =>
	rates === RatesBeingUsed.Current
		? ConsoleMessageId.CalculatingPremiumCurrent
		: ConsoleMessageId.CalculatingPremiumProposed;

export const showFinishedMessages = async (startTime: DateTime): Promise<string> => {
	const endTime = DateTime.now();
	const runtimeObject = endTime.diff(startTime, ["minutes", "seconds"]).toObject();
	const runtimeMessage = `Total runtime: ${runtimeObject.minutes || 0} minutes ${runtimeObject.seconds?.toFixed(0) || 0} seconds`;
	const dataDumpRecordCount = await getDataDumpRecordCount();
	const dataDumpDuplicateCount = await getDataDumpDuplicateCount();
	const dataDumpRecordCountMessage = `Data dump record count: ${dataDumpRecordCount.toLocaleString("en-US")}`;

	addConsoleMessage({text: `Finished running scenario! ${Emoji.FinishFlag}`});
	addConsoleMessage({text: runtimeMessage});
	addConsoleMessage({text: dataDumpRecordCountMessage});

	// Skipping duplicate check for WC Gradient AI initiative since there
	// will always be duplicates for these scenarios due to rating the same
	// policy multiple times (once for each UW company).
	if (scenarioFile.scenarioForm.isWorkCompGradientAiInitiative) {
		addConsoleMessage({text: `Duplicate check skipped ${Emoji.CheckMark}`});
	} else if (dataDumpDuplicateCount > 0) {
		addConsoleMessage({text: `${Emoji.Warning} Duplicates detected in data dump: ${dataDumpDuplicateCount}`});

		await logAsync({
			type: "ERROR",
			subType: "BACKEND",
			payload: `Duplicates detected in data dump: ${dataDumpDuplicateCount}`
		});
	} else {
		addConsoleMessage({text: `No duplicate records detected ${Emoji.CheckMark}`});
	}

	await logAsync({
		type: "INFO",
		subType: "JSON",
		payload: JSON.stringify({
			type: "SCENARIO-RUN-END",
			runTimeInSeconds: endTime.diff(startTime, "seconds").toObject().seconds,
			dataDumpRecordCount: dataDumpRecordCount,
			scenarioFile: JSON.stringify(scenarioFile)
		})
	});

	return `${dataDumpRecordCount} records in ${runtimeObject.minutes}m ${runtimeObject.seconds?.toFixed(0)}s`;
};
