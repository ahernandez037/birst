import {join} from "path";
import {app} from "electron";
import {DateTime} from "luxon";
import {promisify} from "util";
import {randomUUID} from "crypto";
import {stringify} from "csv/sync";
import {pipeline, Transform} from "stream";
import {ensureDir, outputFile, createWriteStream} from "fs-extra";
import {logAsync} from "../logger";
import {scenarioFile} from "../scenario-file";
import {connection, execute} from "../database";
import {convertKeysToLowercase} from "../utilities";
import {USER_HOME_DIRECTORY, userSettings} from "../user-settings";
import {SqlFunctionFile, executeDynamicJsFunction, loadDynamicJsFunction} from "../dynamic-js";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer
} from "../console-message";

// * This feature is only available to developers to facilitate development and
// * debugging.

export let isDebugRun = false;
export let debugRunDynamicJs = "";

export const updateIsDebugRun = (newValue: boolean): void => {
	isDebugRun = newValue;
};
export const appendToDebugRunDynamicJs = (data: string): void => {
	debugRunDynamicJs += data;
};
export const resetDebugRunDynamicJs = (): void => {
	debugRunDynamicJs = "";
};

/**
 * Creates a table that holds a list of all the temporary tables that are
 * created by the various procedures.
 */
export const createTempTableList = async (): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Creating temporary table list...",
			hasTimer: true,
			timerId: ConsoleMessageId.CreatingTemporaryTableList
		});

		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CreateTempTableList)))[0];
		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
					scenarioFile
				}
			})
		);

		await execute({sqlText});
		stopConsoleMessageTimer(ConsoleMessageId.CreatingTemporaryTableList);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CreatingTemporaryTableList);
		throw err;
	}
};

/**
 * Saves the contents of all the temporary tables created in Snowflake (when
 * running a scenario) to CSV files. Also saves DynamicJS to text file.
 * Useful for debugging.
 */
export const saveDebugRunOutput = async (): Promise<void> => {
	try {
		const startTime = DateTime.now();
		const tableNames: string[] = [];
		const uuid = randomUUID();

		let destinationDirectory = "";

		addConsoleMessage({
			text: "Getting table names for debug output...",
			hasTimer: true,
			timerId: ConsoleMessageId.GettingDebugOutputTableNames
		});

		const rs = await getTableNames();
		stopConsoleMessageTimer(ConsoleMessageId.GettingDebugOutputTableNames);

		if (rs) {
			for (const r of rs as Record<string, unknown>[]) {
				tableNames.push(String(r["TABLE_NAME"]).toLowerCase());
			}

			destinationDirectory = join(USER_HOME_DIRECTORY, "Debug", uuid);
			await ensureDir(destinationDirectory);
		} else {
			addConsoleMessage({text: `No tables found ${Emoji.SadFace}`});
			return;
		}

		await outputFile(join(destinationDirectory, ".dynamic_js.txt"), debugRunDynamicJs);

		for (const tableName of tableNames) {
			addConsoleMessage({
				text: `Saving ${tableName}...`,
				hasTimer: true,
				timerId: ConsoleMessageId.SavingDebugOutputToCsv
			});

			await saveToCsv(tableName, destinationDirectory);
			stopConsoleMessageTimer(ConsoleMessageId.SavingDebugOutputToCsv);
		}

		const endTime = DateTime.now();
		const runtime = endTime.diff(startTime, ["minutes", "seconds"]).toObject();

		addConsoleMessage({text: `Finished saving files to: ${destinationDirectory} (${runtime.minutes || 0}m ${runtime.seconds?.toFixed(0) || 0}s)`});
		stopConsoleMessageTimer(ConsoleMessageId.GettingDebugOutputTableNames);
		stopConsoleMessageTimer(ConsoleMessageId.SavingDebugOutputToCsv);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.GettingDebugOutputTableNames);
		stopConsoleMessageTimer(ConsoleMessageId.SavingDebugOutputToCsv);
		throw err;
	}
};

const getTableNames = async (): Promise<unknown[] | undefined> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetTempTableList)))[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile
			}
		})
	);
	const [, rs] = await execute({sqlText});

	return rs;
};

const saveToCsv = async (tableName: string, destinationDirectory: string): Promise<void> => {
	const pipelineStream = promisify(pipeline);
	const transformStream = getTransformStream();
	const writeStream = createWriteStream(join(destinationDirectory, `${tableName}.csv`));

	return new Promise((resolve, reject) => {
		connection?.execute({
			sqlText: `
				SELECT *
				FROM ${tableName};
			`,
			streamResult: true,
			complete: async (err, statement) => {
				if (err) {
					await logAsync({
						type: "ERROR",
						subType: "BACKEND",
						payload: err.message
					});

					reject(err);
					throw err;
				} else {
					await pipelineStream(statement.streamRows(), transformStream, writeStream);
					writeStream.end();
					resolve();
				}
			}
		});
	});
};

const getTransformStream = (): Transform => {
	const transformStream = new Transform({objectMode: true});

	let records: Record<string, unknown>[] = [];
	let isFirstRecord = true;

	transformStream._transform = (chunk, _encode, callback) => {
		records = [];
		records.push(convertKeysToLowercase(chunk) as Record<string, unknown>);

		callback(
			null,
			stringify(records, {
				header: isFirstRecord,
				cast: {
					date: (value) => value.toISOString().slice(0, 10)
				}
			})
		);

		isFirstRecord = false;
	};

	return transformStream;
};
