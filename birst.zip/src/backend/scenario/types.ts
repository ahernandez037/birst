export const enum RunMode {
	RateChange = "RATE-CHANGE",
	OnLevel = "ON-LEVEL",
	Validation = "VALIDATION",
}

export const enum QueryMethod {
	InForce = "IN-FORCE",
	EffectiveDate = "EFFECTIVE-DATE",
}

export const enum DataSource {
	Production = "PROD",
	Mrt = "MRT",
	Qat = "QAT",
}

export const enum RatesBeingUsed {
	Current = "CURRENT",
	Proposed = "PROPOSED",
}

export interface ScenarioForm {
	runMode: string;
	queryMethod: string;
	onLevelRatePlan: string;
	onLevelRatePlanDate: string;
	inforceDate: string;
	startDate: string;
	endDate: string;
	geoState: string;
	lineOfBusiness: string;
	product: string;
	version: string;
	workCompAdoptBureauRates: boolean;
	workCompBureauEffectiveDate: string;
	workCompBureauReleaseDate: string;
	workCompBureauStatusFlag: string;
	newDate: string;
	renewalDate: string;
	availableDate: string;
	fdrcTimestamp: string;
	dataSource: string;
	scenarioId: string;
	scenarioDirectory: string;
	dataDumpTable: string;
	saveDataDumpToHardDrive: boolean;
	useCountrywideData: boolean;
	useAllVersionsData: boolean;
	isAutoFlexRollout: boolean;
	isRstGlSalesInitiative: boolean;
	isWorkCompGradientAiInitiative: boolean;
	isRstBieeSpecifiedLimitInitiative: boolean;
	extractPolicyData: string;
	rateTableListCurrent: string;
	rateTableListProposed: string;
	prepareRateTablesCurrent: string;
	prepareRateTablesProposed: string;
	assignRatesCurrent: string;
	assignRatesProposed: string;
	calculatePremiumCurrent: string;
	calculatePremiumProposed: string;
	createDataDump: string;
	createReports: string;
	policyDataOverrideTable: string;
	driverDataOverrideTable: string;
}

export interface ReusedScenarioId {
	scenarioId: string;
	createdBy: string;
	createdAtUtc: Date;
	geoState: string;
	lineOfBusiness: string;
	product: string;
	version: string;
}
