import {join} from "path";
import {DateTime} from "luxon";
import {app, Notification} from "electron";
import {RunMode} from "./types";
import {mainWindow} from "../main";
import {logAsync} from "../logger";
import {execute} from "../database";
import {RatesBeingUsed} from "./types";
import {IpcMessage} from "../ipc-handlers";
import {assignRates} from "./assign-rates";
import {userSettings} from "../user-settings";
import {calculatePremium} from "./calculate-premium";
import {extractPolicyData} from "./extract-policy-data";
import {prepareRateTables} from "./prepare-rate-tables";
import {createReports, saveReports} from "../report-file";
import {createDataDump, saveDataDump} from "../data-dump";
import {isDebugRun, resetDebugRunDynamicJs} from "./debug";
import {saveScenarioFile, scenarioFile} from "../scenario-file";
import {getWorkCompLCMs, loadImplementedInitiatives} from "../initiatives";
import {ratePlan as currentRatePlan, loadRatePlanCurrent} from "../rate-plan";
import {addConsoleMessage, stopConsoleMessageTimer, Emoji} from "../console-message";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {getRateTypeMessage, showFinishedMessages, getUiMessageIdForCalculatePremium} from "./messages";

export const runScenario = async (): Promise<void> => {
	const startTime = DateTime.now();
	resetDebugRunDynamicJs();
	addConsoleMessage({text: `Running scenario ${Emoji.RunningPerson}${isDebugRun ? `...in debug mode! ${Emoji.Bug}` : ""}`});

	// Destructuring to not log certain properties to save time/space.
	// All properties are saved after a successful scenario run anyway.
	const {files, executiveSummary, rateHistory, ratePlan, ...partialScenarioFile} = scenarioFile;

	await logAsync({
		type: "INFO",
		subType: "JSON",
		payload: JSON.stringify({
			type: "SCENARIO-RUN-START",
			scenarioFile: JSON.stringify(partialScenarioFile)
		})
	});

	if (scenarioFile.scenarioForm.runMode === RunMode.RateChange) {
		showSelectedInitiatives();
		await runRateChangeScenario();
		scenarioFile.ratePlan = currentRatePlan;
	} else {
		await runValidationScenario();
	}

	// To save the executive summary, rate history, and rate plan details.
	await saveScenarioFile();

	if (scenarioFile.executiveSummary.impactPercent !== null) {
		mainWindow.webContents.send(
			IpcMessage.UpdateOverallRateImpact,
			(scenarioFile.executiveSummary.impactPercent * 100).toFixed(2)
		);
	}

	const notificationBody = await showFinishedMessages(startTime);

	new Notification({
		title: `Your scenario finished running ${Emoji.FinishFlag}`,
		body: notificationBody
	}).show();
};

const runRateChangeScenario = async (): Promise<void> => {
	// Redesigned raters.
	if (["HAB", "REA", "ROS", "RST"].includes(scenarioFile.scenarioForm.product)) {
		await Promise.all([
			extractPolicyData(),
			prepareRateTables(RatesBeingUsed.Current),
			prepareRateTables(RatesBeingUsed.Proposed),
			loadRatePlanCurrent(scenarioFile.scenarioForm)
		]).then(async () => {
			const implementedInitiatives = await loadImplementedInitiatives();
			showImplementedInitiatives(implementedInitiatives);

			await Promise.all([
				assignRates(RatesBeingUsed.Current).then(async () => {
					await calculatePremium(RatesBeingUsed.Current, implementedInitiatives);
				}),
				assignRates(RatesBeingUsed.Proposed).then(async () => {
					await calculatePremium(RatesBeingUsed.Proposed, implementedInitiatives);
				})
			]);

			await createDataDump();

			if (scenarioFile.scenarioForm.saveDataDumpToHardDrive) {
				await Promise.all([
					saveDataDump(),
					createReports().then(async () => {
						await saveReports();
					})
				]);
			} else {
				await createReports();
				await saveReports();
			}
		});
	}
	// Lift-and-shift raters.
	else {
		const raterRuns: any[] = [];
		let miscJsonForCreateDataDump: string | undefined = undefined;

		if (scenarioFile.scenarioForm.isWorkCompGradientAiInitiative) {
			const lossCostMultipliers = await getWorkCompLCMs();

			for (const lcm of lossCostMultipliers) {
				raterRuns.push({
					func: runLegacyRater,
					args: {
						ratesBeingUsed: RatesBeingUsed.Current,
						isWorkCompGradientAiInitiative: true,
						uwCompany: lcm.uwCompany,
						lcm: lcm.lcm
					}
				});

				raterRuns.push({
					func: runLegacyRater,
					args: {
						ratesBeingUsed: RatesBeingUsed.Proposed,
						isWorkCompGradientAiInitiative: true,
						uwCompany: lcm.uwCompany,
						lcm: lcm.lcm
					}
				});
			}

			// Used to pass a comma delimited string containing all of the
			// applicable UW company IDs.
			miscJsonForCreateDataDump = JSON.stringify({
				isWorkCompGradientAiInitiative: true,
				uwCompanies: lossCostMultipliers.map((lcm) => lcm.uwCompany).join(",")
			});
		} else {
			raterRuns.push({
				func: runLegacyRater,
				args: {ratesBeingUsed: RatesBeingUsed.Current}
			});

			raterRuns.push({
				func: runLegacyRater,
				args: {ratesBeingUsed: RatesBeingUsed.Proposed}
			});
		}

		await Promise.all([
			extractPolicyData(),
			prepareRateTables(RatesBeingUsed.Current),
			prepareRateTables(RatesBeingUsed.Proposed),
			loadRatePlanCurrent(scenarioFile.scenarioForm)
		]).then(async () => {
			await Promise.all(raterRuns.map((run) => run.func(run.args)));
			await createDataDump(miscJsonForCreateDataDump);

			if (scenarioFile.scenarioForm.saveDataDumpToHardDrive) {
				await Promise.all([
					saveDataDump(),
					createReports()
						.then(async () => {
							await saveReports();
						})
				]);
			} else {
				await createReports();
				await saveReports();
			}
		});
	}
};

const runValidationScenario = async (): Promise<void> => {
	await Promise.all([
		extractPolicyData(),
		prepareRateTables(RatesBeingUsed.Current)
	]).then(async () => {
		// Redesigned raters.
		if (
			scenarioFile.scenarioForm.lineOfBusiness === "CMP" &&
			["HAB", "REA", "ROS", "RST"].includes(scenarioFile.scenarioForm.product)
		) {
			await assignRates(RatesBeingUsed.Current);
			await calculatePremium(RatesBeingUsed.Current);
			await createDataDump();

			// Redesigned raters validation mode.
			if (scenarioFile.scenarioForm.runMode === RunMode.Validation) {
				if (scenarioFile.scenarioForm.saveDataDumpToHardDrive) {
					await Promise.all([
						saveDataDump(),
						createReports().then(() => {
							saveReports();
						})
					]);
				} else {
					await createReports();
					await saveReports();
				}
			}
			// Redesigned raters on-level mode.
			else {
				if (scenarioFile.scenarioForm.saveDataDumpToHardDrive) {
					await saveDataDump();
				}
			}
		}
		// Lift-and-shift raters.
		else {
			await runLegacyRater({ratesBeingUsed: RatesBeingUsed.Current});
			await createDataDump();
			// Lift-and-shift raters validation mode.
			if (scenarioFile.scenarioForm.runMode === RunMode.Validation) {
				if (scenarioFile.scenarioForm.saveDataDumpToHardDrive) {
					await Promise.all([
						saveDataDump(),
						createReports().then(() => {
							saveReports();
						})
					]);
				} else {
					await createReports();
					await saveReports();
				}
			}
			// Lift-and-shift raters on-level mode.
			else {
				if (scenarioFile.scenarioForm.saveDataDumpToHardDrive) {
					await saveDataDump();
				}
			}
		}
	});
};

const runLegacyRater = async (args: {
	ratesBeingUsed: RatesBeingUsed;
	isWorkCompGradientAiInitiative?: boolean;
	uwCompany?: string;
	lcm?: number;
}): Promise<void> => {
	const rateTypeMessage = getRateTypeMessage(args.ratesBeingUsed);
	let message = "Assigning rates & calculating premium";
	let miscJson: string | undefined = undefined;

	if (args.isWorkCompGradientAiInitiative) {
		message = `Calculating premium - UW co. ${args.uwCompany} (${getRateTypeMessage(args.ratesBeingUsed)})...`;

		miscJson = JSON.stringify({
			isWorkCompGradientAiInitiative: true,
			uwCompany: args.uwCompany,
			lcm: args.lcm
		});
	} else {
		if (rateTypeMessage) {
			message += ` (${getRateTypeMessage(args.ratesBeingUsed)})...`;
		} else {
			message += "...";
		}
	}

	addConsoleMessage({
		text: message,
		hasTimer: true,
		timerId: getUiMessageIdForCalculatePremium(args.ratesBeingUsed)
	});

	try {
		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.RunLegacyRater)))[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
					ratesBeingUsed: args.ratesBeingUsed,
					scenarioFile,
					miscJson
				}
			})
		);

		await execute({sqlText});
		stopConsoleMessageTimer(getUiMessageIdForCalculatePremium(args.ratesBeingUsed));
	} catch (err) {
		stopConsoleMessageTimer(getUiMessageIdForCalculatePremium(args.ratesBeingUsed));
		throw err;
	}
};

const showSelectedInitiatives = (): void => {
	if (scenarioFile.scenarioForm.isAutoFlexRollout) {
		addConsoleMessage({text: "<b>FYI - Running with initiative: AUTO-FLEX-ROLLOUT</b>"});
	}

	if (scenarioFile.scenarioForm.isRstBieeSpecifiedLimitInitiative) {
		addConsoleMessage({text: "<b>FYI - Running with initiative: RST-BIEE-SPEC-LIM</b>"});
	}

	if (scenarioFile.scenarioForm.isRstGlSalesInitiative) {
		addConsoleMessage({text: "<b>FYI - Running with initiative: RST-GL-SALES</b>"});
	}

	if (scenarioFile.scenarioForm.isWorkCompGradientAiInitiative) {
		addConsoleMessage({text: "<b>FYI - Running with initiative: WC-GRADIENT-AI</b>"});
	}
};

const showImplementedInitiatives = (implementedInitiatives: string[]): void => {
	for (const initiative of implementedInitiatives) {
		addConsoleMessage({text: `<b>Found previously implemented initiative: ${initiative}</b>`});
	}
};
