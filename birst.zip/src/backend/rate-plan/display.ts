import {DateTime} from "luxon";
import {RatePlan} from "./types";
import {ScenarioForm} from "../scenario";
import {Emoji, addConsoleMessage} from "../console-message";

export const displayRatePlan = (scenarioForm: ScenarioForm, ratePlan: RatePlan[]): void => {
	// For brand new product launches, e.g., Auto Flex, a rate plan might not
	// yet exist. Using this variable to keep track of the number of rate plans
	// and if there aren't any at the end of the loop below, then print a
	// message to the console.
	let ratePlanCount = 0;

	for (let i = 0; i < ratePlan.length; i++) {
		if (ratePlan[i].ratePlan === "N/A") {
			continue;
		}

		// Since Auto Flex rollouts involve multiple legacy versions
		// converting over, show each version.
		if (scenarioForm.isAutoFlexRollout) {
			addConsoleMessage({
				text: `\xa0\xa0\xa0\xa0\xa0\xa0Version ${ratePlan[i].version}:`,
				excludeTimestamp: true
			});
		}

		// Add extra indentation for Auto Flex rollouts.
		const indentation = scenarioForm.isAutoFlexRollout
			? "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\u2022\xa0\xa0"
			: "\xa0\xa0\xa0\xa0\xa0\xa0\u2022\xa0\xa0";

		addConsoleMessage({
			text: `${indentation}Renewal effective date: ${DateTime.fromISO(ratePlan[i].ratePlan).toLocaleString(DateTime.DATE_SHORT)}`,
			excludeTimestamp: true
		});

		addConsoleMessage({
			text: `${indentation}Available in BIRST as of: ${DateTime.fromISO(ratePlan[i].availableAsOf).toLocaleString(DateTime.DATE_SHORT)}`,
			excludeTimestamp: true
		});

		ratePlanCount++;
	}

	if (ratePlanCount === 0) {
		addConsoleMessage({text: `${Emoji.Warning} No rate plans found.`});
	}
};
