import {join} from "path";
import {app} from "electron";
import {RatePlan} from "./types";
import {execute} from "../database";
import {ScenarioForm} from "../scenario";
import {userSettings} from "../user-settings";
import {SqlFunctionFile, executeDynamicJsFunction, loadDynamicJsFunction} from "../dynamic-js";
import {ConsoleMessageId, addConsoleMessage, stopConsoleMessageTimer} from "../console-message";

export let ratePlan: RatePlan[] = [];

export const loadRatePlanCurrent = async (scenarioForm: ScenarioForm): Promise<RatePlan[]> => {
	try {
		addConsoleMessage({
			text: "Loading rate plans...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingRatePlans
		});

		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetRatePlanCurrent)))[0];
		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
					scenarioForm: scenarioForm,
					jsonPayload: JSON.stringify({
						isAutoFlexRollout: scenarioForm.isAutoFlexRollout
					})
				}
			})
		);
		const [, rs] = await execute({sqlText});

		if (rs) {
			ratePlan = JSON.parse((rs[0] as Record<string, string>)["GET_RATE_PLAN_CURRENT"]);
			stopConsoleMessageTimer(ConsoleMessageId.LoadingRatePlans);
			return ratePlan;
		}

		ratePlan = [];
		stopConsoleMessageTimer(ConsoleMessageId.LoadingRatePlans);
		return ratePlan;
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingRatePlans);
		throw err;
	}
};
