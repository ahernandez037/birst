import {join} from "path";
import {app} from "electron";
import {execute} from "../database";
import {userSettings} from "../user-settings";
import {addConsoleMessage} from "../console-message";
import {SqlFunctionFile, executeDynamicJsFunction, loadDynamicJsFunction} from "../dynamic-js";

/**
 * Copies tables from the production schema (birst_tool) to the development
 * schema (birst_tool_dev). The list of tables to be copied is controlled by
 * birst/node-js/v1/src/backend/sql-functions/get-prod-table-list.js.
 *
 * ! WARNING: Any existing tables will be overwritten!
 */
export const copyProdToDev = async ():Promise<void> => {
	const getProdTableList = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetProdTableList)))[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction: getProdTableList,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas
			}
		})
	);
	const [, rs] = await execute({sqlText});

	if (rs) {
		const copyProdTableToDev = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CopyProdTableToDev)))[0];
		for (const r of rs as Record<string, unknown>[]) {
			addConsoleMessage({text: `Processing ${String(r["TABLE_NAME"]).toLowerCase()}`});
			const sqlText = String(
				executeDynamicJsFunction({
					dynamicJsFunction: copyProdTableToDev,
					functionArguments: {
						isNodeJsDevEnv: !app.isPackaged,
						isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
						tableName: String(r["TABLE_NAME"])
					}
				})
			);
			await execute({sqlText});
		}

		addConsoleMessage({text: "Executing post-migration script"});
		const postMigration = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CopyProdTableToDevPostMigration)))[0];
		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction: postMigration,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas
				}
			})
		);
		await execute({sqlText});
	}
};
