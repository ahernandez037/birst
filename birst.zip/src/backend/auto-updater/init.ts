import {autoUpdater, dialog, app, MessageBoxOptions} from "electron";
import {log} from "../logger";
import {mainWindow} from "../main";
import {autoUpdaterSettings} from "../app-settings";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer
} from "../console-message";

export const initAutoUpdater = (): void => {
	// Do not initialize if running in dev environment
	if (!app.isPackaged) {
		return;
	}

	onCheckingForUpdate();
	onUpdateAvailable();
	onUpdateDownloaded();
	onUpdateNotAvailable();
	onError();
	checkForNewAppVersion();
};

const onCheckingForUpdate = (): void => {
	autoUpdater.on("checking-for-update", () => {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Checking for new app version...",
			bypassDatabase: true
		});
	});
};

const onUpdateAvailable = (): void => {
	autoUpdater.on("update-available", () => {
		addConsoleMessage({
			text: `${Emoji.Bell} Downloading new app version...`,
			hasTimer: true,
			timerId: ConsoleMessageId.DownloadingNewAppVersion
		});

		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Downloading new app version...",
			bypassDatabase: true
		});
	});
};

const onUpdateDownloaded = (): void => {
	autoUpdater.on("update-downloaded", () => {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "New app version downloaded.",
			bypassDatabase: true
		});

		stopConsoleMessageTimer(ConsoleMessageId.DownloadingNewAppVersion);

		const dialogOptions: MessageBoxOptions = {
			type: "info",
			buttons: ["Restart", "Later"],
			title: " New Version Available",
			message: "",
			detail: "A new app version has been downloaded. Please restart the application to apply the update."
		};

		dialog.showMessageBox(mainWindow, dialogOptions).then((returnValue) => {
			if (returnValue.response == 0) {
				autoUpdater.quitAndInstall();
			}
		});
	});
};

const onUpdateNotAvailable = (): void => {
	autoUpdater.on("update-not-available", () => {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Latest app version already installed.",
			bypassDatabase: true
		});
	});
};

const onError = (): void => {
	autoUpdater.on("error", (err) => {
		log({
			type: "ERROR",
			subType: "BACKEND",
			payload: `Auto updater error: ${err.message}`,
			bypassDatabase: true
		});
	});
};

const checkForNewAppVersion = (): void => {
	try {
		autoUpdater.setFeedURL({url: autoUpdaterSettings.feedUrl});
		autoUpdater.checkForUpdates();

		// Check for updates at the specified interval, or every 15 minutes if
		// undefined.
		setInterval(() => {
			autoUpdater.checkForUpdates();
		}, autoUpdaterSettings.checkForUpdatesInterval || 900_000);
	} catch (err) {
		log({
			type: "ERROR",
			subType: "BACKEND",
			payload: `Auto updater error: ${String(err)}`,
			bypassDatabase: true
		});
	}
};
