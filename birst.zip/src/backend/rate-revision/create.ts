import {join} from "path";
import {app} from "electron";
import {execute} from "../database";
import {scenarioFile} from "../scenario-file";
import {userSettings, USER_ID} from "../user-settings";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer} from "../console-message";

export const createRateRevision = async (): Promise<void> => {
	addConsoleMessage({
		text: "Creating rate revision in database...",
		hasTimer: true,
		timerId: ConsoleMessageId.CreatingRateRevision
	});

	try {
		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.InitiateRateRevision)))[0];
		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
					scenarioFile: scenarioFile,
					userId: USER_ID.toUpperCase()
				}
			})
		);
		await execute({sqlText});
		stopConsoleMessageTimer(ConsoleMessageId.CreatingRateRevision);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CreatingRateRevision);
		throw err;
	}
};
