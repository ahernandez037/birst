import {app} from "electron";
import {rimraf} from "rimraf";
import {DateTime} from "luxon";
import {join, basename} from "path";
import {ensureDir, copy, remove} from "fs-extra";
import {logAsync} from "../logger";
import {execute} from "../database";
import {scenarioFile} from "../scenario-file";
import {userSettings} from "../user-settings";
import {lineOfBusinessDirectory} from "./types";
import {ActiveExecutiveSummary} from "../executive-summary";
import {SqlFunctionFile, executeDynamicJsFunction, loadDynamicJsFunction} from "../dynamic-js";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer
} from "../console-message";

export let targetParentDirectory: string;
export let targetScenarioDirectory: string;
export let targetCanceledDirectory: string;

export const setTargetDirectories = (): void => {
	targetParentDirectory =
		lineOfBusinessDirectory[scenarioFile.scenarioForm.lineOfBusiness as keyof typeof lineOfBusinessDirectory] +
		scenarioFile.scenarioForm.geoState +
		"\\" +
		scenarioFile.scenarioForm.renewalDate.substring(0, 10) +
		"_RB";

	targetScenarioDirectory = targetParentDirectory + "\\BIRST";
	const timestamp = DateTime.utc().toFormat("yyyy-LL-dd_HH-mm-ss");

	targetCanceledDirectory =
		lineOfBusinessDirectory[scenarioFile.scenarioForm.lineOfBusiness as keyof typeof lineOfBusinessDirectory] +
		scenarioFile.scenarioForm.geoState +
		"\\_canceled_revisions\\" +
		scenarioFile.scenarioForm.renewalDate.substring(0, 10) +
		"_RB_" +
		timestamp;
};

export const createDirectoriesInSharedDrive = async (): Promise<void> => {
	await ensureDir(targetParentDirectory);
	await ensureDir(targetScenarioDirectory);
	await ensureDir(targetParentDirectory + "\\Actuarial");
	await ensureDir(targetParentDirectory + "\\Filings");
	await ensureDir(targetParentDirectory + "\\FIT");
	await ensureDir(targetParentDirectory + "\\Implementation");
	await ensureDir(targetParentDirectory + "\\IT");
	await ensureDir(targetParentDirectory + "\\Manuals");
	await ensureDir(targetParentDirectory + "\\Product");
	await ensureDir(targetParentDirectory + "\\Source_Documents");
};

export const moveToCanceledDirectory = async (
	associatedRateRevisions: ActiveExecutiveSummary[]
): Promise<void> => {
	// ! Not using fs-extra's move or remove function as it was causing issues
	// ! locking files/directories. Defer to using rimraf to delete directories.

	try {
		// If there aren't any active associated rate revisions, simply copy and
		// delete the entire rate revision directory.
		if (associatedRateRevisions.filter((rateRevision) => rateRevision.scenarioId !== scenarioFile.scenarioForm.scenarioId).length === 0) {
			addConsoleMessage({
				text: "Copying files to canceled directory...",
				hasTimer: true,
				timerId: ConsoleMessageId.CopyingFilesToCanceledDirectory
			});

			await ensureDir(targetCanceledDirectory);
			await copy(targetParentDirectory, targetCanceledDirectory);
			stopConsoleMessageTimer(ConsoleMessageId.CopyingFilesToCanceledDirectory);

			addConsoleMessage({
				text: "Deleting files from source directory...",
				hasTimer: true,
				timerId: ConsoleMessageId.DeletingFilesFromSourceDirectory
			});

			// Sometimes unable to remove directory, most likely due to network
			// drive locking issues. That's why we're catching this error
			// separately and allowing the process to continue.
			try {
				await rimraf.windows(targetParentDirectory);
			} catch (err) {
				addConsoleMessage({text: `${Emoji.Warning} Unable to delete the source directory. This could be due to a network drive lock. Please attempt to manually delete the directory.`});
				addConsoleMessage({text: String(err)});
				await logAsync({
					type: "ERROR",
					subType: "BACKEND",
					payload: `Canceling Rate Revision: Unable to delete the source directory. This could be due to a network drive lock. Please attempt to manually delete the directory. Error message: ${String(err)}`
				});
			}

			stopConsoleMessageTimer(ConsoleMessageId.DeletingFilesFromSourceDirectory);
		} else {
			// If there are active associated rate revisions, only copy (to the
			// canceled directory) the files for the rate revision being
			// canceled and then delete them form the source directory.

			// These files are not to be copied to the canceled directory.
			const filenames = await getFilenames(
				associatedRateRevisions
					.filter(
						(rateRevision) =>
							rateRevision.scenarioId.toUpperCase() !==
							scenarioFile.scenarioForm.scenarioId.toUpperCase()
					)
					.map((rateRevision) => "'" + rateRevision.scenarioId.toUpperCase() + "'")
			);

			addConsoleMessage({
				text: "Copying files to canceled directory...",
				hasTimer: true,
				timerId: ConsoleMessageId.CopyingFilesToCanceledDirectory
			});

			await copy(targetParentDirectory, targetCanceledDirectory, {
				filter: (src) => filenames.includes(basename(src).toUpperCase()) ? false : true
			});

			stopConsoleMessageTimer(ConsoleMessageId.CopyingFilesToCanceledDirectory);

			addConsoleMessage({
				text: "Deleting files from source directory...",
				hasTimer: true,
				timerId: ConsoleMessageId.DeletingFilesFromSourceDirectory
			});

			// Sometimes unable to delete files, most likely due to network
			// drive locking issues. That's why we're catching this error
			// separately and allowing the process to continue.
			try {
				await deleteCanceledRateRevisionFiles();
			} catch (err) {
				addConsoleMessage({text: `${Emoji.Warning} Unable to delete the source files. This could be due to a network drive lock. Please attempt to manually delete the directory.`});
				addConsoleMessage({text: String(err)});
				await logAsync({
					type: "ERROR",
					subType: "BACKEND",
					payload: `Canceling Rate Revision: Unable to delete the source files. This could be due to a network drive lock. Please attempt to manually delete the directory. Error message: ${String(err)}`
				});
			}

			stopConsoleMessageTimer(ConsoleMessageId.DeletingFilesFromSourceDirectory);
		}
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CopyingFilesToCanceledDirectory);
		stopConsoleMessageTimer(ConsoleMessageId.DeletingFilesFromSourceDirectory);
		throw err;
	}
};

const getFilenames = async (scenarioIds: string[]): Promise<string[]> => {
	if (scenarioIds.length === 0) {
		return [];
	}

	const filenames: string[] = [];
	const rs = await queryAssociatedRateRevisionDetails(scenarioIds);

	if (rs) {
		for (const r of rs as Record<string, unknown>[]) {
			filenames.push(String(r["SCENARIO_FILE"]).toUpperCase());
			filenames.push(String(r["RATES_FILE"]).toUpperCase());
			filenames.push(String(r["REPORT_FILE"]).toUpperCase());
			filenames.push(String(r["DATA_DUMP_FILE"]).toUpperCase());
			filenames.push(String(r["FIT_EXHIBITS_FILE"]).toUpperCase());
		}
	}

	return filenames;
};

export const queryAssociatedRateRevisionDetails = async (
	scenarioIds: string[]
): Promise<unknown[] | undefined> => {
	try {
		addConsoleMessage({
			text: "Loading associated rate revision details...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingAssociatedRateRevisionDetails
		});

		const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetAssociatedRateRevisionDetails)))[0];
		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isNodeJsDevEnv: !app.isPackaged,
					isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
					scenarioIds: scenarioIds.join(",")
				}
			})
		);
		const [, rs] = await execute({sqlText});
		stopConsoleMessageTimer(ConsoleMessageId.LoadingAssociatedRateRevisionDetails);
		return rs;
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingAssociatedRateRevisionDetails);
		throw err;
	}
};

const deleteCanceledRateRevisionFiles = async (): Promise<void> => {
	if (scenarioFile.files.scenarioFile) {
		await remove(join(targetScenarioDirectory, scenarioFile.files.scenarioFile));
	}

	if (scenarioFile.files.ratesFile) {
		await remove(join(targetScenarioDirectory, scenarioFile.files.ratesFile));
	}

	if (scenarioFile.files.reportFile) {
		await remove(join(targetScenarioDirectory, scenarioFile.files.reportFile));
	}

	if (scenarioFile.files.dataDumpFile) {
		await remove(join(targetScenarioDirectory, scenarioFile.files.dataDumpFile));
	}

	if (scenarioFile.files.fitExhibitsFile) {
		await remove(join(targetParentDirectory, "FIT", scenarioFile.files.fitExhibitsFile));
	}
};
