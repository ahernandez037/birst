export interface RateHistory {
	state: string;
	channel: string;
	company: string;
	lineOfBusiness: string;
	product: string;
	version: string;
	segment: string;
	coverage: string;
	renewalDate: string;
	rate: number;
	inforcePremium: number;
}
