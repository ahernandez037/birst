import {randomUUID} from "crypto";
import {stringify} from "csv/sync";
import {join, basename} from "path";
import {outputFile, remove} from "fs-extra";
import {connection} from "../database";
import {log, logAsync} from "../logger";
import {USER_ID, userSettings} from "../user-settings";
import {scenarioFile} from "../scenario-file";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer
} from "../console-message";

export const saveRateHistory = async (): Promise<void> => {
	if (scenarioFile.rateHistory.length === 0) {
		addConsoleMessage({text: `${Emoji.Warning} There are no rate history records to save.`});

		await logAsync({
			type: "WARNING",
			subType: "BACKEND",
			payload: "There are no rate history records to save."
		});

		return;
	}

	addConsoleMessage({
		text: "Saving rate history...",
		hasTimer: true,
		timerId: ConsoleMessageId.SavingRateHistory
	});

	try {
		const uploadTimestamp = new Date().toISOString();
		const rateHistory: Record<string, unknown>[] = [];

		for (const rateHistoryRecord of scenarioFile.rateHistory) {
			rateHistory.push({
				scenario_id: scenarioFile.scenarioForm.scenarioId,
				state: rateHistoryRecord.state,
				channel: rateHistoryRecord.channel,
				company: rateHistoryRecord.company,
				line_of_business: rateHistoryRecord.lineOfBusiness,
				product: rateHistoryRecord.product,
				version: rateHistoryRecord.version,
				segment: rateHistoryRecord.segment,
				coverage: rateHistoryRecord.coverage,
				renewal_date: rateHistoryRecord.renewalDate,
				rate: rateHistoryRecord.rate,
				inforce_premium: rateHistoryRecord.inforcePremium,
				is_active: true,
				upload_timestamp_utc: uploadTimestamp,
				upload_user: USER_ID.toUpperCase(),
				comment: "BIRST AUTO-GENERATED RECORD"
			});
		}

		await upload(rateHistory);
		stopConsoleMessageTimer(ConsoleMessageId.SavingRateHistory);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.SavingRateHistory);
		throw err;
	}
};

// Using 'connection?.execute' to stream the Snowflake commands because
// Snowflake was throwing random encryption errors when using the 'execute'
// function from the database module when copying into a table from the user
// staging area. These errors only seem to occur when using the PUT and COPY
// INTO commands.
const upload = async (rateHistory: Record<string, unknown>[]): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		// Using UUID to create unique filenames.
		const uuid = randomUUID();
		const csvFile = join(
			scenarioFile.scenarioForm.scenarioDirectory,
			"rate-history-" + uuid + ".csv"
		);

		try {
			// Save CSV file to hard drive.
			await outputFile(
				csvFile,
				stringify(rateHistory, {
					header: true,
					cast: {
						date: (value) => value.toISOString()
					}
				})
			);
		} catch (err) {
			reject(err);
			throw err;
		}

		connection?.execute({
			// Upload CSV file from hard drive to Snowflake user stage.
			sqlText: `PUT file://${csvFile} @~/;`,
			streamResult: true,
			complete: (err, stmt) => {
				if (err) {
					reject(err);
					throw err;
				} else {
					const stream = stmt.streamRows();

					stream.on("data", (row) => {
						log({
							type: "INFO",
							subType: "BACKEND",
							payload: JSON.stringify(row),
							bypassDatabase: true
						});
					});

					stream.on("error", (err) => {
						reject(err);
						throw err;
					});

					stream.on("end", () => {
						log({
							type: "INFO",
							subType: "BACKEND",
							payload: "PUT finished.",
							bypassDatabase: true
						});

						// Copy data from Snowflake user stage to table.
						let index = 1;

						connection?.execute({
							sqlText: `
								COPY INTO prd_bizdb_coml.public_sandbox.${userSettings.isUsingDevelopmentDatabaseSchemas ? "birst_rate_history_dev" : "birst_rate_history"} (${Object.keys(rateHistory[0]).join(",")})
								FROM (
									SELECT ${Object.keys(rateHistory[0]).map(() => `$${index++}`).join(",")}
									FROM @~/${basename(csvFile)}
								)
								FILE_FORMAT = (
									TYPE = CSV,
									SKIP_HEADER = 1,
									NULL_IF = ('NULL', 'null', 'NAN', 'NaN', 'nan'),
									FIELD_OPTIONALLY_ENCLOSED_BY = '"',
									EMPTY_FIELD_AS_NULL = FALSE
								);
							`,
							streamResult: true,
							complete: (err, stmt) => {
								if (err) {
									reject(err);
									throw err;
								} else {
									const stream = stmt.streamRows();

									stream.on("data", (row) => {
										log({
											type: "INFO",
											subType: "BACKEND",
											payload: JSON.stringify(row),
											bypassDatabase: true
										});
									});

									stream.on("error", (err) => {
										reject(err);
										throw err;
									});

									stream.on("end", async () => {
										log({
											type: "INFO",
											subType: "BACKEND",
											payload: "COPY INTO finished.",
											bypassDatabase: true
										});

										// Delete CSV file from hard drive.
										try {
											await remove(csvFile);
										} catch (err) {
											reject(err);
											throw err;
										}

										// Delete CSV file from Snowflake user stage.
										connection?.execute({
											sqlText: `REMOVE @~/${basename(csvFile)}`,
											streamResult: true,
											complete: (err, stmt) => {
												if (err) {
													reject(err);
													throw err;
												} else {
													const stream = stmt.streamRows();

													stream.on("data", (row) => {
														log({
															type: "INFO",
															subType: "BACKEND",
															payload: JSON.stringify(row),
															bypassDatabase: true
														});
													});

													stream.on("error", (err) => {
														reject(err);
														throw err;
													});

													stream.on("end", async () => {
														log({
															type: "INFO",
															subType: "BACKEND",
															payload: "REMOVE finished.",
															bypassDatabase: true
														});

														resolve();
													});
												}
											}
										});
									});
								}
							}
						});
					});
				}
			}
		});
	});
};
