return `
	SELECT *
	FROM prd_bizdb_coml.${args.isDatabaseDevEnv ? "birst_tool_dev" : "birst_tool"}.email_recipient;
`;
