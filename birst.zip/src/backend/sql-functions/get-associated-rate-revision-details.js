return `
	SELECT
		scenario_id,
		scenario_directory,
		scenario_file,
		rates_file,
		report_file,
		data_dump_file,
		fit_exhibits_file
	FROM prd_bizdb_coml.public_sandbox.${args.isDatabaseDevEnv ? "birst_rate_revision_dev" : "birst_rate_revision"}
	WHERE UPPER(scenario_id) IN (${args.scenarioIds});
`;
