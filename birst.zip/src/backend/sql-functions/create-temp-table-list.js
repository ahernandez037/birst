// This table holds a list of all the temporary tables that are created by the
// various procedures. The Node.js application reads from this table to run code
// that copies the contents of the temp tables to CSV files in the user's hard
// drive. This feature is only available to developers to facilitate development
// and debugging.

return "CREATE OR REPLACE TEMP TABLE temp_table_list (table_name VARCHAR);";
