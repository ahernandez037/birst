// This code will point to either the prod or dev birst_tool schema based on
// what the get-database-objects.js function returns, which depends on the UI
// toggle and on the procedures/tables that are in the database_object table
// from the corresponding prod or dev birst_tool schema.

// New Raters
if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "CMP" &&
	["HAB", "REA", "ROS", "RST"].includes(args.scenarioFile.scenarioForm.product)
) {
	return `
		CALL ${args.scenarioFile.scenarioForm.createReports} (
			'${args.scenarioFile.scenarioForm.dataDumpTable}', /* data_dump_table */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'${args.scenarioFile.scenarioForm.renewalDate}', /* renewal_date */
			'${args.scenarioFile.scenarioForm.startDate}', /* start_date */
			'${args.scenarioFile.scenarioForm.endDate}', /* end_date */
			'${args.scenarioFile.scenarioForm.inforceDate}', /* inforce_date */
			'${args.scenarioFile.scenarioForm.geoState}', /* state */
			'${args.scenarioFile.scenarioForm.lineOfBusiness}', /* line_of_business */
			'${args.scenarioFile.scenarioForm.product}', /* product */
			'${args.scenarioFile.scenarioForm.version}', /* version */
			false, /* is_logged */
			${args.isDatabaseDevEnv} /* is_db_dev_env */
		);
	`;
}
// Legacy Raters
else {
	return `
		CALL ${args.scenarioFile.scenarioForm.createReports} (
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
			'${args.scenarioFile.scenarioForm.startDate}', /* start_date */
			'${args.scenarioFile.scenarioForm.endDate}', /* end_date */
			'${args.scenarioFile.scenarioForm.inforceDate}', /* inforce_date */
			'${args.scenarioFile.scenarioForm.geoState}', /* state */
			'${args.scenarioFile.scenarioForm.lineOfBusiness}', /* line_of_business */
			'${args.scenarioFile.scenarioForm.product}', /* product */
			'${args.scenarioFile.scenarioForm.version}', /* version */
			'${args.scenarioFile.scenarioForm.renewalDate}', /* renewal_date */
			'${args.scenarioFile.scenarioForm.dataDumpTable}', /* data_dump_table */
			${args.scenarioFile.scenarioForm.isAutoFlexRollout}, /* is_auto_flex_rollout */
			'${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}', /* bureau_eff_date */
			'${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}', /* bureau_release_date */
			'${args.scenarioFile.scenarioForm.workCompBureauStatusFlag}' /* bureau_status_flag */
		);
	`;
}
