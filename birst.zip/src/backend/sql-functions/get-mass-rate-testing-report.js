return `
	SELECT *
	FROM mass_rate_testing
	ORDER BY
		product_type,
		version,
		state,
		coverage_id;
`;
