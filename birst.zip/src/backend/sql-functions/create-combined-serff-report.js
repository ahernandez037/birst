return `
	CALL prd_bizdb_coml.${args.isDatabaseDevEnv ? "birst_tool_dev" : "birst_tool"}.create_combined_serff_report(
		'${args.scenarioFile.scenarioForm.geoState}',
		'${args.scenarioFile.scenarioForm.renewalDate}'
	);
`;
