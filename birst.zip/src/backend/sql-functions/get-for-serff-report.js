if (args.scenarioFile.scenarioForm.lineOfBusiness == "WC") {
	return `
		SELECT *
		FROM impact_summary;
	`;
} else {
	return `
		SELECT
			state,
			product_type,
			pol_farmers_company_id,
			pol_farmers_company_name,
			num_policies,
			mod_prem_current,
			mod_prem_proposed,
			impact,
			dollar_change,
			max_policy_change,
			min_policy_change
		FROM for_serff
		ORDER BY
			state,
			product_type,
			pol_farmers_company_id,
			pol_farmers_company_name;
	`;
}
