// Keeping sub_type = STATISTIC for backwards compatibility.
// As of v1.3.0, started using JSON sub_type.

return `
	SELECT
		CASE
			WHEN UPPER(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm.lineOfBusiness) = 'WC' THEN 'WC'
			WHEN UPPER(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm.lineOfBusiness) = 'UMB' THEN 'UMB'
			ELSE IFF(
				UPPER(sub_type) = 'STATISTIC',
				PARSE_JSON(payload):product,
				PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm.product
			)
		END AS product,
		COUNT(1) AS number_of_runs,
		ROUND(AVG(PARSE_JSON(payload):runTimeInSeconds), 2) AS average_runtime_in_seconds,
		ROUND(AVG(PARSE_JSON(payload):dataDumpRecordCount), 0) AS average_record_count
	FROM prd_bizdb_coml.public_sandbox.birst_log_node_js
	WHERE
		(
			UPPER(sub_type) = 'STATISTIC'
			OR (
				UPPER(sub_type) = 'JSON'
				AND UPPER(PARSE_JSON(payload):type) = 'SCENARIO-RUN-END'
			)
		)
		AND IFF(
			UPPER(sub_type) = 'STATISTIC',
			UPPER(PARSE_JSON(payload):runMode),
			UPPER(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm.runMode)
		) = 'RATE-CHANGE'
	GROUP BY product
	ORDER BY average_runtime_in_seconds;
`;
