if (args.scenarioFile.scenarioForm.lineOfBusiness == "WC") {
	return `
		SELECT *
		FROM impact_summary;
	`;
} else if (args.scenarioFile.scenarioForm.lineOfBusiness == "UMB") {
	return `
		SELECT *
		FROM impact_summary
		ORDER BY IFF(UPPER(cov_coverage_id) = 'TOTAL', 'ZZZZZZZ', cov_coverage_id);
	`;
} else {
	return `
		SELECT *
		FROM impact_summary
		ORDER BY IFF(UPPER(cov_coverage_id) = 'TOTAL', '9999999', cov_coverage_id);
	`;
}
