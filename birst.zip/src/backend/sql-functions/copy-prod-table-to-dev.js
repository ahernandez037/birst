return `
	CREATE OR REPLACE TABLE prd_bizdb_coml.birst_tool_dev.${args.tableName} AS
	SELECT *
	FROM prd_bizdb_coml.birst_tool.${args.tableName};
`;
