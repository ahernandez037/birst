return `
	SELECT *
	FROM prd_bizdb_coml.public_sandbox.${args.isDatabaseDevEnv ? "birst_rate_revision_dev" : "birst_rate_revision"}
	WHERE
		state = '${args.scenarioFile.scenarioForm.geoState}'
		AND line_of_business = '${args.scenarioFile.scenarioForm.lineOfBusiness}'
		AND product = '${args.scenarioFile.scenarioForm.product}'
		AND version = '${args.scenarioFile.scenarioForm.version}'
		AND renewal_date = '${args.scenarioFile.scenarioForm.renewalDate.substring(0, 10)}'
		AND is_canceled = false;
`;
