// Used to do any necessary updates/clean-up after the tables have been copied
// from the production schema to the development schema.

return `
	EXECUTE IMMEDIATE $$
	BEGIN
		-- Replace references to the production birst_tool schema with
		-- references to the development schema birst_tool_dev.
		UPDATE prd_bizdb_coml.birst_tool_dev.database_object
		SET
			extract_policy_data = REPLACE(extract_policy_data, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			rate_table_list_current = REPLACE(rate_table_list_current, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			rate_table_list_proposed = REPLACE(rate_table_list_proposed, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			prepare_rate_tables_current = REPLACE(prepare_rate_tables_current, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			prepare_rate_tables_proposed = REPLACE(prepare_rate_tables_proposed, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			assign_rates_current = REPLACE(assign_rates_current, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			assign_rates_proposed = REPLACE(assign_rates_proposed, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			calculate_premium_current = REPLACE(calculate_premium_current, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			calculate_premium_proposed = REPLACE(calculate_premium_proposed, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			create_data_dump = REPLACE(create_data_dump, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.'),
			create_reports = REPLACE(create_reports, 'prd_bizdb_coml.birst_tool.', 'prd_bizdb_coml.birst_tool_dev.');
	END;
	$$;
`;
