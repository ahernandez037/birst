return `
	SELECT
		PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):scenarioId::varchar AS scenario_id,
		PARSE_JSON(PARSE_JSON(payload):scenarioFile):createdBy::varchar AS created_by,
		PARSE_JSON(PARSE_JSON(payload):scenarioFile):createdAtUtc::datetime AS created_at_utc,
		PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):geoState::varchar AS geo_state,
		PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):lineOfBusiness::varchar AS line_of_business,
		PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):product::varchar AS product,
		PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):version::varchar AS version
	FROM prd_bizdb_coml.public_sandbox.birst_log_node_js
	WHERE
		UPPER(sub_type) = 'JSON'
		AND UPPER(PARSE_JSON(payload):type::varchar) = 'SCENARIO-RUN-END'
		AND PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):scenarioId::varchar = '${args.scenarioFile.scenarioForm.scenarioId}'
		AND (
			PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):geoState::varchar != '${args.scenarioFile.scenarioForm.geoState}'
			OR PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):lineOfBusiness::varchar != '${args.scenarioFile.scenarioForm.lineOfBusiness}'
			OR PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):product::varchar != '${args.scenarioFile.scenarioForm.product}'
			OR PARSE_JSON(PARSE_JSON(PARSE_JSON(payload):scenarioFile):scenarioForm):version::varchar != '${args.scenarioFile.scenarioForm.version}'
		);
`;
