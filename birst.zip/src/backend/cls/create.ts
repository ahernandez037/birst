import * as fs from "fs-extra";
import {join} from "path";
import {app, Notification} from "electron";
import {log} from "../logger";
import {execute} from "../database";
import {isFileOpen} from "../utilities";
import {userSettings} from "../user-settings";
import {scenarioFile} from "../scenario-file";
import {ClsTableRecord} from "../rates-file/types";
import {tablesForUpload} from "../rates-file/create";
import {executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile} from "../dynamic-js";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer
} from "../console-message";

export const createClsFiles = async (): Promise<void> => {
	// Return early if there are no in-scope tables.
	if (!tablesForUpload.length) {
		return;
	}

	try {
		addConsoleMessage({
			text: "Creating CLS files...",
			hasTimer: true,
			timerId: ConsoleMessageId.CreatingClsTables
		});

		// Removing last 7 characters form the scenario directory, i.e., "\\BIRST".
		const clsDirectory = scenarioFile.scenarioForm.scenarioDirectory.substring(0, scenarioFile.scenarioForm.scenarioDirectory.length - 6) + "\\IT\\CLS";

		if (!(await fs.pathExists(clsDirectory))) {
			await fs.ensureDir(clsDirectory);
		}

		for (const table of tablesForUpload) {
			const tableNumbers = await getTableNumbers(table.tableName);

			// For Work Comp table 41300 for CA, need to also produce extension
			// table 91717.
			if (
				scenarioFile.scenarioForm.lineOfBusiness === "WC" &&
				scenarioFile.scenarioForm.geoState === "CA" &&
				tableNumbers.includes("41300")
			) {
				tableNumbers.push("91717");
			}

			for (const tableNumber of tableNumbers) {
				if (tableNumber === "N/A") {
					continue;
				}

				await createTable(tableNumber);

				const tableRecords = await getTable(tableNumber);
				const companies = new Set(tableRecords.map((record) => record.company));

				for (const company of companies) {
					const filename =
						"T" +
						tableNumber.padStart(5, "0") +
						"-" +
						scenarioFile.scenarioForm.geoState +
						company.charAt(2) +
						"-" +
						scenarioFile.scenarioForm.renewalDate.replaceAll("-", "") +
						"-" +
						scenarioFile.scenarioForm.newDate.replaceAll("-", "") +
						"-" +
						scenarioFile.scenarioForm.availableDate
							.replaceAll("-", "")
							.substring(2, 8) +
						".txt";

					const filepath = join(clsDirectory, filename);

					if (await isFileOpen(filepath)) {
						const message = `Unable to create CLS file for table ${table.tableName} as the file is currently in use.`;
						addConsoleMessage({text: `${Emoji.Warning} ${message}`});

						log({
							type: "WARNING",
							subType: "BACKEND",
							payload: message
						});

						continue;
					}

					const recordsByCompany: string[] = [];

					tableRecords
						.filter((record) => record.company === company)
						.forEach((record) => {
							recordsByCompany.push(record.clsValue);
						});

					// Need to add both carriage return "\r" and new line "\n"
					// characters otherwise CLS upload file does not work with
					// the CLS mainframe system.
					await fs.outputFile(filepath, recordsByCompany.join("\r\n") + "\r\n");
				}
			}
		}

		addConsoleMessage({text: "Finished creating CLS files."});
		new Notification({title: `${Emoji.Bell} Finished creating CLS files`}).show();
		stopConsoleMessageTimer(ConsoleMessageId.CreatingClsTables);
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CreatingClsTables);
		throw err;
	}
};

const getTableNumbers = async (tableName: string): Promise<string[]> => {
	const clsTableNumbers: string[] = [];
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetClsTableNumbers)))[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile: scenarioFile,
				tableName: tableName
			}
		})
	);
	const [, results] = await execute({sqlText});

	if (results) {
		for (const result of results as Record<string, unknown>[]) {
			String(result["TABLE_NUMBER"])
				.split(" | ")
				.forEach((tableNumber) => clsTableNumbers.push(tableNumber));
		}
	}

	return clsTableNumbers;
};

const createTable = async (tableNumber: string): Promise<void> => {
	const dynamicJsFunction = (await loadDynamicJsFunction(join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CreateClsTable)))[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile: scenarioFile,
				tableNumber: tableNumber
			}
		})
	);

	await execute({sqlText});
};

const getTable = async (tableNumber: string): Promise<ClsTableRecord[]> => {
	const clsTableRecords: ClsTableRecord[] = [];
	const dynamicJsFunction = (
		await loadDynamicJsFunction(
			join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetClsTable)
		)
	)[0];
	const sqlText = String(
		executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isNodeJsDevEnv: !app.isPackaged,
				isDatabaseDevEnv: userSettings.isUsingDevelopmentDatabaseSchemas,
				scenarioFile: scenarioFile,
				tableNumber: tableNumber
			}
		})
	);
	const [, results] = await execute({sqlText});

	if (results) {
		for (const result of results as Record<string, unknown>[]) {
			clsTableRecords.push({
				company: String(result["COMPANY"]),
				clsValue: String(result["CLSVALUE"]),
				clsTable: String(result["CLSTABLE"]),
				clsOrder: String(result["CLSORDER"])
			});
		}
	}

	return clsTableRecords;
};
