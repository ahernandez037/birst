module.exports = {
	// Reference: https://electron.github.io/electron-packager/main/interfaces/electronpackager.options.html
	packagerConfig: {
		name: "BIRST",
		executableName: "BIRST",
		icon: "./src/favicon.ico",
		electronZipDir: "c:\\electron",
		ignore: ".angular/.*"
	},
	rebuildConfig: {},
	makers: [
		{
			name: "@electron-forge/maker-squirrel",
			// Reference: https://github.com/electron/windows-installer
			config: {
				name: "BIRST",
				title: "BIRST",
				exe: "BIRST.exe",
				iconUrl: "https://raw.githubusercontent.com/ahernandez037/birst/main/favicon.ico"
			}
		}
	]
};
