module.exports = {
	packagerConfig: {
		ignore: ".angular/.*",
		icon: "./src/favicon.ico",
	},
	rebuildConfig: {},
	makers: [
		{
			name: "@electron-forge/maker-squirrel",
			config: {
				name: "BIRST",
				title: "BIRST",
				exe: "BIRST.exe",
				iconUrl: "https://raw.githubusercontent.com/ahernandez037/birst/main/favicon.ico",
			},
		},
	],
};
