import { join } from "path";
import { writeJson } from "fs-extra";
import { scenarioFile } from "./load";
import { getScenarioOutputFiles } from "./prefill";

export const saveScenarioFile = async (): Promise<void> => {
	try {
		/* Date strings are sent from the frontend with UTC timestamp. Only
		keeping the date portion. */

		scenarioFile.scenarioForm.inforceDate =
			scenarioFile.scenarioForm.inforceDate?.substring(0, 10) ?? "";

		scenarioFile.scenarioForm.renewalDate =
			scenarioFile.scenarioForm.renewalDate?.substring(0, 10) ?? "";

		scenarioFile.scenarioForm.newDate =
			scenarioFile.scenarioForm.newDate?.substring(0, 10) ?? "";

		scenarioFile.scenarioForm.availableDate =
			scenarioFile.scenarioForm.availableDate?.substring(0, 10) ?? "";

		scenarioFile.scenarioForm.startDate =
			scenarioFile.scenarioForm.startDate?.substring(0, 10) ?? "";

		scenarioFile.scenarioForm.endDate =
			scenarioFile.scenarioForm.endDate?.substring(0, 10) ?? "";

		scenarioFile.scenarioForm.fdrcTimestamp =
			scenarioFile.scenarioForm.fdrcTimestamp?.substring(0, 10) ?? "";

		await writeJson(
			join(
				scenarioFile.scenarioForm.scenarioDirectory,
				getScenarioOutputFiles(scenarioFile.scenarioForm).scenarioFile,
			),
			scenarioFile,
			{
				spaces: 4,
			},
		);
	} catch (err) {
		throw err;
	}
};
