import { scenarioFile } from "./load";
import { RunMode } from "../scenario";

export const updateScenarioFileRateHistory = (records: Record<string, unknown>[]): void => {
	if (scenarioFile.scenarioForm.runMode === RunMode.RateChange) {
		// Clear array to overwrite any preexisting data from a previous run.
		scenarioFile.rateHistory = [];

		for (const record of records) {
			scenarioFile.rateHistory.push({
				state: String(record["STATE"]),
				channel: String(record["CHANNEL"]),
				company: String(record["COMPANY"]),
				lineOfBusiness: String(record["LINE_OF_BUSINESS"]),
				product: String(record["PRODUCT"]),
				version: String(record["VERSION"]),
				segment: String(record["SEGMENT"]),
				coverage: String(record["COVERAGE"]),
				renewalDate: new Date(String(record["RENEWAL_DATE"]))
					.toISOString()
					.substring(0, 10),
				rate: Number(record["RATE"]),
				inforcePremium: Number(record["INFORCE_PREMIUM"]),
			});
		}
	}
};
