import { ipcMain, dialog } from "electron";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { getUncPath } from "../utilities";
import { cloneScenarioFile } from "./clone";
import { IpcMessage } from "../ipc-handlers";
import { userSettings } from "../user-settings";
import { loadScenarioFile, resetScenarioFile } from "./load";
import { addConsoleMessage, Emoji } from "../console-message";

export const scenarioFileIpcHandler = (): void => {
	ipcMain.on(IpcMessage.LoadScenarioFile, async () => {
		const filepath = await getFilepath();

		if (filepath) {
			await loadScenarioFile({ uncFilepath: filepath });
		} else {
			mainWindow.webContents.send(IpcMessage.LoadScenarioCanceled);
		}
	});

	ipcMain.on(IpcMessage.LoadScenarioFileFromDragAndDrop, async (_event, payload) => {
		await loadScenarioFile({ uncFilepath: await getUncPath(payload[0]) });
	});

	ipcMain.on(IpcMessage.ResetScenarioFile, () => {
		resetScenarioFile();
	});

	ipcMain.on(IpcMessage.CloneScenarioFile, async (_event, payload) => {
		await cloneScenarioFile(JSON.parse(payload));
	});
};

const getFilepath = async (): Promise<string | undefined> => {
	const openDialogResponse = await dialog.showOpenDialog(mainWindow, {
		filters: [
			{ name: "BIRST Scenario File", extensions: ["birst"] },
			{ name: "All Files", extensions: ["*"] },
		],
		properties: ["openFile"],
		defaultPath: userSettings.defaultScenarioDirectory,
	});

	if (openDialogResponse.filePaths.length) {
		if (!openDialogResponse.filePaths[0].toLowerCase().includes(".birst")) {
			addConsoleMessage({
				text: `${Emoji.Error} ERROR: Invalid scenario file selected.`,
			});

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: `Invalid scenario file selected: ${openDialogResponse.filePaths[0]}`,
			});
		} else {
			return await getUncPath(openDialogResponse.filePaths[0]);
		}
	}

	return undefined;
};
