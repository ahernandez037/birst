import { scenarioFile } from "./load";
import { ScenarioOutputFiles } from "./types";
import { ScenarioForm, RunMode } from "../scenario";
import { USER_ID, userSettings } from "../user-settings";
import { getPrefixesFromScenarioForm, runModePrefix } from "./prefixes";

export const prefillScenarioFile = (scenarioForm: ScenarioForm): void => {
	// Date strings are sent from the frontend with UTC timestamp. Only keeping
	// the date portion
	scenarioForm.inforceDate = scenarioForm.inforceDate?.substring(0, 10) ?? "";
	scenarioForm.renewalDate = scenarioForm.renewalDate?.substring(0, 10) ?? "";
	scenarioForm.newDate = scenarioForm.newDate?.substring(0, 10) ?? "";
	scenarioForm.availableDate = scenarioForm.availableDate?.substring(0, 10) ?? "";
	scenarioForm.startDate = scenarioForm.startDate?.substring(0, 10) ?? "";
	scenarioForm.endDate = scenarioForm.endDate?.substring(0, 10) ?? "";
	scenarioForm.fdrcTimestamp = scenarioForm.fdrcTimestamp?.substring(0, 10) ?? "";

	scenarioFile.createdBy = USER_ID;
	scenarioFile.createdByEmail = userSettings.emailAddress;
	scenarioFile.createdAtUtc = new Date().toISOString();
	scenarioFile.scenarioForm = scenarioForm;
	scenarioFile.files = getScenarioOutputFiles(scenarioForm);
};

export const getScenarioOutputFiles = (scenarioForm: ScenarioForm): ScenarioOutputFiles => {
	let [lineOfBusiness, product, version, geoState, renewalDate, dataSource, inforceDate] =
		getPrefixesFromScenarioForm(scenarioForm);

	renewalDate = scenarioForm.runMode === RunMode.RateChange ? renewalDate : "";
	geoState = geoState.toUpperCase() === "ALL_" ? "CW_" : geoState;
	if (scenarioForm.runMode !== "VALIDATION") inforceDate = "";

	const filePrefix =
		geoState + lineOfBusiness + product + version + renewalDate + dataSource + inforceDate;

	const ratesFile = scenarioForm.runMode === RunMode.RateChange ? `${filePrefix}Rates.xlsx` : "";
	const dataDumpFile = scenarioForm.saveDataDumpToHardDrive ? `${filePrefix}Data_Dump.csv` : "";

	return {
		scenarioFile:
			filePrefix + `${runModePrefix[scenarioForm.runMode as RunMode]}_Scenario.birst`,
		ratesFile: ratesFile,
		reportFile: `${filePrefix}Report.xlsx`,
		dataDumpFile: dataDumpFile,
		fitExhibitsFile: `${filePrefix}Filing.xlsm`,
	};
};
