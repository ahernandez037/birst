import { DynamicJsFunction } from "./types";
import { userSettings } from "../user-settings";
import { appendToDebugRunDynamicJs, isDebugRun } from "../scenario";

export const executeDynamicJsFunction = (args: {
	dynamicJsFunction: DynamicJsFunction;
	functionArguments?: Record<string, unknown>;
}): unknown => {
	const output = new Function("args", args.dynamicJsFunction.body)(args.functionArguments);

	const dynamicJs =
		typeof output === "object" && !Array.isArray(output) ? JSON.stringify(output) : output;

	if (userSettings.isDynamicJsPrinted) console.log("DynamicJS Output:\n" + dynamicJs);
	if (isDebugRun) appendToDebugRunDynamicJs(dynamicJs);

	return output;
};
