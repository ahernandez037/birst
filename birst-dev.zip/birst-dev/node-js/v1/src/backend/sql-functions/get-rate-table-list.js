let versionCondition = "";

if (args.scenarioForm.lineOfBusiness == "AUTO" && args.scenarioForm.product == "AUTO") {
	if (args.scenarioForm.version == "5" || args.scenarioForm.version == "5.1") {
		// Unlike versions 1-4, Auto Flex has rates in all rate tables with
		// explicit version numbers, e.g., 5.1 instead of '@'.
		versionCondition = `AND t1.version = '${args.scenarioForm.version}'`;
	} else {
		versionCondition = `AND t1.version IN ('@', '${args.scenarioForm.version}')`;
	}
}

return `
	SELECT DISTINCT
		t1.*,
		COALESCE(t2.table_number, 'N/A') AS cls_table_number,
		COALESCE(t2.ratabase_table_name, 'N/A') AS ratabase_system_name
	FROM
		${args.scenarioForm.rateTableListCurrent} AS t1
		LEFT JOIN prd_bizdb_coml.birst_tool.map_table_list_v4 as t2
			ON UPPER(TRIM(t1.ratabase_table_name)) = UPPER(TRIM(t2.table_name))
			-- map_table_list_v4 has Auto versions with decimal places but
			-- rate_table_list tables do not, e.g., 1.0 vs. 1. The following code
			-- tries to convert to number to match and coalescing to zero to match
			-- where the version is an @ symbol.
			AND COALESCE(TRY_TO_NUMBER(t1.version, 38, 2), 0) = COALESCE(TRY_TO_NUMBER(t2.version, 38, 2), 0)
	WHERE
		(
			(
				UPPER(t1.state_include) = 'CW'
				AND UPPER(t1.state_exclude) != '${args.scenarioForm.geoState}'
			)
			OR UPPER(t1.state_include) = '${args.scenarioForm.geoState}'
		)
		AND UPPER(t1.line_of_business) = '${args.scenarioForm.lineOfBusiness}'
		AND UPPER(t1.product) = '${
			args.scenarioForm.lineOfBusiness == "WC" || args.scenarioForm.lineOfBusiness == "UMB"
				? "N/A"
				: args.scenarioForm.product
		}'
		${versionCondition}
		AND t1.is_included_in_rates_file = TRUE
	ORDER BY t1.ratabase_table_name;
`;
