return `
	WITH users AS (
		SELECT DISTINCT user_id
		FROM prd_bizdb_coml.public_sandbox.birst_log_node_js
	),
	timestamp AS (
		SELECT
			user_id,
			MAX(TO_TIMESTAMP(created_at_utc)) AS timestamp
		FROM prd_bizdb_coml.public_sandbox.birst_log_node_js
		GROUP BY user_id
	),
	/* As of v1.3.0, using new JSON payload. */
	version_new AS (
		SELECT
			user_id,
			PARSE_JSON(payload):appVersion AS version,
			ROW_NUMBER() OVER (
				PARTITION BY user_id
				ORDER BY created_at_utc DESC
			) AS row_num
		FROM prd_bizdb_coml.public_sandbox.birst_log_node_js
		WHERE
			UPPER(sub_type) = 'JSON'
			AND payload ILIKE '%APP-START%'
	),
	/* Not using JSON payload prior to v1.3.0. */
	version_old AS (
		SELECT
			user_id,
			payload AS version,
			ROW_NUMBER() OVER (
				PARTITION BY user_id
				ORDER BY created_at_utc DESC
			) AS row_num
		FROM prd_bizdb_coml.public_sandbox.birst_log_node_js
		WHERE payload LIKE 'Version: %'
	)
	SELECT
		ROW_NUMBER() OVER (ORDER BY t.timestamp DESC) AS row_num,
		u.user_id,
		t.timestamp AS last_accessed,
		COALESCE(vn.version, vo.version, 'N/A') AS app_version
	FROM
		users AS u
		LEFT JOIN timestamp AS t
			ON u.user_id = t.user_id
		LEFT JOIN version_new AS vn
			ON u.user_id = vn.user_id
		LEFT JOIN version_old AS vo
			ON u.user_id = vo.user_id
	WHERE (
			vn.row_num = 1
			OR vn.row_num IS NULL
		)
		AND (
			vo.row_num = 1
			OR vo.row_num IS NULL
		);
`;
