let version = "N/A";

if (args.scenarioForm.product == "AUTO" && args.scenarioForm.version == "ALL") {
	// Defaulting to using tables & procedures for v1 since v1-v4 use the same
	// tables & procedures. If would like to use other tables or procedures,
	// must manually override through the "Advanced" inputs.
	version = "1";
} else if (args.scenarioForm.lineOfBusiness == "WC" && args.scenarioForm.version == "ALL") {
	version = "SPWC";
} else if (args.scenarioForm.version) {
	version = args.scenarioForm.version;
}

return `
	SELECT
		COALESCE(b.extract_policy_data, c.extract_policy_data) AS extract_policy_data,
		COALESCE(b.rate_table_list_current, c.rate_table_list_current) AS rate_table_list_current,
		COALESCE(b.rate_table_list_proposed, c.rate_table_list_proposed) AS rate_table_list_proposed,
		COALESCE(b.prepare_rate_tables_current, c.prepare_rate_tables_current) AS prepare_rate_tables_current,
		COALESCE(b.prepare_rate_tables_proposed, c.prepare_rate_tables_proposed) AS prepare_rate_tables_proposed,
		COALESCE(b.assign_rates_current, c.assign_rates_current) AS assign_rates_current,
		COALESCE(b.assign_rates_proposed, c.assign_rates_proposed) AS assign_rates_proposed,
		COALESCE(b.calculate_premium_current, c.calculate_premium_current) AS calculate_premium_current,
		COALESCE(b.calculate_premium_proposed, c.calculate_premium_proposed) AS calculate_premium_proposed,
		COALESCE(b.create_data_dump, c.create_data_dump) AS create_data_dump,
		COALESCE(b.create_reports, c.create_reports) AS create_reports,
		COALESCE(b.policy_data_override_table, c.policy_data_override_table) AS policy_data_override_table,
		COALESCE(b.driver_data_override_table, c.driver_data_override_table) AS driver_data_override_table
	FROM (
		SELECT
			'${args.scenarioForm.geoState == "ALL" ? "CW" : args.scenarioForm.geoState}' AS state,
			'${args.scenarioForm.lineOfBusiness}' AS line_of_business,
			'${args.scenarioForm.product ? args.scenarioForm.product : "N/A"}' AS product,
			'${version}' AS version
		) AS a
		LEFT JOIN prd_bizdb_coml.birst_tool.production_object AS b
			ON a.state = b.state
			AND a.line_of_business = b.line_of_business
			AND a.product = b.product
			AND a.version = b.version
		LEFT JOIN prd_bizdb_coml.birst_tool.production_object AS c
			ON c.state = 'CW'
			AND c.line_of_business = a.line_of_business
			AND c.product = a.product
			AND c.version = a.version;
`;
