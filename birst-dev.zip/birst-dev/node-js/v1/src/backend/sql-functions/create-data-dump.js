let policyTable = "POLICY";

if (args.scenarioFile.scenarioForm.isAutoFlexRollout) {
	// Phase 2 states
	if (
		["AZ", "CA", "IL", "NM", "TX", "WY"].includes(
			args.scenarioFile.scenarioForm.geoState.toUpperCase(),
		)
	) {
		policyTable = "PRD_BIZDB_COML.DATA_EXTRACTS.FLEX_PIF_033122_POST_EQF_V3";
	}
	// Phase 3 states
	else {
		policyTable = "PRD_BIZDB_COML.DATA_EXTRACTS.FLEX_PIF_123122_POST_EQF";
	}
} else if (
	args.scenarioFile.scenarioForm.policyDataOverrideTable != "N/A" &&
	args.scenarioFile.scenarioForm.policyDataOverrideTable != ""
) {
	policyTable = args.scenarioFile.scenarioForm.policyDataOverrideTable;
}

// New Raters
if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "CMP" &&
	["HAB", "REA", "ROS", "RST"].includes(args.scenarioFile.scenarioForm.product)
) {
	return `
		CALL ${args.scenarioFile.scenarioForm.createDataDump}(
			'${policyTable}', /* policy_table */
			'RATE', /* rate_table */
			'PRECURSOR', /* precursor_table */
			'PREMIUM', /* premium_table */
			'${args.scenarioFile.scenarioForm.dataDumpTable}', /* data_dump_table */
			'TRANSIENT', /* data_dump_table_type */
			'${args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" ? "_CURRENT" : ""}', /* suffix_current */
			'${
				args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" ? "_PROPOSED" : ""
			}', /* suffix_proposed */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			false /* is_logged */
		);
	`;
}
// Legacy Raters
else {
	return `
		CALL ${args.scenarioFile.scenarioForm.createDataDump}(
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${policyTable}', /* policy_table */
			'${args.scenarioFile.scenarioForm.geoState}', /* state */
			'${args.scenarioFile.scenarioForm.lineOfBusiness}', /* line_of_business */
			'${args.scenarioFile.scenarioForm.product}', /* product */
			'${args.scenarioFile.scenarioForm.version}', /* version */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
			'${args.scenarioFile.scenarioForm.startDate}', /* start_date */
			'${args.scenarioFile.scenarioForm.endDate}', /* end_date */
			'${args.scenarioFile.scenarioForm.dataDumpTable}', /* output_table */
			'TRANSIENT', /* table_type */
			false, /* is_logged */
			'${args.miscJson ? args.miscJson : "{}"}' /* misc_json */
		);
	`;
}
