return `
	SELECT
		TO_CHAR(DATE_TRUNC(MONTH, DATEADD(MONTH, 1, date)), 'yyyy-MM-dd') AS new_date,
		TO_CHAR(DATEADD(DAY, 1, date), 'yyyy-MM-dd') AS available_date
	FROM prd_cbi_datamart.common.dim_date
	WHERE fiscal_month_close_ind = 1;
`;
