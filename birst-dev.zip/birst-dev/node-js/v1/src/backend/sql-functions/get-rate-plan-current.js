return `
	CALL prd_bizdb_coml.birst_tool.get_rate_plan_current(
		'${args.scenarioForm.geoState}', /* state */
		'${args.scenarioForm.lineOfBusiness}', /* line_of_business */
		'${args.scenarioForm.product}', /* product */
		'${args.scenarioForm.version}', /* version */
		'${args.jsonPayload}' /* json_payload */
	);
`;
