return `
	SELECT DISTINCT ratabase_table_name
	FROM prd_bizdb_coml.birst_tool.map_table_list_v4
	WHERE
		upper(table_name) = upper('${args.tableName}')
		AND upper(lob) = upper('${args.scenarioFile.scenarioForm.lineOfBusiness}')
		${
			args.scenarioFile.scenarioForm.lineOfBusiness == "WC"
				? ""
				: "AND try_to_number(version) = try_to_number('${args.scenarioFile.scenarioForm.version}')"
		};
`;
