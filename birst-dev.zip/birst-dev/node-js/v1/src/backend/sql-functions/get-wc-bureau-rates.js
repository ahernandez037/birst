return `
	SELECT DISTINCT *
	FROM (
		SELECT DISTINCT
			state,
			TO_VARCHAR(COALESCE(TO_DATE(eff_date), '1999-01-01')) AS eff_date,
			TO_VARCHAR(COALESCE(TO_DATE(release_date), '1999-01-01')) AS release_date,
			status_flag
		FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
		WHERE DATEDIFF(YEAR, eff_date, CURRENT_DATE()) <= 10
		UNION
		SELECT DISTINCT
			state,
			TO_VARCHAR(COALESCE(TO_DATE(ncci_eff), '1999-01-01')) AS ncci_eff,
			TO_VARCHAR(COALESCE(TO_DATE(release_date), '1999-01-01')) AS release_date,
			status_flag
		FROM prd_bizdb_coml.rate_tables.wc_misc_input
		WHERE DATEDIFF(YEAR, ncci_eff, CURRENT_DATE()) <= 10
	)
	ORDER BY
		state,
		eff_date DESC,
		release_date DESC,
		status_flag;
`;
