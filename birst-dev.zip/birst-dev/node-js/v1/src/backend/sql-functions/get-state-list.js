return `
	SELECT *
	FROM prd_bizdb_coml.birst_tool.state_list
	ORDER BY id;
`;
