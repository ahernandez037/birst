return `
	SELECT DISTINCT
		table_name,
		CASE
			WHEN table_number IS NULL THEN 'N/A'
			ELSE table_number
		END AS table_number,
		CASE
			WHEN ratabase_table_name IS NULL THEN 'N/A'
			ELSE ratabase_table_name
		END AS ratabase_table_name
	FROM prd_bizdb_coml.birst_tool.map_table_list_v4
	WHERE UPPER(table_name) = UPPER('${args.tableName}');
`;
