// Re-designed raters.
if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "CMP" &&
	["HAB", "REA", "ROS", "RST"].includes(args.scenarioFile.scenarioForm.product)
) {
	return `
		SELECT COUNT(1) AS record_count
		FROM prd_bizdb_coml.rate_tables.${args.tableName}
		WHERE
			state = '${args.scenarioFile.scenarioForm.geoState}'
			AND new_date = '${args.scenarioFile.scenarioForm.newDate}'
			AND renewal_date = '${args.scenarioFile.scenarioForm.renewalDate}'
			AND available_date = '${args.scenarioFile.scenarioForm.availableDate}';
	`;
}
// Legacy Work Comp rater.
else if (args.scenarioFile.scenarioForm.lineOfBusiness == "WC") {
	return `
		SELECT COUNT(1) AS record_count
		FROM prd_bizdb_coml.rate_tables.${args.tableName}
		WHERE
			state = '${args.scenarioFile.scenarioForm.geoState}'
			AND eff_date = '${args.scenarioFile.scenarioForm.renewalDate}'
		;
	`;
}
// Legacy all other raters.
else {
	return `
		SELECT COUNT(1) AS record_count
		FROM prd_bizdb_coml.rate_tables.${args.tableName}
		WHERE
			state = '${args.scenarioFile.scenarioForm.geoState}'
			AND rb_eff_date = '${args.scenarioFile.scenarioForm.renewalDate}'
			${
				args.scenarioFile.scenarioForm.product == "AUTO"
					? `AND version = ${args.scenarioFile.scenarioForm.version}`
					: ""
			}
		;
	`;
}
