return `
	SELECT
		state,
		product_type,
		pol_farmers_company_id,
		pol_farmers_company_name,
		num_policies,
		mod_prem_current,
		mod_prem_proposed,
		impact,
		dollar_change,
		max_policy_change,
		min_policy_change
	FROM combined_serff_report_${args.product}
	ORDER BY pol_farmers_company_id;
`;
