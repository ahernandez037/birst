return `
	SELECT *
	FROM wc_minimum_premium_nonbureau_exhibit
	ORDER BY
		company,
		class_code,
		desc_ind;
`;
