if (args.scenarioFile.scenarioForm.lineOfBusiness == "WC") {
	return `
		CALL prd_bizdb_coml.birst_tool.create_ratabase_table_wc (
			'${args.scenarioFile.scenarioForm.geoState}', /* state */
			'${args.scenarioFile.scenarioForm.renewalDate}', /* rb_eff_date */
			'${args.scenarioFile.scenarioForm.version == "LEGACY" ? "L" : "S"}', /* version */
			'${args.tableName}' /* table_name */
		);
	`;
} else {
	return `
		CALL prd_bizdb_coml.birst_tool.create_ratabase_table (
			'${args.scenarioFile.scenarioForm.lineOfBusiness}', /* lob */
			'${args.scenarioFile.scenarioForm.geoState}', /* state */
			'${args.scenarioFile.scenarioForm.renewalDate}', /* rb_eff_date */
			'${args.scenarioFile.scenarioForm.version}', /* version */
			'${args.tableName}' /* table_name */
		);
	`;
}
