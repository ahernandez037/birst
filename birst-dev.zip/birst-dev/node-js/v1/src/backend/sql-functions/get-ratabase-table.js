return `
	SELECT *
	FROM ratabase_table
	${args.orderBy};
`;
