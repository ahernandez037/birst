if (args.scenarioFile.scenarioForm.lineOfBusiness != "WC") {
	return `
		SELECT
			company,
			clsvalue,
			clstable,
			clsorder
		FROM cls_table
		ORDER BY
			clstable,
			company,
			prd_bizdb_coml.birst_tool.sort_cls_table_values(clsvalue);
	`;
} else {
	if (args.tableNumber == "41300") {
		return `
			SELECT
				company,
				text_str AS clsvalue,
				table_number AS clstable,
				REPLACE(text_str, '@', 'z') AS clsorder
			FROM temp1
			WHERE text_str IS NOT NULL
			UNION ALL
			SELECT
				company,
				text_str AS clsvalue,
				table_number AS clstable,
				REPLACE(text_str, '@', 'z') AS clsorder
			FROM temp3
			WHERE text_str IS NOT NULL
			ORDER BY
				company,
				clstable,
				clsorder;
		`;
	}

	if (args.tableNumber == "91717") {
		return `
			SELECT
				company,
				text_str AS clsvalue,
				table_number AS clstable,
				REPLACE(text_str, '@', 'z') AS clsorder
			FROM temp1_ca
			WHERE text_str IS NOT NULL
			ORDER BY
				company,
				table_number,
				REPLACE(text_str, '@', 'z');
		`;
	}
}
