let policySk = "pol_policy_sk";
let sublocationCoverageSk = "cov_policy_sublocation_coverage_sk";

if (args.scenarioFile.scenarioForm.lineOfBusiness == "UMB") {
	policySk = "umb_ul_policy_sk";
	sublocationCoverageSk = "umb_ul_fdrc_policy_umbrella_sk";
}

if (args.scenarioFile.scenarioForm.lineOfBusiness == "WC") {
	policySk = "policy_sk";
	sublocationCoverageSk = "policy_sublocation_coverage_sk";
}

return `
	WITH duplicate_count AS (
		SELECT
			${policySk},
			${sublocationCoverageSk},
			COUNT(1) AS duplicate_count
		FROM ${args.scenarioFile.scenarioForm.dataDumpTable}
		GROUP BY
			${policySk},
			${sublocationCoverageSk}
		HAVING COUNT(1) > 1
	)
	SELECT SUM(duplicate_count) AS total_duplicates
	FROM duplicate_count;
`;
