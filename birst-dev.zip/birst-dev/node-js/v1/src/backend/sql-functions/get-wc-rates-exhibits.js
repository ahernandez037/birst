return `
	SELECT *
	FROM rates_exhibit;
`;
