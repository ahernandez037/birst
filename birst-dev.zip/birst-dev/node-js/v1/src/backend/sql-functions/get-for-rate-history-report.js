return `
	SELECT *
	FROM for_rate_history
	ORDER BY
		state,
		channel,
		company,
		line_of_business,
		product,
		version,
		segment,
		coverage;
`;
