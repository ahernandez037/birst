return `
	WITH rolling_30_working_days AS (
		SELECT TOP 30 TO_DATE(date) AS date
		FROM prd_cbi_datamart.common.dim_date
		WHERE
			wrkg_hours_cnt > 0
			AND TO_DATE(date) <= CURRENT_DATE()
		ORDER BY date DESC
	),
	scenario_runs AS (
		SELECT
			TO_DATE(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', TO_TIMESTAMP(created_at_utc))) AS date,
			user_id
		FROM prd_bizdb_coml.public_sandbox.birst_log_node_js
        WHERE
			/* Keeping for backwards compatibility. */
            payload ILIKE 'FINISHED RUNNING SCENARIO%'
			/* As of v1.3.0, started using SCENARIO-RUN-END. */
            OR payload ILIKE '%SCENARIO-RUN-END%'
	)
	SELECT
		d.date,
		COALESCE(r.user_id, 'N/A') AS user_id,
		COUNT(1) as number_of_runs
	FROM
		rolling_30_working_days AS d
		LEFT JOIN scenario_runs AS r
			ON d.date = r.date
	GROUP BY
		d.date,
		r.user_id
	ORDER BY
		d.date,
		r.user_id;
`;
