return `
	SELECT COUNT(1) AS record_count
	FROM ${args.scenarioFile.scenarioForm.dataDumpTable};
`;
