let version = args.scenarioFile.scenarioForm.version;

if (args.scenarioFile.scenarioForm.lineOfBusiness != "WC") {
	if (version == "" || version == "N/A" || version == "999") version = "97";

	return `
		CALL prd_bizdb_coml.birst_tool.create_cls_table (
			'${args.scenarioFile.scenarioForm.lineOfBusiness}', /* lob */
			'${args.scenarioFile.scenarioForm.geoState}', /* state */
			'${version}', /* version */
			'${args.scenarioFile.scenarioForm.renewalDate}', /* rb_eff_date */
			'${args.tableNumber}', /* table_number */
			'000', /* comp */
			false /* is_debug */
		);
	`;
} else {
	if (version == "LEGACY") version = "L";
	if (version == "SPWC") version = "S";

	return `
		CALL prd_bizdb_coml.birst_tool.create_cls_table_wc (
			'${args.scenarioFile.scenarioForm.lineOfBusiness}', /* lob */
			'${args.scenarioFile.scenarioForm.geoState}', /* state */
			'${version}', /* version */
			'${args.scenarioFile.scenarioForm.renewalDate}', /* rb_eff_date */
			'${args.tableNumber}', /* table_number */
			'003' /* comp */
		);
	`;
}
