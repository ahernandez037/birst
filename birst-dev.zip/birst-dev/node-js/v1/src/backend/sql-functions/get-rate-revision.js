return `
	SELECT *
	FROM prd_bizdb_coml.public_sandbox.birst_rate_revision
	WHERE scenario_id = '${args.scenarioFile.scenarioForm.scenarioId}';
`;
