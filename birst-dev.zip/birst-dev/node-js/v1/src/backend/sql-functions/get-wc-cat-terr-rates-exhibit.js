return `
	SELECT *
	FROM cat_terr_rates_exhibit;
`;
