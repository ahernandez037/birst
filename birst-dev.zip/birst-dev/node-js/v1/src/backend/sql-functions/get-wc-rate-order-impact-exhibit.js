return `
	SELECT *
	FROM rate_order_impact_exhibit;
`;
