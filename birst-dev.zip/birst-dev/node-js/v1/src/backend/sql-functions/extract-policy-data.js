// To enable support for the Umbrella line of business, which requires
// separate data extracts to for the underlying LOBs, e.g., CMP & Auto,
// the SQL function here is unique compared to most others because it
// returns an array of strings. For non-Umbrella LOBs, we simply take
// the first array element, but for the Umbrella LOB, we need to take a
// total of 4 strings that each contain the SQL code to execute for each
// LOB data extract.

switch (args.scenarioFile.scenarioForm.lineOfBusiness) {
	case "CMP":
		return [
			`
			CALL ${args.scenarioFile.scenarioForm.extractPolicyData}(
				'POLICY', /* policy_table */
				'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
				'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
				'${args.scenarioFile.scenarioForm.dataSource}', /* region */
				'${args.scenarioFile.scenarioForm.geoState}', /* state */
				'${args.scenarioFile.scenarioForm.product}', /* industry */
				'${args.scenarioFile.scenarioForm.startDate.substring(0, 10)}', /* start_date */
				'${
					args.scenarioFile.scenarioForm.queryMethod == "IN-FORCE"
						? args.scenarioFile.scenarioForm.inforceDate.substring(0, 10)
						: args.scenarioFile.scenarioForm.endDate.substring(0, 10)
				}', /* end_date */
				'${args.scenarioFile.scenarioForm.fdrcTimestamp.substring(0, 10)}', /* fdrc_timestamp */
				${args.scenarioFile.scenarioForm.useCountrywideData}, /* use_countrywide_data */
				false, /* is_t1_mode */
				${args.scenarioFile.scenarioForm.runMode == "ON-LEVEL" ? "true" : "false"}, /* is_on_level_mode */
				false, /* is_permanent_data_extract */
				false /* is_logged */
			);
			`,
		];
	case "AUTO":
		return [
			`
			CALL ${args.scenarioFile.scenarioForm.extractPolicyData}(
				'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
				'${args.scenarioFile.scenarioForm.geoState}', /* state */
				'${args.scenarioFile.scenarioForm.product}', /* product, i.e., Auto or Garage */
				/* FDRC shows all Auto Flex versions as 5, i.e., there is no
				5.1. Therefore, for the data extract, the version must be set to
				5 for all Auto Flex. In regards to the rates being applied by
				BIRST, the rater overwrites the rate version to 5.0 and 5.1 when
				calculating the Auto Flex premium. */
				'${
					args.scenarioFile.scenarioForm.version == "5.1"
						? "5"
						: args.scenarioFile.scenarioForm.version
				}', /* version */
				'${args.scenarioFile.scenarioForm.dataSource}', /* region */
				'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
				'${args.scenarioFile.scenarioForm.startDate.substring(0, 10)}', /* start_date */
				'${
					args.scenarioFile.scenarioForm.queryMethod == "IN-FORCE"
						? args.scenarioFile.scenarioForm.inforceDate.substring(0, 10)
						: args.scenarioFile.scenarioForm.endDate.substring(0, 10)
				}', /* end_date */
				'${args.scenarioFile.scenarioForm.fdrcTimestamp.substring(0, 10)}', /* fdrc_timestamp */
				false, /* is_t1_mode */
				${args.scenarioFile.scenarioForm.runMode == "ON-LEVEL" ? "true" : "false"}, /* is_on_level_mode */
				false, /* is_logged */
				false, /* is_permanent_data_extract */
				${args.scenarioFile.scenarioForm.useCountrywideData}, /* use_countrywide_data */
				${args.scenarioFile.scenarioForm.useAllVersionsData}, /* use_all_versions_data */
				'POLICY', /* output_policy_table */
				'DRIVER' /* output_driver_table */
			);
			`,
		];
	case "WC":
		return [
			`
			CALL ${args.scenarioFile.scenarioForm.extractPolicyData}(
				'POLICY', /* policy_table */
				'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
				'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
				'${args.scenarioFile.scenarioForm.dataSource}', /* region */
				'${args.scenarioFile.scenarioForm.geoState}', /* state */
				'${args.scenarioFile.scenarioForm.product}', /* product */
				'${args.scenarioFile.scenarioForm.startDate.substring(0, 10)}', /* start_date */
				'${
					args.scenarioFile.scenarioForm.queryMethod == "IN-FORCE"
						? args.scenarioFile.scenarioForm.inforceDate.substring(0, 10)
						: args.scenarioFile.scenarioForm.endDate.substring(0, 10)
				}', /* end_date */
				'${args.scenarioFile.scenarioForm.fdrcTimestamp.substring(0, 10)}', /* fdrc_timestamp */
				false, /* is_t1_mode */
				${args.scenarioFile.scenarioForm.runMode == "ON-LEVEL" ? "true" : "false"}, /* is_on_level_mode */
				false, /* is_logged */
				false /* is_permanent_data_extract */
			);
			`,
		];
	case "UMB":
		// The procedure names for CMP and Auto are hardcoded since the value
		// contained in args.scenarioFile.scenarioForm.extractPolicyData
		// points to the procedure for the actual Umbrella data extract. As a
		// future enhancement, should consider passing the procedure names for
		// CMP and Auto through the arguments.
		//
		// The strings in this array must be in the following order:
		// Array element 0 = CMP
		// Array element 1 = Auto
		// Array element 2 = Garage
		// Array element 3 = Umbrella
		return [
			`
			CALL prd_bizdb_coml.birst_tool.extract_policy_data_cmp(
				'CMP_POLICY', /* policy_table */
				'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
				'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
				'${args.scenarioFile.scenarioForm.dataSource}', /* region */
				'${args.scenarioFile.scenarioForm.geoState}', /* state */
				'ALL', /* industry */
				'${args.scenarioFile.scenarioForm.startDate.substring(0, 10)}', /* start_date */
				'${
					args.scenarioFile.scenarioForm.queryMethod == "IN-FORCE"
						? args.scenarioFile.scenarioForm.inforceDate.substring(0, 10)
						: args.scenarioFile.scenarioForm.endDate.substring(0, 10)
				}', /* end_date */
				'${args.scenarioFile.scenarioForm.fdrcTimestamp.substring(0, 10)}', /* fdrc_timestamp */
				${args.scenarioFile.scenarioForm.useCountrywideData}, /* use_countrywide_data */
				true, /* is_t1_mode */
				${args.scenarioFile.scenarioForm.runMode == "ON-LEVEL" ? "true" : "false"}, /* is_on_level_mode */
				false, /* is_permanent_data_extract */
				false /* is_logged */
			);
			`,
			`
			CALL prd_bizdb_coml.birst_tool.extract_policy_data_auto(
				'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
				'${args.scenarioFile.scenarioForm.geoState}', /* state */
				'AUTO', /* product, i.e., Auto or Garage */
				'ALL', /* version */
				'${args.scenarioFile.scenarioForm.dataSource}', /* region */
				'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
				'${args.scenarioFile.scenarioForm.startDate.substring(0, 10)}', /* start_date */
				'${
					args.scenarioFile.scenarioForm.queryMethod == "IN-FORCE"
						? args.scenarioFile.scenarioForm.inforceDate.substring(0, 10)
						: args.scenarioFile.scenarioForm.endDate.substring(0, 10)
				}', /* end_date */
				'${args.scenarioFile.scenarioForm.fdrcTimestamp.substring(0, 10)}', /* fdrc_timestamp */
				true, /* is_t1_mode */
				${args.scenarioFile.scenarioForm.runMode == "ON-LEVEL" ? "true" : "false"}, /* is_on_level_mode */
				false, /* is_logged */
				false, /* is_permanent_data_extract */
				${args.scenarioFile.scenarioForm.useCountrywideData}, /* use_countrywide_data */
				${args.scenarioFile.scenarioForm.useAllVersionsData}, /* use_all_versions_data */
				'AUTO_POLICY', /* output_policy_table */
				'AUTO_DRIVER' /* output_driver_table */
			);
			`,
			`
			CALL prd_bizdb_coml.birst_tool.extract_policy_data_auto(
				'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
				'${args.scenarioFile.scenarioForm.geoState}', /* state */
				'GAR', /* product, i.e., Auto or Garage */
				'', /* version */
				'${args.scenarioFile.scenarioForm.dataSource}', /* region */
				'${args.scenarioFile.scenarioForm.queryMethod}', /* query_method */
				'${args.scenarioFile.scenarioForm.startDate.substring(0, 10)}', /* start_date */
				'${
					args.scenarioFile.scenarioForm.queryMethod == "IN-FORCE"
						? args.scenarioFile.scenarioForm.inforceDate.substring(0, 10)
						: args.scenarioFile.scenarioForm.endDate.substring(0, 10)
				}', /* end_date */
				'${args.scenarioFile.scenarioForm.fdrcTimestamp.substring(0, 10)}', /* fdrc_timestamp */
				true, /* is_t1_mode */
				${args.scenarioFile.scenarioForm.runMode == "ON-LEVEL" ? "true" : "false"}, /* is_on_level_mode */
				false, /* is_logged */
				false, /* is_permanent_data_extract */
				${args.scenarioFile.scenarioForm.useCountrywideData}, /* use_countrywide_data */
				${args.scenarioFile.scenarioForm.useAllVersionsData}, /* use_all_versions_data */
				'GARAGE_POLICY', /* output_policy_table */
				'' /* output_driver_table */
			);
			`,
			`
			CALL ${args.scenarioFile.scenarioForm.extractPolicyData}(
				'${args.scenarioFile.scenarioForm.runMode}', // run_mode
				'${args.scenarioFile.scenarioForm.geoState}', // state
				'${args.scenarioFile.scenarioForm.dataSource}', // region
				'${args.scenarioFile.scenarioForm.queryMethod}', // query_method
				'${args.scenarioFile.scenarioForm.startDate.substring(0, 10)}', /* start_date */
				'${
					args.scenarioFile.scenarioForm.queryMethod == "IN-FORCE"
						? args.scenarioFile.scenarioForm.inforceDate.substring(0, 10)
						: args.scenarioFile.scenarioForm.endDate.substring(0, 10)
				}', /* end_date */
				'${args.scenarioFile.scenarioForm.fdrcTimestamp.substring(0, 10)}', /* fdrc_timestamp */
				${args.scenarioFile.scenarioForm.runMode == "ON-LEVEL" ? "true" : "false"}, // is_on_level_mode
				false, // is_logged
				false, // is_permanent_data_extract
				${args.scenarioFile.scenarioForm.useCountrywideData}, // use_countrywide_data
				'POLICY' // output_policy_table
			);
			`,
		];
}
