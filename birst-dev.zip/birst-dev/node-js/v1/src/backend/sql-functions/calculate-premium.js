const suffix =
	args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" ? "_" + args.ratesBeingUsed : "";

const policyTable =
	args.scenarioFile.scenarioForm.policyDataOverrideTable == "N/A" ||
	args.scenarioFile.scenarioForm.policyDataOverrideTable == ""
		? "POLICY"
		: (policyTable = args.scenarioFile.scenarioForm.policyDataOverrideTable);

return `
	CALL ${
		args.ratesBeingUsed == "CURRENT"
			? args.scenarioFile.scenarioForm.calculatePremiumCurrent
			: args.scenarioFile.scenarioForm.calculatePremiumProposed
	}(
		'${policyTable}', /* policy_table */
		'RATE', /* rate_table */
		'PRECURSOR', /* precursor_table */
		'PREMIUM', /* premium_table */
		'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
		'${suffix}', /* suffix */
		false, /* is_logged */
		'{"implementedInitiatives": "${args.implementedInitiatives}", "isRstGlSalesInitiative": ${
			args.scenarioFile.scenarioForm.isRstGlSalesInitiative
		}}' /* misc_json */
	);
`;
