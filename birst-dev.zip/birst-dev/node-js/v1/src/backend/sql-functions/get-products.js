return `
	SELECT *
	FROM prd_bizdb_coml.birst_tool.product_availability
	ORDER BY
		state_code,
		line_of_business_code,
		product_code,
		version_code;
`;
