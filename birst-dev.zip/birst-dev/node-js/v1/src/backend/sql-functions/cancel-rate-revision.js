return `
	UPDATE prd_bizdb_coml.public_sandbox.birst_rate_revision
	SET
		is_canceled = true,
		canceled_at_utc = '${new Date().toISOString()}',
		canceled_by = '${args.userId}',
		scenario_directory_canceled = '${args.scenarioFile.scenarioForm.scenarioDirectory.replace(
			/\\/g,
			"\\\\",
		)}'
	WHERE
		scenario_id = '${args.scenarioFile.scenarioForm.scenarioId}'
		AND state = '${args.scenarioFile.scenarioForm.geoState}'
		AND line_of_business = '${args.scenarioFile.scenarioForm.lineOfBusiness}'
		AND product = '${args.scenarioFile.scenarioForm.product}'
		AND version = '${args.scenarioFile.scenarioForm.version}'
		AND renewal_date = '${args.scenarioFile.scenarioForm.renewalDate.substring(0, 10)}';
`;
