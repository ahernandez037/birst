const suffix =
	args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" ? "_" + args.ratesBeingUsed : "";

// New raters.
if (["HAB", "REA", "ROS", "RST"].includes(args.scenarioFile.scenarioForm.product)) {
	return `
		CALL ${
			args.ratesBeingUsed == "CURRENT"
				? args.scenarioFile.scenarioForm.prepareRateTablesCurrent
				: args.scenarioFile.scenarioForm.prepareRateTablesProposed
		}(
			'${
				args.ratesBeingUsed == "CURRENT"
					? args.scenarioFile.scenarioForm.rateTableListCurrent
					: args.scenarioFile.scenarioForm.rateTableListProposed
			}', /* rate_table_list */
			'${args.scenarioFile.scenarioForm.geoState}', /* state */
			'${args.scenarioFile.scenarioForm.lineOfBusiness}', /* line_of_business */
			'${
				args.scenarioFile.scenarioForm.product
					? args.scenarioFile.scenarioForm.product
					: "N/A"
			}', /* product */
			'${
				args.scenarioFile.scenarioForm.version
					? args.scenarioFile.scenarioForm.version
					: "N/A"
			}', /* version */
			'${suffix}', /* suffix */
			false /* is_logged */
		);
`;
}
// Legacy raters.
else {
	return `
		CALL ${
			args.ratesBeingUsed == "CURRENT"
				? args.scenarioFile.scenarioForm.prepareRateTablesCurrent
				: args.scenarioFile.scenarioForm.prepareRateTablesProposed
		}(
			'${
				args.ratesBeingUsed == "CURRENT"
					? args.scenarioFile.scenarioForm.rateTableListCurrent
					: args.scenarioFile.scenarioForm.rateTableListProposed
			}', /* rate_table_list */
			'${suffix}', /* suffix */
			false /* is_logged */
		);
	`;
}
