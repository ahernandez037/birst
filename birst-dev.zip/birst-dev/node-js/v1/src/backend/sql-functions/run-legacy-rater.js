const suffix =
	args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" ? "_" + args.ratesBeingUsed : "";

let policyTable = "POLICY";

if (args.scenarioFile.scenarioForm.isAutoFlexRollout) {
	// Auto Flex phase 2 states.
	if (
		["AZ", "IL", "NM", "TX", "WY"].includes(
			args.scenarioFile.scenarioForm.geoState.toUpperCase(),
		)
	) {
		policyTable = "PRD_BIZDB_COML.DATA_EXTRACTS.FLEX_PIF_033122_POST_EQF_V3";
	}
	// Auto Flex phase 3 and newer states.
	else if (
		[
			"AL",
			"AR",
			"CA",
			"CT",
			"ID",
			"IN",
			"MI",
			"MN",
			"MO",
			"NJ",
			"NV",
			"OH",
			"OK",
			"OR",
			"UT",
		].includes(args.scenarioFile.scenarioForm.geoState.toUpperCase())
	) {
		policyTable = "PRD_BIZDB_COML.DATA_EXTRACTS.FLEX_PIF_123122_POST_EQF";
	}
} else if (
	args.scenarioFile.scenarioForm.policyDataOverrideTable != "N/A" &&
	args.scenarioFile.scenarioForm.policyDataOverrideTable != ""
) {
	policyTable = args.scenarioFile.scenarioForm.policyDataOverrideTable;
}

let driverTable = "DRIVER";

if (args.scenarioFile.scenarioForm.isAutoFlexRollout) {
	// Auto Flex phase 2 states.
	if (
		["AZ", "IL", "NM", "TX", "WY"].includes(
			args.scenarioFile.scenarioForm.geoState.toUpperCase(),
		)
	) {
		driverTable = "PRD_BIZDB_COML.DATA_EXTRACTS.FLEX_PIF_033122_POST_EQF_DRV";
	}
	// Auto Flex phase 3 and newer states.
	else if (
		[
			"AL",
			"AR",
			"CA",
			"CT",
			"ID",
			"IN",
			"MI",
			"MN",
			"MO",
			"NJ",
			"NV",
			"OH",
			"OK",
			"OR",
			"UT",
		].includes(args.scenarioFile.scenarioForm.geoState.toUpperCase())
	) {
		driverTable = "PRD_BIZDB_COML.DATA_EXTRACTS.FLEX_PIF_1233122_DRV_FROM_EQF";
	}
} else if (
	(args.scenarioFile.scenarioForm.driverDataOverrideTable != "N/A") &
	(args.scenarioFile.scenarioForm.driverDataOverrideTable != "")
) {
	driverTable = args.scenarioFile.scenarioForm.driverDataOverrideTable;
}

// *************************************************************************************************
// * Commercial Multi-Peril
// *************************************************************************************************

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "CMP" &&
	["ASR", "CON", "MFG", "WHL"].includes(args.scenarioFile.scenarioForm.product)
) {
	return `
		CALL ${
			args.ratesBeingUsed == "CURRENT"
				? args.scenarioFile.scenarioForm.calculatePremiumCurrent
				: args.scenarioFile.scenarioForm.calculatePremiumProposed
		}(
			'${policyTable}', /* policy_table */
			'${suffix}', /* suffix */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'${
				args.scenarioFile.scenarioForm.renewalDate
					? args.scenarioFile.scenarioForm.renewalDate.substring(0, 10)
					: "1900-01-01"
			}', /* prb_eff_date */
			-- geoState can only come through as "ALL" when running in
			-- validation mode, i.e., when running in rate change mode,
			-- geoState will never be "ALL".
			'${args.scenarioFile.scenarioForm.geoState == "ALL" ? 1 : 0}', /* cw_rates */
			-- useCountrywideData can only come through when running in rate
			-- change mode.
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" ||
				args.scenarioFile.scenarioForm.useCountrywideData
					? 1
					: 0
			}', /* cw_data */
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" &&
				args.scenarioFile.scenarioForm.runMode == "VALIDATION"
					? "@"
					: args.scenarioFile.scenarioForm.geoState
			}', /* pstate */
			false /* is_logged */
		);
	`;
}

// *************************************************************************************************
// * Commercial Auto
// *************************************************************************************************

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "AUTO" &&
	args.scenarioFile.scenarioForm.product == "AUTO" &&
	// Separate handling for Auto Flex found below
	args.scenarioFile.scenarioForm.version != "5" &&
	args.scenarioFile.scenarioForm.version != "5.1"
) {
	return `
		CALL ${
			args.ratesBeingUsed == "CURRENT"
				? args.scenarioFile.scenarioForm.calculatePremiumCurrent
				: args.scenarioFile.scenarioForm.calculatePremiumProposed
		}(
			'${policyTable}', /* policy_table */
			'${driverTable}', /* driver_table */
			'${suffix}', /* suffix */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'${
				args.scenarioFile.scenarioForm.renewalDate
					? args.scenarioFile.scenarioForm.renewalDate.substring(0, 10)
					: "1900-01-01"
			}', /* prb_eff_date */
			-- geoState and version can only come through as "ALL" when running
			-- in validation or on-level modes, i.e., when running in rate change
			-- mode, geoState and version will never be "ALL".
			'${args.scenarioFile.scenarioForm.geoState == "ALL" ? 1 : 0}', /* cw_rates */
			-- useCountrywideData can only come through when running in rate
			-- change mode.
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" ||
				args.scenarioFile.scenarioForm.useCountrywideData
					? 1
					: 0
			}', /* cw_data */
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL"
					? "@"
					: args.scenarioFile.scenarioForm.geoState
			}', /* pstate */
			'${args.scenarioFile.scenarioForm.version == "ALL" ? 1 : 0}', /* mult_rate_vers */
			-- useAllVersionsData can only come through when running in rate
			-- change mode.
			'${
				args.scenarioFile.scenarioForm.version == "ALL" ||
				args.scenarioFile.scenarioForm.useAllVersionsData
					? 1
					: 0
			}', /* mult_data_vers */
			'${
				args.scenarioFile.scenarioForm.version == "ALL"
					? 999
					: args.scenarioFile.scenarioForm.version
			}', /* version */
			false /* is_logged */
		);
	`;
}

// *************************************************************************************************
// * Auto Flex Validation
// *************************************************************************************************

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "AUTO" &&
	args.scenarioFile.scenarioForm.product == "AUTO" &&
	args.scenarioFile.scenarioForm.runMode == "VALIDATION" &&
	(args.scenarioFile.scenarioForm.version == "5" ||
		args.scenarioFile.scenarioForm.version == "5.1")
) {
	return `
		CALL ${args.scenarioFile.scenarioForm.calculatePremiumCurrent}(
			'${policyTable}', /* policy_table */
			'${driverTable}', /* driver_table */
			'${suffix}', /* suffix */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'1900-01-01', /* prb_eff_date */
			'1', /* cw_rates */
			'1', /* cw_data */
			'@', /* pstate */
			'1', /* mult_rate_vers */
			'1', /* mult_data_vers */
			'999', /* version */
			false, /* is_logged */
			false /* is_auto_flex_rollout */
		);
	`;
}

// *************************************************************************************************
// * Auto Flex Rollout
// *************************************************************************************************

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "AUTO" &&
	args.scenarioFile.scenarioForm.product == "AUTO" &&
	args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" &&
	args.scenarioFile.scenarioForm.isAutoFlexRollout &&
	(args.scenarioFile.scenarioForm.version == "5" ||
		args.scenarioFile.scenarioForm.version == "5.1")
) {
	return `
		CALL ${args.scenarioFile.scenarioForm.calculatePremiumCurrent}(
			'${policyTable}', /* policy_table */
			'${driverTable}', /* driver_table */
			'${suffix}', /* suffix */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'1900-01-01', /* prb_eff_date */
			'0', /* cw_rates */
			'0', /* cw_data */
			'${args.scenarioFile.scenarioForm.geoState}', /* pstate */
			'1', /* mult_rate_vers */
			'1', /* mult_data_vers */
			'999', /* version */
			false, /* is_logged */
			true /* is_auto_flex_rollout */
		);
	`;
}

// *************************************************************************************************
// * Auto Flex Rate Change
// *************************************************************************************************

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "AUTO" &&
	args.scenarioFile.scenarioForm.product == "AUTO" &&
	args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" &&
	!args.scenarioFile.scenarioForm.isAutoFlexRollout &&
	(args.scenarioFile.scenarioForm.version == "5" ||
		args.scenarioFile.scenarioForm.version == "5.1")
) {
	return `
		CALL ${args.scenarioFile.scenarioForm.calculatePremiumCurrent}(
			'${policyTable}', /* policy_table */
			'${driverTable}', /* driver_table */
			'${suffix}', /* suffix */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'1900-01-01', /* prb_eff_date */
			'0', /* cw_rates */
			'0', /* cw_data */
			'${args.scenarioFile.scenarioForm.geoState}', /* pstate */
			'${args.scenarioFile.scenarioForm.version == "ALL" ? 1 : 0}', /* mult_rate_vers */
			-- useAllVersionsData can only come through when running in rate
			-- change mode.
			'${
				args.scenarioFile.scenarioForm.version == "ALL" ||
				args.scenarioFile.scenarioForm.useAllVersionsData
					? 1
					: 0
			}', /* mult_data_vers */
			'5', /* version */
			false, /* is_logged */
			false /* is_auto_flex_rollout */
		);
	`;
}

// *************************************************************************************************
// * Garage
// *************************************************************************************************

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "AUTO" &&
	args.scenarioFile.scenarioForm.product == "GAR"
) {
	return `
		CALL ${
			args.ratesBeingUsed == "CURRENT"
				? args.scenarioFile.scenarioForm.calculatePremiumCurrent
				: args.scenarioFile.scenarioForm.calculatePremiumProposed
		}(
			'${policyTable}', /* policy_table */
			'${suffix}', /* suffix */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'${
				args.scenarioFile.scenarioForm.renewalDate
					? args.scenarioFile.scenarioForm.renewalDate.substring(0, 10)
					: "1900-01-01"
			}', /* prb_eff_date */
			-- geoState can only come through as "ALL" when running in
			-- validation mode, i.e., when running in rate change mode,
			-- geoState will never be "ALL".
			'${args.scenarioFile.scenarioForm.geoState == "ALL" ? 1 : 0}', /* cw_rates */
			-- useCountrywideData can only come through when running in rate
			-- change mode.
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" ||
				args.scenarioFile.scenarioForm.useCountrywideData
					? 1
					: 0
			}', /* cw_data */
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" &&
				args.scenarioFile.scenarioForm.runMode == "VALIDATION"
					? "@"
					: args.scenarioFile.scenarioForm.geoState
			}', /* pstate */
			false /* is_logged */
		);
	`;
}

// *************************************************************************************************
// * Workers' Compensation
// *************************************************************************************************

if (args.scenarioFile.scenarioForm.lineOfBusiness == "WC") {
	return `
		CALL ${
			args.ratesBeingUsed == "CURRENT"
				? args.scenarioFile.scenarioForm.calculatePremiumCurrent
				: args.scenarioFile.scenarioForm.calculatePremiumProposed
		}(
			'${policyTable}', /* policy_table */
			'${suffix}', /* suffix */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'${
				args.scenarioFile.scenarioForm.renewalDate
					? args.scenarioFile.scenarioForm.renewalDate.substring(0, 10)
					: "1900-01-01"
			}', /* prb_eff_date */
			-- geoState can only come through as "ALL" when running in
			-- validation mode, i.e., when running in rate change mode,
			-- geoState will never be "ALL".
			'${args.scenarioFile.scenarioForm.geoState == "ALL" ? 1 : 0}', /* cw_rates */
			-- useCountrywideData can only come through when running in rate
			-- change mode.
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" ||
				args.scenarioFile.scenarioForm.useCountrywideData
					? 1
					: 0
			}', /* cw_data */
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" &&
				args.scenarioFile.scenarioForm.runMode == "VALIDATION"
					? "@"
					: args.scenarioFile.scenarioForm.geoState
			}', /* pstate */
			'${args.scenarioFile.scenarioForm.version == "ALL" ? 1 : 0}', /* mult_rate_vers */
			-- useAllVersionsData can only come through when running in rate
			-- change mode.
			'${
				args.scenarioFile.scenarioForm.version == "ALL" ||
				args.scenarioFile.scenarioForm.useAllVersionsData
					? 1
					: 0
			}', /* mult_data_vers */
			'${
				args.scenarioFile.scenarioForm.version == "ALL"
					? 999
					: args.scenarioFile.scenarioForm.version
			}', /* version */
			'${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}', /* bureau_eff_date */
			'${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}', /* bureau_release_date */
			'${args.scenarioFile.scenarioForm.workCompBureauStatusFlag}', /* bureau_status_flag */
			false, /* is_logged */
			'${args.miscJson ? args.miscJson : "{}"}' /* misc_json */
		);
	`;
}

// *************************************************************************************************
// * Umbrella
// *************************************************************************************************

if (args.scenarioFile.scenarioForm.lineOfBusiness == "UMB") {
	return `
		CALL ${
			args.ratesBeingUsed == "CURRENT"
				? args.scenarioFile.scenarioForm.calculatePremiumCurrent
				: args.scenarioFile.scenarioForm.calculatePremiumProposed
		}(
			'${policyTable}', /* policy_table */
			'${suffix}', /* suffix */
			'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
			'${args.scenarioFile.scenarioForm.dataSource}', /* data_source */
			'${
				args.scenarioFile.scenarioForm.renewalDate
					? args.scenarioFile.scenarioForm.renewalDate.substring(0, 10)
					: "1900-01-01"
			}', /* prb_eff_date */
			-- geoState can only come through as "ALL" when running in
			-- validation mode, i.e., when running in rate change mode,
			-- geoState will never be "ALL".
			'${args.scenarioFile.scenarioForm.geoState == "ALL" ? 1 : 0}', /* cw_rates */
			-- useCountrywideData can only come through when running in rate
			-- change mode.
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" ||
				args.scenarioFile.scenarioForm.useCountrywideData
					? 1
					: 0
			}', /* cw_data */
			'${
				args.scenarioFile.scenarioForm.geoState == "ALL" &&
				args.scenarioFile.scenarioForm.runMode == "VALIDATION"
					? "@"
					: args.scenarioFile.scenarioForm.geoState
			}', /* pstate */
			false /* is_logged */
		);
	`;
}
