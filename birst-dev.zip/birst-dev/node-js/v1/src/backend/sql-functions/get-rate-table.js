// List of Work Comp tables that need special handling, such as because the
// rates for these tables may be overridden by rates from the rating bureau
// (when the user selects to adopt the bureau rates). Or tables that are used to
// override certain mappings, e.g., class codes.
const SPECIAL_WC_TABLES = [
	"WC_BUREAU_LC",
	"WC_CAT",
	"WC_TERRORISM",
	"WC_HAZARD_CODE",
	"WC_MINIMUM_PREMIUM_NONBUREAU",
	"WC_MINIMUM_PREMIUM_OVERRIDE",
	"WC_CLASS_CODE_MAPPING",
	"WC_DEVIATION",
	"WC_PAYROLL_USLH"
];

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "CMP" &&
	["HAB", "REA", "ROS", "RST"].includes(args.scenarioFile.scenarioForm.product)
) {
	return `
		SELECT a.*
		FROM
			prd_bizdb_coml.rate_tables.${args.tableName} AS a
			INNER JOIN (
				SELECT
					state,
					MAX(renewal_date) AS max_renewal_date
				FROM prd_bizdb_coml.rate_tables.${args.tableName}
				GROUP BY state
			) AS b
				ON a.state = b.state
				AND a.renewal_date = b.max_renewal_date
		${
			args.scenarioFile.scenarioForm.geoState == "ALL"
				? ""
				: `WHERE UPPER(a.state) = UPPER('${args.scenarioFile.scenarioForm.geoState}')`
		}
		${args.orderBy ? `ORDER BY ${args.orderBy}` : ""};
	`;
}

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "CMP" &&
	["ASR", "CON", "MFG", "WHL"].includes(args.scenarioFile.scenarioForm.product)
) {
	return `
		SELECT a.*
		FROM
			prd_bizdb_coml.rate_tables.${args.tableName} AS a
			INNER JOIN (
				SELECT
					state,
					MAX(rb_eff_date) AS max_renewal_date
				FROM prd_bizdb_coml.rate_tables.${args.tableName}
				GROUP BY state
			) AS b
				ON a.state = b.state
				AND a.rb_eff_date = b.max_renewal_date
		${
			args.scenarioFile.scenarioForm.geoState == "ALL"
				? ""
				: `WHERE UPPER(a.state) = UPPER('${args.scenarioFile.scenarioForm.geoState}')`
		}
		${args.orderBy ? `ORDER BY ${args.orderBy}` : ""};
	`;
}

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "AUTO" &&
	args.scenarioFile.scenarioForm.product == "AUTO"
) {
	return `
		SELECT a.*
		FROM
			prd_bizdb_coml.rate_tables.${args.tableName} AS a
			INNER JOIN (
				SELECT
					state,
					version,
					MAX(rb_eff_date) AS max_renewal_date
				FROM prd_bizdb_coml.rate_tables.${args.tableName}
				GROUP BY
					state,
					version
			) AS b
				ON a.state = b.state
				AND a.version = b.version
				AND a.rb_eff_date = b.max_renewal_date
		WHERE
			a.version = ${args.scenarioFile.scenarioForm.version}
			${
				args.scenarioFile.scenarioForm.geoState == "ALL"
					? ""
					: `AND UPPER(a.state) = UPPER('${args.scenarioFile.scenarioForm.geoState}')`
			}
		${args.orderBy ? `ORDER BY ${args.orderBy}` : ""};
	`;
}

if (
	args.scenarioFile.scenarioForm.lineOfBusiness == "AUTO" &&
	args.scenarioFile.scenarioForm.product == "GAR"
) {
	return `
		SELECT a.*
		FROM
			prd_bizdb_coml.rate_tables.${args.tableName} AS a
			INNER JOIN (
				SELECT
					state,
					MAX(rb_eff_date) AS max_renewal_date
				FROM prd_bizdb_coml.rate_tables.${args.tableName}
				GROUP BY state
			) AS b
				ON a.state = b.state
				AND a.rb_eff_date = b.max_renewal_date
		${
			args.scenarioFile.scenarioForm.geoState == "ALL"
				? ""
				: `WHERE UPPER(a.state) = UPPER('${args.scenarioFile.scenarioForm.geoState}')`
		}
		${args.orderBy ? `ORDER BY ${args.orderBy}` : ""};
	`;
}

if (args.scenarioFile.scenarioForm.lineOfBusiness == "WC") {
	// For WC Gradient AI initiative, bringing in LCMs for all UW companies to
	// allow users to enter proposed rates for both Legacy & SPWC in a single
	// rates file.
	if (
		args.scenarioFile.scenarioForm.isWorkCompGradientAiInitiative &&
		args.tableName.toUpperCase() == "WC_COMPANY_MULTIPLIER"
	) {
		return `
			SELECT a.*
			FROM
				prd_bizdb_coml.rate_tables.${args.tableName} AS a,
				(
					SELECT
						state,
						company,
						MAX(eff_date) AS max_renewal_date
					FROM prd_bizdb_coml.rate_tables.${args.tableName}
					GROUP BY
						state,
						company
				) AS b
			WHERE
				a.state = b.state
				AND a.company = b.company
				AND a.eff_date = b.max_renewal_date
				AND UPPER(a.state) = UPPER('${args.scenarioFile.scenarioForm.geoState}')
			${args.orderBy ? `ORDER BY ${args.orderBy}` : ""};
		`;
	}

	// If not adopting bureau rates, or they are being adopted but the table is
	// not one of the special Work Comp tables, then use the general query below.
	if (
		!args.scenarioFile.scenarioForm.workCompAdoptBureauRates ||
		(
			args.scenarioFile.scenarioForm.workCompAdoptBureauRates &&
			!SPECIAL_WC_TABLES.includes(args.tableName.toUpperCase())
		)
	) {
		return `
			SELECT a.*
			FROM
				prd_bizdb_coml.rate_tables.${args.tableName} AS a,
				(
					SELECT
						state,
						company,
						MAX(eff_date) AS max_renewal_date
					FROM prd_bizdb_coml.rate_tables.${args.tableName}
					GROUP BY
						state,
						company
				) AS b
			WHERE
				a.state = b.state
				AND a.company = b.company
				AND a.eff_date = b.max_renewal_date
				${
					args.scenarioFile.scenarioForm.geoState == "ALL"
						? ""
						: `AND UPPER(a.state) = UPPER('${args.scenarioFile.scenarioForm.geoState}')`
				}
				${
					args.scenarioFile.scenarioForm.version.toUpperCase() == "LEGACY"
						? "AND a.company != '3'"
						: "AND a.company = '3'"
				}
			${args.orderBy ? `ORDER BY ${args.orderBy}` : ""};
		`;
	}

	// Otherwise, handle the special Work Comp tables (when bureau rates are
	// being adopted) with one of the queries below.
	// IMPORTANT: The current and proposed columns for each rate field must be
	// next to each other in order for the rates file generation code to work.
	switch (args.tableName.toUpperCase()) {
		case "WC_BUREAU_LC":
			return `
				SELECT
					CASE
						WHEN a.state IS NULL THEN c.state
						ELSE a.state
					END AS state,
					CASE
						WHEN a.class_code IS NULL THEN c.class_code
						ELSE a.class_code
					END AS class_code,
					TRIM(a.rating_ind) AS rating_ind_current,
					TRIM(c.rating_ind) AS rating_ind_proposed,
					a.loss_cost AS loss_cost_current,
					c.loss_cost AS loss_cost_proposed,
					a.eff_date,
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END AS company,
					c.bureau_eff_date,
					c.release_date,
					c.status_flag
				FROM
					prd_bizdb_coml.rate_tables.wc_bureau_lc AS a
					INNER JOIN (
						SELECT
							state,
							company,
							MAX(eff_date) AS eff_date
						FROM prd_bizdb_coml.rate_tables.wc_bureau_lc
						WHERE
							state = '${args.scenarioFile.scenarioForm.geoState}'
							AND company IN (${
								args.scenarioFile.scenarioForm.version === "LEGACY"
									? "'2', '7', '9', '@'"
									: "'3'"
							})
							AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
						group by
							state,
							company
					) AS b
						ON a.state = b.state
						AND a.eff_date = b.eff_date
						AND a.company = b.company
					RIGHT JOIN (
						SELECT *
						FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
							AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
							AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
					) AS c
						ON a.state = c.state
						AND a.class_code = c.class_code
				ORDER BY
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END,
					CASE
						WHEN a.class_code IS NULL THEN c.class_code
						ELSE a.class_code
					END,
					TRIM(a.rating_ind);
			`;
		case "WC_CAT":
			return `
				SELECT *
				FROM (
					SELECT
						CASE
							WHEN
								a.company IS NULL
								AND c.catastrophe IS NOT NULL
								AND c.catastrophe != 0 THEN
									CASE
										WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
										WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
										ELSE ''
									END
							ELSE a.company
						END AS company,
						CASE
							WHEN
								a.state IS NULL
								AND c.catastrophe IS NOT NULL
								AND c.catastrophe != 0 THEN c.state
								ELSE a.state
						END AS state,
						a.rate AS rate_current,
						CASE
							WHEN c.catastrophe = 0 THEN NULL
							ELSE c.catastrophe
						END AS rate_proposed,
						a.eff_date,
						CASE
							WHEN
								c.catastrophe IS NOT NULL
								AND c.catastrophe != 0
								THEN c.bureau_eff_date
							ELSE NULL
						END AS bureau_eff_date,
						CASE
							WHEN
								c.catastrophe IS NOT NULL
								AND c.catastrophe != 0
								THEN c.release_date
							ELSE NULL
						END AS release_date,
						CASE
							WHEN
								c.catastrophe IS NOT NULL
								AND c.catastrophe != 0
								THEN c.status_flag
							ELSE NULL
						END AS status_flag,
						a.rounding_rule AS rounding_rule_current,
						a.rounding_rule AS rounding_rule_proposed
					FROM
						prd_bizdb_coml.rate_tables.wc_cat AS a
						INNER JOIN (
							SELECT
								state,
								company,
								MAX(eff_date) AS eff_date
							FROM prd_bizdb_coml.rate_tables.wc_cat
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND company IN (${
									args.scenarioFile.scenarioForm.version === "LEGACY"
										? "'2', '7', '9', '@'"
										: "'3'"
								})
								AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
							GROUP BY
								state,
								company
						) AS b
							ON a.state = b.state
							AND a.eff_date = b.eff_date
							AND a.company = b.company
						RIGHT JOIN (
							SELECT *
							FROM prd_bizdb_coml.rate_tables.wc_misc_input
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
								AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
								AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
						) AS c
							ON a.state = c.state
				) AS a
				WHERE
					a.rate_current IS NOT NULL
					or a.rate_proposed IS NOT NULL
				ORDER BY a.company;
			`;
		case "WC_TERRORISM":
			return `
				SELECT *
				FROM (
					SELECT
						CASE
							WHEN
								a.company IS NULL
								AND c.terrorism IS NOT NULL
								AND c.terrorism != 0
								THEN
									CASE
										WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
										WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
										ELSE ''
									END
							ELSE a.company
						END AS company,
						CASE
							WHEN
								a.state IS NULL
								AND c.terrorism IS NOT NULL
								AND c.terrorism != 0 THEN c.state
							ELSE a.state
						END AS state,
						a.rate AS rate_current,
						CASE
							WHEN c.terrorism = 0 THEN NULL
							ELSE c.terrorism
						END AS rate_proposed,
						a.eff_date,
						CASE
							WHEN
								c.terrorism IS NOT NULL
								AND c.terrorism != 0
								THEN c.bureau_eff_date
							ELSE NULL
						END AS bureau_eff_date,
						CASE
							WHEN
								c.terrorism IS NOT NULL
								AND c.terrorism != 0
								THEN c.release_date
							ELSE NULL
						END AS release_date,
						CASE
							WHEN
								c.terrorism IS NOT NULL
								AND c.terrorism != 0
								THEN c.status_flag
							ELSE NULL
						END AS status_flag,
						a.rounding_rule AS rounding_rule_current,
						a.rounding_rule AS rounding_rule_proposed
					FROM
						prd_bizdb_coml.rate_tables.wc_terrorism AS a
						INNER JOIN (
							SELECT
								state,
								company,
								MAX(eff_date) AS eff_date
							FROM prd_bizdb_coml.rate_tables.wc_terrorism
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND company IN (${
									args.scenarioFile.scenarioForm.version === "LEGACY"
										? "'2', '7', '9', '@'"
										: "'3'"
								})
								AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
							GROUP BY
								state,
								company
						) AS b
							ON a.state = b.state
							AND a.eff_date = b.eff_date
							AND a.company = b.company
						RIGHT JOIN (
							SELECT *
							FROM prd_bizdb_coml.rate_tables.wc_misc_input
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
								AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
								AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
						) AS c
							ON a.state = c.state
				) AS a
				WHERE
					a.rate_current IS NOT NULL
					or a.rate_proposed IS NOT NULL
				ORDER BY a.company;
			`;
		case "WC_HAZARD_CODE":
			return `
				SELECT
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END AS company,
					CASE
						WHEN a.state IS NULL THEN c.state
						ELSE a.state
					END AS state,
					CASE
						WHEN a.class_code IS NULL THEN c.class_code
						ELSE a.class_code
					END AS class_code,
					a.hazard_code AS hazard_code_current,
					c.hazard_code AS hazard_code_proposed,
					a.eff_date,
					c.bureau_eff_date,
					c.release_date,
					c.status_flag
				FROM
					prd_bizdb_coml.rate_tables.wc_hazard_code AS a
					INNER JOIN (
						SELECT
							state,
							company,
							MAX(eff_date) AS eff_date
						FROM prd_bizdb_coml.rate_tables.wc_hazard_code
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND company IN (${
								args.scenarioFile.scenarioForm.version === "LEGACY"
									? "'2', '7', '9', '@'"
									: "'3'"
							})
							AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
						GROUP BY
							state,
							company
					) AS b
						ON a.state = b.state
						AND a.eff_date = b.eff_date
						AND a.company = b.company
					RIGHT JOIN (
						SELECT *
						FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
							AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
							AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
					) AS c
						ON a.state = c.state
						AND a.class_code = c.class_code
				ORDER BY
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END,
					CASE
						WHEN a.class_code IS NULL THEN c.class_code
						ELSE a.class_code
					END;
			`;
		case "WC_MINIMUM_PREMIUM_NONBUREAU":
			if (["AZ", "FL", "IA", "ID", "NJ", "WI"].includes(args.scenarioFile.scenarioForm.geoState.toUpperCase())
			) {
				return `
					SELECT
						CASE
							WHEN a.state IS NULL THEN c.state
							ELSE a.state
						END AS state,
						CASE
							WHEN a.company IS NULL THEN
								CASE
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
									ELSE ''
								END
							ELSE a.company
						END AS company,
						CASE
							WHEN a.class_code IS NULL THEN c.class_code
							ELSE a.class_code
						END AS class_code,
						a.min_prem AS min_prem_current,
						c.min_prem AS min_prem_proposed,
						a.eff_date,
						CASE
							WHEN a.desc_ind IS NULL THEN '999'
							ELSE a.desc_ind
						END AS desc_ind,
						c.bureau_eff_date,
						c.release_date,
						c.status_flag
					FROM
						prd_bizdb_coml.rate_tables.wc_minimum_premium_nonbureau AS a
						INNER JOIN (
							SELECT
								state,
								company,
								MAX(eff_date) AS eff_date
							FROM prd_bizdb_coml.rate_tables.wc_minimum_premium_nonbureau
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND company IN (${
									args.scenarioFile.scenarioForm.version === "LEGACY"
										? "'2', '7', '9', '@'"
										: "'3'"
								})
								AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
							GROUP BY
								state,
								company
						) AS b
							ON a.state = b.state
							AND a.eff_date = b.eff_date
							AND a.company = b.company
						RIGHT JOIN (
							SELECT *
							FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
								AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
								AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
						) AS c
							ON a.state = c.state
							AND a.class_code = c.class_code
					ORDER BY
						CASE
							WHEN a.company IS NULL THEN
								CASE
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
									ELSE ''
								END
							ELSE a.company
						END,
						CASE
							WHEN a.class_code IS NULL THEN c.class_code
							ELSE a.class_code
						END,
						CASE
							WHEN a.desc_ind IS NULL THEN '999'
							ELSE a.desc_ind
						END;
				`;
			} else if (args.scenarioFile.scenarioForm.geoState.toUpperCase() === "PA") {
				const PA_CLASS_CODES = "'6824','6826','6843','6872','7309','7313','7317','7327','7366','8709','8726'";
				return `
					SELECT
						CASE
							WHEN a.state IS NULL THEN c.state
							ELSE a.state
						END AS State,
						CASE
							WHEN a.company IS NULL THEN
								CASE
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
									ELSE ''
								END
							ELSE a.company
						END AS company,
						CASE
							WHEN a.class_code IS NULL THEN c.class_code
							ELSE a.class_code
						END AS class_code,
						a.min_prem AS min_prem_current,
						CASE
							WHEN a.class_code IN (${PA_CLASS_CODES}) THEN c.min_prem
							ELSE a.min_prem
						END AS min_prem_proposed,
						a.eff_date,
						CASE
							WHEN a.desc_ind IS NULL THEN '999'
							ELSE a.desc_ind
						END AS desc_ind,
						CASE
							WHEN a.class_code IN (${PA_CLASS_CODES}) THEN c.bureau_eff_date
							ELSE a.bureau_eff_date
						END AS bureau_eff_date,
						CASE
							WHEN a.class_code IN (${PA_CLASS_CODES}) THEN c.release_date
							ELSE a.release_date
						END AS release_date,
						CASE
							WHEN a.class_code IN (${PA_CLASS_CODES}) THEN c.status_flag
							ELSE ''
						END AS status_flag
					FROM
						prd_bizdb_coml.rate_tables.wc_minimum_premium_nonbureau AS a
						INNER JOIN (
							SELECT
								state,
								company,
								MAX(eff_date) AS eff_date
							FROM prd_bizdb_coml.rate_tables.wc_minimum_premium_nonbureau
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND company IN (${
									args.scenarioFile.scenarioForm.version === "LEGACY"
										? "'2', '7', '9', '@'"
										: "'3'"
								})
								AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
							GROUP BY
								state,
								company
						) AS b
							ON a.state = b.state
							AND a.eff_date = b.eff_date
							AND a.company = b.company
						RIGHT JOIN (
							SELECT *
							FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
								AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
								AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
						) AS c
							ON a.state = c.state
							AND a.class_code = c.class_code
					ORDER BY
						CASE
							WHEN a.company IS NULL THEN
								CASE
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
									ELSE ''
								END
							ELSE a.company
						END,
						CASE
							WHEN a.class_code IS NULL THEN c.class_code
							ELSE a.class_code
						END,
						CASE
							WHEN a.desc_ind IS NULL THEN '999'
							ELSE a.desc_ind
						END;
				`;
			} else {
				return `
					SELECT
						CASE
							WHEN a.state IS NULL THEN c.state
							ELSE a.state
						END AS state,
						CASE
							WHEN a.company IS NULL THEN
								CASE
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
									ELSE ''
								END
							ELSE a.company
						END AS company,
						CASE
							WHEN a.class_code IS NULL THEN c.class_code
							ELSE a.class_code
						END AS class_code,
						a.min_prem,
						a.eff_date,
						CASE
							WHEN a.desc_ind IS NULL THEN '999'
							ELSE a.desc_ind
						END AS desc_ind,
						'' AS bureau_eff_date,
						'' AS release_date,
						'' AS status_flag
					FROM
						prd_bizdb_coml.rate_tables.wc_minimum_premium_nonbureau AS a
						INNER JOIN (
							SELECT
								state,
								company,
								MAX(eff_date) AS eff_date
							FROM prd_bizdb_coml.rate_tables.wc_minimum_premium_nonbureau
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND company IN (${
									args.scenarioFile.scenarioForm.version === "LEGACY"
										? "'2', '7', '9', '@'"
										: "'3'"
								})
								AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
							GROUP BY
								state,
								company
						) AS b
							ON a.state = b.state
							AND a.eff_date = b.eff_date
							AND a.company = b.company
						RIGHT JOIN (
							SELECT *
							FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
							WHERE
								UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
								AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
								AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
								AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
						) AS c
						ON
							a.state = c.state
							AND a.class_code = c.class_code
					ORDER BY
						CASE
							WHEN a.company IS NULL THEN
								CASE
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
									WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
									ELSE ''
								END
							ELSE a.company
						END,
						CASE
							WHEN a.class_code IS NULL THEN c.class_code
							ELSE a.class_code
						END,
						CASE
							WHEN a.desc_ind IS NULL THEN '999'
							ELSE a.desc_ind
						END;
				`;
			}
		case "WC_MINIMUM_PREMIUM_OVERRIDE":
			return `
				SELECT
					CASE
						WHEN a.state IS NULL THEN c.state
						ELSE a.state
					END AS state,
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END AS company,
					CASE
						WHEN a.class_code IS NULL THEN c.class_code
						ELSE a.class_code
					END AS class_code,
					a.min_prem AS min_prem_current,
					a.min_prem AS min_prem_proposed,
					a.eff_date,
					CASE
						WHEN a.desc_ind IS NULL THEN '999'
						ELSE a.desc_ind
					END AS desc_ind
				FROM
					prd_bizdb_coml.rate_tables.wc_minimum_premium_override AS a
					INNER JOIN (
						SELECT
							state,
							company,
							MAX(eff_date) AS eff_date
						FROM prd_bizdb_coml.rate_tables.wc_minimum_premium_override
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND company IN (${
								args.scenarioFile.scenarioForm.version === "LEGACY"
									? "'2', '7', '9', '@'"
									: "'3'"
							})
							AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
						GROUP BY
							state,
							company
					) AS b
						ON a.state = b.state
						AND a.eff_date = b.eff_date
						AND a.company = b.company
					RIGHT JOIN (
						SELECT *
						FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
							AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
							AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
					) AS c
						ON a.state = c.state
						AND a.class_code = c.class_code
				ORDER BY
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END,
					CASE
						WHEN a.class_code IS NULL THEN c.class_code
						ELSE a.class_code
					END,
					CASE
						WHEN a.desc_ind IS NULL THEN '999'
						ELSE a.desc_ind
					END;
			`;
		case "WC_CLASS_CODE_MAPPING":
			return `
				SELECT
					CASE
						WHEN a.state IS NULL THEN c.state
						ELSE a.state
					END AS state,
					CASE
						WHEN a.class_code IS NULL THEN c.class_code
						ELSE a.class_code
					END AS class_code,
					a.map_class_code AS map_class_code_current,
					a.map_class_code AS map_class_code_proposed,
					a.eff_date,
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END AS company
				FROM
					prd_bizdb_coml.rate_tables.wc_class_code_mapping AS a
					INNER JOIN (
						SELECT
							state,
							company,
							MAX(eff_date) AS eff_date
						FROM prd_bizdb_coml.rate_tables.wc_class_code_mapping
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND company IN (${
								args.scenarioFile.scenarioForm.version === "LEGACY"
									? "'2', '7', '9', '@'"
									: "'3'"
							})
							AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
						GROUP BY
							state,
							company
					) AS b
						ON a.state = b.state
						AND a.eff_date = b.eff_date
						AND a.company = b.company
					FULL OUTER JOIN (
						SELECT *
						FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
							AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
							AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
					) AS c
						ON a.state = c.state
						AND a.class_code = c.class_code
				ORDER BY
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END,
					CASE
						WHEN a.class_code IS NULL THEN c.class_code
						ELSE a.class_code
					END;
			`;
		case "WC_DEVIATION":
			return `
				SELECT
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END AS company,
					CASE
						WHEN a.state IS NULL THEN c.state
						ELSE a.state
					END AS state,
					CASE
						WHEN a.code IS NULL THEN c.class_code
						ELSE a.code
					END AS code,
					a.deviation AS deviation_current,
					CASE
						WHEN a.deviation IS NULL THEN 1
						ELSE a.deviation
					END AS deviation_proposed,
					a.eff_date,
					CASE
						WHEN a.desc_ind IS NULL THEN '999'
						ELSE a.desc_ind
					END AS desc_ind
				FROM
					prd_bizdb_coml.rate_tables.wc_deviation AS a
					INNER JOIN (
						SELECT
							state,
							company,
							MAX(eff_date) AS eff_date
						FROM prd_bizdb_coml.rate_tables.wc_deviation
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND company IN (${
								args.scenarioFile.scenarioForm.version === "LEGACY"
									? "'2', '7', '9', '@'"
									: "'3'"
							})
							AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
						GROUP BY
							state,
							company
					) AS b
						ON a.state = b.state
						AND a.eff_date = b.eff_date
						AND a.company = b.company
					RIGHT JOIN (
						SELECT *
						FROM prd_bizdb_coml.rate_tables.wc_lcminprem_input
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
							AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
							AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
					) AS c
						ON a.state = c.state
						AND a.code = c.class_code
				ORDER BY
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END,
					CASE
						WHEN a.code IS NULL THEN c.class_code
						ELSE a.code
					END,
					CASE
						WHEN a.desc_ind IS NULL THEN '999'
						ELSE a.desc_ind
					END;
			`;
		case "WC_PAYROLL_USLH":
			return `
				SELECT
					CASE
						WHEN a.state IS NULL THEN c.state
						ELSE a.state
					END AS state,
					c.bureau_eff_date,
					a.max_payroll AS max_payroll_current,
					c.max_payroll AS max_payroll_proposed,
					a.min_payroll AS min_payroll_current,
					c.min_payroll AS min_payroll_proposed,
					a.premium_for_partners_etc AS premium_for_partners_etc_current,
					c.premium_for_partners_etc AS premium_for_partners_etc_proposed,
					a.longshore AS longshore_current,
					c.longshore AS longshore_proposed,
					a.premium_for_partners_max AS premium_for_partners_max_current,
					c.premium_for_partners_max AS premium_for_partners_max_proposed,
					a.construction_hourly_wage AS construction_hourly_wage_current,
					c.construction_hourly_wage AS construction_hourly_wage_proposed,
					a.average_weekly_wage AS average_weekly_wage_current,
					c.average_weekly_wage AS average_weekly_wage_proposed,
					a.emplolyer_assessment AS emplolyer_assessment_current,
					c.emplolyer_assessment AS emplolyer_assessment_proposed,
					a.standard_premium_assessment AS standard_premium_assessment_current,
					c.standard_premium_assessment AS standard_premium_assessment_proposed,
					a.secondary_injury_fund AS secondary_injury_fund_current,
					c.secondary_injury_fund AS secondary_injury_fund_proposed,
					c.release_date,
					c.status_flag,
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END AS company,
					a.eff_date
				FROM
					prd_bizdb_coml.rate_tables.wc_payroll_uslh AS a
					INNER JOIN (
						SELECT
							state,
							company,
							MAX(eff_date) AS eff_date
						FROM prd_bizdb_coml.rate_tables.wc_payroll_uslh
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND company IN (${
								args.scenarioFile.scenarioForm.version === "LEGACY"
									? "'2', '7', '9', '@'"
									: "'3'"
							})
							AND eff_date <= '${args.scenarioFile.scenarioForm.renewalDate}'
						GROUP BY
							state,
							company
					) AS b
						ON a.state = b.state
						AND a.eff_date = b.eff_date
						AND a.company = b.company
					RIGHT JOIN (
						SELECT *
						FROM prd_bizdb_coml.rate_tables.wc_misc_input
						WHERE
							UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}'
							AND bureau_eff_date = '${args.scenarioFile.scenarioForm.workCompBureauEffectiveDate}'
							AND release_date = '${args.scenarioFile.scenarioForm.workCompBureauReleaseDate}'
							AND UPPER(status_flag) = '${args.scenarioFile.scenarioForm.workCompBureauStatusFlag.toUpperCase()}'
					) AS c
						ON a.state = c.state
				ORDER BY
					CASE
						WHEN a.company IS NULL THEN
							CASE
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'LEGACY' THEN '@'
								WHEN '${args.scenarioFile.scenarioForm.version.toUpperCase()}' = 'SPWC' THEN '3'
								ELSE ''
							END
						ELSE a.company
					END;
			`;
	}
}

if (args.scenarioFile.scenarioForm.lineOfBusiness == "UMB") {
	return `
		SELECT a.*
		FROM
			prd_bizdb_coml.rate_tables.${args.tableName} AS a
			INNER JOIN (
				SELECT
					state,
					MAX(rb_eff_date) AS max_renewal_date
				FROM prd_bizdb_coml.rate_tables.${args.tableName}
				GROUP BY state
			) AS b
				ON a.state = b.state
				AND a.rb_eff_date = b.max_renewal_date
		${
			args.scenarioFile.scenarioForm.geoState == "ALL"
				? ""
				: `WHERE UPPER(a.state) = UPPER('${args.scenarioFile.scenarioForm.geoState}')`
		}
		${args.orderBy ? `ORDER BY ${args.orderBy}` : ""};
	`;
}
