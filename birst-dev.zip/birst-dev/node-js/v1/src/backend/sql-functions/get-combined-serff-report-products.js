return `
	SELECT product
	FROM combined_serff_report_product
	ORDER BY product;
`;
