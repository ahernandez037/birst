return `
	SELECT *
	FROM new_expired_class_codes_exhibit;
`;
