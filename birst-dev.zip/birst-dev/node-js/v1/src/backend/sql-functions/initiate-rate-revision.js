return `
	INSERT INTO prd_bizdb_coml.public_sandbox.birst_rate_revision (
		scenario_id,
		created_at_utc,
		created_by,
		is_canceled,
		canceled_at_utc,
		canceled_by,
		state,
		line_of_business,
		product,
		version,
		new_date,
		renewal_date,
		available_date,
		policy_count,
		exposure_count,
		modified_premium_current,
		modified_premium_proposed,
		impact_amount,
		impact_percent,
		tolerance_lo,
		tolerance_hi,
		in_scope_tables,
		in_scope_bureau_tables,
		adopt_bureau_ind,
		bureau_effective_date,
		query_method,
		inforce_date,
		scenario_directory,
		scenario_directory_canceled,
		scenario_file,
		rates_file,
		report_file,
		data_dump_file,
		fit_exhibits_file,
		data_dump_table
	) VALUES (
		'${args.scenarioFile.scenarioForm.scenarioId}',
		'${new Date().toISOString()}',
		'${args.userId}',
		false,
		'',
		'',
		'${args.scenarioFile.scenarioForm.geoState}',
		'${args.scenarioFile.scenarioForm.lineOfBusiness}',
		'${args.scenarioFile.scenarioForm.product}',
		'${args.scenarioFile.scenarioForm.version}',
		'${args.scenarioFile.scenarioForm.newDate.substring(0, 10)}',
		'${args.scenarioFile.scenarioForm.renewalDate.substring(0, 10)}',
		'${args.scenarioFile.scenarioForm.availableDate.substring(0, 10)}',
		'${args.scenarioFile.executiveSummary.policyCount}',
		'${args.scenarioFile.executiveSummary.exposureCount}',
		'${args.scenarioFile.executiveSummary.modifiedPremiumCurrent}',
		'${args.scenarioFile.executiveSummary.modifiedPremiumProposed}',
		'${args.scenarioFile.executiveSummary.impactAmount}',
		'${args.scenarioFile.executiveSummary.impactPercent}',
		'${args.scenarioFile.executiveSummary.toleranceLo}',
		'${args.scenarioFile.executiveSummary.toleranceHi}',
		'${args.scenarioFile.executiveSummary.inScopeTables}',
		'${
			args.scenarioFile.executiveSummary.inScopeBureauTables
				? args.scenarioFile.executiveSummary.inScopeBureauTables
				: ""
		}',
		${
			args.scenarioFile.scenarioForm.adoptBureauInd
				? args.scenarioFile.scenarioForm.adoptBureauInd
				: "false"
		},
		'${
			args.scenarioFile.scenarioForm.bureauEffectiveDate
				? args.scenarioFile.scenarioForm.bureauEffectiveDate
				: ""
		}',
		'${args.scenarioFile.scenarioForm.queryMethod}',
		'${args.scenarioFile.scenarioForm.inforceDate.substring(0, 10)}',
		'${args.scenarioFile.scenarioForm.scenarioDirectory.replace(/\\/g, "\\\\")}',
		'',
		'${args.scenarioFile.files.scenarioFile.replace(/\\/g, "\\\\")}',
		'${args.scenarioFile.files.ratesFile.replace(/\\/g, "\\\\")}',
		'${args.scenarioFile.files.reportFile.replace(/\\/g, "\\\\")}',
		'${args.scenarioFile.files.dataDumpFile.replace(/\\/g, "\\\\")}',
		'${args.scenarioFile.files.fitExhibitsFile.replace(/\\/g, "\\\\")}',
		'${args.scenarioFile.scenarioForm.dataDumpTable}'
	);
`;
