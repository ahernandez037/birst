return `
	SELECT listagg(ratabase_columnname, ',') within group (order by colorder) as order_by
	FROM prd_bizdb_coml.birst_tool.map_art_ratabase_mapping
	WHERE upper(sql_tablename) = upper('${args.tableName}');
`;
