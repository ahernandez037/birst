const suffix =
	args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" ? "_" + args.ratesBeingUsed : "";

const policyTable =
	args.scenarioFile.scenarioForm.policyDataOverrideTable == "N/A" ||
	args.scenarioFile.scenarioForm.policyDataOverrideTable == ""
		? "POLICY"
		: (policyTable = args.scenarioFile.scenarioForm.policyDataOverrideTable);

return `
	CALL ${
		args.ratesBeingUsed == "CURRENT"
			? args.scenarioFile.scenarioForm.assignRatesCurrent
			: args.scenarioFile.scenarioForm.assignRatesProposed
	}(
		'${policyTable}', /* policy_table */
		'RATE', /* rate_table */
		'${args.scenarioFile.scenarioForm.runMode}', /* run_mode */
		'${suffix}', /* suffix */
		false, /* is_duplicates_logged */
		false /* is_logged */
	);
`;
