/* Selecting distinct as there might be duplicates. */
return `
	SELECT DISTINCT table_name
	FROM temp_table_list
	ORDER BY table_name;
`;
