return `
	SELECT *
	FROM prd_bizdb_coml.birst_tool.email_recipient;
`;
