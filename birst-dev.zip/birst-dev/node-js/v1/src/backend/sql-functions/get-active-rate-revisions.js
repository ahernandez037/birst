// Since CMP and UMB are considered separate lines of business in the new BIRST,
// need additional logic below to properly handle CMP & UMB rate revisions,
// i.e., so that they are recognized as being part of the same overall rate
// revision.
let lineOfBusiness = args.scenarioFile.scenarioForm.lineOfBusiness;
if (lineOfBusiness == "CMP" || lineOfBusiness == "UMB") {
	lineOfBusiness = ` IN ('CMP', 'UMB')`;
} else {
	lineOfBusiness = ` = '${args.scenarioFile.scenarioForm.lineOfBusiness}'`;
}

return `
	SELECT
		policy_count,
		exposure_count,
		modified_premium_current,
		modified_premium_proposed,
		impact_amount,
		impact_percent,
		tolerance_lo,
		tolerance_hi,
		in_scope_tables,
		in_scope_bureau_tables,
		scenario_id,
		created_at_utc,
		created_by,
		is_canceled,
		canceled_at_utc,
		canceled_by,
		state,
		line_of_business,
		CASE
			WHEN line_of_business = 'UMB' THEN 'UMB'
			ELSE product
		END AS product,
		version,
		new_date,
		renewal_date,
		available_date,
		adopt_bureau_ind,
		bureau_effective_date,
		query_method,
		inforce_date
	FROM prd_bizdb_coml.public_sandbox.birst_rate_revision
	WHERE
		UPPER(state) = UPPER('${args.scenarioFile.scenarioForm.geoState}')
		AND UPPER(line_of_business) ${lineOfBusiness}
		AND renewal_date = '${args.scenarioFile.scenarioForm.renewalDate}'
		AND is_canceled = false;
`;
