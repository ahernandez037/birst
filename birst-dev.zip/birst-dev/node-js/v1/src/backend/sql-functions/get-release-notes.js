return `
	SELECT *
	FROM prd_bizdb_coml.birst_tool.release_note
	WHERE is_shown_in_ui = true;
`;
