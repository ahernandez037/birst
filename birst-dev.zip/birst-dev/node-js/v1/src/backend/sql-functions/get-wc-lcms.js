// This is used for the Work Comp Gradient AI initiative to loop through all
// available UW companies with their corresponding LCMs.

return `
	SELECT
		rt.state AS geo_state,
		rt.company AS uw_company,
		rt.company_multiplier AS lcm
	FROM
		prd_bizdb_coml.rate_tables.wc_company_multiplier AS rt
		INNER JOIN (
			SELECT
				state,
				company,
				MAX(eff_date) AS eff_date
			FROM prd_bizdb_coml.rate_tables.wc_company_multiplier
			GROUP BY
				state,
				company
		) AS max
			ON rt.state = max.state
			AND rt.company = max.company
			AND rt.eff_date = max.eff_date
	WHERE UPPER(rt.state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}';
`;
