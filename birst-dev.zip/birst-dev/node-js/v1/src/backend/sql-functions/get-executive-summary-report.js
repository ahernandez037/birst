const orderBy =
	args.scenarioFile.scenarioForm.runMode == "VALIDATION"
		? `
			ORDER BY
				state,
				version,
				coverage_id,
				premium_type DESC
		`
		: "";

return `
	SELECT *
	FROM executive_summary
	${orderBy};
`;
