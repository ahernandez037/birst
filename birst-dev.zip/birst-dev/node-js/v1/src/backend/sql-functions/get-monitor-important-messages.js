return `
	SELECT *
	FROM prd_bizdb_coml.public_sandbox.birst_log_node_js
	WHERE
		(
			UPPER(type) IN ('ERROR', 'WARNING')
			OR payload ILIKE 'Forced app quit%'
		)
		AND TO_DATE(created_at_utc) >= DATEADD(DAY, -30, CURRENT_DATE())
	ORDER BY TO_TIMESTAMP(created_at_utc) DESC;
`;
