return `
	SELECT name
	FROM prd_bizdb_coml.birst_tool.initiative
	WHERE
		is_implemented = TRUE
		AND UPPER(state) = '${args.scenarioFile.scenarioForm.geoState.toUpperCase()}';
`;
