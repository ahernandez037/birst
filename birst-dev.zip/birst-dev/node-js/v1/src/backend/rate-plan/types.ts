export interface RatePlan {
	// For products with multiple versions, e.g., Auto & WC. Useful when doing
	// new product launches that require conversion of multiple legacy versions
	//  e.g., Auto Flex.
	version: string;
	ratePlan: string;
	availableAsOf: string;
}
