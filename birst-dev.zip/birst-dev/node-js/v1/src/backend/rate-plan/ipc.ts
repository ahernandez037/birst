import { ipcMain } from "electron";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { ScenarioForm } from "../scenario";
import { displayRatePlan } from "./display";
import { IpcMessage } from "../ipc-handlers";
import { loadRatePlanCurrent } from "./load";
import { scenarioFile } from "../scenario-file";
import { Emoji, addConsoleMessage } from "../console-message";

export const ratePlanIpcHandler = (): void => {
	ipcMain.on(IpcMessage.GetRatePlanCurrent, async (_event, payload) => {
		try {
			const scenarioForm: ScenarioForm = JSON.parse(payload);
			const ratePlan = await loadRatePlanCurrent(scenarioForm);

			if (ratePlan.length === 0) {
				addConsoleMessage({ text: `${Emoji.Warning} No rate plans found.` });
			} else {
				displayRatePlan(scenarioForm, ratePlan);
			}
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
			});
		} finally {
			mainWindow.webContents.send(IpcMessage.GetRatePlanCurrent);
		}
	});

	ipcMain.on(IpcMessage.GetRatePlanUsed, async () => {
		try {
			// This feature only works for scenarios created by v1.3.0 or newer.
			const majorAppVersion = scenarioFile.appVersion.split(".")[0];
			const minorAppVersion = scenarioFile.appVersion.split(".")[1];

			if (!scenarioFile.files.scenarioFile) {
				addConsoleMessage({
					text: `${Emoji.Warning} Please load an existing scenario file or run this scenario first.`,
				});
			} else if (
				Number(majorAppVersion) < 1 ||
				(Number(majorAppVersion) === 1 && Number(minorAppVersion) < 3)
			) {
				addConsoleMessage({
					text: `${Emoji.StopSign} Sorry, this feature is only available for scenarios created by v1.3.0 or newer of the BIRST application ${Emoji.SadFace}`,
				});
			} else if (scenarioFile.ratePlan.length === 0) {
				addConsoleMessage({
					text: `${Emoji.Warning} Rate plan information not found. Have you already ran this scenario?`,
				});
			} else {
				addConsoleMessage({
					text: "Rate plan used to on-level the current premium:",
				});
				displayRatePlan(scenarioFile.scenarioForm, scenarioFile.ratePlan);
			}
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
			});
		} finally {
			mainWindow.webContents.send(IpcMessage.GetRatePlanUsed);
		}
	});
};
