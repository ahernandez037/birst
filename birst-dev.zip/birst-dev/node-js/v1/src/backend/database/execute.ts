import * as sf from "snowflake-sdk";
import { connection } from "./connect";

export const execute = (args: {
	sqlText: string;
	binds?: sf.Binds;
}): Promise<[sf.Statement, unknown[] | undefined]> =>
	new Promise((resolve, reject) => {
		connection?.execute({
			sqlText: args.sqlText,
			binds: args.binds,
			complete: (err, stmt, rows) => {
				if (err) {
					reject(err);
					return;
				}

				resolve([stmt, rows]);
			},
		});
	});
