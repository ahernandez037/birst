import { ipcMain } from "electron";
import { IpcMessage } from "../ipc-handlers";
import { loadExecutiveSummary } from "./load";
import { prefillScenarioFile } from "../scenario-file";

export const executiveSummaryIpcHandler = (): void => {
	ipcMain.handle(IpcMessage.GetExecutiveSummary, async (_event, payload) => {
		try {
			prefillScenarioFile(JSON.parse(payload));
			return JSON.stringify(await loadExecutiveSummary());
		} catch (err) {
			return null;
		}
	});
};
