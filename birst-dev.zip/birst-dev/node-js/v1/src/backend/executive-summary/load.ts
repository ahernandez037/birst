import { join } from "path";
import { app } from "electron";
import { DateTime } from "luxon";
import { execute } from "../database";
import { userSettings } from "../user-settings";
import { scenarioFile } from "../scenario-file";
import { ActiveExecutiveSummary } from "./types";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export const loadExecutiveSummary = async (): Promise<ActiveExecutiveSummary[]> => {
	try {
		addConsoleMessage({
			text: "Loading executive summary...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingExecutiveSummary,
		});

		const activeExecutiveSummaries: ActiveExecutiveSummary[] = [];
		const rs = await queryActiveRateRevisions();

		if (rs && rs?.length > 0) {
			for (const r of rs as Record<string, unknown>[]) {
				activeExecutiveSummaries.push({
					policyCount: Number(r["POLICY_COUNT"]).toLocaleString("en-US"),
					exposureCount: Number(r["EXPOSURE_COUNT"]).toLocaleString("en-US"),
					modifiedPremiumCurrent: Number(
						Number(r["MODIFIED_PREMIUM_CURRENT"]).toFixed(0),
					).toLocaleString("en-US"),
					modifiedPremiumProposed: Number(
						Number(r["MODIFIED_PREMIUM_PROPOSED"]).toFixed(0),
					).toLocaleString("en-US"),
					impactAmount: Number(Number(r["IMPACT_AMOUNT"]).toFixed(0)).toLocaleString(
						"en-US",
					),
					impactPercent: String((Number(r["IMPACT_PERCENT"]) * 100).toFixed(2)) + "%",
					toleranceLo: String((Number(r["TOLERANCE_LO"]) * 100).toFixed(2)) + "%",
					toleranceHi: String((Number(r["TOLERANCE_HI"]) * 100).toFixed(2)) + "%",
					inScopeTables: String(r["IN_SCOPE_TABLES"]).split(",").join(", "),
					inScopeBureauTables: String(r["IN_SCOPE_BUREAU_TABLES"]).split(",").join(", "),
					scenarioId: String(r["SCENARIO_ID"]),
					createdAtUtc: String(r["CREATED_AT_UTC"]),
					createdBy: String(r["CREATED_BY"]),
					isCanceled: r["IS_CANCELED"] as boolean,
					canceledAtUtc: String(r["CANCELED_AT_UTC"]),
					canceledBy: String(r["CANCELED_BY"]),
					state: String(r["STATE"]),
					lineOfBusiness: String(r["LINE_OF_BUSINESS"]),
					product: String(r["PRODUCT"]),
					version: String(r["VERSION"]),
					newDate: DateTime.fromISO(String(r["NEW_DATE"])).toLocaleString(
						DateTime.DATE_SHORT,
					),
					renewalDate: DateTime.fromISO(String(r["RENEWAL_DATE"])).toLocaleString(
						DateTime.DATE_SHORT,
					),
					availableDate: DateTime.fromISO(String(r["AVAILABLE_DATE"])).toLocaleString(
						DateTime.DATE_SHORT,
					),
					adoptBureauInd: r["ADOPT_BUREAU_IND"] as boolean,
					bureauEffectiveDate: String(r["BUREAU_EFFECTIVE_DATE"]),
					queryMethod: String(r["QUERY_METHOD"]),
					inforceDate: DateTime.fromISO(String(r["INFORCE_DATE"])).toLocaleString(
						DateTime.DATE_SHORT,
					),
				});
			}
		}

		return activeExecutiveSummaries;
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingExecutiveSummary);
	}
};

const queryActiveRateRevisions = async (): Promise<unknown[] | undefined> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetActiveRateRevisions),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioFile: scenarioFile,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });
		return rs;
	} catch (err) {
		throw err;
	}
};
