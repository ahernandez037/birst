export interface ExecutiveSummary {
	isRateRevisionCreated: boolean;
	rateRevisionInitiatedByEmail: string;
	policyCount: number | null;
	exposureCount: number | null;
	modifiedPremiumCurrent: number | null;
	modifiedPremiumProposed: number | null;
	impactAmount: number | null;
	impactPercent: number | null;
	toleranceLo: number | null;
	toleranceHi: number | null;
	inScopeTables: string;
	inScopeBureauTables: string;
}

export interface ActiveExecutiveSummary {
	scenarioId: string;
	createdAtUtc: string;
	createdBy: string;
	isCanceled: boolean;
	canceledAtUtc: string;
	canceledBy: string;
	state: string;
	lineOfBusiness: string;
	product: string;
	version: string;
	newDate: string;
	renewalDate: string;
	availableDate: string;
	adoptBureauInd: boolean;
	bureauEffectiveDate: string;
	queryMethod: string;
	inforceDate: string;
	policyCount: string;
	exposureCount: string;
	modifiedPremiumCurrent: string;
	modifiedPremiumProposed: string;
	impactAmount: string;
	impactPercent: string;
	toleranceLo: string;
	toleranceHi: string;
	inScopeTables: string;
	inScopeBureauTables: string;
}
