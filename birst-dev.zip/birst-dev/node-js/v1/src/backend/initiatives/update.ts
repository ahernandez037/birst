import { join } from "path";
import { app } from "electron";
import { execute } from "../database";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export const updateInitiativeTable = async (
	rateRevisionStatus: "INITIATED" | "CANCELED",
): Promise<void> => {
	if (scenarioFile.scenarioForm.isRstGlSalesInitiative && rateRevisionStatus === "INITIATED") {
		addConsoleMessage({
			text: "Updating initiatives...",
			hasTimer: true,
			timerId: ConsoleMessageId.UpdatingInitiatives,
		});

		try {
			const dynamicJsFunction = (
				await loadDynamicJsFunction(
					join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.UpdateInitiative),
				)
			)[0];

			const sqlText = String(
				executeDynamicJsFunction({
					dynamicJsFunction,
					functionArguments: {
						isProduction: app.isPackaged,
						scenarioFile,
						initiativeName: "RST-GL-SALES",
						isInitiativeImplemented: true,
					},
				}),
			);

			await execute({ sqlText });
		} catch (err) {
			throw err;
		} finally {
			stopConsoleMessageTimer(ConsoleMessageId.UpdatingInitiatives);
		}
	}

	if (scenarioFile.scenarioForm.isRstGlSalesInitiative && rateRevisionStatus === "CANCELED") {
		addConsoleMessage({
			text: "Updating initiatives...",
			hasTimer: true,
			timerId: ConsoleMessageId.UpdatingInitiatives,
		});

		try {
			const dynamicJsFunction = (
				await loadDynamicJsFunction(
					join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.UpdateInitiative),
				)
			)[0];

			const sqlText = String(
				executeDynamicJsFunction({
					dynamicJsFunction,
					functionArguments: {
						isProduction: app.isPackaged,
						scenarioFile,
						initiativeName: "RST-GL-SALES",
						isInitiativeImplemented: false,
					},
				}),
			);

			await execute({ sqlText });
		} catch (err) {
			throw err;
		} finally {
			stopConsoleMessageTimer(ConsoleMessageId.UpdatingInitiatives);
		}
	}
};
