export interface WorkCompLCM {
	geoState: string;
	uwCompany: string;
	lcm: number;
}
