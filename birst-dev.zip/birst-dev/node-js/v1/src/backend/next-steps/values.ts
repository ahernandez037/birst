import { join } from "path";
import { app } from "electron";
import { NextSteps } from "./types";
import { ScenarioForm } from "../scenario";
import { userSettings } from "../user-settings";
import { rateRevision } from "../rate-revision";
import { scenarioFile } from "../scenario-file";
import { getFormattedDates } from "../utilities";
import { executeDynamicJsFunction, loadDynamicJsFunction } from "../dynamic-js";

export const getNextStepsFunctionValues = async (
	nextStepsFilename: string,
	scenarioForm: ScenarioForm,
): Promise<NextSteps> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.nextStepsFunctionsDirectory, nextStepsFilename),
			)
		)[0];

		return executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isProduction: app.isPackaged,
				scenarioForm: scenarioForm,
				scenarioFile: scenarioFile,
				rateRevisionStatus: rateRevision,
				formattedDates: getFormattedDates(),
			},
		}) as NextSteps;
	} catch (err) {
		throw err;
	}
};
