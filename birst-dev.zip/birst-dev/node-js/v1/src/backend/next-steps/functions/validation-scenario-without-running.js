const htmlContent = `
	<p>
	It looks like you entered all needed information, but you haven't ran the
	scenario yet. Based on this, the recommended next steps are:
	</p>
	<ul>
	<li>
		Run the scenario by clicking on <b>Scenario</b> and then
		<b>Run</b>.
	</li>
	</ul>
	<p>
	For more information, please refer to the user's guide, which is found under
	the <b>Support</b> tab.
	</p>
`;

return { htmlContent, modalWidth: null, modalHeight: null, buttons: [] };
