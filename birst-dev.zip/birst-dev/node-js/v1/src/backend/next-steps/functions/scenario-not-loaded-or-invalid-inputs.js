const htmlContent = `
	<p>
	It looks like you haven't loaded an existing scenario or haven't entered all
	necessary fields in order to run a scenario. Based on this, the
	recommended next steps are:
	</p>
	<ul>
	<li>
		Load an existing scenario file by clicking on <b>Scenario</b> and then
		<b>Load</b>, or
	</li>
	<li>If starting a new scenario, finish entering all scenario inputs.</li>
	</ul>
	<p>
	For more information, please refer to the user's guide, which is found under
	the <b>Support</b> tab.
	</p>
`;

return { htmlContent, modalWidth: null, modalHeight: null, buttons: [] };
