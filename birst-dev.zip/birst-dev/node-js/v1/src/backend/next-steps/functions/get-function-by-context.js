const scenarioNotLoadedOrInvalidInputs = () => {
	if (!args.isScenarioFormValid) {
		return "scenario-not-loaded-or-invalid-inputs.js";
	}

	return null;
};

const activeRateRevisionForProduct = () => {
	if (args.rateRevision.createdBy && !args.rateRevision.isCanceled && !args.isUserFitMember) {
		return "active-rate-revision-for-product.js";
	}

	return null;
};

const activeRateRevisionForFit = () => {
	if (args.rateRevision.createdBy && !args.rateRevision.isCanceled && args.isUserFitMember) {
		return "active-rate-revision-for-fit.js";
	}

	return null;
};

const canceledRateRevision = () => {
	if (args.rateRevision.isCanceled) {
		return "canceled-rate-revision.js";
	}

	return null;
};

const rateChangeScenarioWithoutRunning = () => {
	if (
		args.scenarioForm.runMode === "RATE-CHANGE" &&
		args.isScenarioFormValid &&
		args.scenarioFile.rateHistory.length === 0
	) {
		return "rate-change-scenario-without-running.js";
	}

	return null;
};

const validationScenarioWithoutRunning = () => {
	if (
		["ON-LEVEL", "VALIDATION"].includes(args.scenarioForm.runMode) &&
		args.isScenarioFormValid &&
		!args.scenarioFile.createdBy
	) {
		return "validation-scenario-without-running.js";
	}

	return null;
};

const validationScenarioAlreadyRan = () => {
	if (
		["ON-LEVEL", "VALIDATION"].includes(args.scenarioForm.runMode) &&
		args.isScenarioFormValid &&
		args.scenarioFile.createdBy
	)
		return "validation-scenario-already-ran.js";

	return null;
};

const rateChangeScenarioWithoutRateRevision = () => {
	if (
		args.scenarioFile.scenarioForm.runMode == "RATE-CHANGE" &&
		args.scenarioFile.rateHistory.length > 0 &&
		args.isScenarioFormValid &&
		!args.rateRevision.createdBy
	) {
		return "rate-change-scenario-without-rate-revision.js";
	}

	return null;
};

const functionsByContext = [
	activeRateRevisionForProduct,
	activeRateRevisionForFit,
	canceledRateRevision,
	rateChangeScenarioWithoutRunning,
	rateChangeScenarioWithoutRateRevision,
	validationScenarioWithoutRunning,
	validationScenarioAlreadyRan,
	scenarioNotLoadedOrInvalidInputs,
];

for (const functionByContext of functionsByContext) {
	const functionFile = functionByContext();

	if (functionFile) {
		return functionFile;
	}
}

return "default-message.js";
