/*
This file is no longer used. Leaving behind to prevent error message when app loads.
Should be OK to delete once everyone is on the latest app version.
*/

const htmlContent = "";

return { htmlContent, modalWidth: null, modalHeight: null, buttons: [], title: "" };
