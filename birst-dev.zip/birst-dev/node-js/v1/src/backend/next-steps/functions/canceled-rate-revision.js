const htmlContent = `
	<p>
	It looks like the rate revision has been canceled. Based on this, the recommended next steps are:
	</p>
	<ul>
	<li>
		If a rate revision is still needed, create a new scenario by clicking on <b>Scenario</b> and then on <b>New</b>
	</li>
	</ul>
	<p>
	For more information, please refer to the user's guide, which is found under
	the <b>Support</b> tab.
	</p>
`;

return { htmlContent, modalWidth: null, modalHeight: null, buttons: [] };
