const geoState = args.scenarioFile.scenarioForm.geoState;
const lineOfBusiness = args.scenarioFile.scenarioForm.lineOfBusiness;

const product =
	args.scenarioFile.scenarioForm.product === "N/A" ? "" : args.scenarioFile.scenarioForm.product;

const version =
	args.scenarioFile.scenarioForm.version === "N/A" ? "" : args.scenarioFile.scenarioForm.version;

const newDate = args.formattedDates.newDate;
const renewalDate = args.formattedDates.renewalDate;
const availableDate = args.formattedDates.availableDate;

const impactAmount =
	"$" + Number(args.scenarioFile.executiveSummary.impactAmount).toLocaleString("en-US");

const impactPercent =
	String((Number(args.scenarioFile.executiveSummary.impactPercent) * 100).toFixed(2)) + "%";

/* Replace second occurrence of "BIRST". Need to skip 1st occurrence due to
  it being part of the parent directory "BIRST_Rate_Revision". */
let occurrence = 0;
const directory = args.scenarioFile.scenarioForm.scenarioDirectory.replace(/\\BIRST/g, (match) =>
	++occurrence === 2 ? "" : match,
);

const htmlContent = `
	<p>
	It looks like the rate revision has been initiated. Based on this, the
	recommended next steps are:
	</p>
	<p><b>If all necessary approvals have been captured in Signavio:</b></p>
	<ul>
	<li>
		Save the rates and generate the output files by clicking on <b>Rate Revision</b> and then on <b>Save Rates & Generate Output</b>
	</li>
	</ul>
	<p><b>If all necessary approvals have <i>NOT</i> been captured in Signavio:</b></p>
	<ul>
	<li>Do NOT proceed. Once all necessary approvals are complete, the FIT Manager will be notified by Signavio to assign a FIT Analyst to the rate revision.</li>
	<li>The assigned FIT Analyst will then be notified by Signavio to complete filing (if applicable) and implementation tasks.</li>
	</ul>
	<table
	border="1"
	cellpadding="4"
	cellspacing="0"
	style="width: auto; font-size: small"
	>
	<tbody>
		<tr>
		<td>State</td>
		<td>${geoState}</td>
		</tr>
		<tr>
		<td>Line of Business</td>
		<td>${lineOfBusiness}</td>
		</tr>
		<tr>
		<td>Product</td>
		<td>${product}</td>
		</tr>
		<tr>
		<td>Version</td>
		<td>${version}</td>
		</tr>
		<tr>
		<td>New Business Date</td>
		<td>${newDate}</td>
		</tr>
		<tr>
		<td>Renewal Date</td>
		<td>${renewalDate}</td>
		</tr>
		<tr>
		<td>Available Date</td>
		<td>${availableDate}</td>
		</tr>
		<tr>
		<td>Impact Amount</td>
		<td>${impactAmount}</td>
		</tr>
		<tr>
		<td>Impact Percent</td>
		<td>${impactPercent}</td>
		</tr>
		<tr>
		<td>Scenario ID</td>
		<td>${args.scenarioFile.scenarioForm.scenarioId}</td>
		</tr>
		<tr>
		<td>Revision Directory</td>
		<td>${directory}</td>
		</tr>
	</tbody>
	</table>
	<p>
	For more information, please refer to the user's guide, which is found under
	the <b>Support</b> tab.
	</p>
`;

return {
	htmlContent,
	modalWidth: null,
	modalHeight: null,
	buttons: [
		{
			text: "Open Directory",
			type: "DIRECTORY",
			url: directory,
		},
		{
			text: "Open Signavio",
			type: "WEBSITE",
			url: "workflow-us.signavio.com/farmers/cases/tasks/inbox",
		},
	],
};
