import { ipcMain } from "electron";
import { IpcMessage } from "./types";
import { createEmail } from "../email";
import { loadRatesFile } from "../rates-file";
import { saveRateHistory } from "../rate-history";
import { createFitExhibits } from "../fit-exhibits";
import { Emoji, addConsoleMessage } from "../console-message";

export const devTestIpcHandler = (): void => {
	ipcMain.on(IpcMessage.DevTestCreateEmail, (_event, payload) => {
		createEmail({
			emailTrigger: payload[0],
			scenarioForm: JSON.parse(payload[1]),
		});
	});

	ipcMain.on(IpcMessage.DevTestSaveRateHistory, async () => {
		try {
			addConsoleMessage({
				text: `${Emoji.Warning} IMPORTANT: This saves to the table used in production for actuarial indications. Please make sure to delete from the table if this was done for testing purposes only.`,
			});

			await saveRateHistory();
			addConsoleMessage({ text: "Finished saving the rate history." });
		} catch (err) {
			addConsoleMessage({ text: String(err) });
		}
	});

	ipcMain.on(IpcMessage.DevTestCreateFitExhibits, async () => {
		try {
			await loadRatesFile();
			await createFitExhibits(true);
			addConsoleMessage({ text: "Finished creating the FIT exhibits." });
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });
		}
	});
};
