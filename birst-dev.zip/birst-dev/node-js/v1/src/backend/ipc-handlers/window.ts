import { ipcMain } from "electron";
import { IpcMessage } from "./types";
import {
	MAIN_WINDOW_WIDTH,
	MAIN_WINDOW_HALF_WIDTH,
	mainWindow,
	numberOfMainWindowColumns,
	updateNumberOfMainWindowColumns,
	isSmallScreen,
} from "../main";

export const windowIpcHandler = (): void => {
	ipcMain.on(IpcMessage.HideConsole, () => {
		// Don't change window size if already hidden.
		if (numberOfMainWindowColumns === 1) return;
		const [_, height] = mainWindow.getSize();
		mainWindow.setSize(MAIN_WINDOW_HALF_WIDTH, height);
		updateNumberOfMainWindowColumns(1);
	});

	ipcMain.on(IpcMessage.ShowConsole, () => {
		// Don't change window size if already showing.
		if (numberOfMainWindowColumns === 2) return;

		if (isSmallScreen) {
			mainWindow.maximize();
		} else {
			const [width, height] = mainWindow.getSize();
			if (width < MAIN_WINDOW_WIDTH) mainWindow.setSize(MAIN_WINDOW_WIDTH, height);
		}

		updateNumberOfMainWindowColumns(2);
	});
};
