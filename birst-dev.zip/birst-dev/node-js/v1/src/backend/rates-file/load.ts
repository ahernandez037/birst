import * as xlsx from "xlsx";
import { USER_ID } from "../user-settings";
import { resetRatesFile, tablesForUpload, updateWorkbook, workbook } from "./create";
import { doesRatesFileExist, getRatesFileAbsoluteFilepath, isRatesFileOpen } from "./file";
import { ConsoleMessageId, addConsoleMessage, stopConsoleMessageTimer } from "../console-message";
import {
	scenarioFile,
	saveScenarioFile,
	updateScenarioFileExecutiveSummaryInScopeTables,
} from "../scenario-file";
import {
	TableListRow,
	InScopeRateTable,
	TABLES_WITHOUT_NB_EFF_DATE,
	TABLES_WITHOUT_WRITTEN_DATE,
} from "./types";

export const loadRatesFile = async (): Promise<void> => {
	if (!doesRatesFileExist() || getRatesFileAbsoluteFilepath() === ".") {
		throw new Error("Unable to locate the rates file for the given scenario inputs.");
	}

	if (await isRatesFileOpen()) {
		throw new Error(
			"The rates file is currently open. Please close the file before proceeding.",
		);
	}

	try {
		addConsoleMessage({
			text: "Loading rates file...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingRatesFile,
		});

		resetRatesFile();

		updateWorkbook(
			xlsx.readFile(getRatesFileAbsoluteFilepath(), {
				bookVBA: true, // To allow macros
				cellDates: true, // To convert date from sequential serial number to ISO string
			}),
		);

		await prepareTablesForUpload(new Date());
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingRatesFile);
	}
};

const prepareTablesForUpload = async (uploadDate: Date): Promise<void> => {
	const inScopeTables = getInScopeRateTables();
	let records: Record<string, unknown>[];

	for (const table of inScopeTables) {
		const worksheet = workbook.Sheets[table.ratesFileTableName];

		// Using "defval = null" option to ensure columns with all null values
		// are included.
		records = xlsx.utils.sheet_to_json(getWorksheetWithoutScratchAreaColumns(worksheet), {
			defval: null,
		});

		tablesForUpload.push({
			tableName: table.fullTableName,
			records: prepareRecordsForUpload(table.fullTableName, records, uploadDate),
		});
	}

	// Do not update the scenario file if the rate revision has already been
	// created.
	if (!scenarioFile.executiveSummary.isRateRevisionCreated) {
		updateScenarioFileExecutiveSummaryInScopeTables(inScopeTables);
		await saveScenarioFile();
	}
};

/**
 * Removes any columns that don't have auto filters as these are "scratch area"
 * columns and only actual rate table columns have auto filters applied. Need
 * to remove the scratch area columns because if we don't they will be attempted
 * to upload to the database which would result in errors.
 */
export const getWorksheetWithoutScratchAreaColumns = (
	worksheet: xlsx.WorkSheet,
): xlsx.WorkSheet => {
	// Ranges are something like "A1:F1", the following code extracts the column
	// letter for the starting and ending columns that have auto filters applied.
	// Using "A1:F1" as an example in the comments below.

	// Split "A1:F1" into array of two strings, first element would be "A1" and
	// second element "F1".
	const excelRangeElements = worksheet["!autofilter"]?.ref.split(":");

	// Remove any numbers, leaving only "A" and "F". Also, we only care about
	// the ending column, i.e., element 1 from the array of strings.
	const lastColumnWithAutoFilter = excelRangeElements
		? excelRangeElements[1].replace(/[0-9]/g, "")
		: "";

	// Create new worksheet that only contains columns that have auto filters,
	// i.e., only columns that are actually part of the rate table, not any
	// "scratch area" columns.
	const filteredWorksheet: Record<string, any> = {};

	for (const [key, value] of Object.entries(worksheet)) {
		if (key.replace(/[0-9]/g, "") <= lastColumnWithAutoFilter) filteredWorksheet[key] = value;
	}

	return filteredWorksheet;
};

export const getInScopeRateTables = (): InScopeRateTable[] => {
	const worksheet = workbook.Sheets["table_list"];
	const tables: Record<string, unknown>[] = xlsx.utils.sheet_to_json(worksheet);

	return tables
		.filter((record) => String(record["In Scope"]).toUpperCase() === "X")
		.map((record) => ({
			fullTableName: String(record["Full Table Name"]),
			ratesFileTableName: String(record["Table Name"]),
		}));
};

/**
 * Remove "Scratch Area" cells, which are cells that are open for users to use
 * freely to enter their own calculations or for any other reason. Since this
 * data is not part of the actual rate table, need to remove it from the data
 * that will be uploaded to the database. Also drops keys/fields that are not
 * needed, such as the ID field, the "_CURRENT" rate field, etc., and does
 * some other preparation steps such as removed the "_PROPOSED" suffix from
 * the proposed rate fields and adds the upload user and upload timestamp
 * fields.
 */
const prepareRecordsForUpload = (
	tableName: string,
	records: Record<string, unknown>[],
	uploadDate: Date,
): Record<string, unknown>[] => {
	const newRecords: Record<string, unknown>[] = [];

	for (const record of records) {
		const newRecord: Record<string, unknown> = {};

		for (const key of Object.keys(record)) {
			if (isKeyIncluded(key)) newRecord[removeProposedWording(key)] = record[key];
		}

		// Redesigned CMP raters.
		if (
			scenarioFile.scenarioForm.lineOfBusiness === "CMP" &&
			["HAB", "REA", "ROS", "RST"].includes(scenarioFile.scenarioForm.product)
		) {
			newRecord["NEW_DATE"] = scenarioFile.scenarioForm.newDate;
			newRecord["RENEWAL_DATE"] = scenarioFile.scenarioForm.renewalDate;
			newRecord["AVAILABLE_DATE"] = scenarioFile.scenarioForm.availableDate;
		}
		// Legacy WC rater.
		else if (scenarioFile.scenarioForm.lineOfBusiness === "WC") {
			newRecord["EFF_DATE"] = scenarioFile.scenarioForm.renewalDate;
		}
		// All other legacy raters.
		else {
			newRecord["RB_EFF_DATE"] = scenarioFile.scenarioForm.renewalDate;

			// Only add these properties if they exist in the rate tables.
			if (!TABLES_WITHOUT_NB_EFF_DATE.includes(tableName.toUpperCase())) {
				newRecord["NB_EFF_DATE"] = scenarioFile.scenarioForm.newDate;
			}

			if (!TABLES_WITHOUT_WRITTEN_DATE.includes(tableName.toUpperCase())) {
				newRecord["WRITTEN_DATE"] = scenarioFile.scenarioForm.availableDate;
			}
		}

		newRecords.push(newRecord);
	}

	return addProperty(
		addProperty(getOnlyValidRecords(newRecords), "UPLOAD_USER", USER_ID),
		"UPLOAD_DATE",
		uploadDate,
	);
};

/**
 * Used to determine if the key (column/field) should be included in the data
 * to be uploaded to the database.
 */
const isKeyIncluded = (key: string): boolean => !isExactKeyMatch(key) && !isSimilarKeyMatch(key);

const isExactKeyMatch = (key: string): boolean => {
	const exactKeys = ["ID"];

	for (const exactKey of exactKeys) {
		if (key === exactKey) return true;
	}

	return false;
};

const isSimilarKeyMatch = (key: string): boolean => {
	const similarKeys = ["__EMPTY", "_CURRENT", "_PCT_CHG"];

	for (const similarKey of similarKeys) {
		if (key.includes(similarKey)) return true;
	}

	return false;
};

const removeProposedWording = (key: string): string => {
	if (key.includes("_PROPOSED")) return key.substring(0, key.indexOf("_PROPOSED"));
	return key;
};

/**
 * Used to add new properties to each record, e.g., the UPLOAD_USER and
 * UPLOAD_DATE properties.
 */
const addProperty = (
	records: Record<string, unknown>[],
	key: string,
	value: unknown,
): Record<string, unknown>[] => {
	const newRecords: Record<string, unknown>[] = [];

	for (const record of records) {
		const newRecord: Record<string, unknown> = {};

		for (const [key, value] of Object.entries(record)) {
			newRecord[key] = value;
		}

		newRecord[key] = value;
		newRecords.push(newRecord);
	}

	return newRecords;
};

/**
 * Performs additional clean up that needs to be done because there could be
 * "Scratch Area" cells below the last row of rates. Also, because using the
 * "defval = null" option when calling "xlsx.utils.sheet_to_json" causes
 * unneeded records to be generated. However, need to use this option
 * otherwise columns with all missing data (such as PAS_TABLE_NUM in some
 * cases), will result in the column not being included at all. Using the
 * 'STATE' column to determine if the record should be included. If 'STATE'
 * is truthy, i.e., populated, then include, otherwise exclude.
 */
const getOnlyValidRecords = (records: Record<string, unknown>[]): Record<string, unknown>[] =>
	records.filter((record) => record["STATE"]);

/**
 * Checks to see if any of the rate tables have rates effective on or after the
 * scenario renewal date. If they do, this is an indication that this is most
 * likely a cancel/re-run and the previously saved rates have not yet been
 * deleted. In this case, hard stop user from continuing and advise to reach out
 * to have the rates deleted.
 */
export const checkForExistingRates = async (): Promise<string[]> => {
	try {
		const tablesWithExistingRates: string[] = [];
		await loadRatesFile();
		const tableList: TableListRow[] = xlsx.utils.sheet_to_json(workbook.Sheets["table_list"]);

		for (const table of tableList) {
			if (table["RB Effective Date"] >= new Date(scenarioFile.scenarioForm.renewalDate)) {
				tablesWithExistingRates.push(table["Full Table Name"]);
			}
		}

		return tablesWithExistingRates;
	} catch (err) {
		throw err;
	}
};
