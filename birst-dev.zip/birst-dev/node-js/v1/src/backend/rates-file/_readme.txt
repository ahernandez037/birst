Directory:
	ignored-fields
Purpose:
	Contains JSON files used by Node.js to determine which table columns to ignore when creating the rates file. For example, the upload_user and upload_date columns are ignored, i.e., they will not be included in the rates file.

Directory:
	order-by
Purpose:
	Contains JSON files used by Node.js to inject the ORDER BY clause into the SQL queries used to query the rate tables. These strings should be valid SQL ORDER BY syntax.

Directory:
	rate-fields
Purpose:
	Contains JSON files used by Node.js to determine which table columns should be open for proposed rates. General field names may be used, i.e., for column names that are common across rate tables. Also, unique fields can be included per individual rate table.
