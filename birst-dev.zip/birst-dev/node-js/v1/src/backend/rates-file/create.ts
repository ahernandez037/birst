import { join } from "path";
import * as xlsx from "xlsx";
import { DateTime } from "luxon";
import { readFile } from "fs-extra";
import { parse } from "comment-json";
import { spawn } from "child_process";
import { MessageBoxOptions, app, dialog } from "electron";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { execute } from "../database";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { getRatesFileAbsoluteFilepath } from "./file";
import { runBirstFileFormatter } from "../utilities/ancillary";
import { addScenarioDetailsToExcelWorkbook } from "../scenario/details";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer,
} from "../console-message";
import {
	RateTable,
	RateFields,
	TargetCount,
	RateTableOrderBy,
	RateTableForUpload,
	ApplicableRateTable,
	SPECIAL_WC_TABLES,
	RATES_FILE_ORDER_BY_FILENAME,
	RATES_FILE_RATE_FIELDS_FILENAME,
	RATES_FILE_IGNORED_FIELDS_FILENAME,
} from "./types";
import { waitUntilFileClosed } from "../utilities";

export let workbook: xlsx.WorkBook;
export let worksheet: xlsx.WorkSheet;
export let allRateTables: RateTable[] = [];
export let applicableRateTables: ApplicableRateTable[] = [];
export let tablesForUpload: RateTableForUpload[] = [];
export let targetCounts: TargetCount[] = [];
export let changedTargetCounts: TargetCount[] = [];
export let ignoredFields: string[] = [];
export let transformedTable: Record<string, unknown>[] = [];
export let rateTableOrderBy: RateTableOrderBy[] = [];
export let rateFields: RateFields;
export let targetCount: TargetCount;
export let changedTargetCount: TargetCount;
let transformedTableColumns: Record<string, unknown>;
let rateColumnCount = 0;

export const createRatesFile = async (): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Creating rates file...",
			hasTimer: true,
			timerId: ConsoleMessageId.CreatingRatesFile,
		});
		workbook = xlsx.utils.book_new();
		addScenarioDetailsToExcelWorkbook(workbook);
		xlsx.utils.book_append_sheet(workbook, xlsx.utils.aoa_to_sheet([]), "table_list");
		await loadRateTableIgnoredFields();
		await loadRateTableOrderBy();
		await loadRateFields();
		await getRateTableList();
		await loadRateTables();
		updateRateTableListWorksheet();
		const tablesWithExistingRates = checkForExistingRates();
		if (tablesWithExistingRates.length > 0) showWarningExistingRates(tablesWithExistingRates);
		await xlsx.writeFile(workbook, getRatesFileAbsoluteFilepath(), {
			bookType: "xlsx",
			compression: true,
		});
		stopConsoleMessageTimer(ConsoleMessageId.CreatingRatesFile);
		// Added wait since shared drives can be slow to save/close files.
		await waitUntilFileClosed(getRatesFileAbsoluteFilepath());

		addConsoleMessage({
			text: "Applying formatting...",
			hasTimer: true,
			timerId: ConsoleMessageId.ApplyingExcelFormatting,
		});
		await runBirstFileFormatter("RATES-FILE", getRatesFileAbsoluteFilepath());
		stopConsoleMessageTimer(ConsoleMessageId.ApplyingExcelFormatting);
		// Added wait since shared drives can be slow to save/close files.
		await waitUntilFileClosed(getRatesFileAbsoluteFilepath());

		addConsoleMessage({
			text: "Evaluating formulas...",
			hasTimer: true,
			timerId: ConsoleMessageId.EvaluatingExcelFormulas,
		});
		await evaluateExcelFormulas();
		stopConsoleMessageTimer(ConsoleMessageId.EvaluatingExcelFormulas);

		addConsoleMessage({ text: "Finished creating the rates file." });
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CreatingRatesFile);
		stopConsoleMessageTimer(ConsoleMessageId.ApplyingExcelFormatting);
		stopConsoleMessageTimer(ConsoleMessageId.EvaluatingExcelFormulas);
		throw err;
	}
};

const loadRateTableIgnoredFields = async (): Promise<void> => {
	try {
		const lobAndProduct = `${scenarioFile.scenarioForm.lineOfBusiness}${
			scenarioFile.scenarioForm.product ? "-" + scenarioFile.scenarioForm.product : ""
		}`;

		const parsedJson: unknown = parse(
			(
				await readFile(
					join(
						userSettings.ratesFileIgnoredFieldsDirectory,
						RATES_FILE_IGNORED_FIELDS_FILENAME[
							lobAndProduct as keyof typeof RATES_FILE_IGNORED_FIELDS_FILENAME
						],
					),
				)
			).toString(),
		);

		ignoredFields = parsedJson as string[];
	} catch (err) {
		throw err;
	}
};

const loadRateTableOrderBy = async (): Promise<void> => {
	try {
		const lobAndProduct = `${scenarioFile.scenarioForm.lineOfBusiness}${
			scenarioFile.scenarioForm.product ? "-" + scenarioFile.scenarioForm.product : ""
		}`;

		const parsedJson: unknown = parse(
			(
				await readFile(
					join(
						userSettings.ratesFileOrderByDirectory,
						RATES_FILE_ORDER_BY_FILENAME[
							lobAndProduct as keyof typeof RATES_FILE_ORDER_BY_FILENAME
						],
					),
				)
			).toString(),
		);

		rateTableOrderBy = parsedJson as RateTableOrderBy[];
	} catch (err) {
		throw err;
	}
};

const loadRateFields = async (): Promise<void> => {
	try {
		const lobAndProduct = `${scenarioFile.scenarioForm.lineOfBusiness}${
			scenarioFile.scenarioForm.product ? "-" + scenarioFile.scenarioForm.product : ""
		}`;

		const parsedJson: unknown = parse(
			(
				await readFile(
					join(
						userSettings.ratesFileRateFieldsDirectory,
						RATES_FILE_RATE_FIELDS_FILENAME[
							lobAndProduct as keyof typeof RATES_FILE_RATE_FIELDS_FILENAME
						],
					),
				)
			).toString(),
		);

		rateFields = parsedJson as RateFields;
	} catch (err) {
		throw err;
	}
};

const getRateTableList = async (): Promise<void> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetRateTableList),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioForm: scenarioFile.scenarioForm,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });

		if (rs) {
			for (const r of rs as Record<string, unknown>[]) {
				let isOpenForProposedRates = Boolean(r["IS_OPEN_FOR_PROPOSED_RATES"]);

				// Work Comp has some special cases where some tables may or may
				// not be open for proposed rates depending on whether bureau
				// rates are being adopted or not.
				if (
					scenarioFile.scenarioForm.lineOfBusiness === "WC" &&
					scenarioFile.scenarioForm.workCompAdoptBureauRates &&
					[
						"WC_BUREAU_LC",
						"WC_MINIMUM_PREMIUM_NONBUREAU",
						"WC_PAYROLL_USLH"
					].includes(String(r["RATES_FILE_TABLE_NAME"]).toUpperCase())
				) {
					isOpenForProposedRates = false;
				}

				allRateTables.push({
					fullTableName: String(r["RATABASE_TABLE_NAME"]).toLowerCase(),
					ratesFileTableName: String(r["RATES_FILE_TABLE_NAME"]).toLowerCase(),
					programmedInRatingEngine: String(r["PROGRAMMED_IN_RATING_ENGINE"]),
					isOpenForProposedRates: isOpenForProposedRates,
					clsTableNumber: String(r["CLS_TABLE_NUMBER"]),
					ratabaseSystemName: String(r["RATABASE_SYSTEM_NAME"]),
					commentsForRatesFile: String(r["COMMENTS_FOR_RATES_FILE"]),
				});
			}
		}
	} catch (err) {
		throw err;
	}
};

const loadRateTables = async (): Promise<void> => {
	let sqlText: string;
	let rs: unknown[] | undefined;
	let transformedRows: Record<string, unknown>[];

	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetRateTable),
			)
		)[0];

		for await (const rateTable of allRateTables) {
			transformedTable = [];

			targetCount = {
				tableName: rateTable.fullTableName,
				components: [],
			};

			changedTargetCount = {
				tableName: rateTable.fullTableName,
				components: [],
			};

			sqlText = String(
				executeDynamicJsFunction({
					dynamicJsFunction,
					functionArguments: {
						isProduction: app.isPackaged,
						scenarioFile: scenarioFile,
						tableName: rateTable.fullTableName,
						orderBy:
							rateTableOrderBy.find(
								(orderBy) =>
									orderBy.tableName.toUpperCase() ===
									rateTable.fullTableName.toUpperCase(),
							)?.orderBy ?? "",
					},
				}),
			);

			[, rs] = await execute({ sqlText });

			// Only include non-empty tables.
			if (rs && rs.length) {
				transformedRows = transformRows(rs as Record<string, unknown>[]);

				let previousRevisionRenewalDate: Date;

				if (
					scenarioFile.scenarioForm.lineOfBusiness === "CMP" &&
					["HAB", "REA", "ROS", "RST"].includes(scenarioFile.scenarioForm.product)
				) {
					previousRevisionRenewalDate = (transformedRows[0] as Record<string, Date>)[
						"RENEWAL_DATE"
					];
				} else if (scenarioFile.scenarioForm.lineOfBusiness === "WC") {
					previousRevisionRenewalDate = (transformedRows[0] as Record<string, Date>)[
						"EFF_DATE"
					];
				} else {
					previousRevisionRenewalDate = (transformedRows[0] as Record<string, Date>)[
						"RB_EFF_DATE"
					];
				}

				applicableRateTables.push({
					ratesFileTableName: rateTable.ratesFileTableName,
					programmedInRatingEngine: rateTable.programmedInRatingEngine,
					previousRevisionRenewalDate: previousRevisionRenewalDate,
					fullTableName: rateTable.fullTableName,
					isOpenForProposedRates: rateTable.isOpenForProposedRates,
					clsTableNumber: rateTable.clsTableNumber,
					ratabaseSystemName: rateTable.ratabaseSystemName,
					commentsForRatesFile: rateTable.commentsForRatesFile,
				});

				addRateTableToExcelWorkbook(rateTable, transformedRows);
				targetCounts.push(targetCount);
				changedTargetCounts.push(changedTargetCount);
			}
		}
	} catch (err) {
		throw err;
	}
};

/**
 * Transforms cell values when needed, e.g., to transform dates from Excel
 * format to JavaScript format.
 */
const transformRows = (rows: Record<string, unknown>[]): Record<string, unknown>[] => {
	const transformedRows: Record<string, unknown>[] = [];
	let transformedColumn: Record<string, unknown>;

	for (const row of rows) {
		transformedColumn = {};

		for (let [columnName, cellValue] of Object.entries(row)) {
			if (cellValue instanceof Date) {
				cellValue = DateTime.fromISO(cellValue.toISOString().substring(0, 10)).toJSDate();
			}

			transformedColumn[columnName] = cellValue;
		}

		transformedRows.push(transformedColumn);
	}

	return transformedRows;
};

const addRateTableToExcelWorkbook = (rateTable: RateTable, rows: unknown[]): void => {
	// Loop through every row of the rate table.
	for (let [rowCount, row] of (rows as Record<string, unknown>[]).entries()) {
		let columnCount = 0;
		rateColumnCount = 0;
		transformedTableColumns = {};

		// Loop through every column of the row.
		for (const [columnName, cellValue] of Object.entries(row)) {
			if (ignoredFields.includes(columnName)) continue;

			if (
				scenarioFile.scenarioForm.lineOfBusiness !== "WC" ||
				!scenarioFile.scenarioForm.workCompAdoptBureauRates ||
				!SPECIAL_WC_TABLES.includes(rateTable.fullTableName.toUpperCase())
			) {
				processRateTableColumn({ rateTable, columnName, cellValue, rowCount, columnCount });
			} else {
				processRateTableColumnForSpecialWorkCompTable({
					rateTable,
					columnName,
					cellValue,
					rowCount,
					columnCount,
				});
			}

			columnCount++;
		}

		transformedTable.push(transformedTableColumns);
	}

	worksheet = xlsx.utils.json_to_sheet(transformedTable);
	xlsx.utils.book_append_sheet(workbook, worksheet, rateTable.ratesFileTableName);
};

/**
 * Append _CURRENT & _PROPOSED suffixes to rate columns, add percent change
 * column (if applicable), and generate the target count formula.
 */
const processRateTableColumn = (args: {
	rateTable: RateTable;
	columnName: string;
	cellValue: unknown;
	rowCount: number;
	columnCount: number;
}): void => {
	if (isRateColumn(args.rateTable.fullTableName, args.columnName)) {
		const currentColumn = xlsx.utils.encode_col(args.columnCount + rateColumnCount);
		const proposedColumn = xlsx.utils.encode_col(args.columnCount + rateColumnCount + 1);
		const row = xlsx.utils.encode_row(args.rowCount + 1); // + 1 since skipping header

		transformedTableColumns[`${args.columnName}_CURRENT`] = args.cellValue;
		transformedTableColumns[`${args.columnName}_PROPOSED`] = args.cellValue;

		// Increment by one since the proposed column was added.
		rateColumnCount++;

		if (isPercentChange(args.rateTable.fullTableName, args.columnName)) {
			transformedTableColumns[`${args.columnName}_PCT_CHG`] = {
				t: "n",
				f: `IFERROR(${proposedColumn}${row}/${currentColumn}${row}-1, 0)`,
				z: "0.0%",
			};

			// Increment by one since the percent change column was added.
			rateColumnCount++;
		}

		createTargetCountFormula({
			rowCount: args.rowCount,
			ratesFileTableName: args.rateTable.ratesFileTableName,
			currentColumn,
			proposedColumn,
		});
	} else {
		transformedTableColumns[args.columnName] = args.cellValue;
	}
};

/**
 * Creates the Excel formulas for the "table_list" worksheet for the columns
 * where the "Target Counts" & "Changed Target Counts" are populated, i.e., the
 * total number of cells that are open for proposed rates and the total number
 * of proposed rates that have changed.
 */
const createTargetCountFormula = (args: {
	rowCount: number;
	ratesFileTableName: string;
	currentColumn: string;
	proposedColumn: string;
}): void => {
	if (args.rowCount === 0) {
		let formula = `COUNTA(${args.ratesFileTableName}!A:A)-1`;
		targetCount.components.push(formula);
		// e.g. SUMPRODUCT(--(WC_CAT!C:C<>WC_CAT!D:D))-1
		formula = `SUMPRODUCT(--(${args.ratesFileTableName}!${args.currentColumn}:${args.currentColumn}<>${args.ratesFileTableName}!${args.proposedColumn}:${args.proposedColumn}))-1`;
		changedTargetCount.components.push(formula);
	}
};

/**
 * For the "special" Work Comp tables, add percent change column (if
 * applicable), and generate the target count formula.
 */
const processRateTableColumnForSpecialWorkCompTable = (args: {
	rateTable: RateTable;
	columnName: string;
	cellValue: unknown;
	rowCount: number;
	columnCount: number;
}): void => {
	transformedTableColumns[args.columnName] = args.cellValue;

	if (args.columnName.toUpperCase().endsWith("_PROPOSED")) {
		const currentColumn = xlsx.utils.encode_col(args.columnCount + rateColumnCount - 1);
		const proposedColumn = xlsx.utils.encode_col(args.columnCount + rateColumnCount);
		const row = xlsx.utils.encode_row(args.rowCount + 1); // + 1 since skipping header
		const columnNameWithoutProposedSuffix = args.columnName.replace(/_PROPOSED$/i, "");

		if (isPercentChange(args.rateTable.fullTableName, columnNameWithoutProposedSuffix)) {
			transformedTableColumns[`${columnNameWithoutProposedSuffix}_PCT_CHG`] = {
				t: "n",
				f: `IFERROR(${proposedColumn}${row}/${currentColumn}${row}-1, 0)`,
				z: "0.0%",
			};

			// Increment by one since the percent change column was added.
			rateColumnCount++;
		}

		createTargetCountFormula({
			rowCount: args.rowCount,
			ratesFileTableName: args.rateTable.ratesFileTableName,
			currentColumn,
			proposedColumn,
		});
	}
};

const isRateColumn = (tableName: string, columnName: string): boolean =>
	!!(
		(findGlobalRateField(columnName) || findUniqueRateField(tableName, columnName)) &&
		isOpenForProposedRates(tableName)
	);

const isOpenForProposedRates = (tableName: string): boolean =>
	applicableRateTables.find(
		(rateTable) => rateTable.fullTableName.toUpperCase() === tableName.toUpperCase(),
	)?.isOpenForProposedRates
		? true
		: false;

const isPercentChange = (tableName: string, columnName: string): boolean =>
	findGlobalRateField(columnName)?.isPercentChange ||
	findUniqueRateField(tableName, columnName)?.isPercentChange ||
	false;

const findGlobalRateField = (columnName: string) =>
	rateFields.global.find(
		(rateField) => rateField.fieldName.toUpperCase() === columnName.toUpperCase(),
	);

const findUniqueRateField = (tableName: string, columnName: string) =>
	rateFields.unique.find(
		(rateField) =>
			rateField.tableName.toUpperCase() === tableName.toUpperCase() &&
			rateField.fieldName.toUpperCase() === columnName.toUpperCase(),
	);

/**
 * Checks to see if any of the applicable rate tables have rates effective on or
 * after the scenario renewal date. If they do, this is an indication that this
 * is most likely a cancel/re-run and the previously saved rates have not yet
 * been deleted. In this case, warn the user but no hard stop at this point.
 * Only hard stop would be if the user chooses to initiate the rate revision.
 */
const checkForExistingRates = (): string[] => {
	const tablesWithExistingRates: string[] = [];

	for (const rateTable of applicableRateTables) {
		if (
			rateTable.previousRevisionRenewalDate >= new Date(scenarioFile.scenarioForm.renewalDate)
		) {
			tablesWithExistingRates.push(rateTable.fullTableName);
		}
	}

	return tablesWithExistingRates;
};

const showWarningExistingRates = async (tablesWithExistingRates: string[]): Promise<void> => {
	addConsoleMessage({
		text: `${
			Emoji.Warning
		} The following tables already have rates effective on or after the renewal date: ${tablesWithExistingRates.join(
			", ",
		)}`,
	});

	addConsoleMessage({
		text: `${Emoji.Warning} If the intent is to initiate a rate revision through this scenario, please reach out to the Technical Solutions Team to have the existing rates deleted before creating the rates file.`,
	});

	await logAsync({
		type: "WARNING",
		subType: "BACKEND",
		payload: `Rates file with existing rates: ${tablesWithExistingRates.join(", ")}`,
	});

	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		noLink: true,
		title: " *** WARNING ***",
		message:
			"The following tables already have rates effective on or after the renewal date:\n" +
			tablesWithExistingRates
				.map((table) => "\xa0\xa0\xa0\xa0\u2022\xa0" + table) // add white space & bullet point
				.join("\n") +
			"\n\nIf the intent is to initiate a rate revision through this scenario, please reach out to the Technical Solutions Team to have the existing rates deleted before creating the rates file.",
	};

	await dialog.showMessageBox(mainWindow, dialogOptions);
};

const updateRateTableListWorksheet = (): void => {
	const arrayOfArrays = [];
	let rowCount = 2;

	for (const rateTable of applicableRateTables) {
		// Create final "Target Count" formula by concatenating the individual
		// components with "+".
		let targetCountFormula = targetCounts
			.find((targetCount) => targetCount.tableName === rateTable.fullTableName)
			?.components.join("+");

		// Create final "Changed Target Count" formula by concatenating the
		// individual components with "+".
		let changedTargetCountFormula = changedTargetCounts
			.find((changedTargetCount) => changedTargetCount.tableName === rateTable.fullTableName)
			?.components.join("+");

		// Overwrite the formulas to simply equal zero if the table is not open
		// for proposed rates. Do not set to zero if it's one of the Work Comp
		// tables that should be locked for proposed rates when adopting rates.
		// Otherwise, the "In Scope" column will not be marked correctly.
		if (
			scenarioFile.scenarioForm.lineOfBusiness === "WC" &&
			scenarioFile.scenarioForm.workCompAdoptBureauRates &&
			["WC_BUREAU_LC", "WC_PAYROLL_USLH"].includes(rateTable.fullTableName.toUpperCase())
		) {
			// Do nothing, i.e., do not overwrite the formulas with zeroes.
		}  else if (
			scenarioFile.scenarioForm.lineOfBusiness === "WC" &&
			scenarioFile.scenarioForm.workCompAdoptBureauRates &&
			rateTable.fullTableName.toUpperCase() === "WC_MINIMUM_PREMIUM_NONBUREAU" &&
			["AZ", "FL", "IA", "ID", "NJ", "PA", "WI"].includes(scenarioFile.scenarioForm.geoState)
		) {
			// Do nothing, i.e., do not overwrite the formulas with zeroes.
			// These states are unique in that they have both current and
			// proposed minimum premiums in this table. All other states do not.
		} else if (!rateTable.isOpenForProposedRates) {
			targetCountFormula = "0";
			changedTargetCountFormula = "0";
		}

		arrayOfArrays.push([
			{
				t: "s",
				f: `=IF($F$${rowCount}>0,"X","")`,
			}, // Column A: In Scope
			{
				t: "s",
				f: `HYPERLINK("#${rateTable.ratesFileTableName}!A2","${rateTable.ratesFileTableName}")`,
			}, // Column B: Table Name
			rateTable.programmedInRatingEngine, // Column C: Programmed in RE
			rateTable.previousRevisionRenewalDate, // Column D: RB Effective Date
			{
				t: "n",
				f: `=${targetCountFormula}`,
			}, // Column E: Target Count
			{
				t: "n",
				f: `=${changedTargetCountFormula}`,
			}, // Column F: Changed Target Count
			rateTable.fullTableName, // Column G: Full Table Name
			rateTable.clsTableNumber, // Column H: CLS Table Number
			rateTable.ratabaseSystemName, // Column I: Ratabase System Name
			rateTable.commentsForRatesFile, // Column J: Comments
		]);

		rowCount++;
	}

	xlsx.utils.sheet_add_aoa(
		workbook.Sheets["table_list"],
		[
			[
				"In Scope",
				"Table Name",
				"Programmed in RE",
				"RB Effective Date",
				"Target Count",
				"Changed Target Count",
				"Full Table Name",
				"CLS Table Number",
				"Ratabase System Name",
				"Comments",
			],
		],
		{ origin: "A1" },
	);

	xlsx.utils.sheet_add_aoa(workbook.Sheets["table_list"], arrayOfArrays, { origin: "A2" });
};

export const resetRatesFile = (): void => {
	workbook = {} as xlsx.WorkBook;
	worksheet = {} as xlsx.WorkSheet;
	allRateTables = [];
	applicableRateTables = [];
	tablesForUpload = [];
	targetCounts = [];
	changedTargetCounts = [];
	ignoredFields = [];
	transformedTable = [];
	rateTableOrderBy = [];
	transformedTableColumns = {};
	rateFields = {} as RateFields;
	targetCount = {} as TargetCount;
	changedTargetCount = {} as TargetCount;
	rateColumnCount = 0;
};

export const updateWorkbook = (wb: xlsx.WorkBook): void => {
	workbook = wb;
};

/**
 * Calls a VB Script that opens the Excel file, calculates the formulas, and
 * saves the file. This is necessary for Work Comp rates files because of tables
 * that are marked as in-scope at file creation (due to adopting bureau rates).
 * Without doing this, these tables wouldn't show up as being in-scope when
 * being loaded through Node.js (because the formulas haven't been evaluated
 * yet, they only get evaluated when saving the file directly in Excel). Also
 * doing for other lines of business since it speeds up the file load time.
 */
const evaluateExcelFormulas = (): Promise<void> => {
	let isDone = false;

	return new Promise((resolve, reject) => {
		// Automatically resolve if not done within 10 minutes. Some users were
		// experiencing long runtimes which could be due to the "close" event
		// not triggering due to any numbers of operating system issues. Greater
		// time allowed due to California files being larger than usual
		// therefore taking longer to save.
		setTimeout(() => {
			if (!isDone) resolve();
		}, 600000);

		const cscript = spawn("C:\\Windows\\System32\\cscript.exe", [
			join(userSettings.appSettingsDirectory, "evaluate-excel-formulas.vbs"),
			getRatesFileAbsoluteFilepath(),
		]);

		cscript.on("error", (err) => {
			isDone = true;
			reject(err);
		});

		cscript.stderr.on("data", (err) => {
			isDone = true;
			reject(err);
		});

		cscript.on("close", () => {
			isDone = true;
			resolve();
		});
	});
};
