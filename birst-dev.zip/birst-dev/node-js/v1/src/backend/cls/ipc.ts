import { dialog, ipcMain } from "electron";
import { mainWindow } from "../main";
import { doRatesExist } from "../rates";
import { log, logAsync } from "../logger";
import { createClsFiles } from "./create";
import { IpcMessage } from "../ipc-handlers";
import { scenarioFile } from "../scenario-file";
import { Emoji, addConsoleMessage } from "../console-message";
import {
	loadRatesFile,
	tablesForUpload,
	getInScopeRateTables,
	getRatesFileAbsoluteFilepath,
} from "../rates-file";

export const clsIpcHandler = (): void => {
	ipcMain.on(IpcMessage.CreateClsFiles, async () => {
		try {
			if (["HAB", "REA", "ROS", "RST"].includes(scenarioFile.scenarioForm.product)) {
				throw new Error("CLS files cannot be generated for this product.");
			}

			const tablesWithSavedRates: string[] = [];
			await loadRatesFile();

			if (!(await areThereInScopeTables())) {
				mainWindow.webContents.send(IpcMessage.CreateClsFilesCanceled);
				return;
			}

			for (const table of tablesForUpload) {
				if (await doRatesExist(table)) {
					tablesWithSavedRates.push(table.tableName);
				}
			}

			if (tablesWithSavedRates.length !== tablesForUpload.length) {
				/* Still allow user the option to continue. For example, if they
				want to create the CLS files using current rates, i.e., not the
				proposed rates. */
				if (!(await doesUserWantToContinue(tablesWithSavedRates))) {
					mainWindow.webContents.send(IpcMessage.CreateClsFilesCanceled);
					return;
				}
			}

			await createClsFiles();
			mainWindow.webContents.send(IpcMessage.CreateClsFilesSuccess);
		} catch (err) {
			if (
				String(err).includes(
					"The rates file is currently open. Please close the file before proceeding.",
				)
			) {
				addConsoleMessage({
					text: `${Emoji.Warning} The rates file is currently open. Please close the file before proceeding.`,
				});

				log({
					type: "WARNING",
					subType: "BACKEND",
					payload: `The rates file is currently open: ${getRatesFileAbsoluteFilepath()}`,
				});
			} else {
				addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });
				await logAsync({ type: "ERROR", subType: "BACKEND", payload: String(err) });
			}

			mainWindow.webContents.send(IpcMessage.CreateClsFilesError);
		}
	});
};

const areThereInScopeTables = async (): Promise<boolean> => {
	if (!getInScopeRateTables().length) {
		const message =
			"Unable to save rates and generate output. There are no in scope rate tables.";

		addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
		await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
		return false;
	}

	return true;
};

const doesUserWantToContinue = async (tablesWithSavedRates: string[]): Promise<boolean> => {
	let message =
		"WARNING: Rates for this rate revision have not been saved. The CLS files will be for the latest available rates, NOT INCLUDING the rates from this rate revision. If the intent is to create CLS files for this rate revision, please save the rates first.\n\nAre you sure you want to continue?";

	if (tablesWithSavedRates.length > 0) {
		message = `WARNING: Some rates for this rate revision have not been saved. The CLS files will be for the latest available rates, NOT INCLUDING the rates that haven't been saved. If the intent is to create CLS files for this rate revision, please delete and re-save the rates first.\n\nOnly found rates saved for the following tables:\n${tablesWithSavedRates
			.map((table) => "\xa0\xa0\xa0\xa0\u2022\xa0" + table)
			.join("\n")}\n\nAre you sure you want to continue?`;
	}

	return !!(
		await dialog.showMessageBox(mainWindow, {
			type: "warning",
			buttons: ["No", "Yes"],
			defaultId: 0,
			cancelId: 0,
			noLink: true,
			title: " Confirmation Required",
			message: message,
		})
	).response;
};
