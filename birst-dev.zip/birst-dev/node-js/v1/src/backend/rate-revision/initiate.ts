import { join } from "path";
import { MessageBoxOptions, app, dialog } from "electron";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { execute } from "../database";
import { IpcMessage } from "../ipc-handlers";
import { createRateRevision } from "./create";
import { userSettings } from "../user-settings";
import { saveRateHistory } from "../rate-history";
import { createFitExhibits } from "../fit-exhibits";
import { EmailTrigger, createEmail } from "../email";
import { doesReportFileExist } from "../report-file";
import { addConsoleMessage, Emoji } from "../console-message";
import { updateInitiativeTable } from "../initiatives/update";
import { loadScenarioFile, scenarioFile } from "../scenario-file";
import { checkForExistingRates, doesRatesFileExist } from "../rates-file";
import { createDirectoriesInSharedDrive, setTargetDirectories } from "./directories";
import { copyFilesToSharedDrive, targetScenarioFile, updateScenarioFiles } from "./files";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";

export const initiateRateRevision = async (isTestRun?: boolean): Promise<void> => {
	try {
		const tablesWithExistingRates = await checkForExistingRates();

		// Hard stop the user from proceeding if rates haven't been deleted from
		// a previous run.
		if (!isTestRun && tablesWithExistingRates.length > 0) {
			addConsoleMessage({
				text: `${
					Emoji.StopSign
				} The following tables already have rates effective on or after the renewal date: ${tablesWithExistingRates.join(
					", ",
				)}`,
			});

			addConsoleMessage({
				text: `${Emoji.Warning} Please reach out to the Technical Solutions Team to have the existing rates deleted before proceeding.`,
			});

			addConsoleMessage({
				text: `${Emoji.Warning} You will have to re-create the rates file and re-run the scenario after the rates have been deleted.`,
			});

			return;
		}

		if (!isTestRun && !(await isOkToProceed())) {
			mainWindow.webContents.send(IpcMessage.DoneInitiatingRateRevision);
			return;
		}

		addConsoleMessage({ text: "Initiating rate revision..." });
		setTargetDirectories();
		await createDirectoriesInSharedDrive();
		await copyFilesToSharedDrive();
		await updateScenarioFiles();
		await createRateRevision();
		await saveRateHistory();
		await createFitExhibits();
		await updateInitiativeTable("INITIATED");
		// Reload scenario from shared drive to update the UI.
		await loadScenarioFile({ uncFilepath: targetScenarioFile });

		addConsoleMessage({ text: "Finished initiating the rate revision." });

		await logAsync({
			type: "INFO",
			subType: "JSON",
			payload: JSON.stringify({
				type: "MILESTONE",
				subType: "RATE-REVISION-INITIATED",
				appVersion: app.getVersion(),
				userEmailAddress: userSettings.emailAddress,
			}),
		});

		if (!isTestRun) {
			mainWindow.webContents.send(IpcMessage.ShowNextSteps);

			createEmail({
				emailTrigger: EmailTrigger.RateRevisionInitiated,
				scenarioForm: scenarioFile.scenarioForm,
			});
		}
	} catch (err) {
		throw err;
	} finally {
		mainWindow.webContents.send(IpcMessage.DoneInitiatingRateRevision);
	}
};

const isOkToProceed = async (): Promise<boolean> =>
	doesRatesFileExist() &&
	doesReportFileExist() &&
	(await rateRevisionDoesNotExist()) &&
	(await confirmUserWantsToCreate());

const confirmUserWantsToCreate = async (): Promise<boolean> => {
	const inScopeTables = scenarioFile.executiveSummary.inScopeTables
		? scenarioFile.executiveSummary.inScopeTables
				.split(",")
				.map((table) => "\xa0\xa0\xa0\xa0\u2022\xa0" + table) // add white space & bullet point
				.join("\n")
		: [];

	const inScopeTablesMessage = scenarioFile.executiveSummary.inScopeTables.length
		? `The following rate tables are in scope:\n${inScopeTables}`
		: "There are no rate tables in scope, i.e., no rate changes were made.";

	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["No", "Yes"],
		defaultId: 0,
		cancelId: 0,
		noLink: true,
		title: " Confirmation Required",
		message: "Are you sure you want to initiate the rate revision?\n\n" + inScopeTablesMessage,
	};

	return !!(await dialog.showMessageBox(mainWindow, dialogOptions)).response;
};

const rateRevisionDoesNotExist = async (): Promise<boolean> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(
					userSettings.sqlFunctionsDirectory,
					SqlFunctionFile.CheckIfActiveRateRevisionExists,
				),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioFile: scenarioFile,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });

		if (rs && rs.length > 0) {
			const existingScenarioId = (rs[0] as Record<string, string>)["SCENARIO_ID"];
			const createdBy = (rs[0] as Record<string, string>)["CREATED_BY"];
			const createdOn = (rs[0] as Record<string, string>)["CREATED_AT_UTC"];

			const message = `There is already an active rate revision under scenario ID ${existingScenarioId} created by user ID ${createdBy} on ${createdOn.substring(
				0,
				10,
			)}.`;

			addConsoleMessage({ text: `${Emoji.StopSign} ${message}` });
			await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
			return false;
		} else {
			return true;
		}
	} catch (err) {
		throw err;
	}
};
