import { join } from "path";
import { execute } from "../database";
import { RateRevision } from "./types";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export let rateRevision: RateRevision;

export const loadRateRevision = async (): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Checking for rate revision...",
			hasTimer: true,
			timerId: ConsoleMessageId.LoadingRateRevision,
		});

		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetRateRevision),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					scenarioFile: scenarioFile,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });
		updateProperties(rs);
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingRateRevision);
	}
};

const updateProperties = (results: unknown[] | undefined): void => {
	if (results && results.length) {
		const result = results[0] as Record<string, unknown>;

		rateRevision = {
			createdOn: String(result["CREATED_ON"]),
			createdBy: String(result["CREATED_BY"]),
			isCanceled: result["IS_CANCELED"] as boolean,
			canceledOn: String(result["CANCELED_ON"]),
			canceledBy: String(result["CANCELED_BY"]),
			scenarioDirectory: String(result["SCENARIO_DIRECTORY"]),
			scenarioDirectoryCanceled: String(result["SCENARIO_DIRECTORY_CANCELED"]),
		};
	} else {
		rateRevision = {
			createdOn: "",
			createdBy: "",
			isCanceled: false,
			canceledOn: "",
			canceledBy: "",
			scenarioDirectory: "",
			scenarioDirectoryCanceled: "",
		};
	}
};

export const resetRateRevision = (): void => {
	rateRevision = {
		createdOn: "",
		createdBy: "",
		isCanceled: false,
		canceledOn: "",
		canceledBy: "",
		scenarioDirectory: "",
		scenarioDirectoryCanceled: "",
	};
};

// To initialize the rate revision object on program load.
resetRateRevision();
