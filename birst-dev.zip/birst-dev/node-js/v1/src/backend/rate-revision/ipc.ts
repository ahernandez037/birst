import { app, ipcMain } from "electron";
import { logAsync } from "../logger";
import { createClsFiles } from "../cls";
import { resetRateRevision } from "./load";
import { IpcMessage } from "../ipc-handlers";
import { saveRatesToDatabase } from "../rates";
import { userSettings } from "../user-settings";
import { scenarioFile } from "../scenario-file";
import { ExecutionState } from "../app-settings";
import { initiateRateRevision } from "./initiate";
import { createRatabaseFiles } from "../ratabase";
import { mainWindow, updateExecutionState } from "../main";
import { addConsoleMessage, Emoji } from "../console-message";
import { cancelAllRateRevisions, cancelRateRevision } from "./cancel";

export const rateRevisionIpcHandler = (): void => {
	ipcMain.on(IpcMessage.InitiateRateRevision, async () => {
		try {
			updateExecutionState(ExecutionState.InitiatingRateRevision);
			await initiateRateRevision();
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
			});
		} finally {
			updateExecutionState(ExecutionState.AtRest);
		}
	});

	ipcMain.on(IpcMessage.CancelRateRevision, async () => {
		try {
			updateExecutionState(ExecutionState.CancelingRateRevision);
			await cancelRateRevision();
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
			});
		} finally {
			updateExecutionState(ExecutionState.AtRest);
		}
	});

	ipcMain.on(IpcMessage.CancelAllRateRevisions, async () => {
		try {
			updateExecutionState(ExecutionState.CancelingRateRevision);
			await cancelAllRateRevisions();
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
			});
		} finally {
			updateExecutionState(ExecutionState.AtRest);
		}
	});

	ipcMain.on(IpcMessage.SaveRatesAndGenerateOutput, async () => {
		try {
			updateExecutionState(ExecutionState.SavingRatesAndGeneratingOutput);

			// If return value is not true then action was canceled.
			if (await saveRatesToDatabase()) {
				// Create CLS files for legacy raters only.
				if (!["HAB", "REA", "ROS", "RST"].includes(scenarioFile.scenarioForm.product)) {
					await createClsFiles();
				}

				await createRatabaseFiles();
				mainWindow.webContents.send(IpcMessage.SaveRatesAndGenerateOutputSuccess);

				addConsoleMessage({
					text: `All done saving rates & generating output ${Emoji.CheckMark}`,
				});
			}

			await logAsync({
				type: "INFO",
				subType: "JSON",
				payload: JSON.stringify({
					type: "MILESTONE",
					subType: "SAVE-RATES-AND-GENERATE-OUTPUT",
					appVersion: app.getVersion(),
					email: userSettings.emailAddress,
				}),
			});
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
			});

			mainWindow.webContents.send(IpcMessage.SaveRatesAndGenerateOutputError);
		} finally {
			updateExecutionState(ExecutionState.AtRest);
		}
	});

	ipcMain.on(IpcMessage.ResetRateRevision, () => {
		resetRateRevision();
	});
};
