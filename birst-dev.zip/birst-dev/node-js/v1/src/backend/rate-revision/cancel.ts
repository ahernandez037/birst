import { join } from "path";
import { rimraf } from "rimraf";
import { ensureDir, copy } from "fs-extra";
import { MessageBoxOptions, app, dialog } from "electron";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { execute } from "../database";
import { doRatesExist } from "../rates";
import { IpcMessage } from "../ipc-handlers";
import { updateRateHistory } from "../rate-history";
import { createEmail, EmailTrigger } from "../email";
import { loadRateRevision, rateRevision } from "./load";
import { userSettings, USER_ID } from "../user-settings";
import { loadExecutiveSummary } from "../executive-summary";
import { updateInitiativeTable } from "../initiatives/update";
import { loadRatesFile, tablesForUpload } from "../rates-file";
import { loadScenarioFile, scenarioFile } from "../scenario-file";
import { canceledScenarioFile, updateCanceledScenarioFile } from "./files";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";
import {
	setTargetDirectories,
	targetParentDirectory,
	moveToCanceledDirectory,
	targetCanceledDirectory,
	queryAssociatedRateRevisionDetails,
} from "./directories";

export const cancelRateRevision = async (isTestRun?: boolean): Promise<void> => {
	try {
		if (!isTestRun && !(await confirmUserWantsToCancel())) {
			mainWindow.webContents.send(IpcMessage.DoneCancelingRateRevision);
			return;
		}

		addConsoleMessage({ text: "Canceling the rate revision..." });
		setTargetDirectories();
		await moveToCanceledDirectory(await loadExecutiveSummary());
		await updateCanceledScenarioFile(
			targetCanceledDirectory + "\\BIRST\\" + scenarioFile.files.scenarioFile,
		);

		// Reload scenario from canceled directory to update the database.
		// Passing skipScenarioDirectoryOverride = true so that the new canceled
		// directory path is preserved. Also passing skipLoadRateRevision = true
		// since rate revision data is being loaded below, after the database
		// has been updated.
		await loadScenarioFile({
			uncFilepath: canceledScenarioFile,
			skipScenarioDirectoryOverride: true,
			skipLoadRateRevision: true,
		});

		// Update to tag as canceled & also to include canceled directory path.
		// Calling after re-loading scenario file to capture the new canceled
		// directory location.
		await updateDatabase();
		await updateRateHistory();
		await updateInitiativeTable("CANCELED");
		// Load updated rate revision data to update the frontend.
		await loadRateRevision();
		mainWindow.webContents.send(IpcMessage.UpdateRateRevision, JSON.stringify(rateRevision));
		await createCancelNotificationEmail();
		addConsoleMessage({ text: "Finished canceling the rate revision." });

		await logAsync({
			type: "INFO",
			subType: "JSON",
			payload: JSON.stringify({
				type: "MILESTONE",
				subType: "RATE-REVISION-CANCELED",
				appVersion: app.getVersion(),
				userEmailAddress: userSettings.emailAddress,
			}),
		});
	} catch (err) {
		throw err;
	} finally {
		mainWindow.webContents.send(IpcMessage.DoneCancelingRateRevision);
	}
};

export const cancelAllRateRevisions = async (): Promise<void> => {
	try {
		if (!(await confirmUserWantsToCancel(true))) {
			mainWindow.webContents.send(IpcMessage.DoneCancelingRateRevision);
			return;
		}

		const associatedRateRevisions = await loadExecutiveSummary();

		const scenarioFiles = await getScenarioFiles(
			associatedRateRevisions.map(
				(rateRevision) => "'" + rateRevision.scenarioId.toUpperCase() + "'",
			),
		);

		addConsoleMessage({ text: "Canceling all rate revisions..." });

		setTargetDirectories();

		addConsoleMessage({
			text: "Copying files to canceled directory...",
			hasTimer: true,
			timerId: ConsoleMessageId.CopyingFilesToCanceledDirectory,
		});

		await ensureDir(targetCanceledDirectory);
		await copy(targetParentDirectory, targetCanceledDirectory);
		stopConsoleMessageTimer(ConsoleMessageId.CopyingFilesToCanceledDirectory);

		const associatedScenarioIDs: string[] = [];

		for (const file of scenarioFiles) {
			await loadScenarioFile({ uncFilepath: file });
			associatedScenarioIDs.push(scenarioFile.scenarioForm.scenarioId);

			await updateCanceledScenarioFile(
				targetCanceledDirectory + "\\BIRST\\" + scenarioFile.files.scenarioFile,
			);

			// Reload scenario from canceled directory to update the database.
			// Passing skipScenarioDirectoryOverride = true so that the new
			// canceled directory path is preserved. Also passing
			// skipLoadRateRevision = true since rate revision data is being
			// loaded below, after the database has been updated.
			await loadScenarioFile({
				uncFilepath: canceledScenarioFile,
				skipScenarioDirectoryOverride: true,
				skipLoadRateRevision: true,
			});

			// Update to tag as canceled & also to include canceled directory
			// path. Calling after re-loading scenario file to capture the new
			// canceled directory location.
			await updateDatabase();
			await updateRateHistory();
			await createCancelNotificationEmail();
		}

		addConsoleMessage({
			text: "Deleting files from source directory...",
			hasTimer: true,
			timerId: ConsoleMessageId.DeletingFilesFromSourceDirectory,
		});

		// ! Not using fs-extra's move or remove function as it was causing
		// ! issues locking files/directories. Defer to using rimraf to delete
		// ! directories.
		await rimraf.windows(targetParentDirectory);
		stopConsoleMessageTimer(ConsoleMessageId.DeletingFilesFromSourceDirectory);

		// Load updated rate revision data to update the frontend.
		await loadRateRevision();
		mainWindow.webContents.send(IpcMessage.UpdateRateRevision, JSON.stringify(rateRevision));
		addConsoleMessage({ text: "Finished canceling all rate revisions." });

		await logAsync({
			type: "INFO",
			subType: "JSON",
			payload: JSON.stringify({
				type: "MILESTONE",
				subType: "RATE-REVISION-CANCELED-ALL",
				appVersion: app.getVersion(),
				userEmailAddress: userSettings.emailAddress,
				associatedScenarioIDs: associatedScenarioIDs.join(","),
			}),
		});
	} catch (err) {
		stopConsoleMessageTimer(ConsoleMessageId.CopyingFilesToCanceledDirectory);
		stopConsoleMessageTimer(ConsoleMessageId.DeletingFilesFromSourceDirectory);
		throw err;
	} finally {
		mainWindow.webContents.send(IpcMessage.DoneCancelingRateRevision);
	}
};

const confirmUserWantsToCancel = async (isCancelAllRateRevisions?: boolean): Promise<boolean> => {
	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["No", "Yes"],
		defaultId: 0,
		cancelId: 0,
		noLink: true,
		title: " Confirmation Required",
		message: isCancelAllRateRevisions
			? "Are you sure you want to cancel this and all associated rate revisions?"
			: "Are you sure you want to cancel the rate revision?",
	};

	return !!(await dialog.showMessageBox(mainWindow, dialogOptions)).response;
};

const updateDatabase = async (): Promise<void> => {
	addConsoleMessage({
		text: "Canceling rate revision in database...",
		hasTimer: true,
		timerId: ConsoleMessageId.CancelingRateRevisionInDatabase,
	});

	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CancelRateRevision),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioFile: scenarioFile,
					userId: USER_ID.toUpperCase(),
				},
			}),
		);

		await execute({ sqlText });
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.CancelingRateRevisionInDatabase);
	}
};

const createCancelNotificationEmail = async (): Promise<void> => {
	try {
		const tablesWithSavedRates: string[] = [];
		await loadRatesFile();

		for (const table of tablesForUpload) {
			if (await doRatesExist(table)) {
				tablesWithSavedRates.push(table.tableName);
			}
		}

		if (tablesWithSavedRates.length > 0) {
			await createEmail({
				emailTrigger: EmailTrigger.RateRevisionCanceledSavedRates,
				scenarioForm: scenarioFile.scenarioForm,
			});
		} else {
			await createEmail({
				emailTrigger: EmailTrigger.RateRevisionCanceled,
				scenarioForm: scenarioFile.scenarioForm,
			});
		}
	} catch (err) {
		throw err;
	}
};

const getScenarioFiles = async (scenarioIds: string[]): Promise<string[]> => {
	if (scenarioIds.length === 0) return [];

	try {
		const scenarioFiles: string[] = [];
		const rs = await queryAssociatedRateRevisionDetails(scenarioIds);

		if (rs) {
			for (const r of rs as Record<string, unknown>[]) {
				scenarioFiles.push(
					join(String(r["SCENARIO_DIRECTORY"]), String(r["SCENARIO_FILE"])),
				);
			}
		}

		return scenarioFiles;
	} catch (err) {
		throw err;
	}
};
