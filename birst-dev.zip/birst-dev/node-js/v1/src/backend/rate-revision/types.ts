export interface RateRevision {
	createdOn: string;
	createdBy: string;
	isCanceled: boolean;
	canceledOn: string;
	canceledBy: string;
	scenarioDirectory: string;
	scenarioDirectoryCanceled: string;
}

export const lineOfBusinessDirectory = {
	CMP: "\\\\hm2ntfs01\\xacm632$\\BIRST_Rate_Revisions\\CMP\\",
	UMB: "\\\\hm2ntfs01\\xacm632$\\BIRST_Rate_Revisions\\CMP\\",
	WC: "\\\\hm2ntfs01\\xacm632$\\BIRST_Rate_Revisions\\WC\\",
	AUTO: "\\\\hm2ntfs01\\xacm632$\\BIRST_Rate_Revisions\\Auto\\",
} as const;
