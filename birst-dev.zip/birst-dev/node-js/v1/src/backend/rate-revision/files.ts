import { join } from "path";
import { copy, chmod, remove, existsSync, writeJson } from "fs-extra";
import { userSettings } from "../user-settings";
import { doesDataDumpFileExist } from "../data-dump";
import { saveScenarioFile, scenarioFile } from "../scenario-file";
import { targetCanceledDirectory, targetScenarioDirectory } from "./directories";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export let targetScenarioFile: string;
export let targetRatesFile: string;
export let targetReportFile: string;
export let targetDataDumpFile: string;
export let canceledScenarioFile: string;

export const copyFilesToSharedDrive = async (): Promise<void> => {
	try {
		await copyRatesFile();
		await copyReportFile();
		await copyDataDumpFile();
	} catch (err) {
		throw err;
	}
};

const copyRatesFile = async (): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Copying rates file...",
			hasTimer: true,
			timerId: ConsoleMessageId.CopyingRatesFile,
		});

		targetRatesFile = targetScenarioDirectory + "\\" + scenarioFile.files.ratesFile;

		await copy(
			join(scenarioFile.scenarioForm.scenarioDirectory, scenarioFile.files.ratesFile),
			targetRatesFile,
		);

		await chmod(targetRatesFile, 0o400); // Read Only
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.CopyingRatesFile);
	}
};

export const copyReportFile = async (): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Copying report file...",
			hasTimer: true,
			timerId: ConsoleMessageId.CopyingReportFile,
		});

		targetReportFile = targetScenarioDirectory + "\\" + scenarioFile.files.reportFile;

		await copy(
			join(scenarioFile.scenarioForm.scenarioDirectory, scenarioFile.files.reportFile),
			targetReportFile,
		);

		await chmod(targetReportFile, 0o400); // Read Only
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.CopyingReportFile);
	}
};

export const copyDataDumpFile = async (): Promise<void> => {
	if (doesDataDumpFileExist()) {
		try {
			addConsoleMessage({
				text: "Copying data dump file...",
				hasTimer: true,
				timerId: ConsoleMessageId.CopyingDataDumpFile,
			});

			targetDataDumpFile = targetScenarioDirectory + "\\" + scenarioFile.files.dataDumpFile;

			await copy(
				join(scenarioFile.scenarioForm.scenarioDirectory, scenarioFile.files.dataDumpFile),
				targetDataDumpFile,
			);

			await chmod(targetDataDumpFile, 0o400); // Read Only
		} catch (err) {
			throw err;
		} finally {
			stopConsoleMessageTimer(ConsoleMessageId.CopyingDataDumpFile);
		}
	} else {
		targetDataDumpFile = "";
	}
};

export const updateScenarioFiles = async (): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Updating scenario files...",
			hasTimer: true,
			timerId: ConsoleMessageId.UpdatingScenarioFiles,
		});

		targetScenarioFile = targetScenarioDirectory + "\\" + scenarioFile.files.scenarioFile;
		scenarioFile.executiveSummary.isRateRevisionCreated = true;
		scenarioFile.executiveSummary.rateRevisionInitiatedByEmail = userSettings.emailAddress;

		/* Save the source scenario file, i.e., the scenario file that was used
		to initiate the rate revision, to update the isRateRevisionCreated
		property to true. */
		await saveScenarioFile();

		/* Update the scenario directory to the shared drive location for
		the scenario file that will be saved in the BIRST_Rate_Revisions
		directory. */
		scenarioFile.scenarioForm.scenarioDirectory = targetScenarioDirectory;

		/* Delete file if it already exists as can't overwrite with writeJson()
		if the file is read-only, which it is. */
		if (existsSync(targetScenarioFile)) await remove(targetScenarioFile);
		await writeJson(targetScenarioFile, scenarioFile, { spaces: "\t" });
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.UpdatingScenarioFiles);
	}
};

export const updateCanceledScenarioFile = async (file: string): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Updating canceled scenario file...",
			hasTimer: true,
			timerId: ConsoleMessageId.UpdatingCanceledScenarioFile,
		});

		canceledScenarioFile = file;
		scenarioFile.scenarioForm.scenarioDirectory = targetCanceledDirectory + "\\BIRST";
		await writeJson(canceledScenarioFile, scenarioFile, { spaces: "\t" });
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.UpdatingCanceledScenarioFile);
	}
};
