import { join } from "path";
import { app } from "electron";
import { execute } from "../database";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export const updateRateHistory = async (): Promise<void> => {
	addConsoleMessage({
		text: "Updating rate history...",
		hasTimer: true,
		timerId: ConsoleMessageId.UpdatingRateHistory,
	});

	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.UpdateRateHistory),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioId: scenarioFile.scenarioForm.scenarioId,
					scenarioFile: scenarioFile,
					rateHistory: scenarioFile.rateHistory,
				},
			}),
		);

		await execute({ sqlText });
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.UpdatingRateHistory);
	}
};
