import { join } from "path";
import * as xlsx from "xlsx";
import { execute } from "../database";
import { userSettings } from "../user-settings";
import { QueryMethod, RunMode } from "../scenario";
import { runBirstFileFormatter } from "../utilities/ancillary";
import { addScenarioDetailsToExcelWorkbook } from "../scenario/details";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";
import {
	scenarioFile,
	saveScenarioFile,
	updateScenarioFileRateHistory,
	updateScenarioFileExecutiveSummary,
} from "../scenario-file";
import { waitUntilFileClosed } from "../utilities";

export const saveReports = async (): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Saving reports to hard drive...",
			hasTimer: true,
			timerId: ConsoleMessageId.SavingReportsToHardDrive,
		});

		if (scenarioFile.scenarioForm.runMode === RunMode.RateChange) {
			await saveRateChangeReports();
		} else {
			await saveValidationReports();
		}
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.SavingReportsToHardDrive);
		stopConsoleMessageTimer(ConsoleMessageId.ApplyingExcelFormatting);
	}
};

const saveRateChangeReports = async (): Promise<void> => {
	try {
		const executiveSummaryReport = await loadReport({
			sqlFunctionFile: SqlFunctionFile.GetExecutiveSummaryReport,
		});

		updateScenarioFileExecutiveSummary(executiveSummaryReport);

		const impactSummaryReport = await loadReport({
			sqlFunctionFile: SqlFunctionFile.GetImpactSummaryReport,
		});

		const forSerffReport = await loadReport({
			sqlFunctionFile: SqlFunctionFile.GetForSerffReport,
		});

		const forRateHistoryReport = await loadReport({
			sqlFunctionFile: SqlFunctionFile.GetForRateHistoryReport,
		});

		updateScenarioFileRateHistory(forRateHistoryReport);
		await saveScenarioFile();

		const workbook = xlsx.utils.book_new();
		addScenarioDetailsToExcelWorkbook(workbook);

		const worksheets = [
			{
				data: executiveSummaryReport,
				name: "executive_summary",
			},
			{
				data: impactSummaryReport,
				name: "impact_summary",
			},
			{
				data: forSerffReport,
				name: "for_serff",
			},
			{
				data: forRateHistoryReport,
				name: "for_rate_history",
			},
		];

		if (scenarioFile.scenarioForm.lineOfBusiness === "WC") {
			worksheets.push({
				data: await loadReport({
					sqlFunctionFile: SqlFunctionFile.GetWorkCompRatesExhibit,
				}),
				name: "rates_exhibit",
			});

			worksheets.push({
				data: await loadReport({
					sqlFunctionFile: SqlFunctionFile.GetWorkCompMinPremNonBureauExhibit,
				}),
				name: "wc_minimum_premium_nonbureau",
			});

			worksheets.push({
				data: await loadReport({
					sqlFunctionFile: SqlFunctionFile.GetWorkCompCatTerrRatesExhibit,
				}),
				name: "cat_terr_rates",
			});

			worksheets.push({
				data: await getWorkCompNewExpiredClassCodes(),
				name: "new_expired_class_codes",
			});

			worksheets.push({
				data: await loadReport({
					sqlFunctionFile: SqlFunctionFile.GetWorkCompRateOrderImpactExhibit,
				}),
				name: "rate_order_impact",
			});
		}

		for (const worksheet of worksheets) {
			xlsx.utils.book_append_sheet(
				workbook,
				xlsx.utils.json_to_sheet(worksheet.data, {
					skipHeader: false,
					origin: "A1",
				}),
				worksheet.name,
			);
		}

		const reportFilepath = join(
			scenarioFile.scenarioForm.scenarioDirectory,
			scenarioFile.files.reportFile,
		);

		await xlsx.writeFile(workbook, reportFilepath, {
			bookType: "xlsx",
			compression: true,
		});
		// Added wait since shared drives can be slow to save/close files.
		await waitUntilFileClosed(reportFilepath);

		addConsoleMessage({
			text: "Applying formatting...",
			hasTimer: true,
			timerId: ConsoleMessageId.ApplyingExcelFormatting,
		});

		if (scenarioFile.scenarioForm.lineOfBusiness === "WC") {
			await runBirstFileFormatter("REPORT-FILE-RATE-CHANGE-WC", reportFilepath);
		} else {
			await runBirstFileFormatter("REPORT-FILE-RATE-CHANGE", reportFilepath);
		}
	} catch (err) {
		throw err;
	}
};

const saveValidationReports = async (): Promise<void> => {
	try {
		const executiveSummaryReport = await loadReport({
			sqlFunctionFile: SqlFunctionFile.GetExecutiveSummaryReport,
		});

		const massRateTestingReport = await loadReport({
			sqlFunctionFile: SqlFunctionFile.GetMassRateTestingReport,
		});

		const workbook = xlsx.utils.book_new();
		addScenarioDetailsToExcelWorkbook(workbook);

		const worksheets = [
			{
				data: executiveSummaryReport,
				name: "executive_summary",
			},
			{
				data: massRateTestingReport,
				name: "mass_rate_testing",
			},
		];

		for (const worksheet of worksheets) {
			xlsx.utils.book_append_sheet(
				workbook,
				xlsx.utils.json_to_sheet(worksheet.data, {
					skipHeader: false,
					origin: "A1",
				}),
				worksheet.name,
			);
		}

		const reportFilepath = join(
			scenarioFile.scenarioForm.scenarioDirectory,
			scenarioFile.files.reportFile,
		);

		await xlsx.writeFile(workbook, reportFilepath, {
			bookType: "xlsx",
			compression: true,
		});
		// Added wait since shared drives can be slow to save/close files.
		await waitUntilFileClosed(reportFilepath);

		addConsoleMessage({
			text: "Applying formatting...",
			hasTimer: true,
			timerId: ConsoleMessageId.ApplyingExcelFormatting,
		});

		if (scenarioFile.scenarioForm.queryMethod === QueryMethod.InForce) {
			await runBirstFileFormatter("REPORT-FILE-VALIDATION-IN-FORCE", reportFilepath);
		} else {
			await runBirstFileFormatter("REPORT-FILE-VALIDATION-EFFECTIVE-DATE", reportFilepath);
		}
	} catch (err) {
		throw err;
	}
};

const loadReport = async (args: {
	sqlFunctionFile: SqlFunctionFile;
}): Promise<Record<string, unknown>[]> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, args.sqlFunctionFile),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					scenarioFile,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });
		return rs as Record<string, unknown>[];
	} catch (err) {
		throw err;
	}
};

/**
 * Calling this function to get the added/expired class code data guarantees
 * that, when there aren't any added/expired class codes, the worksheet will be
 * populated with a message stating that. Otherwise, the worksheet would be
 * completely empty, not even the header row would be populated.
 */
const getWorkCompNewExpiredClassCodes = async (): Promise<Record<string, unknown>[]> => {
	try {
		const data = await loadReport({
			sqlFunctionFile: SqlFunctionFile.GetWorkCompNewExpiredClassCodesExhibit,
		});

		if (data.length) return data;

		return [
			{
				action: "There are no new or expiring class codes.",
				state_specific_y_or_n: "",
				siccode: "",
				naics: "",
				naics_description: "",
				industrykey: "",
				industrydesc: "",
				classcode_91465_and_extension_table: "",
				wcclassdescind_91465_and_extension_table: "",
				classdescription: "",
				state: "",
				underwritergrade_91107_and_41025_tables: "",
				minpay: "",
				edr: "",
				riskyindustries: "",
				hazard_group_41021_table: "",
				assigned_to_expired_cc_only: "",
				policy_count: "",
				policy_premium: "",
			},
		];
	} catch (err) {
		throw err;
	}
};
