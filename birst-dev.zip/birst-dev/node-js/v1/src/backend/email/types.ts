import { EmailFunctionFile } from "../dynamic-js";

export interface EmailRecipient {
	id: number;
	emailAddress: string;
	geoState: string;
	lineOfBusiness: string;
	product: string;
	version: string;
	rateRevisionInitiated: string;
	rateRevisionCanceled: string;
	rateRevisionCanceledSavedRates: string;
	requestToDeleteRates: string;
	ratesDeleted: string;
	feedbackSubmitted: string;
	problemReported: string;
	forcedAppQuit: string;
}

export const enum EmailTrigger {
	RateRevisionInitiated = "rateRevisionInitiated",
	RateRevisionCanceled = "rateRevisionCanceled",
	RateRevisionCanceledSavedRates = "rateRevisionCanceledSavedRates",
	RequestToDeleteRates = "requestToDeleteRates",
	RatesDeleted = "ratesDeleted",
	FeedbackSubmitted = "feedbackSubmitted",
	ProblemReported = "problemReported",
	ForcedAppQuit = "forcedAppQuit",
}

export const MAP_TRIGGER_TO_FILE: Record<EmailTrigger, EmailFunctionFile> = {
	rateRevisionInitiated: EmailFunctionFile.RateRevisionInitiated,
	rateRevisionCanceled: EmailFunctionFile.RateRevisionCanceled,
	rateRevisionCanceledSavedRates: EmailFunctionFile.RateRevisionCanceledSavedRates,
	requestToDeleteRates: EmailFunctionFile.RequestToDeleteRates,
	ratesDeleted: EmailFunctionFile.RatesDeleted,
	feedbackSubmitted: EmailFunctionFile.FeedbackSubmitted,
	problemReported: EmailFunctionFile.ProblemReported,
	forcedAppQuit: EmailFunctionFile.ForcedAppQuit,
} as const;
