import { ipcMain } from "electron";
import { EmailTrigger } from "./types";
import { createEmail } from "./create";
import { ScenarioForm } from "../scenario";
import { IpcMessage } from "../ipc-handlers";

export const emailIpcHandler = (): void => {
	ipcMain.on(IpcMessage.CreateEmailRequestToDeleteRates, () => {
		createEmail({
			emailTrigger: EmailTrigger.RequestToDeleteRates,
			scenarioForm: {} as ScenarioForm,
		});
	});

	ipcMain.on(IpcMessage.CreateEmailReportProblem, (_event, payload) => {
		createEmail({
			emailTrigger: EmailTrigger.ProblemReported,
			scenarioForm: JSON.parse(payload[0]),
		});
	});

	ipcMain.on(IpcMessage.CreateEmailSubmitFeedback, () => {
		createEmail({
			emailTrigger: EmailTrigger.FeedbackSubmitted,
			scenarioForm: {} as ScenarioForm,
		});
	});
};
