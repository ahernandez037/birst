import { join } from "path";
import { app } from "electron";
import { log } from "../logger";
import { execute } from "../database";
import { EmailRecipient } from "./types";
import { userSettings } from "../user-settings";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";

export const loadEmailRecipients = async (): Promise<EmailRecipient[]> => {
	log({
		type: "INFO",
		subType: "BACKEND",
		payload: "Getting email recipients...",
	});

	const recipients: EmailRecipient[] = [];

	try {
		const rs = await queryDatabase();

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				recipients.push({
					id: Number(result["ID"]),
					emailAddress: String(result["EMAIL_ADDRESS"]),
					geoState: String(result["STATE"]),
					lineOfBusiness: String(result["LINE_OF_BUSINESS"]),
					product: String(result["PRODUCT"]),
					version: String(result["VERSION"]),
					rateRevisionInitiated: String(result["RATE_REVISION_INITIATED"]),
					rateRevisionCanceled: String(result["RATE_REVISION_CANCELED"]),
					rateRevisionCanceledSavedRates: String(
						result["RATE_REVISION_CANCELED_SAVED_RATES"],
					),
					requestToDeleteRates: String(result["REQUEST_TO_DELETE_RATES"]),
					ratesDeleted: String(result["RATES_DELETED"]),
					feedbackSubmitted: String(result["FEEDBACK_SUBMITTED"]),
					problemReported: String(result["PROBLEM_REPORTED"]),
					forcedAppQuit: String(result["FORCED_APP_QUIT"]),
				});
			}
		}
	} catch (err) {
		throw err;
	}

	return recipients;
};

const queryDatabase = async (): Promise<unknown[] | undefined> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetEmailRecipients),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });
		return rs;
	} catch (err) {
		throw err;
	}
};
