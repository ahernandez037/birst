const subject = `[BIRST] Feedback`;
const body = "";

return { subject, body };
