const subject = `[BIRST] Forced App Quit - Clean Up Required`;
const body = `
<br /><br />
<b>*** BIRST Automated Message Below ***</b>
<br /><br />
<div>Execution state: ${args.executionState}</div>
<div>Scenario ID: ${args.scenarioFile.scenarioForm.scenarioId}</div>
<br />
<b>Next Steps:</b>
<br /><br />
<b>Technical Solutions Team</b>
<br />
<span>Review if any of the following needs clean up:</span>
<ul>
	<li>Files and directories in the shared drive</li>
	<li>If rates were being saved, ensure that they are all in the database</li>
	<li>The following tables if rate revision was being initiated/canceled:</li>
	<ul>
		<li>prd_bizdb_coml.public_sandbox.birst_rate_history</li>
		<li>prd_bizdb_coml.public_sandbox.birst_rate_revision</li>
	</ul>
</ul>
<br />
`;

return { subject, body };
