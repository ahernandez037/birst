const state = args.scenarioFile.scenarioForm.geoState;

const lineOfBusiness =
	args.scenarioFile.scenarioForm.product === "GAR"
		? ""
		: ` ${args.scenarioFile.scenarioForm.lineOfBusiness}`;

const product =
	args.scenarioFile.scenarioForm.product === "N/A" ||
	args.scenarioFile.scenarioForm.product === "AUTO"
		? ""
		: ` ${args.scenarioFile.scenarioForm.product}`;

let version = "";

version =
	args.scenarioFile.scenarioForm.product === "AUTO"
		? ` v${args.scenarioFile.scenarioForm.version}`
		: version;

version =
	args.scenarioFile.scenarioForm.lineOfBusiness === "WC"
		? `${args.scenarioFile.scenarioForm.version}`
		: version;

const newBusinessDate = args.formattedDates.newDate;
const renewalDate = args.formattedDates.renewalDate;
const availableDate = args.formattedDates.availableDate;

const impactAmount =
	"$" + Number(args.scenarioFile.executiveSummary.impactAmount).toLocaleString("en-US");

const impactPercent =
	String((Number(args.scenarioFile.executiveSummary.impactPercent) * 100).toFixed(2)) + "%";

const directory = args.scenarioFile.scenarioForm.scenarioDirectory;
const hyperlink = `<a href="${directory}">${directory}</a>`;
const subject = `[BIRST] Rate Revision Canceled - ${state}${lineOfBusiness}${product}${version} - Renewal Date: ${renewalDate} *** RATES HAVE BEEN SAVED ***`;

const body = `
<br /><br />
<b>*** BIRST Automated Message Below ***</b>
<br /><br />
<p>The captioned rate revision has been canceled and the rates are saved in the database.</p>
<b>Next Steps:</b>
<br />
<ul>
	<li>
		<b>Technical Solutions Team:</b>
		<ul>
			<li>Open the scenario file for this product.</li>
			<li>
				Delete the rates from the database by clicking on 'Rate Revision' and then on
				'Delete Rates'
			</li>
		</ul>
	</li>
	<li>
		<b>Product:</b>
		<ul>
			<li>Once the rates have been deleted, you will be notified.</li>
			<li>
				Make the necessary changes to the rate revision in BIRST (i.e., revise the rates
				file, run the updated scenario, and initiate the rate revision with the changes).
			</li>
			<li>
				If significant changes are made or impact has changed, the updated rate revision
				will need to be re-approved. Respond to this email to request the Signavio case be
				restarted.
			</li>
		</ul>
	</li>
	<li>
		<b>Filing and Implementation Team:</b>
		<ul>
			<li>
				If the Signavio case is restarted, once the updated rate revision has been
				re-approved, the FIT Manager will be notified by Signavio to assign a FIT Analyst to
				the rate revision.
			</li>
			<ul>
				<li>
					The assigned FIT Analyst will then be notified by Signavio to complete filing
					(if applicable) and implementation tasks.
				</li>
			</ul>
			<li>
				If the Signavio case does not need to be restarted, proceed with filing (if
				applicable) and implementation tasks once the updated rate revision has been
				initiated.
			</li>
		</ul>
	</li>
</ul>
<p>The BIRST files are located here: ${hyperlink}</p>
<b>Rate Revision Details</b>
<table border="1" cellpadding="4" cellspacing="0">
	<tbody>
		<tr>
			<td bgcolor="#072A6C">Scenario ID</td>
			<td>${args.scenarioFile.scenarioForm.scenarioId}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">State</td>
			<td>${args.scenarioFile.scenarioForm.geoState}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Line of Business</td>
			<td>${args.scenarioFile.scenarioForm.lineOfBusiness}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Product</td>
			<td>${product}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Version</td>
			<td>${args.scenarioFile.scenarioForm.version}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">New Business Date</td>
			<td>${newBusinessDate}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Renewal Date</td>
			<td>${renewalDate}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Available Date</td>
			<td>${availableDate}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Impact Amount</td>
			<td>${impactAmount}</td>
		</tr>
		<tr>
			<td bgcolor="#072A6C">Impact Percent</td>
			<td>${impactPercent}</td>
		</tr>
	</tbody>
</table>
<br />
`;

return { subject, body };
