import { join } from "path";
import { app } from "electron";
import { execute } from "../database";
import { RatesBeingUsed } from "./types";
import { userSettings } from "../user-settings";
import { scenarioFile } from "../scenario-file";
import { addConsoleMessage, stopConsoleMessageTimer } from "../console-message";
import { getRateTypeMessage, getUiMessageIdForCalculatePremium } from "./messages";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";

export const calculatePremium = async (
	ratesBeingUsed: RatesBeingUsed,
	implementedInitiatives?: string[],
): Promise<void> => {
	try {
		const message = `Calculating ${getRateTypeMessage(ratesBeingUsed)} premium...`;

		addConsoleMessage({
			text: message,
			hasTimer: true,
			timerId: getUiMessageIdForCalculatePremium(ratesBeingUsed),
		});

		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CalculatePremium),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					ratesBeingUsed,
					scenarioFile,
					implementedInitiatives: implementedInitiatives
						? implementedInitiatives.join(",")
						: "",
				},
			}),
		);

		await execute({ sqlText });
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(getUiMessageIdForCalculatePremium(ratesBeingUsed));
	}
};
