import { join } from "path";
import * as xlsx from "xlsx";
import { app, MessageBoxOptions, dialog } from "electron";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { execute } from "../database";
import { workbook } from "../rates-file";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { ReusedScenarioId, ScenarioForm } from "./types";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";

/**
 * Compares the scenario details from the rates file that is currently loaded
 * with the scenario inputs of the currently loaded scenario file. If there are
 * any differences, it returns an array of records containing the mismatches.
 * Otherwise, it returns an empty array.
 */
export const getScenarioDetailMismatches = (): string[] => {
	let mismatches: string[] = [];

	// For backwards compatibility, return early if the workbook does not
	// contain the scenario_details worksheet.
	const worksheet = workbook.Sheets["scenario_details"];
	if (!worksheet) return [];

	// Since the scenario details are not stored in typical tabular format,
	// i.e., column A is the "header" and column B are the "rows", we need to
	// pass the header option as 1 to create an array of arrays.
	const scenarioDetails: unknown[][] = xlsx.utils.sheet_to_json(worksheet, {
		header: 1,
	});

	// Maps the values from column A of the scenario_details worksheet to the
	// property names of the scenarioFile.scenarioForm object.
	const map = {
		"Run Mode": "runMode",
		"Query Method": "queryMethod",
		"In-force Date": "inforceDate",
		"Data Source": "dataSource",
		State: "geoState",
		"Line of Business": "lineOfBusiness",
		Product: "product",
		Version: "version",
		"Renewal Date": "renewalDate",
		"New Date": "newDate",
		"Available Date": "availableDate",
		"Countrywide Data": "useCountrywideData",
		"All Versions Data": "useAllVersionsData",
		"WC Adopt Bureau Rates": "workCompAdoptBureauRates",
		"WC Bureau Effective Date": "workCompBureauEffectiveDate",
		"WC Bureau Release Date": "workCompBureauReleaseDate",
		"WC Bureau Status Flag": "workCompBureauStatusFlag",
	};

	for (const detail of scenarioDetails) {
		const key = detail[0];
		let ratesFileValue = detail[1];

		// Skipping these fields based on notes below.
		if (
			[
				// For backwards compatibility since scenario ID used to be
				// included in the scenario details.
				"Scenario ID",
				// Rates file is only available in rate change mode.
				"Run Mode",
				// Rate change mode only allows in-force method.
				"Query Method",
				// Same rates file can be used regardless of data source.
				"Data Source",
				// This field does not apply to rate change mode.
				"Start Date",
				// This field does not apply to rate change mode.
				"End Date",
				// Same rates file can be used regardless of this option.
				"Countrywide Data",
				// Same rates file can be used regardless of this option.
				"All Versions Data",
			].includes(String(key))
		) {
			continue;
		}

		if (
			Object.prototype.toString.call(ratesFileValue) === "[object Date]" ||
			ratesFileValue instanceof Date
		) {
			ratesFileValue = (ratesFileValue as Date).toISOString().substring(0, 10);
		}

		// Swapping scenarioFileValue and ratesFileValues with empty strings in
		// case underlying values are falsey, e.g., undefined or null. Otherwise
		// false positives may trigger.

		const scenarioFileValue = scenarioFile.scenarioForm[
			map[key as keyof typeof map] as keyof ScenarioForm
		]
			? scenarioFile.scenarioForm[map[key as keyof typeof map] as keyof ScenarioForm]
			: "";

		// \xa0 = one white space
		// \u2022 = bullet point
		if (String(ratesFileValue ? ratesFileValue : "") !== String(scenarioFileValue)) {
			mismatches.push(
				`${key}:\n\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0Rates file: ${String(
					ratesFileValue,
				)}\n\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0Current scenario: ${String(
					scenarioFileValue,
				)}`,
			);
		}
	}

	return mismatches;
};

export const showWarningMismatchedScenarioDetails = async (
	mismatches: string[],
): Promise<boolean> => {
	await logAsync({
		type: "WARNING",
		subType: "BACKEND",
		payload: `Mismatching scenario details between rates file and current scenario: ${mismatches
			.join(", ")
			.replaceAll("\n", " ")
			.replaceAll("\xa0", "")}`,
	});

	// \xa0 = one white space
	// \u2022 = bullet point
	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["No", "Yes"],
		defaultId: 0,
		cancelId: 0,
		noLink: true,
		title: " Confirmation Required",
		message:
			"The following scenario details found in the rates file differ from the current scenario:\n" +
			mismatches.map((mismatch) => "\xa0\xa0\xa0\xa0\u2022\xa0" + mismatch).join("\n") +
			"\n\nYou should consider recreating the rates file using the current scenario inputs." +
			"\n\nAre you sure you want to continue?",
	};

	return !!(await dialog.showMessageBox(mainWindow, dialogOptions)).response;
};

export const getReusedScenarioIds = async (): Promise<ReusedScenarioId[]> => {
	const reusedScenarioIds: ReusedScenarioId[] = [];

	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CheckForReusedScenarioId),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioFile: scenarioFile,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });

		if (rs && rs.length) {
			for (const r of rs as Record<string, unknown>[]) {
				reusedScenarioIds.push({
					scenarioId: String(r["SCENARIO_ID"]),
					createdBy: String(r["CREATED_BY"]),
					createdAtUtc: r["CREATED_AT_UTC"] as Date,
					geoState: String(r["GEO_STATE"]),
					lineOfBusiness: String(r["LINE_OF_BUSINESS"]),
					product: String(r["PRODUCT"]),
					version: String(r["VERSION"]),
				});
			}

			return reusedScenarioIds;
		}

		return [];
	} catch (err) {
		throw err;
	}
};

export const showWarningReusedScenarioIds = async (
	reusedScenarioIds: ReusedScenarioId[],
): Promise<boolean> => {
	await logAsync({
		type: "WARNING",
		subType: "BACKEND",
		payload: `Reused scenario ID detected. Current product State: ${
			scenarioFile.scenarioForm.geoState
		} / LOB: ${scenarioFile.scenarioForm.lineOfBusiness} / Product: ${
			scenarioFile.scenarioForm.product
		} / Version: ${scenarioFile.scenarioForm.version}. Previous product(s): ${reusedScenarioIds
			.map(
				(x) =>
					`User ID: ${x.createdBy} / State: ${x.geoState} / LOB: ${
						x.lineOfBusiness
					} / Product: ${x.product} / Version: ${
						x.version
					} / Timestamp: ${x.createdAtUtc.toLocaleString()}`,
			)
			.join(" -- ")}`,
	});

	// \xa0 = one white space
	// \u2022 = bullet point
	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["No", "Yes"],
		defaultId: 0,
		cancelId: 0,
		noLink: true,
		title: " Confirmation Required",
		message:
			"It appears that this scenario ID has already been used for the following product(s):\n" +
			reusedScenarioIds
				.map(
					(x) =>
						"\xa0\xa0\xa0\xa0\u2022\xa0" +
						`User ID: ${x.createdBy} / State: ${x.geoState} / LOB: ${
							x.lineOfBusiness
						} / Product: ${x.product} / Version: ${
							x.version
						} / Timestamp: ${x.createdAtUtc.toLocaleString()}`,
				)
				.join("\n") +
			"\n\nSince the product for the current scenario differs from the product(s) above, it is recommended to start a new scenario by clicking on the Scenario -> New button. This will ensure that a new scenario ID is generated for this scenario." +
			"\n\nAre you sure you want to continue?",
	};

	return !!(await dialog.showMessageBox(mainWindow, dialogOptions)).response;
};
