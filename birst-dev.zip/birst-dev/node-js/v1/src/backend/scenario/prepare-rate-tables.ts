import { join } from "path";
import { app } from "electron";
import { Binds } from "snowflake-sdk";
import { execute } from "../database";
import { RatesBeingUsed } from "./types";
import { userSettings } from "../user-settings";
import { scenarioFile } from "../scenario-file";
import { addConsoleMessage, stopConsoleMessageTimer } from "../console-message";
import { getRateTypeMessage, getUiMessageIdForPrepareRateTables } from "./messages";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import {
	tablesForUpload,
	RateTableForUpload,
	TABLES_WITHOUT_NB_EFF_DATE,
	TABLES_WITHOUT_WRITTEN_DATE,
} from "../rates-file";

export const prepareRateTables = async (ratesBeingUsed: RatesBeingUsed): Promise<void> => {
	const message = `Preparing ${getRateTypeMessage(ratesBeingUsed)} rate tables...`;

	try {
		addConsoleMessage({
			text: message,
			hasTimer: true,
			timerId: getUiMessageIdForPrepareRateTables(ratesBeingUsed),
		});

		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.PrepareRateTables),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					ratesBeingUsed: ratesBeingUsed,
					scenarioFile,
				},
			}),
		);

		await execute({ sqlText });

		if (ratesBeingUsed === RatesBeingUsed.Proposed) {
			await overwriteCurrentRatesWithProposedRates("_PROPOSED");
		}
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(getUiMessageIdForPrepareRateTables(ratesBeingUsed));
	}
};

const overwriteCurrentRatesWithProposedRates = async (suffix: string): Promise<void> => {
	const proposedRatesTables = getProposedRatesTables(suffix);

	for (const table of proposedRatesTables) {
		try {
			await execute({ sqlText: `TRUNCATE TABLE ${table.tableName};` });

			await execute({
				sqlText: getInsertStatement(table),
				binds: getBindings(table.records),
			});
		} catch (err) {
			throw new Error(
				`Unable to insert proposed rates for table ${table.tableName}: ${String(err)}`,
			);
		}
	}
};

const getProposedRatesTables = (suffix: string): RateTableForUpload[] => {
	const newTables: RateTableForUpload[] = [];
	let newRecords: Record<string, unknown>[] = [];

	for (const table of tablesForUpload) {
		newRecords = [];

		for (const record of table.records) {
			const deepCopy = JSON.stringify(record); // Don't mutate original data.
			const newRecord = JSON.parse(deepCopy);

			// Redesigned CMP raters.
			if (
				scenarioFile.scenarioForm.lineOfBusiness === "CMP" &&
				["HAB", "REA", "ROS", "RST"].includes(scenarioFile.scenarioForm.product)
			) {
				newRecord.ID = 0; // Dummy value, can be any integer.
				newRecord.NEW_DATE = "1900-01-01";
				newRecord.RENEWAL_DATE = "1900-01-01";
				newRecord.AVAILABLE_DATE = "1900-01-01";
				newRecord.NEW_DATE_EXPIRATION = "9999-12-31";
				newRecord.RENEWAL_DATE_EXPIRATION = "9999-12-31";
			}
			// Legacy WC rater.
			else if (scenarioFile.scenarioForm.lineOfBusiness === "WC") {
				newRecord.RB_EFF_DT = "1900-01-01";
				newRecord.RB_END_EFF_DT = "9999-12-31";
			}
			// All other legacy raters.
			else {
				newRecord.NB_EFF_DT = "1900-01-01";
				newRecord.NB_EFF_DATE = "1900-01-01";
				newRecord.NB_END_EFF_DT = "9999-12-31";
				newRecord.RB_EFF_DT = "1900-01-01";
				newRecord.RB_EFF_DATE = "1900-01-01";
				newRecord.RB_END_EFF_DT = "9999-12-31";
				newRecord.WRITTEN_DATE = "1900-01-01";

				// Remove properties that don't exist for certain rate tables.
				if (TABLES_WITHOUT_NB_EFF_DATE.includes(table.tableName.toUpperCase())) {
					delete newRecord.NB_EFF_DATE;
				}

				if (TABLES_WITHOUT_WRITTEN_DATE.includes(table.tableName.toUpperCase())) {
					delete newRecord.WRITTEN_DATE;
				}
			}

			newRecords.push(newRecord);
		}

		newTables.push({
			tableName: table.tableName + suffix,
			records: newRecords,
		});
	}

	return newTables;
};

const getInsertStatement = (table: RateTableForUpload): string =>
	`INSERT INTO ${table.tableName} (${getCommaDelimitedColumnNames(
		table.records[0],
	)}) VALUES(${getCommaDelimitedQuestionMarks(table.records[0])});`;

const getCommaDelimitedColumnNames = (record: Record<string, unknown>): string =>
	Object.keys(record).join(",");

const getCommaDelimitedQuestionMarks = (record: Record<string, unknown>): string =>
	Object.keys(record)
		.map(() => "?")
		.join(",");

const getBindings = (records: Record<string, unknown>[]): Binds => {
	const arrayOfArrays: unknown[][] = [];

	for (const record of records) {
		const arrayOfValues: unknown[] = [];

		Object.values(record).forEach((value) => {
			arrayOfValues.push(value);
		});

		arrayOfArrays.push(arrayOfValues);
	}

	return arrayOfArrays as Binds;
};
