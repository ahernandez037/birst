import * as xlsx from "xlsx";
import { DateTime } from "luxon";
import { scenarioFile } from "../scenario-file";

/**
 * Used to add scenario details to an Excel worksheet named "scenario_details"
 * for the given workbook, such as for the rates file and report file.
 */
export const addScenarioDetailsToExcelWorkbook = (workbook: xlsx.WorkBook): void => {
	// ! If changing the schema of this object, e.g., adding/removing details,
	// ! make sure to also update the BIRST File Formatter as it makes
	// ! references to the Excel cell values by column and row. Therefore, any
	// ! change to the order of these rows could result in wrong output from the
	// ! BIRST File Formatter.
	const scenarioDetails = [
		["Run Mode", scenarioFile.scenarioForm.runMode],
		["Query Method", scenarioFile.scenarioForm.queryMethod],
		[
			"In-force Date",
			scenarioFile.scenarioForm.inforceDate
				? DateTime.fromISO(scenarioFile.scenarioForm.inforceDate).toJSDate()
				: "",
		],
		[
			"Start Date",
			scenarioFile.scenarioForm.startDate
				? DateTime.fromISO(scenarioFile.scenarioForm.startDate).toJSDate()
				: "",
		],
		[
			"End Date",
			scenarioFile.scenarioForm.endDate
				? DateTime.fromISO(scenarioFile.scenarioForm.endDate).toJSDate()
				: "",
		],
		["Data Source", scenarioFile.scenarioForm.dataSource],
		["State", scenarioFile.scenarioForm.geoState],
		["Line of Business", scenarioFile.scenarioForm.lineOfBusiness],
		[
			"Product",
			["AUTO", "CMP"].includes(scenarioFile.scenarioForm.lineOfBusiness)
				? scenarioFile.scenarioForm.product
				: "",
		],
		[
			"Version",
			scenarioFile.scenarioForm.product === "AUTO" ||
			scenarioFile.scenarioForm.lineOfBusiness === "WC"
				? scenarioFile.scenarioForm.version
				: "",
		],
		[
			"Renewal Date",
			scenarioFile.scenarioForm.renewalDate
				? DateTime.fromISO(scenarioFile.scenarioForm.renewalDate).toJSDate()
				: "",
		],
		[
			"New Date",
			scenarioFile.scenarioForm.newDate
				? DateTime.fromISO(scenarioFile.scenarioForm.newDate).toJSDate()
				: "",
		],
		[
			"Available Date",
			scenarioFile.scenarioForm.availableDate
				? DateTime.fromISO(scenarioFile.scenarioForm.availableDate).toJSDate()
				: "",
		],
		["Countrywide Data", scenarioFile.scenarioForm.useCountrywideData],
		[
			"All Versions Data",
			scenarioFile.scenarioForm.product === "AUTO" ||
			scenarioFile.scenarioForm.lineOfBusiness === "WC"
				? scenarioFile.scenarioForm.useAllVersionsData
				: "",
		],
		[
			"WC Adopt Bureau Rates",
			scenarioFile.scenarioForm.lineOfBusiness === "WC"
				? scenarioFile.scenarioForm.workCompAdoptBureauRates
				: "",
		],
		[
			"WC Bureau Effective Date",
			scenarioFile.scenarioForm.workCompBureauEffectiveDate
				? DateTime.fromISO(scenarioFile.scenarioForm.workCompBureauEffectiveDate).toJSDate()
				: "",
		],
		[
			"WC Bureau Release Date",
			scenarioFile.scenarioForm.workCompBureauReleaseDate
				? DateTime.fromISO(scenarioFile.scenarioForm.workCompBureauReleaseDate).toJSDate()
				: "",
		],
		[
			"WC Bureau Status Flag",
			scenarioFile.scenarioForm.workCompBureauStatusFlag
				? scenarioFile.scenarioForm.workCompBureauStatusFlag
				: "",
		],
	];

	// Only add the scenario_details worksheet if the workbook doesn't already
	// have it, e.g., the FIT exhibits template already has it. If the worksheet
	// already exists, then just copy the details into the existing worksheet.
	const worksheet = workbook.Sheets["scenario_details"];

	if (!worksheet) {
		xlsx.utils.book_append_sheet(
			workbook,
			xlsx.utils.aoa_to_sheet(scenarioDetails),
			"scenario_details",
		);
	} else {
		xlsx.utils.sheet_add_aoa(worksheet, scenarioDetails, { origin: "B1" });
	}
};
