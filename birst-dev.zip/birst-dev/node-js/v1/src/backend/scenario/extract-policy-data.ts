import { join } from "path";
import { app } from "electron";
import { log } from "../logger";
import { execute } from "../database";
import { userSettings } from "../user-settings";
import { scenarioFile } from "../scenario-file";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export const extractPolicyData = async (): Promise<void> => {
	// Return early for Auto Flex Rollouts since they rely on a static dataset
	// instead of a live FDRC data extract.
	if (scenarioFile.scenarioForm.isAutoFlexRollout) return;

	// Additional logic for Commercial Auto since it uses an additional data
	// extract table for driver data.
	if (
		scenarioFile.scenarioForm.lineOfBusiness === "AUTO" &&
		scenarioFile.scenarioForm.product === "AUTO"
	) {
		let numberOfOverrides = 0;

		if (
			scenarioFile.scenarioForm.policyDataOverrideTable !== "N/A" &&
			scenarioFile.scenarioForm.policyDataOverrideTable !== ""
		) {
			addConsoleMessage({
				text: `Using policy data from static dataset: ${scenarioFile.scenarioForm.policyDataOverrideTable}`,
			});

			log({
				type: "INFO",
				subType: "BACKEND",
				payload: `Using policy data from static dataset: ${scenarioFile.scenarioForm.policyDataOverrideTable}`,
			});

			numberOfOverrides++;
		}

		if (
			scenarioFile.scenarioForm.driverDataOverrideTable !== "N/A" &&
			scenarioFile.scenarioForm.driverDataOverrideTable !== ""
		) {
			addConsoleMessage({
				text: `Using driver data from static dataset: ${scenarioFile.scenarioForm.driverDataOverrideTable}`,
			});

			log({
				type: "INFO",
				subType: "BACKEND",
				payload: `Using driver data from static dataset: ${scenarioFile.scenarioForm.driverDataOverrideTable}`,
			});

			numberOfOverrides++;
		}

		// If both tables, i.e., policy and driver, are being overridden, then
		// don't need to execute the extract policy data procedure. Else, if only
		// 1, or none, are being overridden, then continue with executing the
		// extract policy data procedure. Note that any corresponding override
		// table will still be used, however, need to run the data extract
		// procedure for the other table that's not being overridden.
		if (numberOfOverrides === 2) return;
	}
	// For other LOBs/products, e.g., CMP, Garage, etc. (only Auto uses the
	// driver table).
	else if (
		scenarioFile.scenarioForm.policyDataOverrideTable !== "N/A" &&
		scenarioFile.scenarioForm.policyDataOverrideTable !== ""
	) {
		addConsoleMessage({
			text: `Using policy data from static dataset: ${scenarioFile.scenarioForm.policyDataOverrideTable}`,
		});

		log({
			type: "INFO",
			subType: "BACKEND",
			payload: `Using policy data from static dataset: ${scenarioFile.scenarioForm.policyDataOverrideTable}`,
		});

		return;
	}

	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.ExtractPolicyData),
			)
		)[0];

		// To enable support for the Umbrella line of business, which requires
		// separate data extracts to for the underlying LOBs, e.g., CMP & Auto,
		// the SQL function here is unique compared to most others because it
		// returns an array of strings. For non-Umbrella LOBs, we simply take
		// the first array element, but for the Umbrella LOB, we need to take a
		// total of 4 strings that each contain the SQL code to execute for each
		// LOB data extract.
		const arrayOfQueries = executeDynamicJsFunction({
			dynamicJsFunction,
			functionArguments: {
				isProduction: app.isPackaged,
				scenarioFile,
			},
		});

		if (scenarioFile.scenarioForm.lineOfBusiness === "UMB") {
			await runDatabaseProcedure({
				sqlText: (arrayOfQueries as string[])[0],
				consoleMessage: "Extracting CMP policy data...",
				consoleMessageId: ConsoleMessageId.ExtractingUmbrellaCmpPolicyData,
			});

			await runDatabaseProcedure({
				sqlText: (arrayOfQueries as string[])[1],
				consoleMessage: "Extracting Auto policy data...",
				consoleMessageId: ConsoleMessageId.ExtractingUmbrellaAutoPolicyData,
			});

			await runDatabaseProcedure({
				sqlText: (arrayOfQueries as string[])[2],
				consoleMessage: "Extracting Garage policy data...",
				consoleMessageId: ConsoleMessageId.ExtractingUmbrellaGaragePolicyData,
			});

			await runDatabaseProcedure({
				sqlText: (arrayOfQueries as string[])[3],
				consoleMessage: "Extracting Umbrella policy data...",
				consoleMessageId: ConsoleMessageId.ExtractingUmbrellaPolicyData,
			});

			// TODO: As a future enhancement for Umbrella, run three procedures
			// TODO: concurrently. In order to enable this, the data extract
			// TODO: procedures need to be refactored to use unique temp table
			// TODO: names because right now they use the same names, e.g.,
			// TODO: policy_level, location_level, etc., which causes collisions
			// TODO: resulting in errors. Once this refactor is done, the code
			// TODO: below should work. Until then, running procedures sequentially.
			// await Promise.all([
			// 	runDatabaseProcedure({
			// 		sqlText: (arrayOfQueries as string[])[0],
			// 		consoleMessage: "Extracting CMP policy data...",
			// 		consoleMessageId: ConsoleMessageId.ExtractingUmbrellaCmpPolicyData,
			// 	}).catch((err) => {
			// 		throw err;
			// 	}),
			// 	runDatabaseProcedure({
			// 		sqlText: (arrayOfQueries as string[])[1],
			// 		consoleMessage: "Extracting Auto policy data...",
			// 		consoleMessageId: ConsoleMessageId.ExtractingUmbrellaAutoPolicyData,
			// 	}).catch((err) => {
			// 		throw err;
			// 	}),
			// 	runDatabaseProcedure({
			// 		sqlText: (arrayOfQueries as string[])[2],
			// 		consoleMessage: "Extracting Garage policy data...",
			// 		consoleMessageId: ConsoleMessageId.ExtractingUmbrellaGaragePolicyData,
			// 	}).catch((err) => {
			// 		throw err;
			// 	}),
			// ])
			// 	.then(async () => {
			// 		await runDatabaseProcedure({
			// 			sqlText: (arrayOfQueries as string[])[3],
			// 			consoleMessage: "Extracting Umbrella policy data...",
			// 			consoleMessageId: ConsoleMessageId.ExtractingUmbrellaPolicyData,
			// 		}).catch((err) => {
			// 			throw err;
			// 		});
			// 	})
			// 	.catch((err) => {
			// 		throw err;
			// 	});
		} else {
			await runDatabaseProcedure({
				sqlText: (arrayOfQueries as string[])[0],
				consoleMessage: "Extracting policy data...",
				consoleMessageId: ConsoleMessageId.ExtractingPolicyData,
			});
		}
	} catch (err) {
		throw err;
	}
};

const runDatabaseProcedure = async (args: {
	sqlText: string;
	consoleMessage: string;
	consoleMessageId: ConsoleMessageId;
}): Promise<void> => {
	try {
		addConsoleMessage({
			text: args.consoleMessage,
			hasTimer: true,
			timerId: args.consoleMessageId,
		});

		await execute({ sqlText: args.sqlText });
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(args.consoleMessageId);
	}
};
