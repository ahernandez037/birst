import { join } from "path";
import { app } from "electron";
import { execute } from "../database";
import { RatesBeingUsed } from "./types";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { getRateTypeMessage, getUiMessageIdForGetRateData } from "./messages";
import { addConsoleMessage, stopConsoleMessageTimer } from "../console-message";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";

export const assignRates = async (ratesBeingUsed: RatesBeingUsed): Promise<void> => {
	const message = `Assigning ${getRateTypeMessage(ratesBeingUsed)} rates...`;

	addConsoleMessage({
		text: message,
		hasTimer: true,
		timerId: getUiMessageIdForGetRateData(ratesBeingUsed),
	});

	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.AssignRates),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					ratesBeingUsed,
					scenarioFile,
				},
			}),
		);

		await execute({ sqlText });
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(getUiMessageIdForGetRateData(ratesBeingUsed));
	}
};
