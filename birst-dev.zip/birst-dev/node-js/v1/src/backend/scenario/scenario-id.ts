import { customAlphabet } from "nanoid";

export const createScenarioId = customAlphabet("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 16);

export let scenarioId = createScenarioId();

export const updateScenarioId = (newScenarioId: string): void => {
	scenarioId = newScenarioId;
};
