import { MessageBoxOptions, dialog, ipcMain } from "electron";
import { RunMode } from "./types";
import { runScenario } from "./run";
import { logAsync } from "../logger";
import { isFileOpen } from "../utilities";
import { IpcMessage } from "../ipc-handlers";
import { ExecutionState } from "../app-settings";
import { mainWindow, updateExecutionState } from "../main";
import { addConsoleMessage, Emoji } from "../console-message";
import { createScenarioId, scenarioId, updateScenarioId } from "./scenario-id";
import { doesReportFileExist, getReportFileAbsoluteFilepath } from "../report-file";
import { createTempTableList, saveDebugRunOutput, updateIsDebugRun } from "./debug";
import { doesDataDumpFileExist, getDataDumpFileAbsoluteFilepath } from "../data-dump";
import { prefillScenarioFile, saveScenarioFile, scenarioFile } from "../scenario-file";
import {
	loadRatesFile,
	doesRatesFileExist,
	getInScopeRateTables,
	getRatesFileAbsoluteFilepath,
} from "../rates-file";
import {
	getReusedScenarioIds,
	getScenarioDetailMismatches,
	showWarningReusedScenarioIds,
	showWarningMismatchedScenarioDetails,
} from "./checks";

export const scenarioIpcHandler = (): void => {
	ipcMain.on(IpcMessage.GetCurrentScenarioId, () => {
		mainWindow.webContents.send(IpcMessage.GetScenarioId, scenarioId);
	});

	ipcMain.on(IpcMessage.GetNewScenarioId, () => {
		const newScenarioId = createScenarioId();
		updateScenarioId(newScenarioId);
		mainWindow.webContents.send(IpcMessage.GetScenarioId, newScenarioId);
	});

	ipcMain.on(IpcMessage.RunScenario, async (_event, payload) => {
		// payload[0] = ScenarioForm
		// payload[1] = isDebugRun ... this is only available to developers and
		// is used to run the scenario and save all of the temporary tables
		// that are crated by Snowflake to CSV files locally.
		prefillScenarioFile(JSON.parse(payload[0]));
		updateIsDebugRun(payload[1]);

		if (!(await doesUserWantToOverwrite())) {
			mainWindow.webContents.send(IpcMessage.RunScenarioCanceled);
			return;
		}

		if (scenarioFile.scenarioForm.runMode === RunMode.RateChange) {
			if (!doesRatesFileExist()) {
				addConsoleMessage({
					text: `${Emoji.Warning} The rates file does not exist. Please create the file before proceeding.`,
				});

				await logAsync({
					type: "WARNING",
					subType: "BACKEND",
					payload: `The rates file does not exist: ${getRatesFileAbsoluteFilepath()}`,
				});

				mainWindow.webContents.send(IpcMessage.RunScenarioError);
				return;
			}

			if (await isFileOpen(getRatesFileAbsoluteFilepath())) {
				addConsoleMessage({
					text: `${Emoji.Warning} The rates file is currently open. Please close the file before proceeding.`,
				});

				await logAsync({
					type: "WARNING",
					subType: "BACKEND",
					payload: `The rates file is currently open: ${getRatesFileAbsoluteFilepath()}`,
				});

				mainWindow.webContents.send(IpcMessage.RunScenarioError);
				return;
			}
		}

		if (scenarioFile.scenarioForm.saveDataDumpToHardDrive) {
			if (await isFileOpen(getDataDumpFileAbsoluteFilepath())) {
				addConsoleMessage({
					text: `${Emoji.Warning} The data dump file is currently open. Please close the file before proceeding.`,
				});

				await logAsync({
					type: "WARNING",
					subType: "BACKEND",
					payload: `The data dump file is currently open: ${getDataDumpFileAbsoluteFilepath()}`,
				});

				mainWindow.webContents.send(IpcMessage.RunScenarioError);
				return;
			}
		}

		if (
			scenarioFile.scenarioForm.runMode === RunMode.RateChange ||
			scenarioFile.scenarioForm.runMode === RunMode.Validation
		) {
			if (await isFileOpen(getReportFileAbsoluteFilepath())) {
				addConsoleMessage({
					text: `${Emoji.Warning} The report file is currently open. Please close the file before proceeding.`,
				});

				await logAsync({
					type: "WARNING",
					subType: "BACKEND",
					payload: `The report file is currently open: ${getReportFileAbsoluteFilepath()}`,
				});

				mainWindow.webContents.send(IpcMessage.RunScenarioError);
				return;
			}
		}

		try {
			if (scenarioFile.scenarioForm.runMode === RunMode.RateChange) {
				await loadRatesFile();
				const scenarioDetailMismatches = getScenarioDetailMismatches();

				if (scenarioDetailMismatches.length > 0) {
					if (!(await showWarningMismatchedScenarioDetails(scenarioDetailMismatches))) {
						mainWindow.webContents.send(IpcMessage.RunScenarioCanceled);
						return;
					}
				}

				const reusedScenarioIds = await getReusedScenarioIds();

				if (reusedScenarioIds.length > 0) {
					if (!(await showWarningReusedScenarioIds(reusedScenarioIds))) {
						mainWindow.webContents.send(IpcMessage.RunScenarioCanceled);
						return;
					}
				}

				showInScopeTables();
			}

			updateExecutionState(ExecutionState.RunningScenario);
			await createTempTableList();
			await saveScenarioFile();
			await runScenario();
			if (payload[1]) await saveDebugRunOutput();
			mainWindow.webContents.send(IpcMessage.RunScenarioSuccess);
		} catch (err) {
			const errorString = String(err).trim();

			if (
				errorString.includes(
					"The rates file is currently open. Please close the file before proceeding.",
				)
			) {
				addConsoleMessage({
					text: `${Emoji.Warning} The rates file is currently open. Please close the file before proceeding.`,
				});

				await logAsync({
					type: "WARNING",
					subType: "BACKEND",
					payload: `The rates file is currently open: ${getRatesFileAbsoluteFilepath()}`,
				});
			} else if (
				!errorString.toUpperCase().includes("TYPEERROR: OBJECT HAS BEEN DESTROYED")
			) {
				// Suppress error logging for the 'object has been destroyed'
				// error as this is emitted whenever the  user quits the app
				// while a scenario is running.

				addConsoleMessage({ text: `${Emoji.Error} ${errorString}` });

				await logAsync({
					type: "ERROR",
					subType: "BACKEND",
					payload: errorString,
				});

				mainWindow.webContents.send(IpcMessage.RunScenarioError);
			}
		} finally {
			updateExecutionState(ExecutionState.AtRest);
		}
	});
};

const doesUserWantToOverwrite = async (): Promise<boolean> => {
	const listOfExistingFiles = getListOfExistingFiles();
	if (!listOfExistingFiles) return true;

	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["No", "Yes"],
		defaultId: 0,
		cancelId: 0,
		noLink: true,
		title: " Confirmation Required",
		message:
			"The following file(s) already exists:\n" +
			listOfExistingFiles +
			"\nAre you sure you want to overwrite?",
	};

	return !!(await dialog.showMessageBox(mainWindow, dialogOptions)).response;
};

const getListOfExistingFiles = (): string => {
	let output = "";
	// Add white space & bullet points.
	const bulletPointWithWhiteSpace = "\xa0\xa0\xa0\xa0\u2022\xa0";

	if (scenarioFile.scenarioForm.saveDataDumpToHardDrive && doesDataDumpFileExist()) {
		output += bulletPointWithWhiteSpace + scenarioFile.files.dataDumpFile + "\n";
	}

	if (doesReportFileExist()) {
		output += bulletPointWithWhiteSpace + scenarioFile.files.reportFile + "\n";
	}

	return output;
};

const showInScopeTables = (): void => {
	const inScopeTables = getInScopeRateTables();
	// Add white space & bullet points.
	const inScopeTablesList = inScopeTables.length
		? inScopeTables
				.map((table) => "\xa0\xa0\xa0\xa0\u2022\xa0" + table.fullTableName)
				.join("\n")
		: [];

	const inScopeTablesMessage = inScopeTables.length
		? `The following rate tables are in scope:\n${inScopeTablesList}`
		: "There are no rate tables in scope, i.e., no rate changes were made.";

	const dialogOptions: MessageBoxOptions = {
		type: "info",
		buttons: [],
		noLink: true,
		title: " For Your Information",
		message: inScopeTablesMessage,
	};

	dialog.showMessageBox(mainWindow, dialogOptions);
};
