File:
	network-drives.vbs
Purpose:
	Script used by Node.js to get the user's network drive mappings. For example, is the 632 shared drive mapped to Y:, X:, Z:, etc.
