export const enum ExecutionState {
	AtRest = "atRest",
	CreatingRatesFile = "creatingRatesFile",
	RunningScenario = "runningScenario",
	InitiatingRateRevision = "initiatingRateRevision",
	CancelingRateRevision = "cancelingRateRevision",
	SavingRatesAndGeneratingOutput = "savingRatesAndGeneratingOutput",
}

export interface AutoUpdaterSettings {
	feedUrl: string;
	checkForUpdatesInterval: number | null | undefined;
}

export interface MaintenanceSettings {
	reloadInterval: number | null | undefined;
	/* Scenario */
	disableScenario: boolean;
	disableScenarioNew: boolean;
	disableScenarioLoad: boolean;
	disableScenarioClone: boolean;
	disableScenarioDirectory: boolean;
	disableScenarioRun: boolean;
	/* Rates File */
	disableRatesFile: boolean;
	disableRatesFileCreate: boolean;
	disableRatesFileOpen: boolean;
	/* Rate Plan */
	disableRatePlan: boolean;
	disableRatePlanCurrent: boolean;
	disableRatePlanUsed: boolean;
	/* Rate Revision */
	disableRateRevision: boolean;
	disableRateRevisionExecutiveSummary: boolean;
	disableRateRevisionInitiateRateRevision: boolean;
	disableRateRevisionCancelRateRevision: boolean;
	disableRateRevisionOpenFitDirectory: boolean;
	disableRateRevisionSaveRatesAndGenerateOutput: boolean;
	disableRateRevisionSendRequestToDeleteRates: boolean;
	disableRateRevisionSaveRates: boolean;
	disableRateRevisionDeleteRates: boolean;
	disableRateRevisionCreateClsFiles: boolean;
	disableRateRevisionCreateRatabaseFiles: boolean;
	/* Next Steps */
	disableNextSteps: boolean;
	/* Settings */
	disableSaveSettings: boolean;
	/* Support */
	disableUsersGuide: boolean;
	disableTechnicalDocumentation: boolean;
	disableReportProblem: boolean;
	disableSubmitFeedback: boolean;
}

export interface SnowflakeSettings {
	account: string;
	authenticator: string;
	roleForFit: string;
	roleForDeveloper: string;
	roleForOthers: string;
	warehouseForFit: string;
	warehouseForDeveloper: string;
	warehouseForOthers: string;
	role: string;
	warehouse: string;
	database: string;
	schema: string;
	dataDumpDatabaseSchema: string;
}

export interface AnnouncementsForConsole {
	header: string;
	footer: string;
	announcements: string[];
}
