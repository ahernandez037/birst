const htmlContent = "";

return {
	htmlContent,
	modalWidth: null,
	modalHeight: null,
	buttons: [],
	title: "Important Announcement",
};
