import { ipcMain } from "electron";
import { IpcMessage } from "../ipc-handlers";
import { getMonitorData, updateRefreshInterval } from "./init";

export const monitorIpcHandler = (): void => {
	ipcMain.on(IpcMessage.GetMonitorData, () => {
		getMonitorData();
	});

	ipcMain.on(IpcMessage.UpdateMonitorRefreshInterval, (_event, payload) => {
		updateRefreshInterval(payload[0]);
	});
};
