export interface ImportantMessage {
	timestamp: Date;
	type: string;
	userId: string;
	scenarioId: string;
	payload: string;
}

export interface AccessLog {
	rowNumber: number;
	userId: string;
	lastAccessed: Date;
	appVersion: string;
}

export interface ScenarioRun {
	date: string;
	userId: string;
	numberOfRuns: number;
}

export interface SumOfScenarioRunsByDate {
	date: string;
	numberOfRuns: number;
}

export interface Runtime {
	product: string;
	numberOfRuns: number;
	averageRuntimeInSeconds: number;
	averageRecordCount: number;
}
