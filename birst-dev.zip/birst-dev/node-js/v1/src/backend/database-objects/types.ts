export interface DatabaseObjects {
	extractPolicyData: string;
	rateTableListCurrent: string;
	rateTableListProposed: string;
	prepareRateTablesCurrent: string;
	prepareRateTablesProposed: string;
	assignRatesCurrent: string;
	assignRatesProposed: string;
	calculatePremiumCurrent: string;
	calculatePremiumProposed: string;
	createDataDump: string;
	createReports: string;
	policyDataOverrideTable: string;
	driverDataOverrideTable: string;
}
