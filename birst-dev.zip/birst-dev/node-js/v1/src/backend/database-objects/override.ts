import { DatabaseObjects } from "./types";
import { ScenarioForm } from "../scenario";

export const overrideDatabaseObjects = (
	scenarioForm: ScenarioForm,
	productionDatabaseObjects: DatabaseObjects,
): DatabaseObjects => ({
	extractPolicyData: scenarioForm.extractPolicyData
		? scenarioForm.extractPolicyData
		: productionDatabaseObjects.extractPolicyData,

	rateTableListCurrent: scenarioForm.rateTableListCurrent
		? scenarioForm.rateTableListCurrent
		: productionDatabaseObjects.rateTableListCurrent,

	rateTableListProposed: scenarioForm.rateTableListProposed
		? scenarioForm.rateTableListProposed
		: productionDatabaseObjects.rateTableListProposed,

	prepareRateTablesCurrent: scenarioForm.prepareRateTablesCurrent
		? scenarioForm.prepareRateTablesCurrent
		: productionDatabaseObjects.prepareRateTablesCurrent,

	prepareRateTablesProposed: scenarioForm.prepareRateTablesProposed
		? scenarioForm.prepareRateTablesProposed
		: productionDatabaseObjects.prepareRateTablesProposed,

	assignRatesCurrent: scenarioForm.assignRatesCurrent
		? scenarioForm.assignRatesCurrent
		: productionDatabaseObjects.assignRatesCurrent,

	assignRatesProposed: scenarioForm.assignRatesProposed
		? scenarioForm.assignRatesProposed
		: productionDatabaseObjects.assignRatesProposed,

	calculatePremiumCurrent: scenarioForm.calculatePremiumCurrent
		? scenarioForm.calculatePremiumCurrent
		: productionDatabaseObjects.calculatePremiumCurrent,

	calculatePremiumProposed: scenarioForm.calculatePremiumProposed
		? scenarioForm.calculatePremiumProposed
		: productionDatabaseObjects.calculatePremiumProposed,

	createDataDump: scenarioForm.createDataDump
		? scenarioForm.createDataDump
		: productionDatabaseObjects.createDataDump,

	createReports: scenarioForm.createReports
		? scenarioForm.createReports
		: productionDatabaseObjects.createReports,

	policyDataOverrideTable: scenarioForm.policyDataOverrideTable
		? scenarioForm.policyDataOverrideTable
		: productionDatabaseObjects.policyDataOverrideTable,

	driverDataOverrideTable: scenarioForm.driverDataOverrideTable
		? scenarioForm.driverDataOverrideTable
		: productionDatabaseObjects.driverDataOverrideTable,
});
