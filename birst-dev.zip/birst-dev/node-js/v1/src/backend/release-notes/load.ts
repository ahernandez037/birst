import { join } from "path";
import { app } from "electron";
import { ReleaseNote } from "./types";
import { mainWindow } from "../main";
import { execute } from "../database";
import { IpcMessage } from "../ipc-handlers";
import { userSettings } from "../user-settings";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export const loadReleaseNotes = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading release notes...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingReleaseNotes,
	});

	try {
		const releaseNotes: ReleaseNote[] = [];
		const rs = await queryDatabase();

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				const fullVersion =
					String(Number(result["MAJOR_VERSION"])) +
					"." +
					String(Number(result["MINOR_VERSION"])) +
					"." +
					String(Number(result["PATCH_VERSION"]));

				releaseNotes.push({
					majorVersion: Number(result["MAJOR_VERSION"]),
					minorVersion: Number(result["MINOR_VERSION"]),
					patchVersion: Number(result["PATCH_VERSION"]),
					fullVersion: fullVersion,
					releaseDate: result["RELEASE_DATE"] as Date,
					category: String(result["CATEGORY"]),
					description: String(result["DESCRIPTION"]),
				});
			}

			mainWindow.webContents.send(
				IpcMessage.UpdateReleaseNotes,
				JSON.stringify(releaseNotes),
			);
		}
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingReleaseNotes);
	}
};

const queryDatabase = async (): Promise<unknown[] | undefined> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetReleaseNotes),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });
		return rs;
	} catch (err) {
		throw err;
	}
};
