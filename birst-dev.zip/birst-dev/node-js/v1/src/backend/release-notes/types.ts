export type ReleaseNoteType = "ANNOUNCEMENT" | "NEW-FEATURE" | "ENHANCEMENT" | "BUG-FIX";

export interface ReleaseNote {
	majorVersion: number;
	minorVersion: number;
	patchVersion: number;
	fullVersion: string;
	releaseDate: Date;
	category: string;
	description: string;
}
