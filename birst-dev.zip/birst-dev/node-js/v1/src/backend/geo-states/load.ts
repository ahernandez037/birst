import { join } from "path";
import { app } from "electron";
import { GeoState } from "./types";
import { mainWindow } from "../main";
import { execute } from "../database";
import { IpcMessage } from "../ipc-handlers";
import { userSettings } from "../user-settings";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export const loadGeoStates = async (): Promise<void> => {
	addConsoleMessage({
		text: "Loading states...",
		hasTimer: true,
		timerId: ConsoleMessageId.LoadingGeoStates,
	});

	try {
		const geoStates: GeoState[] = [];
		const rs = await queryDatabase();

		if (rs) {
			for (const result of rs as Record<string, unknown>[]) {
				geoStates.push({
					name: String(result["STATE_NAME"]),
					abbreviation: String(result["STATE_CODE"]),
					number: Number(result["STATE_NUMBER"]),
				});
			}

			mainWindow.webContents.send(IpcMessage.UpdateGeoStates, JSON.stringify(geoStates));
		}
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.LoadingGeoStates);
	}
};

const queryDatabase = async (): Promise<unknown[] | undefined> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetGeoStateList),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });

		return rs;
	} catch (err) {
		throw err;
	}
};
