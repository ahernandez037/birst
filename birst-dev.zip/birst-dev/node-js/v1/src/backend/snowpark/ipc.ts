import { DateTime } from "luxon";
import * as archiver from "archiver";
import { join, dirname } from "path";
import { ipcMain, dialog } from "electron";
import { readJson, createWriteStream, outputFile } from "fs-extra";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { execute } from "../database";
import { getUncPath } from "../utilities";
import { IpcMessage } from "../ipc-handlers";
import { SnowparkConfigFile } from "./types";
import { userSettings } from "../user-settings";
import {
	ConsoleMessageId,
	Emoji,
	addConsoleMessage,
	stopConsoleMessageTimer,
} from "../console-message";

export const snowparkIpcHandler = (): void => {
	ipcMain.handle(IpcMessage.GetSnowparkConfigFile, async () => {
		return await getSnowparkConfigFile();
	});

	ipcMain.on(IpcMessage.DeploySnowparkProcedure, async (_event, payload) => {
		const startTime = DateTime.now();
		const filepath = payload[0];
		const workingDirectory = dirname(filepath);

		try {
			const configFile = await loadConfigFile(filepath);
			await createZipFile(workingDirectory, configFile.zipFile);
			const sqlStatements = createSqlStatements(workingDirectory, configFile);
			await createDeployScript({ workingDirectory, configFile, sqlStatements });
			await executeSqlStatements(sqlStatements);
			const endTime = DateTime.now();
			const runtimeObject = endTime.diff(startTime, ["minutes", "seconds"]).toObject();
			const runtime = `${runtimeObject.minutes} min ${runtimeObject.seconds?.toFixed(0)} sec`;
			addConsoleMessage({ text: `Finished deploying Snowpark procedure (${runtime})` });
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
			});
		} finally {
			mainWindow.webContents.send(IpcMessage.DoneDeployingSnowparkProcedure);
		}
	});
};

const getSnowparkConfigFile = async () => {
	const file = await dialog.showOpenDialog(mainWindow, {
		properties: ["openFile"],
		defaultPath: userSettings.snowparkDirectory.replace(/\//g, "\\"),
		filters: [
			{ name: "Snowpark Config File", extensions: ["config.json"] },
			{ name: "All Files", extensions: ["*"] },
		],
	});

	if (file.filePaths.length) {
		const uncPath = await getUncPath(file.filePaths[0]);
		return uncPath;
	} else {
		return "";
	}
};

const loadConfigFile = async (filepath: string): Promise<SnowparkConfigFile> => {
	addConsoleMessage({ text: "Loading config file..." });

	try {
		return await readJson(filepath, { throws: true });
	} catch (err) {
		throw err;
	}
};

const createZipFile = async (workingDirectory: string, zipFilename: string): Promise<void> => {
	addConsoleMessage({ text: "Creating zip file..." });
	const output = createWriteStream(join(workingDirectory, zipFilename));
	const archive = archiver("zip", { zlib: { level: 9 } });

	return new Promise((resolve, reject) => {
		output.on("close", () => {
			addConsoleMessage({
				text: `Total bytes written: ${archive.pointer().toLocaleString()}`,
			});

			resolve();
		});

		output.on("end", () => {
			addConsoleMessage({ text: "Data has been drained." });
		});

		archive.on("warning", (err) => {
			if (err.code === "ENOENT") {
				addConsoleMessage({ text: `${Emoji.Warning} ${err.message}` });
			} else {
				reject(err);
				throw err;
			}
		});

		archive.on("error", (err) => {
			reject(err);
			throw err;
		});

		archive.pipe(output);
		archive.glob("**/*.py", { cwd: workingDirectory });
		archive.finalize();
	});
};

const getPosixPath = (path: string): string => path.replace(/\\/g, "/");

const createSqlStatements = (
	workingDirectory: string,
	configFile: SnowparkConfigFile,
): string[] => {
	const sqlStatements: string[] = [];

	addConsoleMessage({ text: "Creating SQL statements..." });

	sqlStatements.push(`use role ${configFile.role};`);
	sqlStatements.push(`use database ${configFile.database};`);
	sqlStatements.push(`use schema ${configFile.schema};`);

	sqlStatements.push(
		`put 'file://${getPosixPath(workingDirectory)}/${configFile.zipFile}' ${
			configFile.stage
		} auto_compress=false overwrite=true;`,
	);

	const create =
		"create or replace " +
		configFile.objectType +
		" " +
		configFile.database +
		"." +
		configFile.schema +
		"." +
		configFile.objectName +
		"(\n" +
		configFile.params.join(",\n") +
		"\n)\n" +
		"returns " +
		configFile.returns +
		"\n" +
		"language python\n" +
		"runtime_version='" +
		configFile.runtimeVersion +
		"'\n" +
		"packages=(" +
		configFile.packages.join(",") +
		")\n" +
		"handler='" +
		configFile.handler +
		"'\n" +
		"imports=('" +
		configFile.stage +
		"/" +
		configFile.zipFile +
		"')\n" +
		"execute as " +
		configFile.executeAs +
		";";

	sqlStatements.push(create);
	return sqlStatements;
};

const createDeployScript = async (args: {
	workingDirectory: string;
	configFile: SnowparkConfigFile;
	sqlStatements: string[];
}): Promise<void> => {
	addConsoleMessage({ text: "Creating deploy script..." });

	try {
		await outputFile(
			join(args.workingDirectory, args.configFile.deployScript),
			args.sqlStatements.join("\n").replace(getPosixPath(args.workingDirectory) + "/", ""),
			{ encoding: "utf8" },
		);
	} catch (err) {
		throw err;
	}
};

const executeSqlStatements = async (sqlStatements: string[]): Promise<void> => {
	addConsoleMessage({
		text: "Executing SQL statements...",
		hasTimer: true,
		timerId: ConsoleMessageId.ExecutingSnowparkDeploySqlStatements,
	});

	try {
		for (const sqlStatement of sqlStatements) {
			await execute({ sqlText: sqlStatement });
		}
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.ExecutingSnowparkDeploySqlStatements);
	}
};
