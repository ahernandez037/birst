import { ipcMain } from "electron";
import { log } from "./log";
import { IpcMessage } from "../ipc-handlers";

export const loggerIpcHandler = (): void => {
	ipcMain.on(IpcMessage.Log, (_event, args) => {
		log({ type: "INFO", subType: args[0], payload: args[1] });
	});
};
