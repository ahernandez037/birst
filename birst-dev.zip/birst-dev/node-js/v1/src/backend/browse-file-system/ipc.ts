import { ipcMain, dialog, OpenDialogOptions } from "electron";
import { log } from "../logger";
import { mainWindow } from "../main";
import { getUncPath } from "../utilities";
import { IpcMessage } from "../ipc-handlers";

export const browseFileSystemIpcHandler = (): void => {
	ipcMain.handle(IpcMessage.GetDirectory, async () => {
		return await getDirectory();
	});
};

export const getDirectory = async (dialogTitle?: string): Promise<string> => {
	let options: OpenDialogOptions = {
		properties: ["openDirectory"],
	};

	if (dialogTitle) options.title = dialogTitle;
	const directory = await dialog.showOpenDialog(mainWindow, options);

	if (directory.filePaths.length) {
		const uncPath = await getUncPath(directory.filePaths[0]);

		log({
			type: "INFO",
			subType: "BACKEND",
			payload: `Selected directory: ${uncPath}`,
		});

		return uncPath;
	} else {
		log({
			type: "INFO",
			subType: "BACKEND",
			payload: "Open dialog canceled.",
		});

		return "";
	}
};
