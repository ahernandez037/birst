import { DateTime } from "luxon";
import { ipcMain } from "electron";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { HealthCheck } from "./types";
import { IpcMessage } from "../ipc-handlers";
import { checkForDuplicates } from "./duplicates";
import { Emoji, addConsoleMessage } from "../console-message";

export const healthCheckIpcHandler = (): void => {
	ipcMain.on(IpcMessage.RunHealthCheck, async (_event, payload) => {
		const startTime = DateTime.now();
		const healthCheck: HealthCheck = JSON.parse(payload);

		try {
			switch (healthCheck.action) {
				case "DUP-CHECK":
					await checkForDuplicates(healthCheck.product);
					break;
				default:
			}

			const endTime = DateTime.now();
			const runtimeObject = endTime.diff(startTime, ["minutes", "seconds"]).toObject();
			const runtime = `${runtimeObject.minutes} min ${runtimeObject.seconds?.toFixed(0)} sec`;
			addConsoleMessage({ text: `Finished running health check (${runtime})` });
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });

			await logAsync({
				type: "ERROR",
				subType: "BACKEND",
				payload: String(err),
			});
		} finally {
			mainWindow.webContents.send(IpcMessage.DoneRunningHealthCheck);
		}
	});
};
