export type HealthCheckProductCode = "CMP-HAB" | "CMP-REA" | "CMP-ROS" | "CMP-RST";

export type HealthCheckActionCode = "DUP-CHECK";

export interface HealthCheckProduct {
	code: HealthCheckProductCode;
	description: string;
}

export interface HealthCheckAction {
	code: HealthCheckActionCode;
	description: string;
}

export interface HealthCheck {
	product: HealthCheckProductCode;
	action: HealthCheckActionCode;
}

export interface DuplicateCheckRateTable {
	stateInclude: string;
	stateExclude: string;
	lineOfBusiness: string;
	product: string;
	version: string;
	ratabaseTableName: string;
	ratesFileTableName: string;
	programmedInRatingEngine: string;
	isIncludedInRatesFile: boolean;
	isOpenForProposedRates: boolean;
	compositeKey: string;
	legacyTableName: string;
}

export interface DuplicateCheckResult {
	tableName: string;
	duplicateCount: number;
	query: string;
}

export const RateTableListMap: Record<HealthCheckProductCode, string> = {
	"CMP-HAB": "PRD_BIZDB_COML.BIRST_TOOL.RATE_TABLE_LIST_CMP_HAB",
	"CMP-REA": "PRD_BIZDB_COML.BIRST_TOOL.RATE_TABLE_LIST_CMP_REA",
	"CMP-ROS": "PRD_BIZDB_COML.BIRST_TOOL.RATE_TABLE_LIST_CMP_ROS",
	"CMP-RST": "PRD_BIZDB_COML.BIRST_TOOL.RATE_TABLE_LIST_CMP_RST",
};

export const DuplicateCheckOutputFile: Record<HealthCheckProductCode, string> = {
	"CMP-HAB": "duplicate-check-cmp-hab.xlsx",
	"CMP-REA": "duplicate-check-cmp-rea.xlsx",
	"CMP-ROS": "duplicate-check-cmp-ros.xlsx",
	"CMP-RST": "duplicate-check-cmp-rst.xlsx",
};
