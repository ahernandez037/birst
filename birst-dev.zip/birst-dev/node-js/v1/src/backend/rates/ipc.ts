import { ipcMain } from "electron";
import { logAsync } from "../logger";
import { mainWindow } from "../main";
import { IpcMessage } from "../ipc-handlers";
import { scenarioFile } from "../scenario-file";
import { deleteRatesFromDatabase } from "./delete";
import { createEmail, EmailTrigger } from "../email";
import { addConsoleMessage, Emoji } from "../console-message";
import { devSaveRatesToDatabase, saveRatesToDatabase } from "./save";

export const ratesIpcHandler = (): void => {
	ipcMain.on(IpcMessage.SaveRates, async () => {
		try {
			// If return value is not true then action was canceled.
			if (await saveRatesToDatabase()) {
				mainWindow.webContents.send(IpcMessage.SaveRatesSuccess);
			}
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });
			await logAsync({ type: "ERROR", subType: "BACKEND", payload: String(err) });
			mainWindow.webContents.send(IpcMessage.SaveRatesError);
		}
	});

	ipcMain.on(IpcMessage.DevTestSaveRates, async () => {
		try {
			await devSaveRatesToDatabase();
			mainWindow.webContents.send(IpcMessage.SaveRatesSuccess);
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });
			await logAsync({ type: "ERROR", subType: "BACKEND", payload: String(err) });
			mainWindow.webContents.send(IpcMessage.SaveRatesError);
		}
	});

	ipcMain.on(IpcMessage.DeleteRates, async () => {
		try {
			// If return value is not true then action was canceled.
			if (await deleteRatesFromDatabase()) {
				createEmail({
					emailTrigger: EmailTrigger.RatesDeleted,
					scenarioForm: scenarioFile.scenarioForm,
				});

				mainWindow.webContents.send(IpcMessage.DeleteRatesSuccess);
			}
		} catch (err) {
			addConsoleMessage({ text: `${Emoji.Error} ${String(err)}` });
			await logAsync({ type: "ERROR", subType: "BACKEND", payload: String(err) });
			mainWindow.webContents.send(IpcMessage.DeleteRatesError);
		}
	});
};
