import { randomUUID } from "crypto";
import { stringify } from "csv/sync";
import { join, basename } from "path";
import { outputFile, remove } from "fs-extra";
import { app, MessageBoxOptions, dialog } from "electron";
import { mainWindow } from "../main";
import { doRatesExist } from "./exist";
import { connection } from "../database";
import { log, logAsync } from "../logger";
import { IpcMessage } from "../ipc-handlers";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { tablesForUpload } from "../rates-file/create";
import { getInScopeRateTables, loadRatesFile, RateTableForUpload } from "../rates-file";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer,
} from "../console-message";

/**
 * Only available to developers. Use with care, does not do any checks!
 */
export const devSaveRatesToDatabase = async (): Promise<void> => {
	try {
		const tablesWithSavedRates: string[] = [];

		addConsoleMessage({
			text: "Saving rates to database...",
			hasTimer: true,
			timerId: ConsoleMessageId.SavingRatesToDatabase,
		});

		addConsoleMessage({
			text: `${Emoji.Warning} Use with care. No checks are done when saving rates using this method.`,
		});

		await loadRatesFile();

		if (!(await areThereInScopeTables())) {
			addConsoleMessage({ text: `${Emoji.Error} There are no in scope rate tables.` });
			return;
		}

		for (const table of tablesForUpload) {
			await upload(table);
			tablesWithSavedRates.push(table.tableName);
		}

		addConsoleMessage({
			text: `Finished saving rates to database for the following tables: ${tablesWithSavedRates.join(
				", ",
			)}`,
		});
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.SavingRatesToDatabase);
	}
};

export const saveRatesToDatabase = async (isTestRun?: boolean): Promise<boolean> => {
	try {
		const tablesWithSavedRates: string[] = [];
		await loadRatesFile();

		if (!(await areThereInScopeTables())) {
			if (!isTestRun) mainWindow.webContents.send(IpcMessage.SaveRatesCanceled);
			return false;
		}

		if (!isTestRun && !(await doesUserWantToSave())) {
			mainWindow.webContents.send(IpcMessage.SaveRatesCanceled);
			return false;
		}

		addConsoleMessage({
			text: "Saving rates to database...",
			hasTimer: true,
			timerId: ConsoleMessageId.SavingRatesToDatabase,
		});

		for (const table of tablesForUpload) {
			if (await doRatesExist(table)) continue;
			await upload(table);
			tablesWithSavedRates.push(table.tableName);
		}

		if (tablesWithSavedRates.length === 0) {
			const message =
				"Rates already exist in the database. If you want to save them again, the existing rates must be deleted first.";

			addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
			await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
			mainWindow.webContents.send(IpcMessage.SaveRatesCanceled);
			return false;
		} else if (tablesWithSavedRates.length !== tablesForUpload.length) {
			const message = `Some rates already exist in the database. Only rates for the following tables were saved: ${tablesWithSavedRates.join(
				", ",
			)}`;

			addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
			await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
			return true;
		} else {
			addConsoleMessage({
				text: `Finished saving rates to database for the following tables: ${tablesWithSavedRates.join(
					", ",
				)}`,
			});

			await logAsync({
				type: "INFO",
				subType: "JSON",
				payload: JSON.stringify({
					type: "MILESTONE",
					subType: "RATES-SAVED",
					appVersion: app.getVersion(),
					userEmailAddress: userSettings.emailAddress,
					tables: tablesWithSavedRates.join(","),
				}),
			});

			return true;
		}
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.SavingRatesToDatabase);
	}
};

const areThereInScopeTables = async (): Promise<boolean> => {
	if (!getInScopeRateTables().length) {
		const message =
			"Unable to save rates and generate output. There are no in scope rate tables.";

		addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
		await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
		return false;
	}
	return true;
};

const doesUserWantToSave = async (): Promise<boolean> => {
	const inScopeTables = scenarioFile.executiveSummary.inScopeTables
		? scenarioFile.executiveSummary.inScopeTables
				.split(",")
				.map((table) => "\xa0\xa0\xa0\xa0\u2022\xa0" + table) // add white space & bullet point
				.join("\n")
		: [];

	const inScopeTablesMessage = scenarioFile.executiveSummary.inScopeTables.length
		? `The following rate tables are in scope:\n${inScopeTables}`
		: "There are no rate tables in scope, i.e., no rate changes were made.";

	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["No", "Yes"],
		defaultId: 0,
		cancelId: 0,
		noLink: true,
		title: " Confirmation Required",
		message: "Are you sure you want to save rates to the database?\n\n" + inScopeTablesMessage,
	};

	return !!(await dialog.showMessageBox(mainWindow, dialogOptions)).response;
};

const upload = async (table: RateTableForUpload): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		// Using UUID to create unique filenames.
		const uuid = randomUUID();

		const csvFile = join(
			scenarioFile.scenarioForm.scenarioDirectory,
			table.tableName + "-" + uuid + ".csv",
		);

		try {
			// Save CSV file to hard drive.
			await outputFile(
				csvFile,
				stringify(table.records, {
					header: true,
					cast: {
						date: (value) => value.toISOString(),
					},
				}),
			);
		} catch (err) {
			reject(err);
			throw err;
		}

		/* Using 'connection?.execute' to stream the Snowflake commands because
		Snowflake was throwing random encryption errors when using the 'execute'
		function from the database module when copying into a table from the
		user staging area. These errors only seem to occur when using the PUT
		and COPY INTO commands. */
		connection?.execute({
			// Upload CSV file from hard drive to Snowflake user stage.
			sqlText: `PUT file://${csvFile} @~/;`,
			streamResult: true,
			complete: (err, stmt) => {
				if (err) {
					reject(err);
					throw err;
				} else {
					const stream = stmt.streamRows();
					stream.on("data", (row) => {
						log({
							type: "INFO",
							subType: "BACKEND",
							payload: JSON.stringify(row),
							bypassDatabase: true,
						});
					});
					stream.on("error", (err) => {
						reject(err);
						throw err;
					});
					stream.on("end", () => {
						log({
							type: "INFO",
							subType: "BACKEND",
							payload: "PUT finished.",
							bypassDatabase: true,
						});
						// Copy data from Snowflake user stage to table.
						let index = 1;
						connection?.execute({
							sqlText: `
								COPY INTO prd_bizdb_coml.rate_tables.${table.tableName} (${Object.keys(table.records[0]).join(",")})
								FROM (
									SELECT ${Object.keys(table.records[0])
										.map(() => `$${index++}`)
										.join(",")}
									FROM @~/${basename(csvFile)}
								)
								FILE_FORMAT = (
									TYPE = CSV,
									SKIP_HEADER = 1,
									NULL_IF = ('NULL', 'null', 'NAN', 'NaN', 'nan'),
									FIELD_OPTIONALLY_ENCLOSED_BY = '"'
								);
							`,
							streamResult: true,
							complete: (err, stmt) => {
								if (err) {
									reject(err);
									throw err;
								} else {
									const stream = stmt.streamRows();
									stream.on("data", (row) => {
										log({
											type: "INFO",
											subType: "BACKEND",
											payload: JSON.stringify(row),
											bypassDatabase: true,
										});
									});
									stream.on("error", (err) => {
										reject(err);
										throw err;
									});
									stream.on("end", async () => {
										log({
											type: "INFO",
											subType: "BACKEND",
											payload: "COPY INTO finished.",
											bypassDatabase: true,
										});
										// Delete CSV file from hard drive.
										try {
											await remove(csvFile);
										} catch (err) {
											reject(err);
											throw err;
										}
										// Delete CSV file from Snowflake user stage.
										connection?.execute({
											sqlText: `REMOVE @~/${basename(csvFile)}`,
											streamResult: true,
											complete: (err, stmt) => {
												if (err) {
													reject(err);
													throw err;
												} else {
													const stream = stmt.streamRows();
													stream.on("data", (row) => {
														log({
															type: "INFO",
															subType: "BACKEND",
															payload: JSON.stringify(row),
															bypassDatabase: true,
														});
													});
													stream.on("error", (err) => {
														reject(err);
														throw err;
													});
													stream.on("end", async () => {
														log({
															type: "INFO",
															subType: "BACKEND",
															payload: "REMOVE finished.",
															bypassDatabase: true,
														});
														resolve();
													});
												}
											},
										});
									});
								}
							},
						});
					});
				}
			},
		});
	});
};
