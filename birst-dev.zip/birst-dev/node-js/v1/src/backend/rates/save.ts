import * as xlsx from "xlsx";
import { randomUUID } from "crypto";
import { stringify } from "csv/sync";
import { join, basename } from "path";
import { outputFile, remove } from "fs-extra";
import { app, MessageBoxOptions, dialog } from "electron";
import { mainWindow } from "../main";
import { doRatesExist } from "./exist";
import { connection } from "../database";
import { log, logAsync } from "../logger";
import { IpcMessage } from "../ipc-handlers";
import { scenarioFile } from "../scenario-file";
import { USER_ID, userSettings } from "../user-settings";
import { tablesForUpload } from "../rates-file/create";
import { getReportFileAbsoluteFilepath } from "../report-file";
import { getInScopeRateTables, loadRatesFile, RateTableForUpload } from "../rates-file";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer,
} from "../console-message";

/**
 * Only available to developers. Use with care, does not do any checks!
 */
export const devSaveRatesToDatabase = async (): Promise<void> => {
	try {
		const tablesWithSavedRates: string[] = [];

		addConsoleMessage({
			text: "Saving rates to database...",
			hasTimer: true,
			timerId: ConsoleMessageId.SavingRatesToDatabase,
		});

		addConsoleMessage({
			text: `${Emoji.Warning} Use with care. No checks are done when saving rates using this method.`,
		});

		await loadRatesFile();

		if (!(await areThereInScopeTables())) {
			addConsoleMessage({ text: `${Emoji.Error} There are no in scope rate tables.` });
			return;
		}

		if (scenarioFile.scenarioForm.lineOfBusiness === "WC") processSpecialWorkCompTables();

		for (const table of tablesForUpload) {
			await upload(table);
			tablesWithSavedRates.push(table.tableName);
		}

		addConsoleMessage({
			text: `Finished saving rates to database for the following tables: ${tablesWithSavedRates.join(
				", ",
			)}`,
		});
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.SavingRatesToDatabase);
	}
};

export const saveRatesToDatabase = async (isTestRun?: boolean): Promise<boolean> => {
	try {
		const tablesWithSavedRates: string[] = [];
		await loadRatesFile();

		if (!(await areThereInScopeTables())) {
			if (!isTestRun) mainWindow.webContents.send(IpcMessage.SaveRatesCanceled);
			return false;
		}

		if (!isTestRun && !(await doesUserWantToSave())) {
			mainWindow.webContents.send(IpcMessage.SaveRatesCanceled);
			addConsoleMessage({ text: "Action has been canceled." });
			return false;
		}

		addConsoleMessage({
			text: "Saving rates to database...",
			hasTimer: true,
			timerId: ConsoleMessageId.SavingRatesToDatabase,
		});

		if (scenarioFile.scenarioForm.lineOfBusiness === "WC") processSpecialWorkCompTables();

		for (const table of tablesForUpload) {
			if (await doRatesExist(table)) continue;
			await upload(table);
			tablesWithSavedRates.push(table.tableName);
		}

		if (tablesWithSavedRates.length === 0) {
			const message =
				"Rates already exist in the database. If you want to save them again, the existing rates must be deleted first.";

			addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
			await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
			mainWindow.webContents.send(IpcMessage.SaveRatesCanceled);
			return false;
		} else if (tablesWithSavedRates.length !== tablesForUpload.length) {
			const message = `Some rates already exist in the database. Only rates for the following tables were saved: ${tablesWithSavedRates.join(
				", ",
			)}`;

			addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
			await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
			return true;
		} else {
			addConsoleMessage({
				text: `Finished saving rates to database for the following tables: ${tablesWithSavedRates.join(
					", ",
				)}`,
			});

			await logAsync({
				type: "INFO",
				subType: "JSON",
				payload: JSON.stringify({
					type: "MILESTONE",
					subType: "RATES-SAVED",
					appVersion: app.getVersion(),
					userEmailAddress: userSettings.emailAddress,
					tables: tablesWithSavedRates.join(","),
				}),
			});

			return true;
		}
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.SavingRatesToDatabase);
	}
};

const areThereInScopeTables = async (): Promise<boolean> => {
	if (!getInScopeRateTables().length) {
		const message =
			"Unable to save rates and generate output. There are no in scope rate tables.";

		addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
		await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
		return false;
	}
	return true;
};

const doesUserWantToSave = async (): Promise<boolean> => {
	const inScopeTables = tablesForUpload
		.map((table) => "\xa0\xa0\xa0\xa0\u2022\xa0" + table.tableName) // add white space & bullet point
		.join("\n");

	const inScopeTablesMessage = tablesForUpload.length
		? `The following rate tables are in scope:\n${inScopeTables}`
		: "There are no rate tables in scope, i.e., no rate changes were made.";

	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["Yes", "No"],
		defaultId: 1,
		cancelId: 1,
		noLink: true,
		title: " Confirmation Required",
		message: "Are you sure you want to save rates to the database?\n\n" + inScopeTablesMessage,
	};

	return (await dialog.showMessageBox(mainWindow, dialogOptions)).response === 0 ? true : false;
};

/**
 * The wc_minimum_premium_nonbureau table gets updated in the background because
 * of the minimum premium calculations that take place. Users shouldn't enter
 * proposed rates for these anyway. If they want, they can use the table
 * wc_minimum_premium_override to override any values.
 */
const processSpecialWorkCompTables = (): void => {
	const isWcMimPremNonBureauInScope = tablesForUpload.find(
			(table) => table.tableName.toUpperCase() === "WC_MINIMUM_PREMIUM_NONBUREAU",
		),
		reportFileWorkbook = xlsx.readFile(getReportFileAbsoluteFilepath(), {
			// To convert date from sequential serial number to ISO string.
			cellDates: true,
		}),
		worksheet = reportFileWorkbook.Sheets["wc_minimum_premium_nonbureau"],
		// Using "defval = null" option to ensure columns with all null values
		// are included.
		records = xlsx.utils.sheet_to_json(worksheet, {
			defval: null,
		}) as Record<string, unknown>[];

	for (const record of records) {
		record["EFF_DATE"] = scenarioFile.scenarioForm.renewalDate;
		record["UPLOAD_USER"] = USER_ID;
		record["UPLOAD_DATE"] = new Date();
	}

	if (isWcMimPremNonBureauInScope) {
		const table = tablesForUpload.find(
			(table) => table.tableName.toUpperCase() === "WC_MINIMUM_PREMIUM_NONBUREAU",
		);
		if (table) table.records = records;
	} else if (
		!isWcMimPremNonBureauInScope &&
		(tablesForUpload.find((table) => table.tableName.toUpperCase() === "WC_BUREAU_LC") ||
			tablesForUpload.find(
				(table) => table.tableName.toUpperCase() === "WC_COMPANY_MULTIPLIER",
			) ||
			tablesForUpload.find((table) => table.tableName.toUpperCase() === "WC_DEVIATION") ||
			tablesForUpload.find(
				(table) => table.tableName.toUpperCase() === "WC_EXPENSE_CONSTANT_NONBUREAU",
			) ||
			tablesForUpload.find(
				(table) => table.tableName.toUpperCase() === "WC_MIN_PREM_COMPONENTS",
			) ||
			tablesForUpload.find(
				(table) => table.tableName.toUpperCase() === "WC_MINIMUM_PREMIUM_OVERRIDE",
			))
	) {
		tablesForUpload.push({ tableName: "wc_minimum_premium_nonbureau", records: records });
	}
};

const upload = async (table: RateTableForUpload): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		// Using UUID to create unique filenames.
		const uuid = randomUUID();

		const csvFile = join(
			scenarioFile.scenarioForm.scenarioDirectory,
			table.tableName + "-" + uuid + ".csv",
		);

		try {
			// Save CSV file to hard drive.
			await outputFile(
				csvFile,
				stringify(table.records, {
					header: true,
					cast: {
						date: (value) => value.toISOString(),
					},
				}),
			);
		} catch (err) {
			reject(err);
			throw err;
		}

		/* Using 'connection?.execute' to stream the Snowflake commands because
		Snowflake was throwing random encryption errors when using the 'execute'
		function from the database module when copying into a table from the
		user staging area. These errors only seem to occur when using the PUT
		and COPY INTO commands. */
		connection?.execute({
			// Upload CSV file from hard drive to Snowflake user stage.
			sqlText: `PUT file://${csvFile} @~/;`,
			streamResult: true,
			complete: (err, stmt) => {
				if (err) {
					reject(err);
					throw err;
				} else {
					const stream = stmt.streamRows();
					stream.on("data", (row) => {
						log({
							type: "INFO",
							subType: "BACKEND",
							payload: JSON.stringify(row),
							bypassDatabase: true,
						});
					});
					stream.on("error", (err) => {
						reject(err);
						throw err;
					});
					stream.on("end", () => {
						log({
							type: "INFO",
							subType: "BACKEND",
							payload: "PUT finished.",
							bypassDatabase: true,
						});
						// Copy data from Snowflake user stage to table.
						let index = 1;
						connection?.execute({
							sqlText: `
								COPY INTO prd_bizdb_coml.rate_tables.${table.tableName} (${Object.keys(table.records[0]).join(",")})
								FROM (
									SELECT ${Object.keys(table.records[0])
										.map(() => `$${index++}`)
										.join(",")}
									FROM @~/${basename(csvFile)}
								)
								FILE_FORMAT = (
									TYPE = CSV,
									SKIP_HEADER = 1,
									NULL_IF = ('NULL', 'null', 'NAN', 'NaN', 'nan'),
									FIELD_OPTIONALLY_ENCLOSED_BY = '"'
								);
							`,
							streamResult: true,
							complete: (err, stmt) => {
								if (err) {
									reject(err);
									throw err;
								} else {
									const stream = stmt.streamRows();
									stream.on("data", (row) => {
										log({
											type: "INFO",
											subType: "BACKEND",
											payload: JSON.stringify(row),
											bypassDatabase: true,
										});
									});
									stream.on("error", (err) => {
										reject(err);
										throw err;
									});
									stream.on("end", async () => {
										log({
											type: "INFO",
											subType: "BACKEND",
											payload: "COPY INTO finished.",
											bypassDatabase: true,
										});
										// Delete CSV file from hard drive.
										try {
											await remove(csvFile);
										} catch (err) {
											reject(err);
											throw err;
										}
										// Delete CSV file from Snowflake user stage.
										connection?.execute({
											sqlText: `REMOVE @~/${basename(csvFile)}`,
											streamResult: true,
											complete: (err, stmt) => {
												if (err) {
													reject(err);
													throw err;
												} else {
													const stream = stmt.streamRows();
													stream.on("data", (row) => {
														log({
															type: "INFO",
															subType: "BACKEND",
															payload: JSON.stringify(row),
															bypassDatabase: true,
														});
													});
													stream.on("error", (err) => {
														reject(err);
														throw err;
													});
													stream.on("end", async () => {
														log({
															type: "INFO",
															subType: "BACKEND",
															payload: "REMOVE finished.",
															bypassDatabase: true,
														});
														resolve();
													});
												}
											},
										});
									});
								}
							},
						});
					});
				}
			},
		});
	});
};
