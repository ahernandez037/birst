import { join } from "path";
import { app, MessageBoxOptions, dialog } from "electron";
import { mainWindow } from "../main";
import { logAsync } from "../logger";
import { execute } from "../database";
import { doRatesExist } from "./exist";
import { IpcMessage } from "../ipc-handlers";
import { userSettings } from "../user-settings";
import { scenarioFile } from "../scenario-file";
import { RateTableForUpload } from "../rates-file";
import { tablesForUpload } from "../rates-file/create";
import { getInScopeRateTables, loadRatesFile } from "../rates-file/load";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import {
	Emoji,
	ConsoleMessageId,
	addConsoleMessage,
	stopConsoleMessageTimer,
} from "../console-message";

export const deleteRatesFromDatabase = async (isTestRun?: boolean): Promise<boolean> => {
	try {
		const tablesWithDeletedRates: string[] = [];
		await loadRatesFile();

		if (!(await areThereInScopeTables())) {
			if (!isTestRun) mainWindow.webContents.send(IpcMessage.DeleteRatesCanceled);
			return false;
		}

		if (!isTestRun && !(await doesUserWantToDelete())) {
			mainWindow.webContents.send(IpcMessage.DeleteRatesCanceled);
			addConsoleMessage({ text: "Action has been canceled." });
			return false;
		}

		addConsoleMessage({
			text: "Deleting rates from database...",
			hasTimer: true,
			timerId: ConsoleMessageId.DeletingRatesFromDatabase,
		});

		// Work Comp has a special table that gets saved in the background even
		// when no proposed rates are entered. This is due to the minimum
		// premium calculations that are needed to derive the Farmers minimum
		// premium. Therefore, need to check if the rates need to be deleted for
		// this table too.
		if (
			scenarioFile.scenarioForm.lineOfBusiness === "WC" &&
			(await doRatesExist({ tableName: "wc_minimum_premium_nonbureau", records: [] })) &&
			!tablesForUpload.find((table) => table.tableName.toUpperCase() === "WC_MINIMUM_PREMIUM_NONBUREAU")
		) {
			tablesForUpload.push({ tableName: "wc_minimum_premium_nonbureau", records: [] });
		}

		for (const table of tablesForUpload) {
			if (!(await doRatesExist(table))) continue;
			await deleteRates(table);
			tablesWithDeletedRates.push(table.tableName);
		}

		if (tablesWithDeletedRates.length === 0) {
			const message = "Did not find any rates in the database that needed to be deleted.";
			addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
			await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
			mainWindow.webContents.send(IpcMessage.DeleteRatesCanceled);
			return false;
		} else if (tablesWithDeletedRates.length !== tablesForUpload.length) {
			const message = `Some rates were not found in the database. Only rates for the following tables were deleted: ${tablesWithDeletedRates.join(
				", ",
			)}`;

			addConsoleMessage({ text: `${Emoji.Warning} ${message}` });
			await logAsync({ type: "WARNING", subType: "BACKEND", payload: message });
			return true;
		} else {
			addConsoleMessage({
				text: `Finished deleting rates from the database for the following tables: ${tablesWithDeletedRates.join(
					", ",
				)}`,
			});

			await logAsync({
				type: "INFO",
				subType: "JSON",
				payload: JSON.stringify({
					type: "MILESTONE",
					subType: "RATES-DELETED",
					appVersion: app.getVersion(),
					userEmailAddress: userSettings.emailAddress,
					tables: tablesWithDeletedRates.join(","),
				}),
			});

			return true;
		}
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.DeletingRatesFromDatabase);
	}
};

const areThereInScopeTables = async (): Promise<boolean> => {
	if (!getInScopeRateTables().length) {
		const message = "Unable to delete rates. There are no in scope rate tables.";
		addConsoleMessage({ text: `${Emoji.Error} ${message}` });
		await logAsync({ type: "ERROR", subType: "BACKEND", payload: message });
		return false;
	}
	return true;
};

const doesUserWantToDelete = async (): Promise<boolean> => {
	const inScopeTables = tablesForUpload
		.map((table) => "\xa0\xa0\xa0\xa0\u2022\xa0" + table.tableName) // add white space & bullet point
		.join("\n");

	const inScopeTablesMessage = tablesForUpload.length
		? `The following rate tables are in scope:\n${inScopeTables}`
		: "There are no rate tables in scope, i.e., no rate changes were made.";

	const dialogOptions: MessageBoxOptions = {
		type: "warning",
		buttons: ["Yes", "No"],
		defaultId: 1,
		cancelId: 1,
		noLink: true,
		title: " Confirmation Required",
		message: "Are you sure you want to delete rates from the database?\n\n" + inScopeTablesMessage,
	};

	return (await dialog.showMessageBox(mainWindow, dialogOptions)).response === 0 ? true : false;
};

const deleteRates = async (table: RateTableForUpload): Promise<void> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.DeleteRates),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					tableName: table.tableName,
					scenarioFile: scenarioFile,
				},
			}),
		);

		await execute({ sqlText });
	} catch (err) {
		throw err;
	}
};
