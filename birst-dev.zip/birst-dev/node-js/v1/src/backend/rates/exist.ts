import { join } from "path";
import { app } from "electron";
import { execute } from "../database";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { RateTableForUpload } from "../rates-file";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";

export const doRatesExist = async (table: RateTableForUpload): Promise<boolean> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CheckIfRatesExist),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					tableName: table.tableName,
					scenarioFile: scenarioFile,
				},
			}),
		);

		const [, results] = await execute({ sqlText });
		const recordCount = Number((results as Record<string, unknown>[])[0]["RECORD_COUNT"]);
		if (recordCount > 0) return true;
		return false;
	} catch (err) {
		throw err;
	}
};
