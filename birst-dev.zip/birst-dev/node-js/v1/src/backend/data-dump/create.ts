import { join } from "path";
import { app } from "electron";
import { execute } from "../database";
import { scenarioFile } from "../scenario-file";
import { userSettings } from "../user-settings";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";
import { addConsoleMessage, ConsoleMessageId, stopConsoleMessageTimer } from "../console-message";

export const createDataDump = async (miscJson?: string): Promise<void> => {
	try {
		addConsoleMessage({
			text: "Creating data dump...",
			hasTimer: true,
			timerId: ConsoleMessageId.CreatingDataDump,
		});

		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.CreateDataDump),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioFile,
					miscJson,
				},
			}),
		);

		await execute({ sqlText });
	} catch (err) {
		throw err;
	} finally {
		stopConsoleMessageTimer(ConsoleMessageId.CreatingDataDump);
	}
};
