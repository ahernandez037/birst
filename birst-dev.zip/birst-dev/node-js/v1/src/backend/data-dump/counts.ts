import { join } from "path";
import { app } from "electron";
import { execute } from "../database";
import { userSettings } from "../user-settings";
import { scenarioFile } from "../scenario-file";
import { executeDynamicJsFunction, loadDynamicJsFunction, SqlFunctionFile } from "../dynamic-js";

export const getDataDumpRecordCount = async (): Promise<number> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetDataDumpRecordCount),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioFile: scenarioFile,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });
		return Number(rs && rs.length > 0 ? (rs[0] as Record<string, number>)["RECORD_COUNT"] : 0);
	} catch (err) {
		throw err;
	}
};

export const getDataDumpDuplicateCount = async (): Promise<number> => {
	try {
		const dynamicJsFunction = (
			await loadDynamicJsFunction(
				join(userSettings.sqlFunctionsDirectory, SqlFunctionFile.GetDataDumpDuplicateCount),
			)
		)[0];

		const sqlText = String(
			executeDynamicJsFunction({
				dynamicJsFunction,
				functionArguments: {
					isProduction: app.isPackaged,
					scenarioFile: scenarioFile,
				},
			}),
		);

		const [, rs] = await execute({ sqlText });

		return Number(
			rs && rs.length > 0 ? (rs[0] as Record<string, number>)["TOTAL_DUPLICATES"] : 0,
		);
	} catch (err) {
		throw err;
	}
};
