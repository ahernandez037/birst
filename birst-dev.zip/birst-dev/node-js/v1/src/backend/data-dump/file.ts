import { join } from "path";
import { existsSync } from "fs-extra";
import { scenarioFile } from "../scenario-file";

export const doesDataDumpFileExist = (): boolean => {
	if (!scenarioFile.scenarioForm.scenarioDirectory || !scenarioFile.files.dataDumpFile) {
		return false;
	}

	return existsSync(getDataDumpFileAbsoluteFilepath());
};

export const getDataDumpFileAbsoluteFilepath = (): string => {
	return join(scenarioFile.scenarioForm.scenarioDirectory, scenarioFile.files.dataDumpFile);
};
