import { mainWindow } from "../main";
import { ConsoleMessageId } from "./types";
import { IpcMessage } from "../ipc-handlers";

export const stopConsoleMessageTimer = (timerId: ConsoleMessageId): void => {
	mainWindow.webContents.send(IpcMessage.StopConsoleMessageTimer, timerId);
};
