import { mainWindow } from "../main";
import { IpcMessage } from "../ipc-handlers";

export const addConsoleMessage = (args: {
	text: string;
	hasTimer?: boolean;
	timerId?: string;
	excludeTimestamp?: boolean;
}): void => {
	mainWindow.webContents.send(
		IpcMessage.AddConsoleMessage,
		JSON.stringify({
			text: args.text,
			hasTimer: args.hasTimer,
			timerId: args.timerId,
			excludeTimestamp: args.excludeTimestamp,
		}),
	);
};
