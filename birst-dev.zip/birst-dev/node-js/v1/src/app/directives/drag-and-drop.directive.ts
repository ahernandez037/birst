import { Directive, HostListener } from "@angular/core";
import { ElectronService } from "../services/electron.service";
import { IpcMessage } from "src/backend/ipc-handlers";

@Directive({
	selector: "[appDragAndDrop]",
})
export class DragAndDropDirective {
	constructor(private _electronService: ElectronService) {}

	@HostListener("dragover", ["$event"]) onDragOver(event: DragEvent) {
		event.preventDefault();
		event.stopPropagation();
	}

	@HostListener("dragleave", ["$event"]) onDragLeave(event: DragEvent) {
		event.preventDefault();
		event.stopPropagation();
	}

	@HostListener("drop", ["$event"]) onDrop(event: DragEvent) {
		event.preventDefault();
		event.stopPropagation();
		const files = event.dataTransfer?.files;
		if (files && files.length > 0) {
			this._electronService.send(IpcMessage.LoadScenarioFileFromDragAndDrop, files[0].path);
		}
	}
}
