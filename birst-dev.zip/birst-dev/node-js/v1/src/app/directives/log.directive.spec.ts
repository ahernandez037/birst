import { LogDirective } from "./log.directive";

describe("LogDirective", () => {
	it("should create an instance", () => {
		const directive = new LogDirective();
		expect(directive).toBeTruthy();
	});
});
