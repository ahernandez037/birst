import { createReducer, on } from "@ngrx/store";
import { AppState } from "../models/app-state";
import { ScenarioForm } from "src/backend/scenario";
import { RateRevision } from "src/backend/rate-revision";
import { MaintenanceSettings } from "src/backend/app-settings";
import {
	updateUser,
	updateProducts,
	updateGeoStates,
	updateAppVersion,
	updateIsAppReady,
	updateScenarioId,
	updateTestSuites,
	updateColorTheme,
	addConsoleMessage,
	updateReleaseNotes,
	updateRateRevision,
	updateScenarioForm,
	updateUserSettings,
	updateAvailableDates,
	stopConsoleMessageTimer,
	updateOverallRateImpact,
	updateIsTestSuiteRunning,
	updateSnowflakeSessionId,
	updateIsScenarioFormValid,
	updateMaintenanceSettings,
	updateMonitorScenarioRuns,
	updateWorkCompBureauRates,
	updateMonitorAverageRuntimes,
} from "./app-state.actions";

const initialState: AppState = {
	maintenanceSettings: {} as MaintenanceSettings,
	appVersion: "",
	isAppReady: false,
	snowflakeSessionId: "TBD",
	scenarioId: "",
	user: {
		isFirstTimeSetup: true,
		isDeveloper: false,
		isFitMember: false,
	},
	userSettings: {
		userSettingsVersion: 0,
		isResetRequired: false,
		emailAddress: "",
		defaultScenarioDirectory: "",
		appSettingsDirectory: "",
		excelTemplatesDirectory: "",
		emailFunctionsDirectory: "",
		nextStepsFunctionsDirectory: "",
		sqlFunctionsDirectory: "",
		ratesFileIgnoredFieldsDirectory: "",
		ratesFileOrderByDirectory: "",
		ratesFileRateFieldsDirectory: "",
		testSuitesDirectory: "",
		snowparkDirectory: "",
		isDarkMode: false,
		isConsoleShownOnStartup: true,
		isDynamicJsPrinted: false,
		isMonitorNotificationOn: true,
	},
	geoStates: [],
	products: [],
	releaseNotes: [],
	consoleMessages: [],
	availableDates: [],
	workCompBureauRates: [],
	scenarioForm: {} as ScenarioForm,
	isScenarioFormValid: false,
	overallRateImpact: null,
	rateRevision: {} as RateRevision,
	testSuites: [],
	isTestSuiteRunning: false,
	colorTheme: "",
	monitorScenarioRuns: [],
	monitorAverageRuntimes: [],
};

export const appStateReducer = createReducer(
	initialState,
	on(updateMaintenanceSettings, (state, payload) => ({
		...state,
		maintenanceSettings: payload.maintenanceSettings,
	})),
	on(updateAppVersion, (state, payload) => ({
		...state,
		appVersion: payload.appVersion,
	})),
	on(updateIsAppReady, (state, payload) => ({
		...state,
		isAppReady: payload.isAppReady,
	})),
	on(updateSnowflakeSessionId, (state, payload) => ({
		...state,
		snowflakeSessionId: payload.snowflakeSessionId,
	})),
	on(updateScenarioId, (state, payload) => ({
		...state,
		scenarioId: payload.scenarioId,
	})),
	on(updateUser, (state, payload) => ({
		...state,
		user: payload.user,
	})),
	on(updateUserSettings, (state, payload) => ({
		...state,
		userSettings: payload.userSettings,
	})),
	on(updateGeoStates, (state, payload) => ({
		...state,
		geoStates: payload.geoStates,
	})),
	on(updateWorkCompBureauRates, (state, payload) => ({
		...state,
		workCompBureauRates: payload.workCompBureauRates,
	})),
	on(updateProducts, (state, payload) => ({
		...state,
		products: payload.products,
	})),
	on(updateReleaseNotes, (state, payload) => ({
		...state,
		releaseNotes: payload.releaseNotes,
	})),
	on(updateAvailableDates, (state, payload) => ({
		...state,
		availableDates: payload.availableDates,
	})),
	on(addConsoleMessage, (state, payload) => ({
		...state,
		consoleMessages: [...state.consoleMessages, ...payload.consoleMessages],
	})),
	on(stopConsoleMessageTimer, (state, payload) => {
		state.consoleMessages
			.filter((message) => message.timerId === payload.timerId)
			.forEach((message) => message.stopTimer());

		return state;
	}),
	on(updateScenarioForm, (state, payload) => ({
		...state,
		scenarioForm: payload.scenarioForm,
	})),
	on(updateIsScenarioFormValid, (state, payload) => ({
		...state,
		isScenarioFormValid: payload.isScenarioFormValid,
	})),
	on(updateOverallRateImpact, (state, payload) => ({
		...state,
		overallRateImpact: payload.overallRateImpact,
	})),
	on(updateRateRevision, (state, payload) => ({
		...state,
		rateRevision: payload.rateRevision,
	})),
	on(updateTestSuites, (state, payload) => ({
		...state,
		testSuites: payload.testSuites,
	})),
	on(updateIsTestSuiteRunning, (state, payload) => ({
		...state,
		isTestSuiteRunning: payload.isTestSuiteRunning,
	})),
	on(updateColorTheme, (state, payload) => ({
		...state,
		colorTheme: payload.colorTheme,
	})),
	on(updateMonitorScenarioRuns, (state, payload) => ({
		...state,
		monitorScenarioRuns: payload.monitorScenarioRuns,
	})),
	on(updateMonitorAverageRuntimes, (state, payload) => ({
		...state,
		monitorAverageRuntimes: payload.monitorAverageRuntimes,
	})),
);
