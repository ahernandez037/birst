export interface Release {
	dateAndVersion: string;
	announcements: string[];
	newFeatures: string[];
	enhancements: string[];
	bugFixes: string[];
}
