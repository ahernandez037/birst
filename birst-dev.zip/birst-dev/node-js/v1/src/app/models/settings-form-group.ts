import { FormControl } from "@angular/forms";

export interface SettingsFormGroup {
	userSettingsVersion: FormControl<number>;
	isResetRequired: FormControl<boolean>;
	emailAddress: FormControl<string>;
	defaultScenarioDirectory: FormControl<string>;
	appSettingsDirectory: FormControl<string>;
	excelTemplatesDirectory: FormControl<string>;
	emailFunctionsDirectory: FormControl<string>;
	nextStepsFunctionsDirectory: FormControl<string>;
	sqlFunctionsDirectory: FormControl<string>;
	ratesFileIgnoredFieldsDirectory: FormControl<string>;
	ratesFileOrderByDirectory: FormControl<string>;
	ratesFileRateFieldsDirectory: FormControl<string>;
	testSuitesDirectory: FormControl<string>;
	snowparkDirectory: FormControl<string>;
	isDarkMode: FormControl<boolean>;
	isConsoleShownOnStartup: FormControl<boolean>;
	isDynamicJsPrinted: FormControl<boolean>;
	isMonitorNotificationOn: FormControl<boolean>;
}
