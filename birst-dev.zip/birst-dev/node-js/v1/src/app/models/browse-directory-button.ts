export interface BrowseDirectoryButton {
	formControlName: string;
	isLoading: boolean;
}
