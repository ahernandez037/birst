import { TestResult } from "src/backend/tests";

export interface TestSuiteResultsDialogData {
	testSuiteName: string;
	header: [
		{
			startedAt: string;
			endedAt: string;
			totalRuntime: string;
			totalPass: number;
			totalFail: number;
			totalSkipped: number;
		},
	];
	body: TestResult[];
}
