import { ActiveExecutiveSummary } from "src/backend/executive-summary";

export interface ExecutiveSummaryDialogData {
	header: [
		{
			state: string;
			lineOfBusiness: string;
			newDate: string;
			renewalDate: string;
			availableDate: string;
		},
	];
	body: ActiveExecutiveSummary[];
}
