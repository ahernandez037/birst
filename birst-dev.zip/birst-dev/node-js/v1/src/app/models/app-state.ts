import { User } from "src/backend/user";
import { TestSuite } from "src/backend/tests";
import { Product } from "src/backend/products";
import { GeoState } from "src/backend/geo-states";
import { ConsoleMessage } from "./console-message";
import { ScenarioForm } from "src/backend/scenario";
import { ReleaseNote } from "src/backend/release-notes";
import { UserSettings } from "src/backend/user-settings";
import { RateRevision } from "src/backend/rate-revision";
import { Runtime, ScenarioRun } from "src/backend/monitor";
import { AvailableDate } from "src/backend/available-dates";
import { MaintenanceSettings } from "src/backend/app-settings";
import { WorkCompBureauRate } from "src/backend/wc-bureau-rates";

export interface AppState {
	maintenanceSettings: MaintenanceSettings;
	appVersion: string;
	isAppReady: boolean;
	snowflakeSessionId: string;
	scenarioId: string;
	user: User;
	userSettings: UserSettings;
	geoStates: GeoState[];
	products: Product[];
	releaseNotes: ReleaseNote[];
	consoleMessages: ConsoleMessage[];
	availableDates: AvailableDate[];
	workCompBureauRates: WorkCompBureauRate[];
	scenarioForm: ScenarioForm;
	isScenarioFormValid: boolean;
	overallRateImpact: number | null;
	rateRevision: RateRevision;
	testSuites: TestSuite[];
	isTestSuiteRunning: boolean;
	colorTheme: string;
	monitorScenarioRuns: ScenarioRun[];
	monitorAverageRuntimes: Runtime[];
}
