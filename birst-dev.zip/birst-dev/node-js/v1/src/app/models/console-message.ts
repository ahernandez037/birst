import { DateTime } from "luxon";

export class ConsoleMessage {
	text: string;
	hasTimer?: boolean;
	timerId?: string;
	private _originalText: string;
	private _timer: NodeJS.Timer | undefined;
	private _startTime: DateTime;

	constructor(args: {
		text: string;
		hasTimer?: boolean;
		timerId?: string;
		excludeTimestamp?: boolean;
	}) {
		if (args.excludeTimestamp) {
			this.text = args.text;
		} else {
			// https://github.com/moment/luxon/blob/master/docs/formatting.md
			this.text = DateTime.local().toFormat("MM/dd/yy hh:mm a") + ": " + args.text;
		}

		this._originalText = this.text;
		this.hasTimer = args.hasTimer;
		this.timerId = args.timerId;
		this._timer = undefined;
		this._startTime = DateTime.now();

		if (args.hasTimer) {
			this._startTimer();
		}
	}

	private _startTimer(): void {
		this._timer = setInterval(() => {
			this.text = this._originalText + " " + this._getElapsedTime();
		}, 1000);
	}

	stopTimer(): void {
		if (this._timer) {
			clearInterval(this._timer);
		}
	}

	private _getElapsedTime(): string {
		const runtime = DateTime.now().diff(this._startTime, ["minutes", "seconds"]).toObject();

		return `${runtime.minutes ? runtime.minutes + "m" : ""} ${
			runtime.seconds !== undefined ? runtime.seconds.toFixed(0) + "s" : ""
		}`.trim();
	}
}
