import { Store } from "@ngrx/store";
import { ThemeOption } from "ngx-echarts";
import { Component, OnInit, OnDestroy, signal } from "@angular/core";
import { MatSlideToggleChange } from "@angular/material/slide-toggle";
import { BehaviorSubject, Observable, Subscription, debounceTime } from "rxjs";
import { AppState } from "src/app/models/app-state";
import { IpcMessage } from "src/backend/ipc-handlers";
import { ElectronService } from "../../services/electron.service";
import { AccessLog, ImportantMessage } from "src/backend/monitor";
import { EChartCustomDarkTheme } from "./echart-custom-dark-theme";
import { selectColorTheme } from "src/app/store/app-state.selectors";
import {
	updateMonitorScenarioRuns,
	updateMonitorAverageRuntimes,
} from "src/app/store/app-state.actions";

@Component({
	selector: "app-monitor",
	templateUrl: "./monitor.component.html",
	styleUrls: ["./monitor.component.scss"],
})
export class MonitorComponent implements OnInit, OnDestroy {
	appColorTheme$: Observable<string>;
	appColorThemeSubscription: Subscription;
	eChartTheme: string | ThemeOption = "";
	eChartCustomDarkTheme = EChartCustomDarkTheme;

	readonly INITIAL_REFRESH_INTERVAL = 30;
	refreshInterval = this.INITIAL_REFRESH_INTERVAL;
	refreshIntervalSubject = new BehaviorSubject<number>(this.INITIAL_REFRESH_INTERVAL);
	refreshIntervalSubscription: Subscription;

	areDevelopersIncluded = false;
	isFetchingData = true;
	lastRefresh = "Loading...";

	unfilteredImportantLogMessages: ImportantMessage[] = [];
	importantLogMessages = signal<ImportantMessage[]>([
		{
			timestamp: new Date(),
			type: "Loading...",
			userId: "Loading...",
			scenarioId: "Loading...",
			payload: "Loading...",
		},
	]);

	unfilteredAccessLog: AccessLog[] = [];
	accessLog = signal<AccessLog[]>([
		{
			rowNumber: 0,
			userId: "Loading...",
			lastAccessed: new Date(),
			appVersion: "Loading...",
		},
	]);

	developers = [
		"A.HERNANDEZ",
		"DANIEL.TINOCO",
		"JEFFREY.KAO",
		"KATHERINE.BIGLARIAN",
		"WILLY.LAI",
		"YULIA.MESHCHERYAKOVA",
	];

	constructor(
		private _electronService: ElectronService,
		private _store: Store<{ appState: AppState }>,
	) {
		this.appColorTheme$ = this._store.select(selectColorTheme);
	}

	ngOnInit(): void {
		this._electronService.on(IpcMessage.GetMonitorData, (payload) => {
			this.isFetchingData = false;
			this.lastRefresh = new Date().toLocaleString();

			/**
			 * payload[0] = Important Messages
			 * payload[1] = Access Logs
			 * payload[2] = Scenario Runs
			 * payload[3] = Average Runtimes
			 */
			this.processImportantMessages(this.areDevelopersIncluded, payload[0]);
			this.processAccessLogs(this.areDevelopersIncluded, payload[1]);

			this._store.dispatch(
				updateMonitorScenarioRuns({
					monitorScenarioRuns: JSON.parse(payload[2]),
				}),
			);

			this._store.dispatch(
				updateMonitorAverageRuntimes({
					monitorAverageRuntimes: JSON.parse(payload[3]),
				}),
			);
		});

		this.refreshIntervalSubscription = this.refreshIntervalSubject
			.pipe(debounceTime(1000))
			.subscribe((value) => {
				/* Logging this element separately since couldn't do it within
				the appLog directive. */
				this._electronService.send(
					IpcMessage.Log,
					"INPUT-SELECT",
					"MONITOR-DATA-SET-REFRESH-INTERVAL" + ": " + value,
				);

				this._electronService.send(IpcMessage.UpdateMonitorRefreshInterval, value);
			});

		this.appColorThemeSubscription = this.appColorTheme$.subscribe((value) => {
			this.eChartTheme = value.toUpperCase() === "DARK" ? this.eChartCustomDarkTheme : "";
		});
	}

	ngOnDestroy(): void {
		this.refreshIntervalSubscription.unsubscribe();
		this.appColorThemeSubscription.unsubscribe();
	}

	refresh(): void {
		this.isFetchingData = true;
		this._electronService.send(IpcMessage.GetMonitorData);
	}

	updateRefreshInterval(value: number): void {
		this.refreshIntervalSubject.next(value);
	}

	includeDevelopersToggleChange(event: MatSlideToggleChange): void {
		/* Logging this element separately since couldn't do it within the
		appLog directive. */
		this._electronService.send(
			IpcMessage.Log,
			"INPUT-TOGGLE",
			"MONITOR-DATA-INCLUDE-DEVELOPERS" + ": " + event.checked,
		);

		this.processImportantMessages(event.checked);
		this.processAccessLogs(event.checked);
	}

	processImportantMessages(areDevelopersIncluded: boolean, payload?: string): void {
		if (payload) {
			this.unfilteredImportantLogMessages = JSON.parse(payload, (key, value) => {
				if (key.toUpperCase() === "TIMESTAMP") return new Date(value);
				return value;
			});
		}

		this.importantLogMessages.set(
			areDevelopersIncluded
				? this.unfilteredImportantLogMessages
				: this.unfilteredImportantLogMessages.filter(
						(importantLogMessage: ImportantMessage) =>
							!this.developers.includes(importantLogMessage.userId.toUpperCase()),
				  ),
		);
	}

	processAccessLogs(areDevelopersIncluded: boolean, payload?: string): void {
		if (payload) {
			this.unfilteredAccessLog = JSON.parse(payload, (key, value) => {
				if (key.toUpperCase() === "LASTACCESSED") return new Date(value);
				return value;
			});
		}

		let index = 0;

		this.accessLog.set(
			areDevelopersIncluded
				? this.unfilteredAccessLog.map((el) => ({
						rowNumber: ++index,
						userId: el.userId,
						lastAccessed: el.lastAccessed,
						appVersion: el.appVersion,
				  }))
				: this.unfilteredAccessLog
						.filter((el) => !this.developers.includes(el.userId.toUpperCase()))
						.map((el) => ({
							rowNumber: ++index,
							userId: el.userId,
							lastAccessed: el.lastAccessed,
							appVersion: el.appVersion,
						})),
		);
	}
}
