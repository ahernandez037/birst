import { Component, OnInit, OnDestroy, Input } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { BrowseDirectoryButton } from "src/app/models/browse-directory-button";
import { SettingsFormGroup } from "src/app/models/settings-form-group";
import { ColorThemeService } from "src/app/services/color-theme.service";
import { ElectronService } from "src/app/services/electron.service";
import { IpcMessage } from "src/backend/ipc-handlers";

@Component({
	selector: "app-general",
	templateUrl: "./general.component.html",
	styleUrls: ["./general.component.scss"],
})
export class GeneralComponent implements OnInit, OnDestroy {
	@Input() browseDirectoryButtons: BrowseDirectoryButton[];

	formGroup: FormGroup<SettingsFormGroup>;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
		public colorTheme: ColorThemeService,
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}

	getLoadingStatus(formControlName: string): boolean {
		const button = this.browseDirectoryButtons.find(
			(button) => button.formControlName === formControlName,
		);

		if (!button) {
			return false;
		}

		return button.isLoading;
	}

	async getDirectory(formControlName: string): Promise<void> {
		const button = this.browseDirectoryButtons.find(
			(button) => button.formControlName === formControlName,
		);

		if (!button) {
			return;
		}

		button.isLoading = true;
		const directory = await this._electronService.invoke(IpcMessage.GetDirectory);

		if (directory) {
			this.formGroup.get(button.formControlName)?.setValue(directory);
		}

		button.isLoading = false;
	}
}
