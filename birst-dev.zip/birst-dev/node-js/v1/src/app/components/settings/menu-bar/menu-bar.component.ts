import { Observable } from "rxjs";
import { Store } from "@ngrx/store";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { AppState } from "src/app/models/app-state";
import { IpcMessage } from "src/backend/ipc-handlers";
import { MaintenanceSettings } from "src/backend/app-settings";
import { ElectronService } from "src/app/services/electron.service";
import { SettingsFormGroup } from "src/app/models/settings-form-group";
import { selectMaintenanceSettings } from "src/app/store/app-state.selectors";

@Component({
	selector: "app-settings-menu-bar",
	templateUrl: "./menu-bar.component.html",
	styleUrls: ["./menu-bar.component.scss"],
})
export class MenuBarComponent implements OnInit, OnDestroy {
	maintenanceSettings$: Observable<MaintenanceSettings>;
	formGroup: FormGroup<SettingsFormGroup>;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
		private _snackBar: MatSnackBar,
		private _store: Store<{ appState: AppState }>,
	) {}

	ngOnInit(): void {
		this.maintenanceSettings$ = this._store.select(selectMaintenanceSettings);
		this.formGroup = this._formGroupDirective.control;
		this.initIpcListeners();
	}

	ngOnDestroy(): void {}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.SaveUserSettingsSuccess, () => {
			this._snackBar.open("Settings saved successfully.", undefined, {
				duration: 2500,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});
	}

	saveSettings(): void {
		this._electronService.send(
			IpcMessage.SaveUserSettings,
			JSON.stringify(this.formGroup.value),
		);

		if (this.formGroup.controls.isConsoleShownOnStartup.value) {
			this._electronService.send(IpcMessage.ShowConsole);
		} else {
			this._electronService.send(IpcMessage.HideConsole);
		}
	}
}
