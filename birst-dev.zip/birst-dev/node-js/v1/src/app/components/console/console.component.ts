import { Observable } from "rxjs";
import { Store } from "@ngrx/store";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { AppState } from "../../models/app-state";
import { ConsoleMessage } from "../../models/console-message";
import { selectConsoleMessages } from "../../store/app-state.selectors";

@Component({
	selector: "app-console",
	templateUrl: "./console.component.html",
	styleUrls: ["./console.component.scss"],
})
export class ConsoleComponent implements OnInit, OnDestroy {
	consoleMessages$: Observable<ConsoleMessage[]>;

	constructor(private _store: Store<{ appState: AppState }>) {}

	ngOnInit(): void {
		this.consoleMessages$ = this._store.select(selectConsoleMessages);
	}

	ngOnDestroy(): void {}
}
