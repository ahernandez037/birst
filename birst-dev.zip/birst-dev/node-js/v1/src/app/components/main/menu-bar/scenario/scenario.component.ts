import { DateTime } from "luxon";
import { Store } from "@ngrx/store";
import { Observable, Subscription } from "rxjs";
import { MatSnackBar } from "@angular/material/snack-bar";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from "@angular/core";
import { AppState } from "src/app/models/app-state";
import { ScenarioForm } from "src/backend/scenario";
import { IpcMessage } from "src/backend/ipc-handlers";
import { UserSettings } from "src/backend/user-settings";
import { RateRevision } from "src/backend/rate-revision";
import { MaintenanceSettings } from "src/backend/app-settings";
import * as fromAppState from "src/app/store/app-state.selectors";
import { ElectronService } from "src/app/services/electron.service";
import { updateAdvancedInputs } from "../../shared/database-objects";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import {
	updateRateRevision,
	updateScenarioForm,
	updateOverallRateImpact,
} from "src/app/store/app-state.actions";

@Component({
	selector: "app-scenario",
	templateUrl: "./scenario.component.html",
	styleUrls: ["./scenario.component.scss"],
})
export class ScenarioComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() isDeveloper$: Observable<boolean>;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() userSettings$: Observable<UserSettings>;
	@Output() isFormDisabledChange = new EventEmitter<boolean>();

	maintenanceSettings$: Observable<MaintenanceSettings>;
	formGroup: FormGroup<ScenarioFormGroup>;
	isScenarioLoading: boolean;
	isScenarioRunning: boolean;
	private _defaultScenarioDirectory: string;
	private _userSettingsSubscription: Subscription;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
		private _store: Store<{ appState: AppState }>,
		private _matSnackBar: MatSnackBar,
	) {}

	ngOnInit(): void {
		this.maintenanceSettings$ = this._store.select(fromAppState.selectMaintenanceSettings);
		this.formGroup = this._formGroupDirective.control;
		this.isScenarioLoading = false;
		this.isScenarioRunning = false;

		this._userSettingsSubscription = this.userSettings$.subscribe(
			(value) => (this._defaultScenarioDirectory = value.defaultScenarioDirectory),
		);

		this.initIpcListeners();
	}

	ngOnDestroy(): void {
		this._userSettingsSubscription.unsubscribe();
	}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.LoadScenarioSuccess, (payload) => {
			const formGroup = JSON.parse(payload) as ScenarioForm;

			// Need to convert dates to UTC in ISO format for the date input
			// elements to properly display them.
			formGroup.inforceDate =
				DateTime.fromFormat(formGroup.inforceDate, "yyyy-MM-dd").toUTC().toISO() ?? "";

			formGroup.renewalDate =
				DateTime.fromFormat(formGroup.renewalDate, "yyyy-MM-dd").toUTC().toISO() ?? "";

			formGroup.newDate =
				DateTime.fromFormat(formGroup.newDate, "yyyy-MM-dd").toUTC().toISO() ?? "";

			formGroup.availableDate =
				DateTime.fromFormat(formGroup.availableDate, "yyyy-MM-dd").toUTC().toISO() ?? "";

			formGroup.startDate =
				DateTime.fromFormat(formGroup.startDate, "yyyy-MM-dd").toUTC().toISO() ?? "";

			formGroup.endDate =
				DateTime.fromFormat(formGroup.endDate, "yyyy-MM-dd").toUTC().toISO() ?? "";

			formGroup.fdrcTimestamp =
				DateTime.fromFormat(formGroup.fdrcTimestamp, "yyyy-MM-dd").toUTC().toISO() ?? "";

			// ! Setting value here triggers all UI logic, e.g., setting/
			// ! clearing validators and auto-populating some fields (see below).
			// ! Therefore, need to be very careful to manually set back certain
			// ! fields as to overwrite the UI logic with the actual values from
			// ! the scenario file being loaded.
			this.formGroup.setValue(formGroup);

			// Need to manually set the "Save Data Dump to Hard Drive" toggle
			// after setting the form group value above since setting the form
			// group value triggers the logic that automatically sets the toggle
			// which overrides the value from the scenario file.
			this.formGroup.controls.saveDataDumpToHardDrive.setValue(
				formGroup.saveDataDumpToHardDrive,
			);

			// Same as above, these dates are auto-populated by the UI, so need
			// to manually set them back to the values from the scenario file.
			this.formGroup.controls.newDate.setValue(formGroup.newDate);
			this.formGroup.controls.availableDate.setValue(formGroup.availableDate);

			// The following code is useful for debugging issues related to
			// invalid form controls. If any invalid controls are found after
			// loading a scenario file, they will be printed to the Chrome Dev
			// Tools console.
			const invalidControls = [];
			const controls = this.formGroup.controls;

			for (const name in controls) {
				if (controls[name as keyof ScenarioFormGroup].invalid) {
					invalidControls.push(name);
				}
			}

			if (invalidControls.length > 0) console.error("INVALID CONTROLS:", invalidControls);

			this._matSnackBar.open("Scenario loaded successfully.", undefined, {
				duration: 2500,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});

			this.isScenarioLoading = false;

			this._store.dispatch(
				updateScenarioForm({
					scenarioForm: formGroup,
				}),
			);
		});

		this._electronService.on(IpcMessage.LoadScenarioCanceled, () => {
			this.isScenarioLoading = false;
		});

		this._electronService.on(IpcMessage.RunScenarioSuccess, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isScenarioRunning = false;

			this._matSnackBar.open("Scenario run successful.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.RunScenarioError, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isScenarioRunning = false;
		});

		this._electronService.on(IpcMessage.RunScenarioCanceled, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isScenarioRunning = false;
		});

		this._electronService.on(IpcMessage.CloneScenarioFileSuccess, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isScenarioLoading = false;

			this._matSnackBar.open("Scenario clone successful.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.CloneScenarioFileCanceled, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isScenarioLoading = false;

			this._matSnackBar.open("Scenario clone canceled.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.CloneScenarioFileError, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isScenarioLoading = false;
		});
	}

	newScenario(): void {
		this.formGroup.reset();
		this._electronService.send(IpcMessage.ResetScenarioFile);
		this._electronService.send(IpcMessage.ResetRateRevision);
		this._electronService.send(IpcMessage.GetNewScenarioId);
		this.formGroup.controls.scenarioDirectory.setValue(this._defaultScenarioDirectory);

		this._store.dispatch(
			updateOverallRateImpact({
				overallRateImpact: null,
			}),
		);

		this._store.dispatch(
			updateRateRevision({
				rateRevision: {} as RateRevision,
			}),
		);
	}

	loadScenario(): void {
		this.isScenarioLoading = true;
		this._electronService.send(IpcMessage.LoadScenarioFile);
	}

	cloneScenario(): void {
		this.isScenarioLoading = true;
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);

		this._electronService.send(
			IpcMessage.CloneScenarioFile,
			JSON.stringify(this.formGroup.value),
		);
	}

	openScenarioDirectory(): void {
		this._electronService.send(
			IpcMessage.OpenUrl,
			this.formGroup.controls.scenarioDirectory.value ?? "",
		);
	}

	async runScenario(isDebugRun: boolean): Promise<void> {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isScenarioRunning = true;

		const dataDumpTableName = await this._electronService.invoke(
			IpcMessage.GetDataDumpTableName,
			JSON.stringify(this.formGroup.value),
		);

		this.formGroup.controls.dataDumpTable.setValue(JSON.parse(dataDumpTableName) ?? "");

		const databaseObjects = await this._electronService.invoke(
			IpcMessage.GetDatabaseObjects,
			JSON.stringify(this.formGroup.value),
		);

		updateAdvancedInputs(this.formGroup, JSON.parse(databaseObjects));

		this._electronService.send(
			IpcMessage.RunScenario,
			JSON.stringify(this.formGroup.value),
			isDebugRun,
		);
	}
}
