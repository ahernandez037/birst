import { Component, OnInit, OnDestroy, Input } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Observable } from "rxjs";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { RateRevision } from "src/backend/rate-revision";

@Component({
	selector: "app-effective-date-range",
	templateUrl: "./effective-date-range.component.html",
	styleUrls: ["./effective-date-range.component.scss"],
})
export class EffectiveDateRangeComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;

	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}
}
