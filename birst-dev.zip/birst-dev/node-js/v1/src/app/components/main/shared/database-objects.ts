import { FormGroup } from "@angular/forms";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { DatabaseObjects } from "src/backend/database-objects";

export const updateAdvancedInputs = (
	formGroup: FormGroup<ScenarioFormGroup>,
	databaseObjects?: DatabaseObjects,
) => {
	formGroup.controls.extractPolicyData.setValue(databaseObjects?.extractPolicyData ?? "");

	formGroup.controls.rateTableListCurrent.setValue(databaseObjects?.rateTableListCurrent ?? "");

	formGroup.controls.rateTableListProposed.setValue(databaseObjects?.rateTableListProposed ?? "");

	formGroup.controls.prepareRateTablesCurrent.setValue(
		databaseObjects?.prepareRateTablesCurrent ?? "",
	);

	formGroup.controls.prepareRateTablesProposed.setValue(
		databaseObjects?.prepareRateTablesProposed ?? "",
	);

	formGroup.controls.assignRatesCurrent.setValue(databaseObjects?.assignRatesCurrent ?? "");

	formGroup.controls.assignRatesProposed.setValue(databaseObjects?.assignRatesProposed ?? "");

	formGroup.controls.calculatePremiumCurrent.setValue(
		databaseObjects?.calculatePremiumCurrent ?? "",
	);

	formGroup.controls.calculatePremiumProposed.setValue(
		databaseObjects?.calculatePremiumProposed ?? "",
	);

	formGroup.controls.createDataDump.setValue(databaseObjects?.createDataDump ?? "");

	formGroup.controls.createReports.setValue(databaseObjects?.createReports ?? "");

	formGroup.controls.policyDataOverrideTable.setValue(
		databaseObjects?.policyDataOverrideTable ?? "",
	);

	formGroup.controls.driverDataOverrideTable.setValue(
		databaseObjects?.driverDataOverrideTable ?? "",
	);
};
