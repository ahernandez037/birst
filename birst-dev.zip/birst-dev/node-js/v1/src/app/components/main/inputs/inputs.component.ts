import { Observable } from "rxjs";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { Product } from "src/backend/products";
import { GeoState } from "src/backend/geo-states";
import { RateRevision } from "src/backend/rate-revision";
import { AvailableDate } from "src/backend/available-dates";
import { WorkCompBureauRate } from "src/backend/wc-bureau-rates";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";

@Component({
	selector: "app-inputs",
	templateUrl: "./inputs.component.html",
	styleUrls: ["./inputs.component.scss"],
})
export class InputsComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() geoStates$: Observable<GeoState[]>;
	@Input() workCompBureauRates$: Observable<WorkCompBureauRate[]>;
	@Input() products$: Observable<Product[]>;
	@Input() availableDates$: Observable<AvailableDate[]>;

	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}
}
