import { ComponentFixture, TestBed } from "@angular/core/testing";
import { WcGradientAiInitiativeComponent } from "./wc-gradient-ai-initiative.component";

describe("WcGradientAiComponent", () => {
	let component: WcGradientAiInitiativeComponent;
	let fixture: ComponentFixture<WcGradientAiInitiativeComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [WcGradientAiInitiativeComponent],
		});
		fixture = TestBed.createComponent(WcGradientAiInitiativeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
