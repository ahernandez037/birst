import { Component, OnInit, OnDestroy, Input } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Observable, Subscription } from "rxjs";
import { RateRevision } from "src/backend/rate-revision";
import { Product } from "src/backend/products";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { updateAdvancedInputs } from "../../shared/database-objects";

@Component({
	selector: "app-version",
	templateUrl: "./version.component.html",
	styleUrls: ["./version.component.scss"],
})
export class VersionComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() products$: Observable<Product[]>;

	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;

		this._subscription = this.formGroup.controls.version.valueChanges.subscribe(() => {
			updateAdvancedInputs(this.formGroup);
		});
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}
}
