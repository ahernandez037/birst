import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Observable } from "rxjs";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { RateRevision } from "src/backend/rate-revision";
import { UserSettings } from "src/backend/user-settings";

@Component({
	selector: "app-main-menu-bar",
	templateUrl: "./menu-bar.component.html",
	styleUrls: ["./menu-bar.component.scss"],
})
export class MenuBarComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() isScenarioRunning: boolean;
	@Input() isDeveloper$: Observable<boolean>;
	@Input() isFitMember$: Observable<boolean>;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() overallRateImpact$: Observable<number | null>;
	@Input() userSettings$: Observable<UserSettings>;

	@Output() isFormDisabledChange = new EventEmitter<boolean>();

	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}

	updateIsFormDisabled(value: boolean) {
		this.isFormDisabledChange.emit(value);
	}
}
