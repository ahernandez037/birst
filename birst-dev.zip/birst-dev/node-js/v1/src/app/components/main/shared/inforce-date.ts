import { DateTime } from "luxon";

export const getDefaultInforceDate = (): string => {
	return DateTime.now().minus({ month: 1 }).endOf("month").toISO() ?? "";
};

export const getMaxInforceDate = (runMode: string): string => {
	if (runMode === "VALIDATION") {
		// No max date when running in validation mode, since we need to use
		// future dates for MRT & QAT.
		return "9999-12-31";
	} else {
		return DateTime.now().minus({ days: 1 }).toISO() ?? "";
	}
};
