import { ComponentFixture, TestBed } from "@angular/core/testing";

import { NextStepsDialogComponent } from "./next-steps-dialog.component";

describe("NextStepsDialogComponent", () => {
	let component: NextStepsDialogComponent;
	let fixture: ComponentFixture<NextStepsDialogComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [NextStepsDialogComponent],
		}).compileComponents();

		fixture = TestBed.createComponent(NextStepsDialogComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
