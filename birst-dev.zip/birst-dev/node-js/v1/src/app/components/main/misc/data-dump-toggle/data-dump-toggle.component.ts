import { Observable } from "rxjs";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { MatSlideToggleChange } from "@angular/material/slide-toggle";
import { IpcMessage } from "src/backend/ipc-handlers";
import { RateRevision } from "src/backend/rate-revision";
import { isLargeDataDump } from "../../shared/data-dump";
import { ElectronService } from "src/app/services/electron.service";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";

@Component({
	selector: "app-data-dump-toggle",
	templateUrl: "./data-dump-toggle.component.html",
	styleUrls: ["./data-dump-toggle.component.scss"],
})
export class DataDumpToggleComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;

	formGroup: FormGroup<ScenarioFormGroup>;
	isLargeDataDump: (formGroup: FormGroup<ScenarioFormGroup>) => boolean;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		this.isLargeDataDump = isLargeDataDump;
	}

	ngOnDestroy(): void {}

	/* Logging this element separately since couldn't do it within the appLog
    directive. */
	logToggleChange(event: MatSlideToggleChange) {
		this._electronService.send(
			IpcMessage.Log,
			"INPUT-TOGGLE",
			"SAVE-DATA-DUMP-TO-HARD-DRIVE" + ": " + event.checked,
		);
	}
}
