import { ComponentFixture, TestBed } from "@angular/core/testing";

import { RunModeComponent } from "./run-mode.component";

describe("RunModeComponent", () => {
	let component: RunModeComponent;
	let fixture: ComponentFixture<RunModeComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [RunModeComponent],
		}).compileComponents();

		fixture = TestBed.createComponent(RunModeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
