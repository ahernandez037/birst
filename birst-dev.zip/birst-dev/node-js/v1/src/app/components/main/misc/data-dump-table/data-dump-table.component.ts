import { Component, OnInit, OnDestroy } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Clipboard } from "@angular/cdk/clipboard";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";

@Component({
	selector: "app-data-dump-table",
	templateUrl: "./data-dump-table.component.html",
	styleUrls: ["./data-dump-table.component.scss"],
})
export class DataDumpTableComponent implements OnInit, OnDestroy {
	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _clipboard: Clipboard,
		private _matSnackBar: MatSnackBar,
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}

	copyDataDumpToClipboard() {
		this._clipboard.copy(this.formGroup.controls.dataDumpTable.value);

		this._matSnackBar.open("Copied to clipboard.", undefined, {
			duration: 2500,
			horizontalPosition: "center",
			verticalPosition: "bottom",
		});
	}
}
