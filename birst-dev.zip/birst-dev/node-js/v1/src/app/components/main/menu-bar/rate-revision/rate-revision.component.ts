import { Observable } from "rxjs";
import { Store } from "@ngrx/store";
import { MatSnackBar } from "@angular/material/snack-bar";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from "@angular/core";
import { AppState } from "src/app/models/app-state";
import { MatDialog } from "@angular/material/dialog";
import { IpcMessage } from "src/backend/ipc-handlers";
import { RateRevision } from "src/backend/rate-revision";
import { MaintenanceSettings } from "src/backend/app-settings";
import * as fromAppState from "src/app/store/app-state.selectors";
import { ElectronService } from "src/app/services/electron.service";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { ActiveExecutiveSummary } from "src/backend/executive-summary";
import { ExecutiveSummaryComponent } from "./executive-summary/executive-summary.component";

@Component({
	selector: "app-rate-revision",
	templateUrl: "./rate-revision.component.html",
	styleUrls: ["./rate-revision.component.scss"],
})
export class RateRevisionComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() isDeveloper$: Observable<boolean>;
	@Input() isFitMember$: Observable<boolean>;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() overallRateImpact$: Observable<number | null>;
	@Output() isFormDisabledChange = new EventEmitter<boolean>();

	maintenanceSettings$: Observable<MaintenanceSettings>;
	isProcessingRateRevisionFunction: boolean;
	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
		private _store: Store<{ appState: AppState }>,
		private _matSnackBar: MatSnackBar,
		private _dialog: MatDialog,
	) {}

	ngOnInit(): void {
		this.maintenanceSettings$ = this._store.select(fromAppState.selectMaintenanceSettings);
		this.formGroup = this._formGroupDirective.control;
		this.isProcessingRateRevisionFunction = false;
		this.initIpcListeners();
	}

	ngOnDestroy(): void {}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.DoneInitiatingRateRevision, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.DoneCreatingCombinedSerffReport, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.DoneCancelingRateRevision, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.SaveRatesAndGenerateOutputSuccess, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
			this._matSnackBar.open("Rates saved & output generated successfully.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.SaveRatesAndGenerateOutputError, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.CreateClsFilesSuccess, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
			this._matSnackBar.open("CLS files created successfully.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.CreateClsFilesError, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.CreateClsFilesCanceled, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.CreateRatabaseFilesSuccess, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
			this._matSnackBar.open("Ratabase files created successfully.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.CreateRatabaseFilesError, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.CreateRatabaseFilesCanceled, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.DoneCheckingForSavedRates, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.SaveRatesSuccess, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
			this._matSnackBar.open("Rates saved successfully.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.SaveRatesError, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.SaveRatesCanceled, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.DeleteRatesSuccess, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
			this._matSnackBar.open("Rates deleted successfully.", undefined, {
				duration: 3000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.DeleteRatesError, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});

		this._electronService.on(IpcMessage.DeleteRatesCanceled, () => {
			this.isFormDisabled = false;
			this.isFormDisabledChange.emit(false);
			this.isProcessingRateRevisionFunction = false;
		});
	}

	async showExecutiveSummary(): Promise<void> {
		const activeExecutiveSummaries: ActiveExecutiveSummary[] = JSON.parse(
			await this._electronService.invoke(
				IpcMessage.GetExecutiveSummary,
				JSON.stringify(this.formGroup.value),
			),
		);

		if (activeExecutiveSummaries?.length === 0) {
			this._matSnackBar.open("There are no active rate revisions.", undefined, {
				duration: 5000,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		} else {
			const lineOfBusiness = activeExecutiveSummaries[0].lineOfBusiness;
			let body = activeExecutiveSummaries;

			switch (lineOfBusiness.toUpperCase()) {
				case "AUTO":
					body = activeExecutiveSummaries.sort(
						(a, b) => (Number(a.version) || 999) - (Number(b.version) || 999),
					);
					break;
				case "CMP":
					body = activeExecutiveSummaries.sort((a, b) =>
						a.product.localeCompare(b.product),
					);
					break;
				case "WC":
					body = activeExecutiveSummaries.sort((a, b) =>
						a.version.localeCompare(b.version),
					);
					break;
			}

			this._dialog.open(ExecutiveSummaryComponent, {
				width: "100%",
				data: {
					header: [
						{
							state: activeExecutiveSummaries[0].state,
							lineOfBusiness,
							newDate: activeExecutiveSummaries[0].newDate,
							renewalDate: activeExecutiveSummaries[0].renewalDate,
							availableDate: activeExecutiveSummaries[0].availableDate,
						},
					],
					body,
				},
			});
		}
	}

	createCombinedSerffReport(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.CreateCombinedSerffReport);
	}

	initiateRateRevision(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.InitiateRateRevision);
	}

	cancelRateRevision(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.CancelRateRevision);
	}

	cancelAllRateRevisions(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.CancelAllRateRevisions);
	}

	openFitDirectory(): void {
		/* Replace second occurrence of "BIRST". Need to skip 1st occurrence due
		to it being part of the parent directory "BIRST_Rate_Revision". */
		let occurrence = 0;
		const fitDirectory = this.formGroup.controls.scenarioDirectory.value.replace(
			/\\BIRST/g,
			(match) => (++occurrence === 2 ? "\\FIT" : match),
		);

		this._electronService.send(IpcMessage.OpenUrl, fitDirectory);
	}

	saveRatesAndGenerateOutput(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.SaveRatesAndGenerateOutput);
	}

	sendRequestToDeleteRates(): void {
		this._matSnackBar.open("Creating new email...", undefined, {
			duration: 3000,
			horizontalPosition: "center",
			verticalPosition: "bottom",
		});

		this._electronService.send(IpcMessage.CreateEmailRequestToDeleteRates);
	}

	checkForSavedRates(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.CheckForSavedRates);
	}

	saveRates(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.SaveRates);
	}

	deleteRates(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.DeleteRates);
	}

	createClsFiles(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.CreateClsFiles);
	}

	createRatabaseFiles(): void {
		this.isFormDisabled = true;
		this.isFormDisabledChange.emit(true);
		this.isProcessingRateRevisionFunction = true;
		this._electronService.send(IpcMessage.CreateRatabaseFiles);
	}
}
