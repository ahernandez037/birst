import { Observable, Subscription } from "rxjs";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Component, OnInit, OnDestroy, Input } from "@angular/core";
import { RateRevision } from "src/backend/rate-revision";
import { getMaxInforceDate } from "../../shared/inforce-date";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";

@Component({
	selector: "app-inforce-date",
	templateUrl: "./inforce-date.component.html",
	styleUrls: ["./inforce-date.component.scss"],
})
export class InforceDateComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;

	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;
	maxInforceDate: string;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		this.maxInforceDate = getMaxInforceDate(this.formGroup.controls.runMode.value);

		this._subscription = this.formGroup.controls.runMode.valueChanges.subscribe((value) => {
			this.maxInforceDate = getMaxInforceDate(value);
		});
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}
}
