import { ComponentFixture, TestBed } from "@angular/core/testing";

import { QueryMethodComponent } from "./query-method.component";

describe("QueryMethodComponent", () => {
	let component: QueryMethodComponent;
	let fixture: ComponentFixture<QueryMethodComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [QueryMethodComponent],
		}).compileComponents();

		fixture = TestBed.createComponent(QueryMethodComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
