import { ComponentFixture, TestBed } from "@angular/core/testing";

import { InforceDateComponent } from "./inforce-date.component";

describe("InforceDateComponent", () => {
	let component: InforceDateComponent;
	let fixture: ComponentFixture<InforceDateComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [InforceDateComponent],
		}).compileComponents();

		fixture = TestBed.createComponent(InforceDateComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
