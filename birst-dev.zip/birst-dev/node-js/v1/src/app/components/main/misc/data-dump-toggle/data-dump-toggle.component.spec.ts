import { ComponentFixture, TestBed } from "@angular/core/testing";

import { DataDumpToggleComponent } from "./data-dump-toggle.component";

describe("DataDumpToggleComponent", () => {
	let component: DataDumpToggleComponent;
	let fixture: ComponentFixture<DataDumpToggleComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [DataDumpToggleComponent],
		}).compileComponents();

		fixture = TestBed.createComponent(DataDumpToggleComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
