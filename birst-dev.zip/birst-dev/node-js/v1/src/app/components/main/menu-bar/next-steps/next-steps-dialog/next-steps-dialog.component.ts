import { Component, OnInit, OnDestroy, Inject } from "@angular/core";
import { MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ElectronService } from "src/app/services/electron.service";
import { IpcMessage } from "src/backend/ipc-handlers";

export interface NextStepsData {
	isAppStartAnnouncements: boolean;
	title: string;
	body: string;
	buttons: [{ text: string; type: "WEBSITE" | "DIRECTORY"; url: string }];
}

@Component({
	selector: "app-next-steps-dialog",
	templateUrl: "./next-steps-dialog.component.html",
	styleUrls: ["./next-steps-dialog.component.scss"],
})
export class NextStepsDialogComponent implements OnInit, OnDestroy {
	constructor(
		@Inject(MAT_DIALOG_DATA) public data: NextStepsData,
		private _electronService: ElectronService,
	) {}

	ngOnInit(): void {}

	ngOnDestroy(): void {}

	openUrl(type: "WEBSITE" | "DIRECTORY", url: string): void {
		this._electronService.send(IpcMessage.OpenUrl, type === "WEBSITE" ? "https://" + url : url);
	}
}
