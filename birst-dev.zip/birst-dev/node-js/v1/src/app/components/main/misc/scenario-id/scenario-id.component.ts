import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Observable } from "rxjs";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Clipboard } from "@angular/cdk/clipboard";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { ElectronService } from "src/app/services/electron.service";
import { IpcMessage } from "src/backend/ipc-handlers";

@Component({
	selector: "app-scenario-id",
	templateUrl: "./scenario-id.component.html",
	styleUrls: ["./scenario-id.component.scss"],
})
export class ScenarioIdComponent implements OnInit, OnDestroy {
	@Input() scenarioId$: Observable<string>;

	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _clipboard: Clipboard,
		private _matSnackBar: MatSnackBar,
		private _electronService: ElectronService,
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		this._electronService.send(IpcMessage.GetCurrentScenarioId);
	}

	ngOnDestroy(): void {}

	copyScenarioIdToClipboard() {
		this._clipboard.copy(this.formGroup.controls.scenarioId.value);

		this._matSnackBar.open("Copied to clipboard.", undefined, {
			duration: 2500,
			horizontalPosition: "center",
			verticalPosition: "bottom",
		});
	}
}
