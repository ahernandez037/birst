import { Store } from "@ngrx/store";
import { Observable, Subscription } from "rxjs";
import { MatDialog } from "@angular/material/dialog";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { User } from "src/backend/user";
import { Product } from "src/backend/products";
import { AppState } from "../../models/app-state";
import { GeoState } from "src/backend/geo-states";
import { IpcMessage } from "src/backend/ipc-handlers";
import { UserSettings } from "src/backend/user-settings";
import { RateRevision } from "src/backend/rate-revision";
import { AvailableDate } from "src/backend/available-dates";
import { getDefaultInforceDate } from "./shared/inforce-date";
import * as fromAppState from "../../store/app-state.selectors";
import { ElectronService } from "../../services/electron.service";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { updateOverallRateImpact, updateRateRevision } from "../../store/app-state.actions";
import { NextStepsDialogComponent } from "./menu-bar/next-steps/next-steps-dialog/next-steps-dialog.component";

@Component({
	selector: "app-main",
	templateUrl: "./main.component.html",
	styleUrls: ["./main.component.scss"],
})
export class MainComponent implements OnInit, OnDestroy {
	isFormDisabled: boolean;
	isAppReady$: Observable<boolean>;
	user$: Observable<User>;
	userSettings$: Observable<UserSettings>;
	geoStates$: Observable<GeoState[]>;
	products$: Observable<Product[]>;
	availableDates$: Observable<AvailableDate[]>;
	scenarioId$: Observable<string>;
	overallRateImpact$: Observable<number | null>;
	rateRevision$: Observable<RateRevision>;
	isDeveloper$: Observable<boolean>;
	isFitMember$: Observable<boolean>;
	isTestSuiteRunning$: Observable<boolean>;
	private _isTestSuiteRunningSubscription: Subscription;

	scenarioForm: FormGroup<ScenarioFormGroup>;

	constructor(
		private _store: Store<{ appState: AppState }>,
		private _formBuilder: FormBuilder,
		private _electronService: ElectronService,
		private _matSnackBar: MatSnackBar,
		private _dialog: MatDialog,
	) {}

	ngOnInit(): void {
		this.isFormDisabled = false;
		this.isAppReady$ = this._store.select(fromAppState.selectIsAppReady);
		this.user$ = this._store.select(fromAppState.selectUser);
		this.scenarioId$ = this._store.select(fromAppState.selectScenarioId);
		this.rateRevision$ = this._store.select(fromAppState.selectRateRevision);
		this.geoStates$ = this._store.select(fromAppState.selectGeoStates);
		this.products$ = this._store.select(fromAppState.selectProducts);
		this.availableDates$ = this._store.select(fromAppState.selectAvailableDates);
		this.overallRateImpact$ = this._store.select(fromAppState.selectOverallRateImpact);
		this.rateRevision$ = this._store.select(fromAppState.selectRateRevision);
		this.isDeveloper$ = this._store.select(fromAppState.selectIsDeveloper);
		this.isFitMember$ = this._store.select(fromAppState.selectIsFitMember);
		this.userSettings$ = this._store.select(fromAppState.selectUserSettings);
		this.isTestSuiteRunning$ = this._store.select(fromAppState.selectIsTestSuiteRunning);

		this.scenarioForm = this._formBuilder.nonNullable.group({
			runMode: ["RATE-CHANGE", Validators.required],
			queryMethod: ["IN-FORCE", Validators.required],
			geoState: ["", Validators.required],
			lineOfBusiness: ["", Validators.required],
			product: ["N/A"],
			version: ["N/A"],
			workCompAdoptBureauRates: [false],
			workCompBureauEffectiveDate: [""],
			workCompBureauReleaseDate: [""],
			workCompBureauStatusFlag: [""],
			newDate: ["", Validators.required],
			renewalDate: ["", Validators.required],
			availableDate: ["", Validators.required],
			inforceDate: [getDefaultInforceDate(), Validators.required],
			startDate: [""],
			endDate: [""],
			fdrcTimestamp: [""],
			dataSource: ["PROD", Validators.required],
			scenarioId: ["", Validators.required],
			scenarioDirectory: ["", Validators.required],
			dataDumpTable: ["TBD"],
			saveDataDumpToHardDrive: [true, Validators.required],
			useCountrywideData: [false, Validators.required],
			useAllVersionsData: [false, Validators.required],
			isAutoFlexRollout: [false, Validators.required],
			isRstGlSalesInitiative: [false, Validators.required],
			isWorkCompGradientAiInitiative: [false, Validators.required],
			extractPolicyData: [""],
			rateTableListCurrent: [""],
			rateTableListProposed: [""],
			prepareRateTablesCurrent: [""],
			prepareRateTablesProposed: [""],
			assignRatesCurrent: [""],
			assignRatesProposed: [""],
			calculatePremiumCurrent: [""],
			calculatePremiumProposed: [""],
			createDataDump: [""],
			createReports: [""],
			policyDataOverrideTable: [""],
			driverDataOverrideTable: [""],
		});

		this.initIpcListeners();

		this._isTestSuiteRunningSubscription = this.isTestSuiteRunning$.subscribe(
			(isTestSuiteRunning) => {
				this.isFormDisabled = isTestSuiteRunning;
			},
		);
	}

	ngOnDestroy(): void {
		this._isTestSuiteRunningSubscription.unsubscribe();
	}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.ShowAnnouncementsDialog, (payload) => {
			this.showAppStartAnnouncements(payload);
		});

		this._electronService.on(IpcMessage.FirstTimeSetupSuccess, () => {
			this._matSnackBar.open("Email saved successfully.", undefined, {
				duration: 2500,
				horizontalPosition: "center",
				verticalPosition: "bottom",
			});
		});

		this._electronService.on(IpcMessage.UpdateOverallRateImpact, (payload) => {
			this._store.dispatch(
				updateOverallRateImpact({
					overallRateImpact: payload[0],
				}),
			);
		});

		this._electronService.on(IpcMessage.UpdateRateRevision, (payload) => {
			this._store.dispatch(
				updateRateRevision({
					rateRevision: JSON.parse(payload),
				}),
			);
		});
	}

	async showAppStartAnnouncements(payload: string): Promise<void> {
		const announcements = JSON.parse(payload);

		this._dialog.open(NextStepsDialogComponent, {
			disableClose: true,
			width: announcements.modalWidth ? `${announcements.modalWidth}px` : undefined,
			height: announcements.modalHeight ? `${announcements.modalHeight}px` : undefined,
			data: {
				isAppStartAnnouncements: true,
				title: announcements.title,
				body: announcements.htmlContent,
				buttons: announcements.buttons,
			},
		});
	}

	updateIsFormDisabled(value: boolean) {
		this.isFormDisabled = value;
	}
}
