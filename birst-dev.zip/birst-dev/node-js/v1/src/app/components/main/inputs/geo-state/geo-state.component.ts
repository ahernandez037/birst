import { Observable, Subscription } from "rxjs";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Component, OnInit, OnDestroy, Input } from "@angular/core";
import { GeoState } from "src/backend/geo-states";
import { RateRevision } from "src/backend/rate-revision";
import { toggleSaveDataDump } from "../../shared/data-dump";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";

@Component({
	selector: "app-geo-state",
	templateUrl: "./geo-state.component.html",
	styleUrls: ["./geo-state.component.scss"],
})
export class GeoStateComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() geoStates$: Observable<GeoState[]>;

	formGroup: FormGroup<ScenarioFormGroup>;
	private _geoStateSubscription: Subscription;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		const lineOfBusiness = this.formGroup.controls.lineOfBusiness;
		const product = this.formGroup.controls.product;
		const version = this.formGroup.controls.version;

		this._geoStateSubscription = this.formGroup.controls.geoState.valueChanges.subscribe(() => {
			lineOfBusiness.setValue("");
			product.setValue("");
			version.setValue("");
			lineOfBusiness.updateValueAndValidity();
			product.updateValueAndValidity();
			version.updateValueAndValidity();
			toggleSaveDataDump(this.formGroup);
		});
	}

	ngOnDestroy(): void {
		this._geoStateSubscription.unsubscribe();
	}
}
