import { ComponentFixture, TestBed } from "@angular/core/testing";

import { InScopeTablesComponent } from "./in-scope-tables.component";

describe("InScopeTablesComponent", () => {
	let component: InScopeTablesComponent;
	let fixture: ComponentFixture<InScopeTablesComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [InScopeTablesComponent],
		}).compileComponents();

		fixture = TestBed.createComponent(InScopeTablesComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
