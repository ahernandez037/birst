import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Observable } from "rxjs";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { RateRevision } from "src/backend/rate-revision";

@Component({
	selector: "app-data-source",
	templateUrl: "./data-source.component.html",
	styleUrls: ["./data-source.component.scss"],
})
export class DataSourceComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;

	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}
}
