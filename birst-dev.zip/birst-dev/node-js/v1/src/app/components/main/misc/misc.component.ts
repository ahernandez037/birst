import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Observable } from "rxjs";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { AvailableDate } from "src/backend/available-dates";
import { GeoState } from "src/backend/geo-states";
import { Product } from "src/backend/products";
import { RateRevision } from "src/backend/rate-revision";
import { UserSettings } from "src/backend/user-settings";

@Component({
	selector: "app-misc",
	templateUrl: "./misc.component.html",
	styleUrls: ["./misc.component.scss"],
})
export class MiscComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() geoStates$: Observable<GeoState[]>;
	@Input() products$: Observable<Product[]>;
	@Input() availableDates$: Observable<AvailableDate[]>;
	@Input() scenarioId$: Observable<string>;
	@Input() userSettings$: Observable<UserSettings>;

	formGroup: FormGroup<ScenarioFormGroup>;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
	}

	ngOnDestroy(): void {}
}
