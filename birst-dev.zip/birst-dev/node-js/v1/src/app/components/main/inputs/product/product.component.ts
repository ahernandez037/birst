import { Component, OnInit, OnDestroy, Input } from "@angular/core";
import { FormGroup, FormGroupDirective, Validators } from "@angular/forms";
import { Observable, Subscription } from "rxjs";
import { RateRevision } from "src/backend/rate-revision";
import { Product } from "src/backend/products";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";
import { updateAdvancedInputs } from "../../shared/database-objects";

@Component({
	selector: "app-product",
	templateUrl: "./product.component.html",
	styleUrls: ["./product.component.scss"],
})
export class ProductComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() products$: Observable<Product[]>;

	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		const version = this.formGroup.controls.version;

		this._subscription = this.formGroup.controls.product.valueChanges.subscribe((value) => {
			if (value === "AUTO") {
				version.setValue("");
				version.setValidators(Validators.required);
			} else if (value === "GAR") {
				version.setValue("");
				version.clearValidators();
			}

			version.updateValueAndValidity();
			updateAdvancedInputs(this.formGroup);
		});
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}
}
