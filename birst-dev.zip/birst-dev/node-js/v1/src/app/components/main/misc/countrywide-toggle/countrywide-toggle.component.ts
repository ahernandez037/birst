import { Observable, Subscription } from "rxjs";
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { MatSlideToggleChange } from "@angular/material/slide-toggle";
import { IpcMessage } from "src/backend/ipc-handlers";
import { RateRevision } from "src/backend/rate-revision";
import { toggleSaveDataDump } from "../../shared/data-dump";
import { ElectronService } from "src/app/services/electron.service";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";

@Component({
	selector: "app-countrywide-toggle",
	templateUrl: "./countrywide-toggle.component.html",
	styleUrls: ["./countrywide-toggle.component.scss"],
})
export class CountrywideToggleComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;

	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;

	constructor(
		private _formGroupDirective: FormGroupDirective,
		private _electronService: ElectronService,
	) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;

		this._subscription = this.formGroup.controls.useCountrywideData.valueChanges.subscribe(
			() => {
				toggleSaveDataDump(this.formGroup);
			},
		);
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}

	/* Logging this element separately since couldn't do it within the appLog
    directive. */
	logToggleChange(event: MatSlideToggleChange) {
		this._electronService.send(
			IpcMessage.Log,
			"INPUT-TOGGLE",
			"USE-COUNTRYWIDE-DATA" + ": " + event.checked,
		);
	}
}
