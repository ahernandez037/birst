import { ComponentFixture, TestBed } from "@angular/core/testing";

import { RatesFileComponent } from "./rates-file.component";

describe("RatesFileComponent", () => {
	let component: RatesFileComponent;
	let fixture: ComponentFixture<RatesFileComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [RatesFileComponent],
		}).compileComponents();

		fixture = TestBed.createComponent(RatesFileComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
