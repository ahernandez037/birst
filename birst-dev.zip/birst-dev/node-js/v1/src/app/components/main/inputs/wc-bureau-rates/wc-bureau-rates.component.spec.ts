import { ComponentFixture, TestBed } from "@angular/core/testing";

import { WcBureauRatesComponent } from "./wc-bureau-rates.component";

describe("WcBureauRatesComponent", () => {
	let component: WcBureauRatesComponent;
	let fixture: ComponentFixture<WcBureauRatesComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [WcBureauRatesComponent],
		});
		fixture = TestBed.createComponent(WcBureauRatesComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
