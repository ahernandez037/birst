import { Observable, Subscription } from "rxjs";
import { Component, OnInit, OnDestroy, Input } from "@angular/core";
import { FormGroup, FormGroupDirective, Validators } from "@angular/forms";
import { RunMode } from "src/backend/scenario";
import { Product } from "src/backend/products";
import { RateRevision } from "src/backend/rate-revision";
import { toggleSaveDataDump } from "../../shared/data-dump";
import { updateAdvancedInputs } from "../../shared/database-objects";
import { ScenarioFormGroup } from "src/app/models/scenario-form-group";

@Component({
	selector: "app-line-of-business",
	templateUrl: "./line-of-business.component.html",
	styleUrls: ["./line-of-business.component.scss"],
})
export class LineOfBusinessComponent implements OnInit, OnDestroy {
	@Input() isFormDisabled: boolean;
	@Input() rateRevision$: Observable<RateRevision>;
	@Input() products$: Observable<Product[]>;

	formGroup: FormGroup<ScenarioFormGroup>;
	private _subscription: Subscription;

	constructor(private _formGroupDirective: FormGroupDirective) {}

	ngOnInit(): void {
		this.formGroup = this._formGroupDirective.control;
		const product = this.formGroup.controls.product;
		const version = this.formGroup.controls.version;
		const workCompAdoptBureauRates = this.formGroup.controls.workCompAdoptBureauRates;
		const newDate = this.formGroup.controls.newDate;
		const renewalDate = this.formGroup.controls.renewalDate;
		const availableDate = this.formGroup.controls.availableDate;

		this._subscription = this.formGroup.controls.lineOfBusiness.valueChanges.subscribe(
			(value) => {
				switch (value) {
					case "CMP":
						product.setValue("");
						product.setValidators(Validators.required);
						version.clearValidators();
						version.setValue("");
						workCompAdoptBureauRates.clearValidators();
						workCompAdoptBureauRates.setValue(false);
						break;
					case "AUTO":
						product.setValue("");
						product.setValidators(Validators.required);
						version.setValue("");
						version.setValidators(Validators.required);
						workCompAdoptBureauRates.clearValidators();
						workCompAdoptBureauRates.setValue(false);
						break;
					case "WC":
						product.clearValidators();
						product.setValue("");
						version.setValue("");
						version.setValidators(Validators.required);
						if (this.formGroup.controls.runMode.value === RunMode.RateChange) {
							workCompAdoptBureauRates.setValue(true);
							workCompAdoptBureauRates.setValidators(Validators.required);
						} else {
							workCompAdoptBureauRates.clearValidators();
							workCompAdoptBureauRates.setValue(false);
						}
						break;
					case "UMB":
						product.clearValidators();
						product.setValue("");
						version.clearValidators();
						version.setValue("");
						workCompAdoptBureauRates.clearValidators();
						workCompAdoptBureauRates.setValue(false);
						break;
				}

				newDate.setValue("");
				renewalDate.setValue("");
				availableDate.setValue("");

				product.updateValueAndValidity();
				version.updateValueAndValidity();
				workCompAdoptBureauRates.updateValueAndValidity();
				newDate.updateValueAndValidity();
				renewalDate.updateValueAndValidity();
				availableDate.updateValueAndValidity();

				updateAdvancedInputs(this.formGroup);
				toggleSaveDataDump(this.formGroup);
			},
		);
	}

	ngOnDestroy(): void {
		this._subscription.unsubscribe();
	}
}
