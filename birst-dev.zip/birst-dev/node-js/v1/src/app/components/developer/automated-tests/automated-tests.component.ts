import { DateTime } from "luxon";
import { Observable } from "rxjs";
import { Store } from "@ngrx/store";
import { MatDialog } from "@angular/material/dialog";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { AppState } from "src/app/models/app-state";
import { IpcMessage } from "src/backend/ipc-handlers";
import { TestSuite, TestSuiteResults } from "src/backend/tests";
import { ElectronService } from "src/app/services/electron.service";
import * as fromAppStateAction from "src/app/store/app-state.actions";
import * as fromAppStateSelector from "src/app/store/app-state.selectors";
import { TestSuiteResultsComponent } from "./test-suite-results/test-suite-results.component";

@Component({
	selector: "app-automated-tests",
	templateUrl: "./automated-tests.component.html",
	styleUrls: ["./automated-tests.component.scss"],
})
export class AutomatedTestsComponent implements OnInit, OnDestroy {
	testSuites$: Observable<TestSuite[]>;
	selectedTestSuite: string;
	isTestSuiteRunning: boolean;

	constructor(
		private _store: Store<{ appState: AppState }>,
		private _electronService: ElectronService,
		private _dialog: MatDialog,
	) {}

	ngOnInit(): void {
		this.testSuites$ = this._store.select(fromAppStateSelector.selectTestSuites);
		this.isTestSuiteRunning = false;
		this.initIpcListeners();
	}

	ngOnDestroy(): void {}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.DoneRunningTestSuite, () => {
			this.isTestSuiteRunning = false;

			this._store.dispatch(
				fromAppStateAction.updateIsTestSuiteRunning({ isTestSuiteRunning: false }),
			);
		});

		this._electronService.on(IpcMessage.ShowTestSuiteResults, (payload) => {
			const testSuiteResults: TestSuiteResults = JSON.parse(payload);

			if (testSuiteResults.startedAt) {
				testSuiteResults.startedAt = DateTime.fromISO(testSuiteResults.startedAt).toFormat(
					"MM/dd/yy hh:mm a",
				);
			}

			if (testSuiteResults.endedAt) {
				testSuiteResults.endedAt = DateTime.fromISO(testSuiteResults.endedAt).toFormat(
					"MM/dd/yy hh:mm a",
				);
			}

			this._dialog.open(TestSuiteResultsComponent, {
				width: "100%",
				data: {
					testSuiteName: this.selectedTestSuite,
					header: [
						{
							startedAt: testSuiteResults.startedAt,
							endedAt: testSuiteResults.endedAt,
							totalRuntime: testSuiteResults.totalRuntime,
							totalPass: testSuiteResults.totalPass,
							totalFail: testSuiteResults.totalFail,
							totalSkipped: testSuiteResults.totalSkipped,
						},
					],
					body: testSuiteResults.testResults,
				},
			});
		});
	}

	runTestSuite(): void {
		this.isTestSuiteRunning = true;

		this._store.dispatch(
			fromAppStateAction.updateIsTestSuiteRunning({ isTestSuiteRunning: true }),
		);

		this._electronService.send(IpcMessage.RunTestSuite, this.selectedTestSuite);
	}
}
