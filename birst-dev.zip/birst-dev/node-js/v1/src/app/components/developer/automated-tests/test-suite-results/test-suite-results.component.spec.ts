import { ComponentFixture, TestBed } from "@angular/core/testing";

import { TestSuiteResultsComponent } from "./test-suite-results.component";

describe("TestSuiteResultsComponent", () => {
	let component: TestSuiteResultsComponent;
	let fixture: ComponentFixture<TestSuiteResultsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [TestSuiteResultsComponent],
		}).compileComponents();

		fixture = TestBed.createComponent(TestSuiteResultsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
