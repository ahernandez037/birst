import { Component, OnInit, OnDestroy } from "@angular/core";

@Component({
	selector: "app-developer",
	templateUrl: "./developer.component.html",
	styleUrls: ["./developer.component.scss"],
})
export class DeveloperComponent implements OnInit, OnDestroy {
	constructor() {}

	ngOnInit(): void {}

	ngOnDestroy(): void {}
}
