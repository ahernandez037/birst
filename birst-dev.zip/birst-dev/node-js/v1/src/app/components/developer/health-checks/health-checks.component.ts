import { Component, OnInit, OnDestroy } from "@angular/core";
import { IpcMessage } from "src/backend/ipc-handlers";
import { ElectronService } from "src/app/services/electron.service";
import { HealthCheckAction, HealthCheckProduct } from "src/backend/health-checks";

@Component({
	selector: "app-health-checks",
	templateUrl: "./health-checks.component.html",
	styleUrls: ["./health-checks.component.scss"],
})
export class HealthChecksComponent implements OnInit, OnDestroy {
	isHealthCheckRunning: boolean;
	products: HealthCheckProduct[];
	actions: HealthCheckAction[];
	selectedProduct: string;
	selectedAction: string;

	constructor(private _electronService: ElectronService) {}

	ngOnInit(): void {
		this.isHealthCheckRunning = false;

		this.products = [
			{
				code: "CMP-HAB",
				description: "CMP Habitational",
			},
			{
				code: "CMP-REA",
				description: "CMP Real Estate",
			},
			{
				code: "CMP-ROS",
				description: "CMP Retail Office Service",
			},
			{
				code: "CMP-RST",
				description: "CMP Restaurant",
			},
		];

		this.actions = [
			{
				code: "DUP-CHECK",
				description: "Check for Duplicates",
			},
		];

		this.initIpcListeners();
	}

	ngOnDestroy(): void {}

	initIpcListeners(): void {
		this._electronService.on(IpcMessage.DoneRunningHealthCheck, () => {
			this.isHealthCheckRunning = false;
		});
	}

	runHealthCheck(): void {
		this.isHealthCheckRunning = true;

		this._electronService.send(
			IpcMessage.RunHealthCheck,
			JSON.stringify({
				product: this.selectedProduct,
				action: this.selectedAction,
			}),
		);
	}
}
