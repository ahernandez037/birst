import { Component, OnInit, OnDestroy, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialog } from "@angular/material/dialog";
import { TestSuiteResultsDialogData } from "src/app/models/test-suite-results-dialog-data";

@Component({
	selector: "app-test-suite-results",
	templateUrl: "./test-suite-results.component.html",
	styleUrls: ["./test-suite-results.component.scss"],
})
export class TestSuiteResultsComponent implements OnInit, OnDestroy {
	summaryDisplayedColumns: string[] = [
		"startedAt",
		"endedAt",
		"totalRuntime",
		"totalPass",
		"totalFail",
		"totalSkipped",
	];

	detailDisplayedColumns: string[] = ["name", "runtime", "outcome", "error"];

	constructor(
		@Inject(MAT_DIALOG_DATA) public data: TestSuiteResultsDialogData,
		public dialog: MatDialog,
	) {}

	ngOnInit(): void {}

	ngOnDestroy(): void {}
}
