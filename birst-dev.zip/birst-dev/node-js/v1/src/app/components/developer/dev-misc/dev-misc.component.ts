import { Store } from "@ngrx/store";
import { Observable, Subscription } from "rxjs";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { EmailTrigger } from "src/backend/email";
import { AppState } from "src/app/models/app-state";
import { ScenarioForm } from "src/backend/scenario";
import { IpcMessage } from "src/backend/ipc-handlers";
import { ConsoleMessage } from "src/app/models/console-message";
import { ElectronService } from "src/app/services/electron.service";
import * as fromAppStateAction from "src/app/store/app-state.actions";
import * as fromAppStateSelector from "src/app/store/app-state.selectors";

@Component({
	selector: "app-dev-misc",
	templateUrl: "./dev-misc.component.html",
	styleUrls: ["./dev-misc.component.scss"],
})
export class DevMiscComponent implements OnInit, OnDestroy {
	scenarioForm$: Observable<ScenarioForm>;
	scenarioForm: ScenarioForm;
	emailTriggers: EmailTrigger[];
	selectedEmailTrigger: EmailTrigger;
	private _scenarioFormSubscription: Subscription;

	constructor(
		private _store: Store<{ appState: AppState }>,
		private _electronService: ElectronService,
	) {}

	ngOnInit(): void {
		this.emailTriggers = [
			EmailTrigger.RateRevisionInitiated,
			EmailTrigger.RateRevisionCanceled,
			EmailTrigger.RateRevisionCanceledSavedRates,
			EmailTrigger.RequestToDeleteRates,
			EmailTrigger.RatesDeleted,
			EmailTrigger.FeedbackSubmitted,
			EmailTrigger.ProblemReported,
			EmailTrigger.ForcedAppQuit,
		];

		this.scenarioForm$ = this._store.select(fromAppStateSelector.selectScenarioForm);
		this.scenarioForm = {} as ScenarioForm;

		this._scenarioFormSubscription = this.scenarioForm$.subscribe((scenarioForm) => {
			this.scenarioForm = scenarioForm;
		});
	}

	ngOnDestroy(): void {
		this._scenarioFormSubscription.unsubscribe();
	}

	createEmail(): void {
		this._electronService.send(
			IpcMessage.DevTestCreateEmail,
			this.selectedEmailTrigger,
			JSON.stringify(this.scenarioForm),
		);
	}

	printToConsole(): void {
		for (let i = 0; i < 10; i++) {
			this._store.dispatch(
				fromAppStateAction.addConsoleMessage({
					consoleMessages: [new ConsoleMessage({ text: `Test Message ${i}` })],
				}),
			);
		}
	}

	saveRateHistory(): void {
		this._electronService.send(IpcMessage.DevTestSaveRateHistory);
	}

	createFitExhibits(): void {
		this._electronService.send(IpcMessage.DevTestCreateFitExhibits);
	}

	saveRates(): void {
		this._electronService.send(IpcMessage.DevTestSaveRates);
	}

	uploadWorkCompLossCosts(): void {
		this._electronService.send(IpcMessage.UploadWorkCompLossCosts);
	}
}
