import { Pipe, PipeTransform } from "@angular/core";
import { Product } from "src/backend/products";
import { getUniqueValues } from "./shared/get-unique-values";

@Pipe({
	name: "version",
})
export class VersionPipe implements PipeTransform {
	transform(
		value: Product[] | null,
		runMode: string | null | undefined,
		geoState: string | null | undefined,
		lineOfBusiness: string | null | undefined,
		productCode: string | null | undefined,
	): Pick<Product, "versionCode" | "versionDescription">[] {
		if (!value || value?.length === 0) {
			return [];
		}

		const output = getUniqueValues(
			value
				.filter(
					(product) =>
						product.isAvailable &&
						(product.stateCode === geoState || geoState === "ALL") &&
						product.lineOfBusinessCode === lineOfBusiness &&
						(product.productCode === productCode || productCode === "") &&
						product.versionCode !== "N/A",
				)
				.map(({ versionCode, versionDescription }) => ({
					versionCode,
					versionDescription,
				})),
		);

		if (runMode !== "RATE-CHANGE") {
			return [
				{
					versionCode: "ALL",
					versionDescription: "All Versions",
				},
				...output.sort((a, b) => a.versionCode.localeCompare(b.versionCode)),
			];
		} else {
			return output;
		}
	}
}
