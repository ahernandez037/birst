import { GeoStatesPipe } from "./geo-states.pipe";

describe("GeoStatesPipe", () => {
	it("create an instance", () => {
		const pipe = new GeoStatesPipe();
		expect(pipe).toBeTruthy();
	});
});
