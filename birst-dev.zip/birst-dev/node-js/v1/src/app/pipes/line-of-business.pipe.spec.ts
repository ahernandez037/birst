import { LineOfBusinessPipe } from "./line-of-business.pipe";

describe("LineOfBusinessPipe", () => {
	it("create an instance", () => {
		const pipe = new LineOfBusinessPipe();
		expect(pipe).toBeTruthy();
	});
});
