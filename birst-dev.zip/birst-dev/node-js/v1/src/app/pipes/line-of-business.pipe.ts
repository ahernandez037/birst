import { Pipe, PipeTransform } from "@angular/core";
import { Product } from "../../backend/products";
import { getUniqueValues } from "./shared/get-unique-values";

@Pipe({
	name: "lineOfBusiness",
})
export class LineOfBusinessPipe implements PipeTransform {
	transform(
		value: Product[] | null,
		geoState: string | null | undefined,
	): Pick<Product, "lineOfBusinessCode" | "lineOfBusinessDescription">[] {
		if (!value || value?.length === 0) {
			return [];
		}

		return getUniqueValues(
			value
				.filter(
					(product) =>
						product.isAvailable &&
						(product.stateCode === geoState || geoState === "ALL"),
				)
				.map(({ lineOfBusinessCode, lineOfBusinessDescription }) => ({
					lineOfBusinessCode,
					lineOfBusinessDescription,
				})),
		);
	}
}
