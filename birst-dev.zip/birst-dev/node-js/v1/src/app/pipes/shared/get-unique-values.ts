/* Must stringify objects before adding them to the set and then parse them back
into objects. Otherwise, will cause them to be treated as unique objects, i.e,
duplicates will not be eliminated. */

export const getUniqueValues = <T>(values: T[]): T[] => {
	const uniqueValues = new Set<string>();

	for (const value of values) {
		uniqueValues.add(JSON.stringify(value));
	}

	return [...uniqueValues].map((value) => JSON.parse(value));
};
